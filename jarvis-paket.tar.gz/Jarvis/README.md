# Jarvis

Persoenlicher KI-Assistent mit Sprachsteuerung, nach der Architektur:

- **Frontend** (`frontend/`): Browser-UI mit Sprache-zu-Text (Web Speech API), animiertes Jarvis-Gehirn als Sternenhimmel (`frontend/brain.js`, reagiert aufs Mikrofon, einstellbar mit `JarvisBrain.configure`). Startbar per Klick auf den Mikrofon-Button, per Doppelklatschen oder mit „Hey Jarvis“. Danach Gesprächsmodus, bis man „danke“ sagt oder schweigt. „Jarvis, stopp“ unterbricht ihn mitten in der Antwort und er hört sofort zu.
- **Backend** (`backend/`): FastAPI-Server mit Systemprompt und Aktions-System (Tools), plus WebSocket zum Aufwecken der UI.
- **Externe Services**: Claude (Anthropic API) als Gehirn, ElevenLabs fuer Sprachausgabe (optional, sonst faellt der Browser auf seine eigene Stimme zurueck).
- **Lokale Tools**: App-Start (`open -a`), Browser-Steuerung (Playwright), Bildschirm sehen (Screenshot + Claude Vision), Doppelklatsch-Erkennung (`sounddevice`).

## Setup

Ordner nach `~/Jarvis` legen (nicht auf den Schreibtisch, der liegt in iCloud Drive), dann im Terminal:

```bash
cd ~/Jarvis
bash install.sh
```

Das Skript legt ein frisches `venv` an, installiert alles und übernimmt deine `.env` aus dem alten Ordner. Einstellungen (Modell, schnelles Modell `JARVIS_FAST_MODEL` für einfache Fragen, Stadt, Start-Apps) stehen in `.env`, siehe `.env.example`.

## Starten

Doppelklick auf **Jarvis.command**. Das startet den Server und hört auf Doppelklatschen.
Hängt Jarvis, beendet **Jarvis neu starten.command** den alten und startet ihn frisch.

- **Zweimal klatschen, Jarvis ist noch nicht offen:** Spotify, VS Code, Obsidian und Chrome mit Jarvis starten, Jarvis begrüßt dich mit dem Wetter.
- **Zweimal klatschen, Jarvis ist offen:** Jarvis hört zu (wie ein Klick auf den Mikrofon-Button).

Automatisch beim Anmelden: Systemeinstellungen → Allgemein → Anmeldeobjekte → `Jarvis.command` hinzufügen.

Manuell geht weiterhin: `venv/bin/uvicorn backend.main:app --host 0.0.0.0 --port 8000` und `http://localhost:8000` in Chrome öffnen.

Handy oder Tablet als Anzeige: im Jarvis-Fenster bei „Mac“ auf „Anzeige“ klicken und den QR-Code scannen (selbes WLAN). Die Anzeige kann nur zusehen, nichts steuern.

Selbst ausbauen: „Bau dir eine Funktion, die …“. Jarvis lässt Claude Code die Funktion im Ordner `eigene/` bauen und kann sie sofort; Updates fassen `eigene/` nie an. Regeln für Claude Code stehen in `CLAUDE.md`, prüfen mit `venv/bin/python -m backend.eigene`.

Internet-Suche: „Such mir ein Fitnessstudio“, „Welche Pizzeria hat jetzt noch offen?“ Jarvis sucht, liest die Seiten und sagt das Ergebnis; die Quellen stehen als Links im Fenster.

Haushaltsbuch: „Hey Jarvis, bau mir ein Haushaltsbuch“ oder auf die Kachel „Haushalt“ neben dem Gehirn klicken. Die Daten liegen in `haushaltsbuch.json` im Jarvis-Ordner, nur auf dem Mac.

## Tools, die Jarvis nutzen kann

- `open_app` — startet Programme, auch mit deutschen oder ungefähren Namen (Rechner, Aktivitätsanzeige, Visual Studio)
- `open_website` — öffnet eine Seite im normalen Browser (nur http/https; ein Begriff ohne Adresse öffnet die Google-Suche)
- `browser_navigate` / `browser_click` / `browser_type` / `browser_read` — steuert ein eigenes, sichtbares Playwright-Browserfenster (getrennt vom Chrome-Tab, in dem die UI laeuft)
- `get_weather` — aktuelles Wetter und Vorhersage (Open-Meteo, kostenlos)
- `web_search` / `web_fetch` — Internet-Suche und Seiten lesen; laufen direkt bei Anthropic (ca. 1 Cent pro Suche), Jarvis liest das Ergebnis vor und zeigt die Quellen als Links
- `see_screen` — macht einen Screenshot des Bildschirms und beschreibt ihn per Claude Vision
- `haushalt_buchen` / `haushalt_fest` / `haushalt_aendern` / `haushalt_uebersicht` / `haushalt_einstellen` — Haushaltsbuch: Ausgaben, feste Posten, Spartöpfe, Budgets, Monatsüberblick
- `find_folder` / `list_folder` / `read_file` — Ordner finden und Dateien lesen (PDF, Bilder, Office, Text); reingezogene Dateien landen in `eingang/`
- `open_in_claude` — öffnet ein Projekt im Terminal mit `--remote-control`, damit es in der Claude-App sichtbar ist
- `get_daily_overview` — Tagesüberblick: Wetter, Termine, ungelesene Mails, Nachrichten
- `get_mails` / `read_mail` / `open_mail` — ungelesene Mails aus der Mail-App (AppleScript), ganze Mail lesen, Mail in der Mail-App öffnen
- `get_messages` — iMessage/SMS aus `~/Library/Messages/chat.db` (braucht Festplattenvollzugriff fürs Terminal), Namen aus den Kontakten
- `get_calendar` — Termine aus der Kalender-App (EventKit)
- `add_calendar_event` / `change_calendar_event` — Termine eintragen, verschieben, ändern, löschen (EventKit, `backend/planer.py`)
- `get_reminder_list` / `add_reminder` / `complete_reminder` / `change_reminder` — Listen der Erinnerungen-App lesen und bearbeiten (Einkaufsliste: mehrere Einträge auf einmal, umbenennen, verschieben, löschen, ganze Liste abhaken, neue Liste nach Rückfrage)
- `open_contact` / `call_contact` — Kontakt zeigen (`addressbook://`), anrufen über das iPhone (`tel://`, der Mac fragt vorher nach); Kontakte aus der Kontakte-Datenbank, sonst per AppleScript
- `get_system_status` / `get_week_load` / `set_mail_priority` — Mac-Auslastung (psutil, GPU über ioreg), Wochenauslastung, eigene Mail-Regeln (`mail-prioritaeten.json`)
- Selbst gebaute Tools aus `eigene/*.py` (Schnittstelle in `backend/eigene.py` und `CLAUDE.md`), dazu `eigene/*.js` und `eigene/*.css` fürs Fenster
- `ask_claude_code` / `list_projects` / `create_project` — gibt Projektaufgaben an Claude Code (`claude -p`) im Ordner `~/Projekte/<Name>` weiter (oder an den Jarvis-Ordner selbst) und liest das Ergebnis vor, wenn es fertig ist. Ordner änderbar über `JARVIS_PROJECTS_DIR` in `.env`

Diese laufen lokal mit deinen Rechten — Jarvis entscheidet selbst, wann er sie einsetzt, basierend auf dem Systemprompt in `backend/config.py`.

## Dashboard

Links: Mac-Auslastung live (CPU, RAM, GPU, Festplatte, Akku, Netz, größte Verbraucher), Woche (Kalender, Mo–Fr 8–20 Uhr verplant), Dateien. Rechts: wichtige Mails (Kurzfassung vom schnellen Modell, einmal pro Mail, gemerkt in `mail-einordnung.json`), Termine der nächsten 5 Tage und fällige Erinnerungen, Arbeitsfenster. API: `/api/system`, `/api/dashboard`, `/api/priorities`.

## Nur ein Jarvis

Jeder Jarvis-Tab meldet sich mit einer Kennung (`#jt…` in der Adresse) beim Server. Aktiv ist nur der zuletzt geöffnete: Nur er bekommt „zuhören“ und darf sprechen. Weitere Tabs werden stumm und, wenn macOS es erlaubt, per AppleScript geschlossen (`backend/fenster.py`). Beim Start holt Jarvis einen vorhandenen Tab nach vorne statt einen neuen zu öffnen. Sprachausgaben laufen nacheinander (`_speech_lock`). `clap_daemon` läuft nur einmal (Sperre `.jarvis-laeuft.lock`).

Der Server liefert `index.html` und `anzeige.html` mit `?v=<VERSION>` an Skripten und Styles aus, alle Fenster-Dateien mit `Cache-Control: no-cache`. So läuft nach einem Update nie der alte Stand aus dem Chrome-Zwischenspeicher weiter. Tabs melden ihre Version im `hello`; passt sie nicht, laden sie einmal neu. Tabs ohne `hello` (vor Update 19) werden höchstens viermal je Start zum Neuladen aufgefordert.

## Doppelklatschen

`backend/clap_daemon.py` hört über das Mikrofon mit und ruft bei zwei kurz aufeinanderfolgenden Klatschern `POST /api/clap` auf. Läuft der Server noch nicht, startet der Daemon ihn selbst. Braucht macOS-Mikrofonrechte für das Terminal (Systemeinstellungen → Datenschutz & Sicherheit → Mikrofon). Löst es zu oft oder zu selten aus: `THRESHOLD` in `backend/clap_daemon.py` anpassen (höher = unempfindlicher).

## Naechste Schritte (noch nicht gebaut)

- Mehrfach-Sprecher-Unterkennung, Konversationsverlauf dauerhaft speichern statt nur In-Memory pro Tab.
