# Was sich geändert hat (2. Oktober 2026)

## Fehler behoben
- **Browser-Steuerung brach ab dem zweiten Befehl ab.** Playwright darf nur aus einem Thread benutzt werden, FastAPI ruft aber aus wechselnden Threads auf („Cannot switch to a different thread“). Alle Browser-Befehle laufen jetzt in einem festen Thread.
- **Längere Gespräche konnten abstürzen.** `messages[-20:]` schnitt mitten in einen Tool-Aufruf; die API lehnt so einen Verlauf ab. Der Verlauf beginnt jetzt immer bei einer normalen Frage.
- **Leere Antworten möglich.** Sonnet denkt automatisch mit, und 1024 Tokens reichten dafür teils nicht. Jetzt 4096 Tokens und Denktiefe `low` (schneller, passt zu Sprache).
- **Verlauf im Browser bereinigt.** Denkblöcke werden nicht mehr zurückgeschickt; die API würde sie bei neueren Modellen nach jeder Kürzung ablehnen.

## Verbessert
- Modell: `claude-sonnet-5-5` statt `claude-sonnet-5` (gleicher Preis, neuer).
- Bildschirm sehen: Screenshot wird vorher verkleinert, dadurch schneller.
- Jarvis kennt Datum und Uhrzeit.

## Neu (wie im Video)
- **Doppelklatschen startet alles:** Server, Spotify, VS Code, Obsidian, Chrome mit Jarvis, dazu eine gesprochene Begrüßung mit dem Wetter.
- **Wetter-Tool** über Open-Meteo (kostenlos, kein Schlüssel).
- **install.sh** und **Jarvis.command** zum Einrichten und Starten.

Ungetestet, weil nur auf einem Mac möglich: Klatschen, Sprachausgabe, App-Start, Bildschirmfoto.

## Update (2. Oktober, Vormittag)
- **Jarvis hörte sich selbst und redete ununterbrochen.** Seine eigene Stimme oder Musik wurde als Klatschen erkannt. Jetzt zählt nur ein kurzer Knall aus der Stille, und solange Jarvis spricht, denkt oder zuhört, wird Klatschen ignoriert.
- **Wetter für Aschaffenburg** statt Berlin (änderbar über `JARVIS_CITY` in `.env`).
- **Neue Stimme:** männliche deutsche Stimme wie im Video (ElevenLabs). Ohne ElevenLabs spricht jetzt die Mac-Stimme „Markus“ statt der Browser-Stimme.
- Das Terminal-Fenster zeigt beim Klatschen die Lautstärke an, damit man die Empfindlichkeit einstellen kann.

## Update (2. Oktober, Mittag)
- **Klare Fehlermeldungen:** Statt „Fehler: HTTP 500“ sagt Jarvis jetzt, was los ist (Schlüssel fehlt, Guthaben leer, kein Internet, Modell unbekannt).
- **„Schlüssel eintragen.command“:** Schlüssel bei Anthropic oder ElevenLabs kopieren, Datei doppelklicken, fertig. Jarvis startet danach neu.
- Wenn ein Modell die Denktiefe-Einstellung nicht kennt, fragt Jarvis automatisch ohne sie.
- Server-Meldungen landen sofort in `jarvis-server.log`.
- „Nichts gehört“ statt „Fehler beim Zuhören“, wenn nach dem Klatschen niemand spricht.

## Update (2. Oktober, Nachmittag)
- **Sprachstart „Hey Jarvis“:** Zusätzlich zum Klatschen startet Jarvis, wenn du „Hey Jarvis“ sagst (englisch ausgesprochen, „Hey Dschar-wis“). Läuft lokal auf dem Mac, ohne Internet und ohne Schlüssel (openWakeWord).
- **Rückmeldung beim Zuhören:** Ist Jarvis schon offen, holt Klatschen oder „Hey Jarvis“ Chrome nach vorne, und ein kurzer Ton zeigt, dass er zuhört.

## Update 3 (2. Oktober, Nachmittag)
- **Jarvis spricht über die Mac-Lautsprecher** statt über Chrome. Chrome blockiert manchmal Ton in Tabs, in die nie geklickt wurde; dann blieb Jarvis hängen.
- **Sicherheitsnetz:** Hängt Jarvis länger als 90 Sekunden in einem Zustand, ist er danach wieder bereit.
- **Updates ohne Terminal:** Update-Zip herunterladen, dann wie immer `Jarvis.command` doppelklicken. Jarvis spielt das Update selbst ein und startet neu. Ältere Update-Pakete werden ignoriert.
- **Gesprächsmodus:** Nach „Hey Jarvis“, Klatschen oder einem Klick auf das Mikrofon hört Jarvis nach jeder Antwort von selbst weiter zu (kurzer Ton als Zeichen). „Danke“, „das war's“, „tschüss“ oder Schweigen beenden das Gespräch.
- **Claude Code per Sprache:** „Frag Claude Code im Projekt Jarvis, …“ gibt die Aufgabe an Claude Code auf dem Mac weiter. Es arbeitet im Hintergrund im Projektordner, und wenn es fertig ist, liest Jarvis das Ergebnis vor. Folgefragen landen im selben Gespräch („neues Gespräch“ startet frisch). Projekte sind Ordner in `~/Projekte`; „leg ein neues Projekt … an“ erstellt einen. Claude Code nutzt dein Claude-Abo, nicht das API-Guthaben. Voraussetzung: Claude Code ist installiert und angemeldet.
- **Jarvis-Gehirn statt blauem Punkt:** Ein rotierendes, leuchtendes Neuronen-Netz mit HUD-Ringen. Beim Zuhören reagiert es auf deine Stimme, beim Nachdenken scannt es lila, beim Sprechen pulsiert es türkis.

## Update 4 (2. Oktober, Nachmittag)
- **Datei-Fenster:** Dateien oder ganze Ordner einfach ins Jarvis-Fenster ziehen (oder „Dateien auswählen“). Jarvis schaut sie sich an und sagt kurz, was drin ist; danach kannst du direkt nachfragen. Er liest PDF, Bilder (auch iPhone-Fotos), Text, HTML, Code, Word, Excel, PowerPoint und die Vorschau von Pages/Numbers/Keynote. Kopien liegen in `eingang/`.
- **Ordner per Sprache:** „Schau in den Ordner Rechnungen auf dem Schreibtisch“ findet den Ordner und fasst zusammen, was drin ist. Schlüssel und Passwörter (`.env`, `.ssh`) liest er nie.
- **Arbeitsfenster:** Rechts siehst du live, was Claude Code gerade an einem Projekt macht (liest, ändert, sucht ...), und wann es fertig ist.
- **In Claude öffnen:** Knopf im Arbeitsfenster oder „Zeig mir das Projekt in Claude“. Öffnet das Projekt mit dem bisherigen Gespräch im Terminal und per Remote Control in der Claude-App (Mac und iPhone, Bereich Code), wo du mitlesen und weiterschreiben kannst.
- Claude Code kann jetzt auch in beliebigen Ordnern arbeiten („Arbeite im Ordner Downloads/Website weiter“).


## Update 5 (2. Oktober, Abend)
- **Tagesüberblick:** „Was steht heute an?“ oder „Gib mir einen Überblick“: Jarvis sagt Wetter, Termine und das Wichtigste aus Mails und Nachrichten. Auch die Begrüßung nach dem Klatschen ist jetzt so ein kurzer Überblick.
- **Mails:** „Hab ich neue Mails?“ liest die ungelesenen Mails aus der Mail-App (alle Konten) und nennt die wichtigsten zuerst: echte Menschen und Fristen vor Rechnungen und Lieferungen, Newsletter und Werbung nur als Anzahl. „Was schreibt Tim genau?“ liest die ganze Mail, „Zeig mir die Mail“ öffnet sie in der Mail-App.
- **Nachrichten:** „Wer hat mir geschrieben?“ liest iMessage und SMS (auch was aufs iPhone kam), mit Namen aus deinen Kontakten, und sagt, wer noch auf Antwort wartet.
- **Kalender:** „Was hab ich morgen?“ oder „diese Woche“ liest alle Kalender (iCloud, Google usw.).
- Alles wird nur gelesen, nichts gesendet oder gelöscht. Codes und Passwörter liest Jarvis nie laut vor.
- macOS fragt beim ersten Mal nach Erlaubnis (Mail, Kalender). Für Nachrichten braucht das Terminal einmalig „Festplattenvollzugriff“; Jarvis öffnet die Einstellung dafür selbst.

## Update 6 (2. Oktober, Abend)
- **Schnellere Antworten:** Einfache Fragen (Wetter, Uhrzeit, Apps öffnen, Smalltalk) beantwortet jetzt Claude Haiku, das deutlich schneller ist. Alles, was Nachdenken braucht (Projekte, Dateien, Ordner, Erklärungen, Mails und Nachrichten sortieren), bleibt bei Sonnet. Holt Haiku Mails, Dateien oder den Tagesüberblick, übernimmt Sonnet die Zusammenfassung.
- Abschalten oder anderes Modell: `JARVIS_FAST_MODEL` in `.env` (leer = immer Sonnet). Gibt es das schnelle Modell nicht, nimmt Jarvis automatisch Sonnet.


## Update 7 (2. Oktober, Abend)
- **Dashboard im Jarvis-Fenster.** Links: deine **Mac-Auslastung live** (Prozessor, Arbeitsspeicher, Grafik in Prozent, Verlauf der letzten 2 Minuten, Festplatte, Akku, Netz und welche Programme gerade am meisten Leistung brauchen) und deine **Woche** (wie viel Prozent Mo–Fr zwischen 8 und 20 Uhr verplant sind, mit Balken pro Tag). Rechts: **wichtige Mails** ohne Werbung, jede mit einer Kurzfassung, und deine **Termine** der nächsten Tage samt fälliger Erinnerungen. Klick auf eine Mail öffnet sie in der Mail-App.
- **Prioritäten:** Über den Knopf „Prioritäten“ legst du fest, welche Absender immer wichtig sind, welche Stichwörter Mails wichtig machen und was ausgeblendet wird. Geht auch per Sprache: „Mails von Tim sind immer wichtig“, „Zeig mir nichts mehr von Zalando“.
- Jarvis kann es auch sagen: „Wie ausgelastet ist mein Mac?“, „Wie voll ist meine Woche?“
- Beim ersten Öffnen fragt macOS evtl. nach **Erinnerungen**: Erlauben. Fehlt eine Erlaubnis, zeigt das Dashboard einen Knopf „Einstellung öffnen“.

## Update 8 (2. Oktober, Abend)
- **Unterbrechen:** Während Jarvis spricht, sagst du „Jarvis, stopp“ (oder nur „stopp“). Er hört sofort auf und das Mikrofon geht gleich an, du kannst direkt die nächste Frage stellen. „Hey Jarvis“ unterbricht ihn genauso, ein Klick auf den Mikrofon-Knopf auch.
- Seine eigene Stimme landet auch im Mikrofon. Wörter, die in seiner Antwort selbst vorkommen, lösen deshalb nichts aus.
- Ein nachgeschobenes „stopp“ beendet das Gespräch nicht; „danke“ weiterhin schon.

## Update 9 (2. Oktober, Abend)
- **Handy als Anzeige:** Ein altes Handy oder Tablet zeigt Uhr, das Jarvis-Gehirn, Mac-Auslastung, Woche, nächste Termine und wichtige Mails. Es zeigt live, ob Jarvis zuhört, nachdenkt oder spricht, und blendet Frage und Antwort als Untertitel ein. Gesprochen wird weiter mit dem Mac.
- Verbinden: Im Jarvis-Fenster oben links bei „Mac“ auf **Anzeige** klicken und den QR-Code mit der Kamera des Handys scannen. Handy und Mac müssen im selben WLAN sein. Auf der Anzeige einmal tippen: Vollbild.
- **Sicherheit:** Jarvis ist dafür im WLAN erreichbar. Andere Geräte dürfen aber nur die Anzeige sehen, und nur mit dem Schlüssel aus dem QR-Code. Chat, Apps öffnen, Mails öffnen, Dateien und Claude Code gehen weiterhin nur am Mac. Wer die Anzeige ganz abschalten will: `JARVIS_HOST=127.0.0.1` in `.env`.
- Fragt der Mac beim ersten Start, ob „Python“ eingehende Verbindungen annehmen darf: **Erlauben**.

## Update 10 (2. Oktober, Abend)
- **„Hey Jarvis“ startet sofort:** Ist Jarvis noch nicht offen, begrüßt er dich jetzt nur kurz („Guten Abend, Lukas. Was kann ich für dich tun?“) und hört gleich danach zu. Kein Wetter, keine Mails, keine Apps. Die Begrüßung ist vorab gespeichert und kommt ohne Wartezeit. Den Überblick bekommst du weiter mit „Was steht heute an?“. Doppelklatschen startet wie bisher alles wie im Video.
- **Fahrzeit mit Verkehr:** „Wie lange brauche ich zum Frankfurter Flughafen?“ oder „Wie lange von Würzburg nach Frankfurt mit der Bahn?“ Jarvis fragt Apple Karten (ohne Konto) und sagt Fahrzeit, Ankunft und Strecke. Klappt die Abfrage nicht, öffnet er die Route in der Karten-App.
- **Zuhause merken:** „Ich wohne in der Hauptstraße 5 in Aschaffenburg.“ Ohne Startpunkt rechnet Jarvis ab dort, sonst ab Aschaffenburg.
- Beim Einspielen wird einmal ein kleines Karten-Programm gebaut (dauert etwas).

## Update 11 (2. Oktober, Abend)
- **Aufs iPhone schicken:** „Schick mir die Route aufs Handy“, „Schick mir die Einkaufsliste aufs Handy“. Jarvis schickt eine Mitteilung aufs iPhone. Bei Routen startet ein Tipp darauf die Navigation in Apple Karten, bei Links öffnet sich der Link.
- Einmal einrichten: Im Jarvis-Fenster bei „Mac“ auf **iPhone** klicken. Auf dem iPhone die kostenlose App **ntfy** laden, das angezeigte Thema eintragen, dann „Test senden“.
- Gut zu wissen: Die Mitteilungen laufen über den Dienst ntfy.sh. Das Thema ist ein zufälliger Name, den nur dein Mac kennt; wer ihn kennt, könnte mitlesen. Gib ihn also nicht weiter.

## Update 12 (2. Oktober, Abend)
- **Haushaltsbuch:** Sag „Hey Jarvis, bau mir ein Haushaltsbuch“. Es geht groß im Jarvis-Fenster auf, und Jarvis fragt dich der Reihe nach: Gehalt, Miete, Auto, Finanzierung, Kredit, Sparen, Urlaubskonto und weitere feste Kosten. Jede Antwort steht sofort drin.
- **Eintragen per Sprache:** „Ich war für 42 Euro bei Rewe“, „Gestern 60 Euro getankt“, „Leg 100 Euro im Monat aufs Urlaubskonto“, „Die Miete ist ab November 950 Euro“, „Der letzte Einkauf war 32, nicht 42“. Fragen gehen auch: „Wie viel habe ich diesen Monat noch?“, „Was habe ich für Lebensmittel ausgegeben?“, „Was wird noch abgebucht?“
- **Belege:** Kassenzettel, Rechnungen, Kontoauszüge oder Screenshots links ins Dateifenster ziehen. Jarvis liest sie und trägt jede Zahlung in die passende Kategorie ein. Doppelte erkennt er, und Gehalt oder Miete aus dem Kontoauszug zählt er nicht doppelt.
- **Kleine Kachel neben dem Gehirn:** was diesen Monat übrig ist, pro Tag bis Monatsende und was schon ausgegeben ist. Klick darauf öffnet das Haushaltsbuch, „Mach das Haushaltsbuch zu“ schließt es.
- **Im großen Fenster:** feste Posten, Ausgaben des Monats, wohin das Geld geht, Spartöpfe mit Ziel, was noch abgebucht wird, Monate vor- und zurückblättern. Beträge per Klick ändern, mit × löschen, Monatsbudget per Klick auf eine Kategorie. Mit + vor dem Betrag wird es eine Einnahme.
- Die Daten liegen nur auf deinem Mac in `haushaltsbuch.json` im Jarvis-Ordner (dazu eine Sicherungskopie). Die Anzeige im WLAN bekommt das Haushaltsbuch nicht zu sehen.

## Update 13 (2. Oktober, Abend)
- **Zurück zur Hauptansicht:** Beendest du ein Gespräch mit „Danke“ (oder „Tschüss“, „Das war's“), schließt Jarvis nach seiner Antwort das Haushaltsbuch und offene Info-Fenster. Du siehst wieder das Gehirn mit allen Kacheln.

## Update 14 (3. Oktober, Morgen)
- **Jarvis sucht im Internet und liest dir das Ergebnis vor:** „Such mir ein Fitnessstudio“, „Welche Pizzeria hat jetzt noch offen?“, „Was kostet ein iPhone 17 Pro gerade?“, „Wie hat die Eintracht gespielt?“ Jarvis sucht selbst, liest bei Bedarf die passenden Seiten und sagt dir die zwei, drei besten Treffer mit dem Wichtigsten (Ort, Öffnungszeiten, Preis, Bewertung). Ohne Ort sucht er rund um Aschaffenburg.
- Sagst du nur „Such mir was im Internet“, fragt er: „Was soll ich für dich suchen?“
- Während er sucht, steht im Fenster, wonach („Suche im Internet: Fitnessstudio Aschaffenburg“). Die Seiten, die er benutzt hat, stehen als Links unter seiner Antwort. „Schick mir den Link aufs Handy“ geht auch.
- Den Browser öffnet er nur noch, wenn du eine Seite selbst sehen oder bedienen willst.
- **Kosten:** Die Suche läuft über dein Anthropic-Guthaben, rund 1 Cent pro Suche plus die normale Antwort. Kein neues Konto, kein neuer Schlüssel.

## Update 15 (3. Oktober, Morgen)
- **Jarvis baut sich selbst aus:** Sag ihm einfach, was er Neues können soll, z. B. „Bau dir eine Funktion, die mir jeden Morgen den Spritpreis sagt“ oder „Ich möchte, dass du würfeln kannst“. Jarvis gibt den Wunsch an Claude Code auf deinem Mac, das baut die Funktion, prüft sie, und Jarvis kann sie sofort. Kein Update, kein Neustart. Braucht die Funktion etwas im Fenster, lädt es sich kurz neu.
- **Bleibt erhalten:** Alles Selbstgebaute liegt im Ordner `eigene` im Jarvis-Ordner. Meine Updates fassen diesen Ordner nie an.
- **Sicher:** Claude Code darf dabei nur in `eigene` bauen. Den Kern von Jarvis und deine Schlüssel in `.env` kann es nicht ändern oder lesen. Geht ein Wunsch nur mit einem Umbau am Kern, sagt Jarvis dir das, und du sagst es mir hier.
- **Rückgängig:** „Mach den letzten Umbau rückgängig“ oder „Lösch die Würfel-Funktion wieder“. Vor jedem Umbau wird gesichert.
- Ist eine selbst gebaute Funktion kaputt, sagt Jarvis das gleich nach dem Umbau. Die anderen Funktionen laufen trotzdem weiter.
- Voraussetzung: Claude Code ist auf dem Mac installiert und angemeldet (wie für „Frag Claude Code im Projekt …“). Es nutzt dein Claude-Abo, nicht das Anthropic-Guthaben.

## Update 16 (3. Oktober, Morgen)
- **Neues Gehirn als Sternenhimmel:** Das Gehirn in der Mitte besteht jetzt aus deutlich mehr bunten Lichtpunkten (Eisblau, Violett, Magenta, Türkis, Gold, Rosa). Innen funkelt Sternenstaub wie in einer kleinen Galaxie, rundherum dreht sich ein Sternenhimmel, ein Ring aus Lichtteilchen kreist um das Gehirn und ab und zu fliegt eine Sternschnuppe vorbei. Zuhören, Nachdenken und Sprechen erkennst du weiter an der Farbe der Ringe.
- **Selbst einstellbar:** „Mach dein Gehirn röter“ oder „Nimm mehr Sterne“ kann Jarvis jetzt über Claude Code selbst umsetzen (Farben, Anzahl der Punkte und Sterne, Tempo). Eine ganz neue Form kommt weiter als Update von mir.
- Ruckelt es auf einem Gerät, nimmt das Gehirn von selbst weniger Punkte. Auf der Handy-Anzeige läuft eine leichtere Fassung.
- **Behoben:** Meldete sich Claude Code genau in dem Moment, in dem Jarvis im Gespräch wieder zuhören wollte, hörte er danach nicht mehr zu. Jetzt hört er nach der Meldung weiter zu.

## Update 17 (3. Oktober, Morgen)
- **Dashboard hängt nicht mehr bei „wird geladen …“:** Mails, Termine und Erinnerungen laden jetzt getrennt im Hintergrund. Was fertig ist, siehst du sofort, auch wenn Mail noch braucht.
- **Mails kommen schneller:** Zuerst Absender und Betreff, die Kurzfassungen folgen nach und nach.
- **Klare Hinweise statt Warten:** Antwortet Mail oder Kalender nicht, steht oben, woran es liegt. Oft wartet ein Erlaubnis-Fenster von macOS versteckt hinter anderen Fenstern, dort „Erlauben“ klicken. Fehlt eine Erlaubnis, öffnet der Knopf „Einstellung öffnen“ die richtige Stelle.
- Im Terminal-Fenster steht jetzt, wie lange Mail, Kalender und Erinnerungen gebraucht haben.

## Update 18 (3. Oktober, Morgen)
- **Termine eintragen, verschieben, löschen:** „Trag mir nächsten Dienstag um 14 Uhr Zahnarzt ein“, „Verschieb den Zahnarzt um eine Stunde“, „Leg das Meeting auf Donnerstag“, „Lösch den Friseurtermin“. Jarvis bestätigt mit Wochentag, Datum und Uhrzeit. Ohne Uhrzeit wird der Termin ganztägig, „Urlaub vom 13. bis 17.“ geht auch. Die Termine landen in der Kalender-App und per iCloud auf dem iPhone. Gelöscht wird nur, wenn du es ausdrücklich sagst; passen mehrere Termine, fragt er nach.
- **Erinnerungen:** „Erinnere mich heute um 18 Uhr an den Müll“, „Setz Milch auf die Einkaufsliste“, „Hak den Müll ab“. Mac und iPhone melden sich zur Uhrzeit.
- **Kontakte und Anrufe:** „Zeig mir den Kontakt von Max“, „Ruf Mama an“, „Ruf Anna privat an“ oder eine Nummer direkt. Jarvis findet auch Spitznamen und Umlaute (Müller = Mueller). Gibt es zwei Max oder mehrere Nummern ohne Handy, fragt er, welche. Angerufen wird über dein iPhone: Der Mac zeigt oben rechts „Anrufen“, ein Klick darauf wählt.
- **Websites öffnen:** „Öffne YouTube“, „Mach spiegel.de auf“. Die Seite geht in deinem normalen Browser auf. Ein Begriff ohne Adresse öffnet die Google-Suche dazu.
- **Programme öffnen:** Auch mit deutschen Namen („Öffne den Rechner“, „die Aktivitätsanzeige“, „Systemeinstellungen“) und ungefähren Namen („Visual Studio“). Findet er nichts, sagt er es.
- Jarvis kennt jetzt die Daten der nächsten zwei Wochen, damit „nächsten Dienstag“ sicher stimmt. Das Dashboard zeigt neue Termine und Erinnerungen beim nächsten Laden.
- **Einmalig erlauben** (Systemeinstellungen → Datenschutz & Sicherheit): Kalender und Erinnerungen → Terminal auf „Vollzugriff“; für Kontakte „Festplattenvollzugriff“ fürs Terminal (hast du für Nachrichten vielleicht schon). Für Anrufe auf dem iPhone: Einstellungen → Telefon → Anrufe auf anderen Geräten → deinen Mac einschalten. Fehlt etwas, sagt Jarvis es und öffnet die richtige Einstellung.

## Update 19 (3. Oktober, Abend)
- **Nie mehr zwei Jarvis gleichzeitig:** Waren zwei Jarvis-Tabs offen (zum Beispiel weil Chrome beim Start den alten Tab wiederhergestellt und Jarvis zusätzlich einen neuen geöffnet hat), hörten beide zu und redeten übereinander. Jetzt ist immer nur ein Tab aktiv, der zuletzt geöffnete. Jeder weitere Tab wird sofort stumm, zeigt „Jarvis läuft schon in einem anderen Tab“ und schließt sich von selbst. Mit „Lieber hier benutzen“ holst du Jarvis in diesen Tab.
- **Kein zweiter Tab mehr beim Start:** Klatschen oder „Hey Jarvis“ holen den vorhandenen Jarvis-Tab nach vorne, statt einen neuen zu öffnen. Dafür fragt macOS einmal „Terminal möchte Google Chrome steuern“: bitte **OK** klicken.
- **Nie zwei Stimmen gleichzeitig:** Kommen zwei Ansagen auf einmal (zum Beispiel eine Antwort und die Meldung von Claude Code), spricht Jarvis sie nacheinander. „Jarvis, stopp“ bricht auch die wartende ab.
- **Jarvis.command doppelt geöffnet:** Das zweite Fenster startet keinen zweiten Jarvis mehr, sondern holt nur das Jarvis-Fenster nach vorne und beendet sich.
- **Einkaufsliste und alle Listen in Erinnerungen bearbeiten:** „Was steht auf der Einkaufsliste?“, „Setz Milch, Brot und Eier auf die Einkaufsliste“, „Mach aus Milch Hafermilch“, „Schieb die Schrauben auf die Baumarkt-Liste“, „Streich die Eier“, „Milch hab ich“, „Hak die ganze Einkaufsliste ab“. Jarvis findet die Liste auch, wenn sie bei dir „Einkauf“ oder „Einkaufen“ heißt. Gibt es eine Liste noch nicht, fragt er, ob er sie anlegen soll. Gelöscht wird nur, wenn du es ausdrücklich sagst. Alles kommt per iCloud aufs iPhone.

## Update 20 (3. Oktober, Abend)
- **Behoben: Flackern und kein Zuhören nach Update 19.** Chrome hatte die alte Fassung von Jarvis noch gespeichert und lud sie nach dem Update weiter. Der Server bat den Tab um ein Neuladen, Chrome nahm wieder die alte Fassung, und so ging es endlos weiter. Jetzt holt Chrome nach jedem Update garantiert den neuen Stand. Ein Tab mit altem Stand wird höchstens einmal neu geladen, eine Schleife ist nicht mehr möglich.
- **Kein Fokus-Klau mehr:** Klatschen oder „Hey Jarvis“ holen Chrome nicht mehr in den Vordergrund, wenn Jarvis schon offen ist. Er hört einfach zu, du kannst weiterarbeiten.
- **Neu: „Jarvis neu starten.command“** im Jarvis-Ordner. Hängt Jarvis oder reagiert nicht mehr, doppelklickst du diese Datei: Sie beendet den alten Jarvis und startet ihn frisch. Ein normaler Doppelklick auf Jarvis.command startet keinen zweiten Jarvis, wenn schon einer läuft.

## Update 21 (5. Oktober, Abend)
- **Mails im Dashboard kommen wieder, und zwar sofort:** Jarvis liest Absender, Betreff und Vorschau jetzt direkt aus Mails eigenem Verzeichnis auf dem Mac, statt die Mail-App zu fragen. Bei großen Postfächern hat die Mail-App dafür zu lange gebraucht („Zeitlimit“). Die Mail-App muss dafür nicht einmal offen sein.
- Auch „Lies mir meine Mails vor“ und der Tagesüberblick sind dadurch schneller.
- Braucht „Festplattenvollzugriff“ fürs Terminal (wie bei den Nachrichten). Fehlt er, fragt Jarvis wie bisher die Mail-App und zeigt im Dashboard einen Knopf, der die richtige Einstellung öffnet.
- Gelesen wird nur, nichts wird verändert, gesendet oder gelöscht.
