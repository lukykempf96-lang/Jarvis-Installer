#!/bin/bash
# Jarvis aktualisieren, ohne Schlüssel und Einstellungen anzufassen.
# Wird von Jarvis.command automatisch gestartet, wenn ein Update in „Downloads“ liegt.
set -e
SRC="$(cd "$(dirname "$0")" && pwd)"
DEST="$HOME/Downloads/Jarvis"
[ -d "$DEST" ] || { echo "Jarvis-Ordner nicht gefunden: $DEST"; exit 1; }
NEW="$(cat "$SRC/VERSION" 2>/dev/null || echo 0)"
OLD="$(cat "$DEST/VERSION" 2>/dev/null || echo 0)"
if [ "$NEW" -le "$OLD" ]; then
    echo "Dieses Update (Stand $NEW) ist schon installiert."
    rm -rf "$SRC"
    open "$DEST/Jarvis.command"
    exit 0
fi
pkill -f "uvicorn backend.main" || true
pkill -f backend.clap_daemon || true
# Nur den Programmcode kopieren; venv, .env, Startdateien und Log im Jarvis-Ordner bleiben unberuehrt,
# auch wenn im Update-Ordner versehentlich install.sh lief.
(cd "$SRC" && tar -cf - --exclude ./venv --exclude ./.env --exclude ./.env.tmp --exclude '*.command' --exclude '*.log' .) | (cd "$DEST" && tar -xf -)
bash "$DEST/install.sh" --update
rm -rf "$SRC"
echo "Jarvis ist jetzt auf Stand $NEW."
open "$DEST/Jarvis.command"  # Jarvis gleich wieder starten
