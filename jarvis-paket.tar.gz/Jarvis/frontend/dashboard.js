// Dashboard: Mac-Auslastung (live), Wochenauslastung, wichtige Mails, Termine und Erinnerungen.
// Nutzt addMessage aus app.js.

const RING = 2 * Math.PI * 32;
const cpuHistory = [];
const $ = (id) => document.getElementById(id);

function el(tag, cls, text) {
  const node = document.createElement(tag);
  if (cls) node.className = cls;
  if (text !== undefined) node.textContent = text;
  return node;
}

function level(pct) {
  return pct >= 90 ? "crit" : pct >= 75 ? "warn" : "";
}

// ---------- Mac-Auslastung ----------

function setGauge(id, pct, label) {
  const g = $(id);
  const val = g.querySelector(".val");
  const b = g.querySelector("b");
  if (pct === null || pct === undefined) {
    val.style.strokeDashoffset = RING;
    b.textContent = "–";
    g.title = `${label}: nicht verfügbar`;
    return;
  }
  val.style.strokeDashoffset = RING * (1 - Math.min(100, pct) / 100);
  b.replaceChildren(document.createTextNode(Math.round(pct)), el("small", "", "%"));
  g.className = `gauge ${level(pct)}`;
  g.title = `${label}: ${Math.round(pct)} %`;
}

function drawSpark() {
  const n = 60;
  const pts = cpuHistory.slice(-n);
  if (pts.length < 2) return;
  const step = 240 / (n - 1);
  const offset = (n - pts.length) * step;
  const line = pts.map((v, i) => `${(offset + i * step).toFixed(1)},${(40 - (v / 100) * 38 - 1).toFixed(1)}`);
  $("spark-line").setAttribute("points", line.join(" "));
  $("spark-area").setAttribute("points", `${offset.toFixed(1)},40 ${line.join(" ")} 240,40`);
}

function row(label, value, pct) {
  const dt = el("dt", "", label);
  const dd = el("dd", "", value);
  if (pct !== undefined) {
    const bar = el("div", "bar");
    const fill = el("i");
    fill.style.width = `${Math.min(100, pct)}%`;
    if (level(pct)) fill.style.background = `var(--${level(pct)})`;
    bar.append(fill);
    dd.append(bar);
  }
  return [dt, dd];
}

function fmtRate(kbs) {
  return kbs >= 1024 ? `${(kbs / 1024).toFixed(1)} MB/s` : `${kbs} KB/s`;
}

async function updateSystem() {
  let s;
  try {
    s = await fetch("/api/system").then((r) => r.json());
  } catch {
    return;
  }
  setGauge("g-cpu", s.cpu, "Prozessor");
  setGauge("g-ram", s.ram, `Arbeitsspeicher (${s.ram_used_gb} von ${s.ram_total_gb} GB)`);
  setGauge("g-gpu", s.gpu, "Grafik");
  cpuHistory.push(s.cpu);
  if (cpuHistory.length > 60) cpuHistory.shift();
  drawSpark();

  const rows = [row("Arbeitsspeicher", `${s.ram_used_gb} / ${s.ram_total_gb} GB`)];
  if (s.disk && s.disk.percent !== undefined) rows.push(row("Festplatte", `${s.disk.free_gb} GB frei`, s.disk.percent));
  if (s.battery) rows.push(row("Akku", `${s.battery.percent} %${s.battery.plugged ? " ⚡" : ""}`, s.battery.percent));
  rows.push(row("Netz", `↓ ${fmtRate(s.net.down_kbs)}  ↑ ${fmtRate(s.net.up_kbs)}`));
  $("sys-rows").replaceChildren(...rows.flat());
  $("sys-uptime").textContent = s.uptime_h >= 24 ? `läuft seit ${Math.round(s.uptime_h / 24)} Tagen` : `läuft seit ${s.uptime_h} h`;

  $("sys-top").replaceChildren(
    ...(s.top || []).map((p) => {
      const li = el("li");
      li.append(el("span", "", p.name), el("span", "", `${p.cpu.toFixed(1)} %`));
      return li;
    })
  );
}

// ---------- Woche ----------

function renderWeek(week) {
  const box = $("week");
  if (!week) return;
  $("week-kw").textContent = `KW ${week.kw}`;
  const top = el("div", "week-top");
  const pct = el("div", "week-pct");
  pct.append(document.createTextNode(week.percent), el("small", "", " %"));
  top.append(pct, el("div", "week-sub", `verplant · ${week.hours} h · ${week.window}`));
  const bars = el("div", "week-bars");
  for (const d of week.days) {
    const day = el("div", `wday${d.today ? " today" : ""}${["Sa", "So"].includes(d.label) ? " weekend" : ""}`);
    day.title = `${d.label}, ${d.date}: ${d.hours} h verplant (${d.percent} %), ${d.count} Termin${d.count === 1 ? "" : "e"}`;
    const col = el("div", "col");
    const fill = el("i");
    fill.style.height = `${Math.min(100, d.percent)}%`;
    col.append(fill);
    day.append(el("b", "", `${d.percent}%`), col, el("span", "", d.label));
    bars.append(day);
  }
  box.replaceChildren(top, bars);
}

// ---------- Mails ----------

function stat(value, label) {
  const box = el("div", "stat");
  box.append(el("b", "", value), el("span", "", label));
  return box;
}

function renderMails(mails) {
  const list = $("mails");
  if (!mails) {
    list.replaceChildren(el("li", "hint", "Mails nicht verfügbar."));
    $("mail-stats").replaceChildren();
    return;
  }
  $("mail-stats").replaceChildren(
    stat(mails.unread_important, "wichtig neu"),
    stat(mails.info, "sonstige neu"),
    stat(mails.ads, "Werbung")
  );
  if (!mails.important.length) {
    list.replaceChildren(el("li", "hint", "Nichts Wichtiges in den letzten drei Tagen."));
    return;
  }
  list.replaceChildren(
    ...mails.important.map((m) => {
      const li = el("li", `mail ${m.read ? "read" : "unread"}`);
      li.title = `${m.name} <${m.address}>\nKlicken: in Mail öffnen`;
      const top = el("div", "mail-top");
      top.append(el("span", "from", m.name));
      if (m.reason) top.append(el("span", "chip", m.reason));
      top.append(el("span", "when", m.when));
      li.append(top, el("div", "sum", m.summary || m.subject));
      if (m.summary) li.append(el("div", "subj", m.subject));
      li.addEventListener("click", () => fetch(`/api/mail/open?id=${encodeURIComponent(m.id)}`, { method: "POST" }));
      return li;
    })
  );
}

function renderHints(hints) {
  $("dash-hints").replaceChildren(
    ...(hints || []).map((h) => {
      const box = el("div", "dash-hint");
      box.append(el("span", "", h.text));
      if (h.pane) {
        const btn = el("button", "icon-btn", "Einstellung öffnen");
        btn.type = "button";
        btn.addEventListener("click", () => fetch(`/api/privacy?pane=${h.pane}`, { method: "POST" }));
        box.append(btn);
      }
      return box;
    })
  );
}

// ---------- Termine ----------

function renderAgenda(agenda, reminders) {
  const rem = $("reminders");
  rem.replaceChildren(
    ...(reminders || []).map((r) => {
      const item = el("div", `reminder${r.overdue ? " overdue" : ""}`);
      item.append(el("span", "", r.title), el("span", "t", r.overdue ? `überfällig${r.time ? " " + r.time : ""}` : r.time));
      return item;
    })
  );
  const box = $("agenda");
  if (!agenda) {
    box.replaceChildren(el("p", "hint", "Kalender nicht verfügbar."));
    return;
  }
  box.replaceChildren(
    ...agenda.map((day, i) => {
      const wrap = el("div", `aday${i === 0 ? " today" : ""}`);
      wrap.append(el("h3", "", day.label));
      if (!day.items.length) wrap.append(el("div", "none", "Keine Termine"));
      for (const e of day.items) {
        const ev = el("div", `event${e.past ? " past" : ""}${e.now ? " now" : ""}`);
        const color = el("span", "c");
        if (e.color) color.style.background = e.color;
        const what = el("div", "what");
        what.append(el("div", "", e.title));
        const details = [e.end ? `bis ${e.end}` : "", e.location, e.calendar].filter(Boolean).join(" · ");
        if (details) what.append(el("small", "", details));
        ev.title = `${e.title}${e.location ? "\n" + e.location : ""}\nKalender: ${e.calendar}`;
        ev.append(el("span", "t", e.time === "ganztägig" ? "ganzt." : e.time), color, what);
        wrap.append(ev);
      }
      return wrap;
    })
  );
}

// ---------- Laden ----------

let dashLoading = false;

let dashRetry = null;

function loadingNote(text) {
  return el("p", "hint", text);
}

async function loadDashboard(refresh = false) {
  if (dashLoading) return;
  dashLoading = true;
  clearTimeout(dashRetry);
  const btn = $("dash-refresh");
  btn.classList.add("spin");
  let busy = false;
  try {
    const d = await fetch(`/api/dashboard${refresh ? "?refresh=true" : ""}`).then((r) => r.json());
    const loading = d.loading || [];
    busy = loading.length > 0;
    // Jeder Teil kommt, sobald er da ist; was noch laedt, behaelt seinen Hinweis
    if (d.mails || !loading.includes("mails")) renderMails(d.mails);
    if (d.week || !loading.includes("calendar")) {
      if (d.week) renderWeek(d.week);
      else $("week").replaceChildren(loadingNote("Kalender nicht verfügbar."));
    }
    if (d.agenda || !loading.includes("calendar")) renderAgenda(d.agenda, d.reminders);
    else if (d.reminders) renderAgenda(null, d.reminders), $("agenda").replaceChildren(loadingNote("Kalender wird geladen …"));
    renderHints(d.hints);
    $("dash-updated").textContent = busy ? "lädt …" : `Stand ${d.updated}`;
  } catch {
    $("dash-updated").textContent = "Server nicht erreichbar";
  } finally {
    btn.classList.toggle("spin", busy);
    dashLoading = false;
    // Solange noch etwas laedt, alle 3 Sekunden nachsehen
    if (busy) dashRetry = setTimeout(() => loadDashboard(), 3000);
  }
}

$("dash-refresh").addEventListener("click", () => loadDashboard(true));

// ---------- Prioritaeten ----------

const prioDialog = $("prio-dialog");
const prioForm = $("prio-form");

$("prio-btn").addEventListener("click", async () => {
  const p = await fetch("/api/priorities").then((r) => r.json()).catch(() => ({}));
  for (const key of ["wichtig_absender", "wichtig_woerter", "ausblenden"]) {
    prioForm.elements[key].value = (p[key] || []).join("\n");
  }
  prioDialog.showModal();
});

prioDialog.addEventListener("close", async () => {
  if (prioDialog.returnValue !== "save") return;
  const body = {};
  for (const key of ["wichtig_absender", "wichtig_woerter", "ausblenden"]) {
    body[key] = prioForm.elements[key].value.split("\n").map((s) => s.trim()).filter(Boolean);
  }
  await fetch("/api/priorities", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  }).catch(() => {});
  loadDashboard(true);
});

updateSystem();
setInterval(updateSystem, 2000);
loadDashboard();
setInterval(() => loadDashboard(), 3 * 60 * 1000);
