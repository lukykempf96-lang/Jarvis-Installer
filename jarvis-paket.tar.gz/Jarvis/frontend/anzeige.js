// Anzeige auf einem zweiten Geraet: Gehirn, Uhr, Dashboard. Nur ansehen, gesteuert wird am Mac.

const $ = (id) => document.getElementById(id);
const RING = 2 * Math.PI * 32;
const STATUS = {
  idle: "Bereit",
  listening: "Ich höre zu …",
  thinking: "Ich denke nach …",
  speaking: "Jarvis spricht …",
};

function el(tag, cls, text) {
  const node = document.createElement(tag);
  if (cls) node.className = cls;
  if (text !== undefined) node.textContent = text;
  return node;
}

// ---------- Uhr ----------

function tick() {
  const now = new Date();
  $("a-time").textContent = now.toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" });
  $("a-date").textContent = now.toLocaleDateString("de-DE", { weekday: "long", day: "numeric", month: "long" });
}
tick();
setInterval(tick, 1000);

// ---------- Zustand vom Mac ----------

let mode = "idle";

function setMode(next) {
  mode = STATUS[next] ? next : "idle";
  $("orb").className = `core ${mode}`;
  window.JarvisBrain?.setMode(mode);
  $("a-status").textContent = STATUS[mode];
}

let captionTimer = null;

function caption(question, answer) {
  const box = $("a-caption");
  if (question !== undefined) {
    $("a-q").textContent = question;
    $("a-a").textContent = "";
  }
  if (answer !== undefined) $("a-a").textContent = answer;
  box.hidden = false;
  box.classList.remove("fade");
  clearTimeout(captionTimer);
  // Nach zwei Minuten verblasst der Text wieder, die Anzeige soll ruhig bleiben
  captionTimer = setTimeout(() => box.classList.add("fade"), 120000);
}

let socket = null;
let failures = 0;

function connect() {
  // Auch am Mac selbst ist die Anzeige nur Anzeige (nie ein zweiter Jarvis)
  const ws = new WebSocket(`ws://${location.host}/ws?rolle=anzeige`);
  socket = ws;
  ws.onopen = () => {
    failures = 0;
    $("a-offline").hidden = true;
    loadDashboard();
  };
  ws.onmessage = (event) => {
    let data;
    try {
      data = JSON.parse(event.data);
    } catch {
      return;
    }
    if (data.type === "state") setMode(data.state);
    if (data.type === "say") {
      if (data.on) {
        setMode("speaking");
        if (data.text) caption("", data.text);
      } else if (mode === "speaking") {
        setMode("idle");
      }
    }
    if (data.type === "chat") {
      if (data.user !== undefined) caption(data.user);
      if (data.reply !== undefined) caption(undefined, data.reply);
    }
    if (data.type === "notice") caption("", data.text);
    if (data.type === "status" && mode === "thinking") $("a-status").textContent = data.text;
  };
  ws.onclose = () => {
    if (socket !== ws) return;
    failures++;
    if (failures > 1) {
      $("a-offline").hidden = false;
      setMode("idle");
      $("a-status").textContent = "Keine Verbindung";
    }
    setTimeout(connect, Math.min(10000, 1500 * failures));
  };
}
connect();

// ---------- Mac-Auslastung ----------

function setGauge(id, pct) {
  const g = $(id);
  const val = g.querySelector(".val");
  const b = g.querySelector("b");
  if (pct === null || pct === undefined) {
    val.style.strokeDashoffset = RING;
    b.textContent = "–";
    return;
  }
  val.style.strokeDashoffset = RING * (1 - Math.min(100, pct) / 100);
  b.replaceChildren(document.createTextNode(Math.round(pct)), el("small", "", "%"));
  g.className = `gauge ${pct >= 90 ? "crit" : pct >= 75 ? "warn" : ""}`;
}

async function updateSystem() {
  let s;
  try {
    const res = await fetch("/api/system");
    if (res.status === 403) return locked();
    s = await res.json();
  } catch {
    return;
  }
  setGauge("g-cpu", s.cpu);
  setGauge("g-ram", s.ram);
  setGauge("g-gpu", s.gpu);
  const parts = [];
  if (s.battery) parts.push(`Akku ${s.battery.percent} %${s.battery.plugged ? " ⚡" : ""}`);
  if (s.ram_used_gb !== undefined) parts.push(`${s.ram_used_gb}/${s.ram_total_gb} GB`);
  $("a-sys-meta").textContent = parts.join(" · ");
}
updateSystem();
setInterval(updateSystem, 3000);

// ---------- Woche, Termine, Mails ----------

function renderWeek(week) {
  const box = $("a-week");
  if (!week) {
    box.replaceChildren(el("p", "hint", "Kalender nicht verfügbar."));
    return;
  }
  $("a-kw").textContent = `KW ${week.kw}`;
  const top = el("div", "week-top");
  const pct = el("div", "week-pct");
  pct.append(document.createTextNode(week.percent), el("small", "", " %"));
  top.append(pct, el("div", "week-sub", `verplant · ${week.hours} h`));
  const bars = el("div", "week-bars");
  for (const d of week.days) {
    const day = el("div", `wday${d.today ? " today" : ""}${["Sa", "So"].includes(d.label) ? " weekend" : ""}`);
    const col = el("div", "col");
    const fill = el("i");
    fill.style.height = `${Math.min(100, d.percent)}%`;
    col.append(fill);
    day.append(el("b", "", `${d.percent}%`), col, el("span", "", d.label));
    bars.append(day);
  }
  box.replaceChildren(top, bars);
}

function renderAgenda(agenda, reminders) {
  const list = $("a-agenda");
  if (!agenda) {
    list.replaceChildren(el("li", "hint", "Kalender nicht verfügbar."));
    return;
  }
  const items = [];
  for (const r of (reminders || []).filter((r) => r.overdue).slice(0, 1)) {
    const li = el("li");
    li.append(el("span", "t", "fällig"), el("span", "x", r.title));
    items.push(li);
  }
  // Was noch kommt: heute ohne Vergangenes, dann die naechsten Tage, insgesamt hoechstens 6 Zeilen
  for (const day of agenda) {
    const upcoming = day.items.filter((e) => !e.past);
    if (!upcoming.length) continue;
    items.push(el("li", "day", day.label));
    for (const e of upcoming) {
      const li = el("li", e.now ? "now" : "");
      li.append(el("span", "t", e.time === "ganztägig" ? "ganzt." : e.time), el("span", "x", e.title));
      items.push(li);
    }
    if (items.length >= 6) break;
  }
  if (!items.length) items.push(el("li", "hint", "Keine Termine in den nächsten Tagen."));
  list.replaceChildren(...items.slice(0, 7));
}

function renderMails(mails) {
  const list = $("a-mails");
  if (!mails) {
    $("a-mail-count").textContent = "";
    list.replaceChildren(el("li", "hint", "Mails nicht verfügbar."));
    return;
  }
  $("a-mail-count").textContent = `${mails.unread_important} wichtig neu`;
  const important = mails.important.filter((m) => !m.read).concat(mails.important.filter((m) => m.read));
  if (!important.length) {
    list.replaceChildren(el("li", "hint", "Nichts Wichtiges."));
    return;
  }
  list.replaceChildren(
    ...important.slice(0, 3).map((m) => {
      const li = el("li", "mail");
      li.append(el("b", "", m.name), el("span", "", m.summary || m.subject));
      return li;
    })
  );
}

async function loadDashboard() {
  try {
    const res = await fetch("/api/dashboard");
    if (res.status === 403) return locked();
    const d = await res.json();
    renderWeek(d.week);
    renderAgenda(d.agenda, d.reminders);
    renderMails(d.mails);
    $("a-updated").textContent = d.updated ? `Stand ${d.updated}` : "";
  } catch {
    // naechster Versuch beim naechsten Intervall
  }
}
setInterval(loadDashboard, 3 * 60 * 1000);

function locked() {
  $("a-offline").textContent = "Dieses Gerät ist nicht mehr freigegeben. Bitte den QR-Code im Jarvis-Fenster neu scannen.";
  $("a-offline").hidden = false;
}

// ---------- Vollbild und wach bleiben ----------

let wakeLock = null;

async function keepAwake() {
  // Klappt nur bei sicheren Verbindungen; sonst bleibt die Einstellung am Handy zustaendig
  try {
    if (navigator.wakeLock && !wakeLock) {
      wakeLock = await navigator.wakeLock.request("screen");
      wakeLock.addEventListener("release", () => (wakeLock = null));
    }
  } catch {
    wakeLock = null;
  }
}

document.addEventListener("click", () => {
  const root = document.documentElement;
  if (!document.fullscreenElement && root.requestFullscreen) root.requestFullscreen().catch(() => {});
  keepAwake();
  $("a-tap").classList.add("gone");
});
document.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "visible") keepAwake();
});
setTimeout(() => $("a-tap").classList.add("gone"), 15000);
