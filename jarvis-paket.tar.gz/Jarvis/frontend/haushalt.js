// Haushaltsbuch: kleine Kachel neben Jarvis und das grosse Fenster.
// Eintragen geht per Sprache (Jarvis-Tools), hier im Fenster oder mit Belegen (reinziehen, siehe panels.js).

const hhCard = document.getElementById("hh-card");
const hhCardBody = document.getElementById("hh-card-body");
const hhCardMonth = document.getElementById("hh-card-month");
const hhView = document.getElementById("hh-view");
const hhFixedForm = document.getElementById("hh-fixed-form");
const hhBookForm = document.getElementById("hh-book-form");
const hhCaption = document.getElementById("hh-caption");

let hhMonth = ""; // angezeigter Monat im Fenster, "" = dieser Monat
let hhData = null;
let hhFresh = new Set(); // gerade eingetragen: kurz aufleuchten lassen
let hhResetDate = true; // Datum im Formular auf den angezeigten Monat setzen

const HH_SUGGEST = [
  ["Gehalt", "einnahme", "monatlich"], ["Miete", "ausgabe", "monatlich"], ["Strom", "ausgabe", "monatlich"],
  ["Internet", "ausgabe", "monatlich"], ["Handy", "ausgabe", "monatlich"], ["Auto-Versicherung", "ausgabe", "monatlich"],
  ["Kfz-Steuer", "ausgabe", "jaehrlich"], ["Auto-Finanzierung", "ausgabe", "monatlich"], ["Kredit", "ausgabe", "monatlich"],
  ["Sparen", "sparen", "monatlich"], ["Urlaubskonto", "sparen", "monatlich"], ["Streaming", "ausgabe", "monatlich"],
  ["Fitnessstudio", "ausgabe", "monatlich"],
];
const HH_RHYTHM = { vierteljaehrlich: "vierteljährlich", halbjaehrlich: "halbjährlich", jaehrlich: "jährlich" };
const HH_SOURCE = { beleg: "📎", sprache: "🎙", hand: "✍" };

const hhEuro = new Intl.NumberFormat("de-DE", { style: "currency", currency: "EUR" });
const hhEuroRound = new Intl.NumberFormat("de-DE", { style: "currency", currency: "EUR", maximumFractionDigits: 0 });
const eur = (v) => hhEuro.format(v || 0);
const eurRound = (v) => hhEuroRound.format(v || 0);
const hhPlain = (v) => String(v).replace(".", ",");

function hhEl(tag, cls, text) {
  const node = document.createElement(tag);
  if (cls) node.className = cls;
  if (text !== undefined) node.textContent = text;
  return node;
}

function hhDay(iso) {
  const [, m, d] = iso.split("-");
  return `${d}.${m}.`;
}

window.hhIsOpen = () => !hhView.hidden;

async function hhGet(month) {
  const res = await fetch(`/api/haushalt?monat=${encodeURIComponent(month || "")}`);
  if (!res.ok) throw new Error(res.status);
  return res.json();
}

async function hhPost(action) {
  try {
    const res = await fetch("/api/haushalt", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(action),
    });
    const data = await res.json();
    if (!data.ok) hhShowCaption("Jarvis", data.text);
    return data;
  } catch {
    hhShowCaption("Jarvis", "Der Jarvis-Server ist nicht erreichbar.");
    return { ok: false };
  } finally {
    hhRefresh();
  }
}

async function hhRefresh() {
  let current = null;
  try {
    current = await hhGet("");
  } catch {
    current = null;
  }
  hhRenderCard(current);
  if (hhView.hidden) return;
  try {
    hhData = !hhMonth || (current && hhMonth === current.monat) ? current : await hhGet(hhMonth);
  } catch {
    hhData = null;
  }
  if (hhData) hhRenderView(hhData);
}

// ---------- Kachel ----------

function hhRenderCard(d) {
  hhCardBody.replaceChildren();
  if (!d) {
    hhCardMonth.textContent = "";
    hhCardBody.append(hhEl("span", "meta", "Jarvis-Server nicht erreichbar"));
    return;
  }
  hhCardMonth.textContent = d.label.split(" ")[0];
  if (!d.exists) {
    hhCardBody.append(hhEl("span", "", "Noch kein Haushaltsbuch."));
    hhCardBody.append(hhEl("span", "meta", "Klicken oder sag: „Bau mir ein Haushaltsbuch.“"));
    return;
  }
  const big = hhEl("span", `hh-big ${d.uebrig < 0 ? "hh-neg" : "hh-pos"}`, eurRound(d.uebrig));
  big.append(hhEl("small", "", "übrig"));
  const bar = hhEl("span", "hh-mini-bar");
  const fill = hhEl("i");
  const share = d.verfuegbar > 0 ? d.ausgaben / d.verfuegbar : d.ausgaben > 0 ? 1 : 0;
  fill.style.width = `${Math.min(100, share * 100)}%`;
  bar.classList.toggle("over", share > 1);
  bar.append(fill);
  const rows = hhEl("span", "hh-card-rows");
  const row = (label, value) => rows.append(hhEl("span", "", label), hhEl("b", "", value));
  if (d.pro_tag) row("pro Tag", eur(d.pro_tag));
  row("Ausgaben", eurRound(d.ausgaben));
  row("Frei nach Fixkosten", eurRound(d.verfuegbar));
  hhCardBody.append(big, bar, rows);
  const over = d.kategorien_summe.find((c) => c.budget && c.betrag > c.budget);
  if (over) hhCardBody.append(hhEl("span", "hh-warn", `${over.kategorie} über Budget`));
}

hhCard.addEventListener("click", () => hhOpen(""));

// ---------- Fenster ----------

async function hhOpen(month) {
  hhMonth = month || "";
  hhShow();
  const current = await hhGet("").catch(() => null);
  if (current && !current.exists) await hhPost({ aktion: "anlegen" });
  else hhRefresh();
}

function hhShow() {
  hhView.hidden = false;
  document.body.classList.add("hh-open");
  hhResetDate = true;
}

function hhClose() {
  hhView.hidden = true;
  hhCaption.hidden = true;
  document.body.classList.remove("hh-open");
}

document.getElementById("hh-close").addEventListener("click", hhClose);
addEventListener("jarvis-home", hhClose); // "danke": zurueck zur Hauptansicht
document.getElementById("hh-mic").addEventListener("click", () => document.getElementById("talk-btn").click());
document.getElementById("hh-prev").addEventListener("click", () => {
  if (!hhData) return;
  hhMonth = hhData.vorher;
  hhResetDate = true;
  hhRefresh();
});
document.getElementById("hh-next").addEventListener("click", () => {
  if (!hhData) return;
  hhMonth = hhData.nachher;
  hhResetDate = true;
  hhRefresh();
});
addEventListener("keydown", (e) => {
  if (e.key === "Escape" && !hhView.hidden && !document.querySelector("dialog[open]") && e.target.tagName !== "INPUT") hhClose();
});

function hhRenderView(d) {
  document.getElementById("hh-month").textContent = d.label;

  // Kacheln oben
  const tiles = document.getElementById("hh-tiles");
  const tile = (label, value, note, cls = "") => {
    const t = hhEl("div", `hh-tile ${cls}`);
    t.append(hhEl("span", "", label), hhEl("b", "", value));
    if (note) t.append(hhEl("small", "", note));
    return t;
  };
  const left = tile("Übrig", eur(d.uebrig), d.pro_tag ? `${eur(d.pro_tag)} pro Tag, noch ${d.tage_rest} Tage` : "", "main");
  left.querySelector("b").className = d.uebrig < 0 ? "hh-neg" : "hh-pos";
  tiles.replaceChildren(
    tile("Einnahmen", eur(d.einnahmen)),
    tile("Feste Kosten", eur(d.fix)),
    tile("Sparen", eur(d.sparen)),
    tile("Ausgaben", eur(d.ausgaben), d.verfuegbar > 0 ? `${Math.round((d.ausgaben / d.verfuegbar) * 100)} % vom Freien` : ""),
    left
  );
  const share = d.verfuegbar > 0 ? d.ausgaben / d.verfuegbar : d.ausgaben > 0 ? 1 : 0;
  document.getElementById("hh-bar-fill").style.width = `${Math.min(100, share * 100)}%`;
  document.querySelector(".hh-bar").classList.toggle("over", share > 1);

  hhRenderFixed(d);
  hhRenderBookings(d);
  hhRenderSide(d);

  document.getElementById("hh-cat-list").replaceChildren(...d.kategorien.map((k) => Object.assign(hhEl("option"), { value: k })));
  if (hhResetDate) {
    hhBookForm.datum.value = d.aktuell ? d.heute : `${d.monat}-01`;
    hhResetDate = false;
  }
  for (const id of hhFresh) {
    const row = hhView.querySelector(`[data-id="${id}"]`);
    if (row) {
      row.classList.add("fresh");
      row.scrollIntoView({ block: "nearest", behavior: "smooth" });
    }
  }
  hhFresh = new Set();
}

function hhEditable(span, value, onSave) {
  span.classList.add("editable");
  span.title = "Klicken zum Ändern";
  span.addEventListener("click", () => {
    const input = hhEl("input", "hh-inline");
    input.value = hhPlain(value);
    input.inputMode = "decimal";
    span.replaceWith(input);
    input.focus();
    input.select();
    let done = false;
    const finish = (save) => {
      if (done) return;
      done = true;
      const text = input.value.trim();
      if (save && text && text !== hhPlain(value)) onSave(text);
      else hhRefresh();
    };
    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter") finish(true);
      if (e.key === "Escape") finish(false);
    });
    input.addEventListener("blur", () => finish(true));
  });
}

function hhRenderFixed(d) {
  const list = document.getElementById("hh-fixed");
  const items = [];
  const groups = { einnahme: "Einnahmen", ausgabe: "Feste Kosten", sparen: "Sparen" };
  let last = "";
  for (const item of d.fest) {
    if (item.art !== last) {
      items.push(hhEl("li", "group", groups[item.art] || item.art));
      last = item.art;
    }
    const li = hhEl("li", item.faellig ? "" : "off");
    li.dataset.id = item.id;
    const name = hhEl("span", "hh-name", item.name);
    const meta = [item.kategorie];
    if (item.tag) meta.push(`am ${item.tag}.`);
    if (item.rhythmus && item.rhythmus !== "monatlich") meta.push(HH_RHYTHM[item.rhythmus] || item.rhythmus);
    if (!item.faellig) meta.push(item.ab > d.monat ? `nächstes Mal ${hhMonthName(item.ab)}` : "nicht in diesem Monat");
    if (item.bis) meta.push(`bis ${hhMonthName(item.bis)}`);
    name.append(hhEl("small", "", meta.join(" · ")));
    name.title = `${item.name}: ${meta.join(", ")}`;
    const amt = hhEl("span", `hh-amt ${item.art === "einnahme" ? "in" : item.art === "sparen" ? "save" : ""}`,
      (item.art === "einnahme" ? "+" : "") + eur(item.betrag));
    hhEditable(amt, item.betrag, (betrag) => hhPost({ aktion: "fest", id: item.id, betrag, ab: d.monat }));
    const x = hhEl("button", "hh-x", "×");
    x.type = "button";
    x.title = "Ab diesem Monat streichen";
    x.addEventListener("click", () => {
      if (confirm(`${item.name} ab ${d.label} streichen? Frühere Monate bleiben, wie sie waren.`)) {
        hhPost({ aktion: "fest", id: item.id, beenden: true, ab: d.monat });
      }
    });
    li.append(name, amt, x);
    items.push(li);
  }
  if (!d.fest.length) items.push(hhEl("li", "empty", "Noch keine festen Posten. Sag sie Jarvis oder trag sie unten ein."));
  list.replaceChildren(...items);

  const have = d.fest.map((i) => i.name.toLowerCase());
  const chips = HH_SUGGEST.filter(([n]) => !have.some((h) => h.includes(n.toLowerCase().split("-")[0])))
    .map(([n, art, rhythmus]) => {
      const b = hhEl("button", "", `+ ${n}`);
      b.type = "button";
      b.addEventListener("click", () => {
        hhFixedForm.name.value = n;
        hhFixedForm.art.value = art;
        hhFixedForm.rhythmus.value = rhythmus;
        hhFixedForm.betrag.focus();
      });
      return b;
    });
  document.getElementById("hh-suggest").replaceChildren(...chips);
}

function hhMonthName(key) {
  const [y, m] = key.split("-");
  const names = ["Januar", "Februar", "März", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember"];
  return `${names[Number(m) - 1]} ${y}`;
}

function hhRenderBookings(d) {
  const list = document.getElementById("hh-bookings");
  const n = d.buchungen.length;
  document.getElementById("hh-count").textContent = n ? `${n} ${n === 1 ? "Buchung" : "Buchungen"}` : "";
  const rows = d.buchungen.map((b) => {
    const li = hhEl("li");
    li.dataset.id = b.id;
    const name = hhEl("span", "hh-name", b.text);
    const meta = b.art === "sparen" || b.art === "entnahme"
      ? `${b.art === "sparen" ? "auf" : "von"} ${b.topf || "Sparen"}`
      : b.kategorie;
    const small = hhEl("small", "", meta);
    small.append(hhEl("span", "hh-src", HH_SOURCE[b.quelle] || ""));
    if (b.datei) small.title = `Beleg: ${b.datei}`;
    name.append(small);
    const plus = b.art === "einnahme" || b.art === "entnahme";
    const amt = hhEl("span", `hh-amt ${plus ? "in" : b.art === "sparen" ? "save" : ""}`, (plus ? "+" : "") + eur(b.betrag));
    hhEditable(amt, b.betrag, (betrag) => hhPost({ aktion: "buchung", id: b.id, betrag }));
    const x = hhEl("button", "hh-x", "×");
    x.type = "button";
    x.title = "Löschen";
    x.addEventListener("click", () => {
      if (confirm(`${b.text} (${eur(b.betrag)}) löschen?`)) hhPost({ aktion: "buchung", id: b.id, loeschen: true });
    });
    li.append(hhEl("span", "hh-date", hhDay(b.datum)), name, amt, x);
    return li;
  });
  if (!n) rows.push(hhEl("li", "empty", "Noch nichts eingetragen. Sag zum Beispiel: „Ich war für 42 Euro bei Rewe.“"));
  list.replaceChildren(...rows);
}

function hhRenderSide(d) {
  const cats = document.getElementById("hh-cats");
  const max = Math.max(1, ...d.kategorien_summe.map((c) => Math.max(c.betrag, c.budget || 0)));
  const rows = d.kategorien_summe.map((c) => {
    const li = hhEl("li", c.budget && c.betrag > c.budget ? "over" : "");
    li.title = "Klicken: Monatsbudget festlegen";
    const head = hhEl("div", "hh-row");
    const value = hhEl("b", "", eur(c.betrag));
    if (c.budget) value.append(hhEl("small", "", ` / ${eurRound(c.budget)}`));
    head.append(hhEl("span", "", c.kategorie), value);
    const bar = hhEl("span", "hh-mini-bar");
    const fill = hhEl("i");
    fill.style.width = `${Math.min(100, (c.betrag / (c.budget || max)) * 100)}%`;
    bar.classList.toggle("over", Boolean(c.budget && c.betrag > c.budget));
    bar.append(fill);
    li.append(head, bar);
    li.addEventListener("click", () => {
      const answer = prompt(`Monatsbudget für ${c.kategorie} in Euro (leer lassen = kein Budget):`, c.budget ? hhPlain(c.budget) : "");
      if (answer !== null) hhPost({ aktion: "einstellen", budget_kategorie: c.kategorie, budget: answer.trim() || 0 });
    });
    return li;
  });
  if (!rows.length) rows.push(hhEl("li", "meta", "Sobald etwas eingetragen ist, siehst du hier, wofür das Geld weggeht."));
  cats.replaceChildren(...rows);

  const pots = document.getElementById("hh-pots");
  const potRows = d.toepfe.map((p) => {
    const li = hhEl("li");
    const head = hhEl("div", "hh-row");
    const value = hhEl("b", "", eur(p.stand));
    value.title = "Klicken: aktuellen Stand eintragen";
    value.classList.add("editable");
    const goal = hhEl("small", "hh-goal", p.ziel ? ` / Ziel ${eurRound(p.ziel)}` : " · Ziel setzen");
    goal.title = "Klicken: Sparziel festlegen";
    const right = hhEl("span");
    right.append(value, goal);
    const name = hhEl("span", "", p.name);
    if (p.rate) name.append(hhEl("small", "", ` · ${eurRound(p.rate)} im Monat`));
    head.append(name, right);
    li.append(head);
    if (p.ziel) {
      const bar = hhEl("span", "hh-mini-bar");
      const fill = hhEl("i");
      fill.style.width = `${Math.max(0, Math.min(100, (p.stand / p.ziel) * 100))}%`;
      bar.append(fill);
      li.append(bar);
    }
    value.addEventListener("click", () => {
      const answer = prompt(`Was ist gerade auf ${p.name}? (Euro)`, hhPlain(p.stand));
      if (answer !== null && answer.trim()) hhPost({ aktion: "einstellen", topf: p.name, topf_stand: answer.trim() });
    });
    goal.addEventListener("click", () => {
      const answer = prompt(`Sparziel für ${p.name} in Euro (leer lassen = keins):`, p.ziel ? hhPlain(p.ziel) : "");
      if (answer !== null) hhPost({ aktion: "einstellen", topf: p.name, topf_ziel: answer.trim() || 0 });
    });
    return li;
  });
  if (!potRows.length) potRows.push(hhEl("li", "meta", "Noch keine. Sag zum Beispiel: „Leg jeden Monat 100 Euro aufs Urlaubskonto.“"));
  pots.replaceChildren(...potRows);

  const open = document.getElementById("hh-open");
  const openRows = d.offen.map((o) => {
    const li = hhEl("li");
    li.append(hhEl("span", "hh-name", o.name), hhEl("span", "hh-date", `am ${o.tag}.`), hhEl("span", "hh-amt", eur(o.betrag)));
    return li;
  });
  if (!openRows.length) {
    openRows.push(hhEl("li", "empty", d.aktuell ? "Diesen Monat wird nichts Festes mehr abgebucht." : "Nur für den laufenden Monat."));
  }
  open.replaceChildren(...openRows);
}

// ---------- Formulare ----------

hhFixedForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const f = hhFixedForm;
  const res = await hhPost({
    aktion: "fest", name: f.name.value.trim(), betrag: f.betrag.value.trim(), art: f.art.value,
    rhythmus: f.rhythmus.value, tag: f.tag.value.trim() || null, ab: hhData ? hhData.monat : "",
  });
  if (res.ok) {
    f.reset();
    f.name.focus();
  }
});

hhBookForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const f = hhBookForm;
  const datum = f.datum.value;
  const betrag = f.betrag.value.trim();
  const res = await hhPost({
    aktion: "buchen",
    eintrag: { text: f.text.value.trim(), betrag, kategorie: f.kategorie.value.trim(), datum,
               art: betrag.startsWith("+") ? "einnahme" : "ausgabe" },
  });
  if (res.ok) {
    f.reset();
    f.datum.value = datum; // mehrere Belege vom selben Tag schnell hintereinander
    f.text.focus();
  }
});

// ---------- Jarvis spricht mit ----------

function hhShowCaption(who, text) {
  hhCaption.replaceChildren(hhEl("b", "", `${who}: `), document.createTextNode(text));
  hhCaption.hidden = false;
}

// Zustand und letzte Antwort aus dem Hauptfenster spiegeln, das Gehirn liegt ja unter dem Haushaltsbuch
const hhState = document.getElementById("hh-state");
new MutationObserver(() => {
  const mode = ["listening", "thinking", "speaking"].find((m) => document.getElementById("orb").classList.contains(m)) || "idle";
  hhState.className = `hh-state ${mode}`;
  hhState.lastElementChild.textContent = document.getElementById("status").textContent;
}).observe(document.getElementById("status"), { childList: true, characterData: true, subtree: true });

new MutationObserver(() => {
  if (hhView.hidden) return;
  const last = document.getElementById("log").lastElementChild;
  if (last && last.classList.contains("msg")) hhShowCaption(last.classList.contains("user") ? "Du" : "Jarvis", last.textContent);
}).observe(document.getElementById("log"), { childList: true });

// Nachricht vom Server: etwas wurde eingetragen, oder Jarvis soll das Fenster oeffnen/schliessen
window.onHaushalt = (data) => {
  for (const id of data.neu || []) hhFresh.add(id);
  if (data.show === true) {
    hhMonth = data.monat && hhData && data.monat === hhData.heute.slice(0, 7) ? "" : data.monat || "";
    hhShow();
  } else if (data.show === false) {
    hhClose();
  }
  hhRefresh();
};

hhRefresh();
setInterval(() => {
  if (hhView.hidden) hhRefresh(); // "pro Tag" und Monatswechsel aktuell halten
}, 10 * 60 * 1000);
