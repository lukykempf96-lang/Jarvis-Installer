const orb = document.getElementById("orb");
const statusEl = document.getElementById("status");
const talkBtn = document.getElementById("talk-btn");
const log = document.getElementById("log");
const player = document.getElementById("player");

let history = [];
let listening = false;

// Nur ein Jarvis-Fenster: Jeder Tab hat eine Kennung (bleibt beim Neuladen gleich). Der Server macht den
// zuletzt geoeffneten Tab zum aktiven; alle anderen werden stumm und schliessen sich, wenn Chrome es erlaubt.
const TAB = (() => {
  let id = "";
  let opened = 0;
  try {
    id = sessionStorage.getItem("jarvis-tab") || "";
    opened = Number(sessionStorage.getItem("jarvis-opened")) || 0;
  } catch {
    // ohne sessionStorage gilt jeder Seitenaufruf als neuer Tab
  }
  if (!id || !opened) {
    id = "jt" + Math.random().toString(36).slice(2, 10);
    opened = Date.now();
    try {
      sessionStorage.setItem("jarvis-tab", id);
      sessionStorage.setItem("jarvis-opened", String(opened));
    } catch {
      // egal
    }
  }
  // Stand dieses Fensters (der Server haengt ihn an die Adresse): passt er nicht zum Server, laedt der Tab neu
  let version = "";
  try {
    version = new URL(document.currentScript.src).searchParams.get("v") || "";
  } catch {
    // dann gilt der Tab als alt und wird einmal neu geladen
  }
  return { id, opened, version };
})();
window.history.replaceState(null, "", location.pathname + location.search + "#" + TAB.id);
let passive = false;
// Gespraechsmodus: Nach jeder Antwort hoert Jarvis weiter zu, bis man schweigt oder "danke" sagt.
let conversation = false;
const END_WORDS = /\b(danke|das wars|das war's|tsch(ue|ü)ss|stopp|ende|gute nacht)\b/i;
// Nach "danke" & Co. geht es nach der Antwort zurueck zur Hauptansicht (Haushaltsbuch usw. schliessen sich)
let homeAfterAnswer = false;

const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
let recognition = null;
let relisten = false;
let interruptedAt = 0;
// Kurz nach "Jarvis, stopp" ist "stopp" nur der Rest der Unterbrechung, kein Gespraechsende
const justInterrupted = () => Date.now() - interruptedAt < 5000;

if (SpeechRecognition) {
  recognition = new SpeechRecognition();
  recognition.lang = "de-DE";
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;

  recognition.onresult = (event) => {
    const transcript = event.results[0][0].transcript;
    if (justInterrupted()) {
      // Nur "Jarvis, stopp" nochmal gehoert: nicht schicken, weiter auf die eigentliche Frage warten
      if (!transcript.replace(STOP_WORDS, "").replace(/\b(hey|okay|ok)\b|[\s.,!?]/gi, "")) {
        relisten = true;
        return;
      }
      homeAfterAnswer = END_WORDS.test(transcript.replace(/\bstopp\b/gi, ""));
    } else homeAfterAnswer = END_WORDS.test(transcript);
    if (homeAfterAnswer) conversation = false;
    addMessage("user", transcript);
    sendToJarvis(transcript);
  };

  // Das Gehirn bewegt sich mit, sobald gesprochen wird
  recognition.onspeechstart = () => window.JarvisBrain?.speech(true);
  recognition.onspeechend = () => window.JarvisBrain?.speech(false);

  recognition.onerror = (event) => {
    conversation = false;
    setState("idle", ["no-speech", "aborted"].includes(event.error) ? "Bereit" : "Fehler beim Zuhoeren");
  };
  recognition.onend = () => {
    listening = false;
    talkBtn.classList.remove("active");
    if (relisten) {
      relisten = false;
      startListening();
      return;
    }
    if (currentState === "listening") setState("idle", "Bereit");
  };
} else {
  statusEl.textContent = "Spracherkennung nicht unterstuetzt (Chrome nutzen)";
}

function startListening() {
  if (!recognition || listening || passive) return;
  listening = true;
  talkBtn.classList.add("active");
  setState("listening", conversation ? "Ich hoere zu... (\u201edanke\u201c beendet das Gespraech)" : "Ich hoere zu...");
  try {
    recognition.start();
  } catch {
    listening = false;
    setState("idle", "Bereit");
  }
}

talkBtn.addEventListener("click", () => {
  if (passive) return;
  if (currentState === "speaking") return interrupt();
  if (!recognition) return;
  if (listening) {
    conversation = false;
    recognition.stop();
    return;
  }
  conversation = true;
  startListening();
});

// "Jarvis, stopp": Waehrend er spricht, hoert ein zweiter Erkenner auf das Stoppwort.
// Seine eigene Stimme landet auch im Mikrofon; Woerter, die in seiner Antwort vorkommen, zaehlen deshalb nicht.
const STOP_WORDS = /\b(stopp?|jarvis|javis|chavis|jarwis|jervis|ruhe)\b/gi;
let bargeRec = null;
let bargeActive = false;
let bargeText = "";
let bargeEnded = Promise.resolve();
let interrupted = false;

function startBargeIn(text) {
  if (!SpeechRecognition || bargeActive || passive) return;
  bargeText = text.toLowerCase();
  bargeActive = true;
  const rec = new SpeechRecognition();
  rec.lang = "de-DE";
  rec.continuous = true;
  rec.interimResults = true;
  let finish;
  bargeEnded = new Promise((resolve) => (finish = resolve));
  rec.onresult = (event) => {
    for (let i = event.resultIndex; i < event.results.length; i++) {
      const words = event.results[i][0].transcript.toLowerCase().match(STOP_WORDS) || [];
      if (words.some((word) => !bargeText.includes(word))) return interrupt();
    }
  };
  rec.onerror = (event) => {
    if (event.error === "not-allowed" || event.error === "service-not-allowed") bargeActive = false;
  };
  rec.onend = () => {
    // Chrome beendet laengere Erkennung von selbst; solange Jarvis spricht, neu starten
    if (bargeActive && bargeRec === rec) {
      try {
        rec.start();
        return;
      } catch {
        // dann eben ohne Stoppwort weiter
      }
    }
    finish();
  };
  bargeRec = rec;
  try {
    rec.start();
  } catch {
    bargeActive = false;
    finish();
  }
}

function stopBargeIn() {
  bargeActive = false;
  if (bargeRec) {
    try {
      bargeRec.abort();
    } catch {
      // war schon beendet
    }
    bargeRec = null;
  }
  // Chrome erlaubt nur einen Erkenner gleichzeitig: erst weiter, wenn dieser wirklich aus ist
  return Promise.race([bargeEnded, new Promise((resolve) => setTimeout(resolve, 700))]);
}

function interrupt() {
  if (currentState !== "speaking" || interrupted) return;
  interrupted = true;
  interruptedAt = Date.now();
  conversation = true;
  stopBargeIn();
  statusEl.textContent = "Unterbrochen";
  fetch("/api/stop", { method: "POST" }).catch(() => {});
  if (window.speechSynthesis) speechSynthesis.cancel();
}

// Auch "Hey Jarvis" (Mac-Mikrofon) kann ihn unterbrechen; danach wird wie bei "stopp" zugehoert
function markInterrupted() {
  if (!interrupted) interruptedAt = Date.now();
  interrupted = true;
  conversation = true;
}

// Nach einer Antwort: im Gespraech direkt weiter zuhoeren (kurzer Ton als Zeichen), sonst bereit
function afterAnswer() {
  setState("idle", "Bereit");
  if (!conversation) return;
  fetch("/api/cue", { method: "POST" }).catch(() => {});
  setTimeout(() => {
    if (conversation && currentState === "idle") startListening();
  }, 400);
}

let triggerSocket = null;
let currentState = "idle";
let reconnectTimer = null;

function connectTriggerSocket() {
  clearTimeout(reconnectTimer);
  if (triggerSocket && triggerSocket.readyState <= WebSocket.OPEN) return; // verbindet schon oder ist verbunden
  const ws = new WebSocket(`ws://${location.host}/ws`);
  triggerSocket = ws;
  ws.onopen = () => {
    ws.send(JSON.stringify({ type: "hello", tab: TAB.id, opened: TAB.opened, version: TAB.version }));
    reportState(currentState);
  };
  ws.onmessage = (event) => {
    const data = JSON.parse(event.data);
    if (data.type === "role") setPassive(!data.active);
    // Nur zuhoeren, wenn Jarvis gerade nichts tut (sonst hoert er sich selbst)
    if (data.type === "listen" && !listening && currentState === "idle") {
      conversation = true;
      startListening();
    }
    if (data.type === "work" && window.onWork) window.onWork(data);
    if (data.type === "haushalt" && window.onHaushalt) window.onHaushalt(data);
    if (data.type === "eigene" && window.onEigene) window.onEigene(data);
    // Waehrend er nachdenkt: was er gerade tut, z. B. "Suche im Internet: ..."
    if (data.type === "status" && currentState === "thinking") statusEl.textContent = data.text;
    if (data.type === "say" && !passive) {
      if (data.on && currentState === "idle" && !listening) {
        setState("speaking", "Ich melde mich...");
        interrupted = false;
        startBargeIn(data.text || "");
      }
      if (!data.on && currentState === "speaking") {
        stopBargeIn().then(() => {
          if (data.interrupted) markInterrupted();
          // Kam die Meldung mitten im Gespraech, hoert Jarvis danach weiter zu
          afterAnswer();
        });
      }
    }
    if (data.type === "notice") {
      addMessage("jarvis", data.text);
      // Damit Jarvis bei Rueckfragen weiss, was gemeldet wurde
      if (history.length && history[history.length - 1].role === "assistant") {
        history.push({ role: "user", content: `(Hintergrund-Meldung) ${data.text}` });
        history.push({ role: "assistant", content: "Verstanden." });
      }
    }
  };
  ws.onclose = () => {
    clearTimeout(reconnectTimer);
    reconnectTimer = setTimeout(connectTriggerSocket, 2000);
  };
  ws.onerror = () => ws.close();
}
connectTriggerSocket();
// Chrome bremst Zeitgeber in Hintergrund-Tabs (bis zu einer Minute). Sobald man hinschaut: sofort verbinden,
// sonst haelt der Server Jarvis fuer geschlossen und oeffnet einen zweiten Tab.
const reconnectNow = () => {
  if (!triggerSocket || triggerSocket.readyState > WebSocket.OPEN) connectTriggerSocket();
};
document.addEventListener("visibilitychange", () => document.hidden || reconnectNow());
addEventListener("focus", reconnectNow);
addEventListener("online", reconnectNow);
addEventListener("pageshow", reconnectNow);

// Stummer zweiter Tab: hoert nicht zu, spricht nicht, zeigt einen Hinweis
function setPassive(on) {
  if (on === passive) return;
  passive = on;
  let cover = document.getElementById("passive-cover");
  if (on) {
    conversation = false;
    relisten = false;
    if (listening && recognition) recognition.abort();
    stopBargeIn();
    if (!cover) {
      cover = document.createElement("div");
      cover.id = "passive-cover";
      cover.className = "passive-cover";
      cover.innerHTML =
        "<div><h2>Jarvis läuft schon in einem anderen Tab</h2>" +
        "<p>Damit er nicht doppelt spricht, ist dieser Tab stumm. Du kannst ihn einfach schließen.</p>" +
        '<button type="button" class="small-btn">Lieber hier benutzen</button></div>';
      cover.querySelector("button").addEventListener("click", () => {
        TAB.opened = Date.now();
        try {
          sessionStorage.setItem("jarvis-opened", String(TAB.opened));
        } catch {
          // egal
        }
        if (triggerSocket && triggerSocket.readyState === WebSocket.OPEN) {
          triggerSocket.send(JSON.stringify({ type: "claim" }));
        }
      });
      document.body.append(cover);
    }
    cover.hidden = false;
    if (currentState !== "idle") setState("idle", "Stumm (anderer Tab aktiv)");
    else statusEl.textContent = "Stumm (anderer Tab aktiv)";
  } else {
    if (cover) cover.hidden = true;
    if (currentState === "idle") statusEl.textContent = "Bereit";
  }
}

function reportState(mode) {
  if (triggerSocket && triggerSocket.readyState === WebSocket.OPEN) {
    triggerSocket.send(JSON.stringify({ type: "state", state: mode }));
  }
}

let stateSince = Date.now();

// Sicherheitsnetz: Haengt Jarvis zu lange in einem Zustand, wieder bereit werden,
// sonst ignoriert er Klatschen und "Hey Jarvis" fuer immer.
setInterval(() => {
  const limit = currentState === "thinking" ? 600000 : 90000;
  if (currentState !== "idle" && Date.now() - stateSince > limit) {
    conversation = false;
    stopBargeIn();
    if (listening && recognition) recognition.abort();
    listening = false;
    talkBtn.classList.remove("active");
    setState("idle", "Bereit");
  }
}, 5000);

function setState(mode, text) {
  currentState = mode;
  stateSince = Date.now();
  orb.className = `core ${mode}`;
  window.JarvisBrain?.setMode(mode);
  statusEl.textContent = text;
  reportState(mode);
  if (mode === "idle" && homeAfterAnswer && !conversation) {
    homeAfterAnswer = false;
    dispatchEvent(new Event("jarvis-home"));
  }
}

function addMessage(role, text, sources = []) {
  const el = document.createElement("div");
  el.className = `msg ${role === "user" ? "user" : "jarvis"}`;
  el.textContent = text;
  // Internet-Suche: die Seiten, auf die sich die Antwort stuetzt, zum Anklicken
  if (sources.length) {
    const list = document.createElement("div");
    list.className = "msg-sources";
    for (const source of sources) {
      if (!/^https?:\/\//i.test(source.url)) continue;
      const a = document.createElement("a");
      a.href = source.url;
      a.target = "_blank";
      a.rel = "noopener noreferrer";
      a.textContent = source.title;
      a.title = source.url;
      list.append(a);
    }
    el.append(list);
  }
  log.appendChild(el);
  log.scrollTop = log.scrollHeight;
}

async function sendToJarvis(message) {
  if (passive) return;
  setState("thinking", "Ich denke nach...");
  try {
    const res = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message, history }),
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    history = data.history || [];
    addMessage("jarvis", data.reply, data.sources || []);
    await speak(data.reply);
  } catch (err) {
    conversation = false;
    setState("idle", "Verbindungsfehler zum Server");
    addMessage("jarvis", `Fehler: ${err.message}`);
  }
}

async function speak(text) {
  setState("speaking", "Ich antworte... (\u201eJarvis, stopp\u201c unterbricht)");
  interrupted = false;
  startBargeIn(text);
  try {
    // Der Mac spricht selbst (afplay); der Browser wartet nur, bis er fertig ist.
    const res = await fetch("/api/say", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text, tab: TAB.id }),
    });
    const data = await res.json();
    if (data.ok) {
      await stopBargeIn();
      if (data.interrupted) markInterrupted();
      afterAnswer();
      return;
    }
  } catch {
    // weiter mit der Browser-Stimme
  }
  speakBrowserTTS(text);
}

function speakBrowserTTS(text) {
  if (!window.speechSynthesis) {
    stopBargeIn();
    setState("idle", "Bereit");
    return;
  }
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = "de-DE";
  const done = () => stopBargeIn().then(afterAnswer);
  utterance.onend = done;
  utterance.onerror = () => (interrupted ? done() : stopBargeIn().then(() => setState("idle", "Bereit")));
  speechSynthesis.speak(utterance);
}
