// Jarvis-Gehirn: ein rotierendes Sternen-Gehirn aus vielen bunten Lichtpunkten, darin Sternenstaub,
// rundherum ein Sternenhimmel mit Sternschnuppen und HUD-Ringe. Reagiert auf den Zustand
// (bereit, zuhoeren, nachdenken, sprechen) und beim Zuhoeren auf den echten Mikrofon-Pegel.
// Aussehen einstellbar: JarvisBrain.configure({...}) (siehe DEFAULTS), z. B. aus eigene/*.js.
(() => {
  const canvas = document.getElementById("brain");
  const ctx = canvas && canvas.getContext("2d");
  if (!ctx) return;

  const COLORS = {
    idle: [60, 165, 255],
    listening: [80, 235, 255],
    thinking: [175, 120, 255],
    speaking: [100, 255, 215],
  };
  const SPIN = { idle: 0.16, listening: 0.28, thinking: 1.0, speaking: 0.35 };

  const LITE = Boolean(window.JARVIS_MAX_DPR && window.JARVIS_MAX_DPR < 2); // Anzeige auf Handy/Tablet
  const DEFAULTS = {
    palette: [
      [70, 200, 255], // Eisblau
      [160, 100, 255], // Violett
      [255, 80, 200], // Magenta
      [60, 255, 200], // Tuerkis
      [255, 200, 100], // Gold
      [90, 120, 255], // Saphir
      [255, 120, 140], // Rosa
    ],
    nodes: LITE ? 520 : 820, // Lichtpunkte auf der Gehirn-Oberflaeche
    dust: LITE ? 380 : 650, // Sternenstaub im Inneren
    stars: LITE ? 360 : 650, // Sternenhimmel rundherum
    orbit: LITE ? 110 : 180, // Lichtteilchen auf einer Umlaufbahn ums Gehirn
    colorMix: 0.2, // wie stark die Zustandsfarbe die Sternfarben einfaerbt (0 bis 1)
    nebula: 1, // farbiger Nebel im Gehirn (0 = aus)
    shootingStars: true,
    speed: 1, // Drehgeschwindigkeit
    autoQuality: true, // ruckelt es, automatisch weniger Punkte
  };
  let cfg = { ...DEFAULTS, ...(window.JARVIS_BRAIN || {}) };

  let mode = "idle";
  let color = COLORS.idle.slice();
  let spin = SPIN.idle;
  let level = 0;
  let thinkMix = 0;
  let speechActive = false;

  const rand = (a, b) => a + Math.random() * (b - a);
  const golden = Math.PI * (3 - Math.sqrt(5));

  // ---------- Gehirn, Sternenstaub und Himmel aufbauen ----------
  let nodes = [];
  let dust = [];
  let stars = [];
  let orbit = [];
  let edges = [];
  let adj = [];
  let paletteSize = 0;
  let quality = 1; // sinkt, wenn der Rechner nicht hinterherkommt
  const scaled = (n, min = 0) => Math.max(min, Math.round(n * quality));

  // Farbe nach Lage: wie Baender in einem Nebel, dazu einzelne weisse Funkelpunkte
  function colorAt(x, y, z) {
    if (Math.random() < 0.06) return paletteSize; // weiss
    const band = (Math.atan2(z, x) / (Math.PI * 2) + 0.5) * paletteSize * 1.5 + y * 2.4 + Math.sin(z * 4 + x * 3) * 0.9;
    return ((Math.floor(band) % paletteSize) + paletteSize) % paletteSize;
  }

  function build() {
    paletteSize = cfg.palette.length;
    nodes = [];
    const addNode = (x, y, z) =>
      nodes.push({ x, y, z, c: colorAt(x, y, z), phase: Math.random() * Math.PI * 2, flash: 0, sx: 0, sy: 0, d: 0, scan: 0 });

    // Grosshirn: zwei Haelften mit Spalt, unten flacher, Windungen auf der Oberflaeche
    const surface = scaled(cfg.nodes, 60);
    for (let i = 0; i < surface; i++) {
      const u = 1 - (i / (surface - 1)) * 2;
      const r = Math.sqrt(1 - u * u);
      const th = golden * i;
      const x = Math.cos(th) * r;
      const z = Math.sin(th) * r;
      const azi = Math.atan2(z, x);
      const pol = Math.acos(u);
      const bump = 1 + 0.05 * Math.sin(9 * pol + 2 * Math.sin(3 * azi)) * Math.cos(6 * azi + 1.5 * pol);
      let px = x * 0.8;
      let py = u * 0.72;
      const pz = z * 1.05;
      if (py < 0) py *= 0.72;
      px += (px >= 0 ? 1 : -1) * 0.06;
      py -= Math.exp(-(x * x) / 0.015) * Math.max(0, u) * 0.22;
      addNode(px * bump, py * bump + 0.05, pz * bump);
    }
    // Kleinhirn hinten unten
    const small = Math.round(surface * 0.09);
    for (let i = 0; i < small; i++) {
      const u = 1 - (i / Math.max(1, small - 1)) * 2;
      const r = Math.sqrt(1 - u * u);
      const th = golden * i;
      addNode(Math.cos(th) * r * 0.42, -0.5 + u * 0.17, -0.72 + Math.sin(th) * r * 0.24);
    }
    // Neuronen im Inneren
    const inner = Math.round(surface * 0.08);
    for (let i = 0; i < inner; i++) {
      let x, y, z;
      do {
        x = rand(-1, 1);
        y = rand(-1, 1);
        z = rand(-1, 1);
      } while (x * x + y * y + z * z > 1);
      addNode(x * 0.5, y * 0.38, z * 0.7);
    }

    // Verbindungen: jeder Punkt zu seinen naechsten Nachbarn (Abstand passt sich der Punktzahl an)
    edges = [];
    adj = nodes.map(() => []);
    const seen = new Set();
    const reach = 0.3 * Math.sqrt(526 / nodes.length) * 1.15;
    for (let i = 0; i < nodes.length; i++) {
      const a = nodes[i];
      const near = [];
      for (let j = 0; j < nodes.length; j++) {
        if (i === j) continue;
        const b = nodes[j];
        const d = (a.x - b.x) ** 2 + (a.y - b.y) ** 2 + (a.z - b.z) ** 2;
        if (d < reach * reach) near.push([d, j]);
      }
      near.sort((p, q) => p[0] - q[0]);
      for (const [, j] of near.slice(0, 3)) {
        const key = i < j ? `${i}-${j}` : `${j}-${i}`;
        if (seen.has(key)) continue;
        seen.add(key);
        edges.push([i, j]);
        adj[i].push(j);
        adj[j].push(i);
      }
    }

    // Sternenstaub: winzige Punkte, die das Gehirn von innen fuellen wie eine kleine Galaxie
    dust = [];
    for (let i = 0, n = scaled(cfg.dust); i < n; i++) {
      let x, y, z;
      do {
        x = rand(-1, 1);
        y = rand(-1, 1);
        z = rand(-1, 1);
      } while (x * x + y * y + z * z > 1);
      // dichter zur Mitte, leicht spiralfoermig verdreht
      const k = 0.55 + 0.45 * Math.cbrt(Math.random());
      const twist = y * 1.2;
      const xs = (x * Math.cos(twist) - z * Math.sin(twist)) * 0.76 * k;
      const zs = (x * Math.sin(twist) + z * Math.cos(twist)) * 0.98 * k;
      dust.push({ x: xs, y: y * 0.6 * k + 0.03, z: zs, c: colorAt(xs, y, zs), phase: Math.random() * 6.3,
                  rate: rand(0.8, 3.2), size: rand(0.45, 1.1), sx: 0, sy: 0, d: 0 });
    }

    // Sternenhimmel: Kugelschale um das Gehirn, dreht sich langsam anders herum (Tiefenwirkung)
    stars = [];
    for (let i = 0, n = scaled(cfg.stars); i < n; i++) {
      const u = rand(-1, 1);
      const th = rand(0, Math.PI * 2);
      const r = rand(1.2, 1.85);
      const s = Math.sqrt(1 - u * u);
      const tinted = Math.random() < 0.35;
      stars.push({ x: Math.cos(th) * s * r, y: u * r * 0.9, z: Math.sin(th) * s * r,
                   c: tinted ? (Math.random() * paletteSize) | 0 : paletteSize, phase: Math.random() * 6.3,
                   rate: rand(0.5, 2.5), size: rand(0.35, 1) * (Math.random() < 0.08 ? 1.9 : 1) });
    }
    // Umlaufbahn: schmaler, schraeger Ring aus Lichtteilchen
    orbit = [];
    const ring = scaled(cfg.orbit);
    for (let i = 0; i < ring; i++) {
      const a = (i / ring) * Math.PI * 2 + rand(-0.03, 0.03);
      const r = 1.34 + rand(-0.04, 0.04) + (Math.random() < 0.15 ? rand(0.05, 0.12) : 0);
      orbit.push({ a, r, h: rand(-0.025, 0.025), c: ((i / ring) * paletteSize) | 0,
                   phase: Math.random() * 6.3, rate: rand(1, 4), size: rand(0.5, 1.2), sx: 0, sy: 0, d: 0 });
    }
    pulses.length = 0;
    spriteKey = "";
  }

  // ---------- Signale, die durch das Netz laufen ----------
  const pulses = [];
  let spawnDebt = 0;
  function spawnPulse() {
    const a = (Math.random() * nodes.length) | 0;
    if (!adj[a].length) return;
    const b = adj[a][(Math.random() * adj[a].length) | 0];
    pulses.push({ a, b, t: 0, rate: 2 + Math.random() * 2.5, hops: 0 });
  }
  function updatePulses(dt, speedMul) {
    for (let i = pulses.length - 1; i >= 0; i--) {
      const p = pulses[i];
      p.t += dt * p.rate * speedMul;
      if (p.t < 1) continue;
      nodes[p.b].flash = 1;
      const next = adj[p.b].filter((n) => n !== p.a);
      if (p.hops < 6 && next.length && Math.random() < 0.7) {
        p.a = p.b;
        p.b = next[(Math.random() * next.length) | 0];
        p.t = 0;
        p.hops++;
      } else {
        pulses.splice(i, 1);
      }
    }
  }

  // ---------- Sternschnuppen ----------
  const meteors = [];
  let meteorWait = rand(2, 5);
  function updateMeteors(dt) {
    if (!cfg.shootingStars) return (meteors.length = 0);
    meteorWait -= dt * (1 + thinkMix * 3 + level * 2);
    if (meteorWait <= 0) {
      meteorWait = rand(3, 8);
      const a = rand(0, Math.PI * 2);
      const dir = a + Math.PI * rand(0.62, 0.85) * (Math.random() < 0.5 ? 1 : -1);
      meteors.push({ a, r: rand(0.3, 0.42), dir, t: 0, life: rand(0.6, 1.1), len: rand(0.06, 0.11),
                     c: Math.random() < 0.5 ? paletteSize : (Math.random() * paletteSize) | 0 });
    }
    for (let i = meteors.length - 1; i >= 0; i--) {
      meteors[i].t += dt;
      if (meteors[i].t > meteors[i].life) meteors.splice(i, 1);
    }
  }

  // ---------- Leuchtpunkt-Vorlagen: eine je Farbe, leicht in der Zustandsfarbe getoent ----------
  const sprites = []; // weiches Leuchten (Gehirn, Signale)
  const sharp = []; // kleine scharfe Sterne (Himmel, Staub, Umlaufbahn)
  let spriteKey = "";
  function tintOf(i) {
    const base = i < paletteSize ? cfg.palette[i] : [255, 255, 255];
    const m = i < paletteSize ? Math.min(1, Math.max(0, cfg.colorMix)) : cfg.colorMix * 0.5;
    return base.map((c, k) => Math.round(c * (1 - m) + color[k] * m));
  }
  function paintSprite(canvasEl, rgb, crisp) {
    const g2 = canvasEl.getContext("2d");
    const g = g2.createRadialGradient(32, 32, 0, 32, 32, 32);
    g.addColorStop(0, "rgba(255,255,255,1)");
    if (crisp) {
      g.addColorStop(0.14, `rgba(${rgb},1)`);
      g.addColorStop(0.3, `rgba(${rgb},0.28)`);
      g.addColorStop(0.6, `rgba(${rgb},0.05)`);
    } else {
      g.addColorStop(0.12, `rgba(${rgb},0.95)`);
      g.addColorStop(0.4, `rgba(${rgb},0.22)`);
    }
    g.addColorStop(1, `rgba(${rgb},0)`);
    g2.clearRect(0, 0, 64, 64);
    g2.fillStyle = g;
    g2.fillRect(0, 0, 64, 64);
  }
  const tints = [];
  function paintSprites() {
    const key = color.map((c) => Math.round(c / 3)).join(",") + "|" + paletteSize + "|" + cfg.colorMix;
    if (key === spriteKey) return;
    spriteKey = key;
    for (let i = 0; i <= paletteSize + 1; i++) {
      for (const list of [sprites, sharp]) {
        if (!list[i]) {
          list[i] = document.createElement("canvas");
          list[i].width = list[i].height = 64;
        }
      }
      // letzter Eintrag: reine Zustandsfarbe (Scan-Linie, Signale beim Nachdenken)
      const rgb = i === paletteSize + 1 ? color.map(Math.round) : tintOf(i);
      tints[i] = rgb.join(",");
      paintSprite(sprites[i], tints[i], false);
      paintSprite(sharp[i], tints[i], true);
    }
  }

  build();

  // ---------- Mikrofon-Pegel beim Zuhoeren ----------
  let audioCtx = null;
  let analyser = null;
  let micStream = null;
  let micPending = false;
  let micWanted = false;
  let micPeak = 0.04;
  let timeData = null;
  let freqData = null;

  async function micStart() {
    micWanted = true;
    if (window.JARVIS_NO_MIC || micStream || micPending || !navigator.mediaDevices?.getUserMedia) return;
    micPending = true;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false },
      });
      if (!micWanted) {
        stream.getTracks().forEach((t) => t.stop());
        return;
      }
      micStream = stream;
      audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
      if (audioCtx.state === "suspended") audioCtx.resume().catch(() => {});
      analyser = audioCtx.createAnalyser();
      analyser.fftSize = 512;
      analyser.smoothingTimeConstant = 0.6;
      analyser.minDecibels = -90;
      analyser.maxDecibels = -25;
      audioCtx.createMediaStreamSource(stream).connect(analyser);
      timeData = new Uint8Array(analyser.fftSize);
      freqData = new Uint8Array(analyser.frequencyBinCount);
    } catch {
      // Ohne Pegel geht es mit der Spracherkennung als Signal weiter
    } finally {
      micPending = false;
    }
  }

  function micStop() {
    micWanted = false;
    if (micStream) micStream.getTracks().forEach((t) => t.stop());
    micStream = null;
    analyser = null;
  }

  // Chrome startet Audio erst nach einem Klick auf die Seite
  for (const ev of ["pointerdown", "keydown"]) {
    addEventListener(ev, () => audioCtx && audioCtx.resume().catch(() => {}), { passive: true });
  }

  function micLive() {
    return analyser && audioCtx && audioCtx.state === "running";
  }

  function micLevel() {
    analyser.getByteTimeDomainData(timeData);
    let sum = 0;
    for (let i = 0; i < timeData.length; i++) {
      const v = (timeData[i] - 128) / 128;
      sum += v * v;
    }
    const rms = Math.sqrt(sum / timeData.length);
    micPeak = Math.max(rms, micPeak * 0.997, 0.04);
    return Math.min(1, Math.max(0, (rms - 0.006) / (micPeak - 0.006)));
  }

  // Sprechrhythmus fuer Jarvis' eigene Stimme (die laeuft ueber den Mac, nicht den Browser)
  function voiceEnvelope(t) {
    const syllable = Math.max(0, Math.sin(t * 2 * Math.PI * 4.2 + Math.sin(t * 1.7) * 2));
    const phrase = 0.55 + 0.45 * Math.sin(t * 0.9 + Math.sin(t * 0.37) * 3);
    if (phrase < 0.18) return 0.05;
    return Math.min(1, syllable * phrase * (0.85 + 0.15 * Math.sin(t * 23)) * 1.15);
  }

  // ---------- Zeichnen ----------
  let size = 0;
  function resize() {
    const dpr = Math.min(window.devicePixelRatio || 1, window.JARVIS_MAX_DPR || 2);
    const w = Math.round(canvas.clientWidth * dpr);
    if (w && w !== size) {
      size = w;
      canvas.width = canvas.height = w;
    }
  }
  addEventListener("resize", resize);

  const BARS = 72;
  const half = BARS / 2;
  let angle = 0;
  let ringRot = 0;
  let last = performance.now();
  let perfFrames = 0;
  let perfTime = 0;

  // Schafft der Rechner (oder ein altes Handy als Anzeige) keine 30 Bilder pro Sekunde, weniger Punkte
  function watchSpeed(ms) {
    if (!cfg.autoQuality || document.visibilityState !== "visible" || ms > 250) return;
    perfFrames++;
    perfTime += ms;
    if (perfFrames < 120) return;
    const slow = perfTime / perfFrames > 1000 / 30;
    perfFrames = perfTime = 0;
    if (slow && quality > 0.45) {
      quality *= 0.75;
      build();
    }
  }

  function frame(now) {
    watchSpeed(now - last);
    const dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    const t = now / 1000;
    resize();
    if (!size) return requestAnimationFrame(frame);

    // Zustand weich ueberblenden
    const target = COLORS[mode] || COLORS.idle;
    const k = 1 - Math.exp(-dt * 4);
    for (let i = 0; i < 3; i++) color[i] += (target[i] - color[i]) * k;
    spin += ((SPIN[mode] || SPIN.idle) - spin) * k;
    thinkMix += ((mode === "thinking" ? 1 : 0) - thinkMix) * k;
    paintSprites();
    const rgb = color.map((c) => Math.round(c)).join(",");
    const stateSprite = sprites[paletteSize + 1];

    const live = mode === "listening" && micLive();
    let goal = 0;
    if (mode === "listening") goal = live ? micLevel() : speechActive ? voiceEnvelope(t) * 0.85 : 0.08;
    else if (mode === "speaking") goal = voiceEnvelope(t);
    else if (mode === "thinking") goal = 0.22 + 0.08 * Math.sin(t * 6);
    level += (goal - level) * (1 - Math.exp(-dt * (goal > level ? 30 : 7)));

    angle += dt * spin * cfg.speed;
    ringRot += dt * (0.12 + thinkMix * 0.9 + level * 0.4);

    const S = size;
    const cx = S / 2;
    const cy = S / 2;
    const R = S * 0.25 * (1 + 0.015 * Math.sin(t * 1.2) + level * 0.05);
    const dpr = S / Math.max(1, canvas.clientWidth);

    ctx.clearRect(0, 0, S, S);
    ctx.globalCompositeOperation = "source-over";

    // Hintergrund-Glimmen
    const glow = ctx.createRadialGradient(cx, cy, 0, cx, cy, S * 0.48);
    glow.addColorStop(0, `rgba(${rgb},${0.13 + level * 0.18})`);
    glow.addColorStop(0.55, `rgba(${rgb},0.04)`);
    glow.addColorStop(1, `rgba(${rgb},0)`);
    ctx.fillStyle = glow;
    ctx.fillRect(0, 0, S, S);

    ctx.globalCompositeOperation = "lighter";

    // Aeusserer Skalenring
    ctx.strokeStyle = `rgba(${rgb},0.35)`;
    ctx.lineWidth = 1 * dpr;
    ctx.beginPath();
    for (let i = 0; i < 120; i++) {
      const a = (i / 120) * Math.PI * 2 + ringRot * 0.25;
      const r1 = S * 0.475;
      const r2 = r1 - (i % 10 === 0 ? 9 : 3.5) * dpr;
      ctx.moveTo(cx + Math.cos(a) * r1, cy + Math.sin(a) * r1);
      ctx.lineTo(cx + Math.cos(a) * r2, cy + Math.sin(a) * r2);
    }
    ctx.stroke();

    // Rotierende Boegen
    const arcSets = [
      { r: 0.445, w: 2.2, dir: 1, segs: [[0, 0.9], [1.5, 0.35], [2.6, 1.25], [4.5, 0.6]] },
      { r: 0.42, w: 1, dir: -1.6, segs: [[0.4, 1.6], [2.5, 0.5], [3.6, 1.9]] },
    ];
    for (const set of arcSets) {
      ctx.strokeStyle = `rgba(${rgb},${0.45 + thinkMix * 0.3})`;
      ctx.lineWidth = set.w * dpr;
      for (const [start, len] of set.segs) {
        const a0 = start + ringRot * set.dir;
        ctx.beginPath();
        ctx.arc(cx, cy, S * set.r, a0, a0 + len);
        ctx.stroke();
      }
    }

    // Sprach-Ring (Equalizer)
    let spectrum = null;
    if (live) {
      analyser.getByteFrequencyData(freqData);
      spectrum = freqData;
    }
    ctx.strokeStyle = `rgba(${rgb},${0.35 + level * 0.55})`;
    ctx.lineWidth = 2 * dpr;
    ctx.lineCap = "round";
    ctx.beginPath();
    for (let i = 0; i < BARS; i++) {
      const a = (i / BARS) * Math.PI * 2 - Math.PI / 2;
      const m = i <= half ? i : BARS - i;
      const v = spectrum
        ? Math.min(1, spectrum[2 + Math.round(m * 1.1)] / 255)
        : 0.35 + 0.65 * Math.abs(Math.sin(m * 0.9 + t * 7.3) * Math.sin(m * 0.37 - t * 4.1 + Math.sin(t) * 2));
      const len = 1.5 * dpr + v * level * S * 0.085;
      const r1 = S * 0.36;
      ctx.moveTo(cx + Math.cos(a) * r1, cy + Math.sin(a) * r1);
      ctx.lineTo(cx + Math.cos(a) * (r1 + len), cy + Math.sin(a) * (r1 + len));
    }
    ctx.stroke();

    // Drehung und Projektion (fuer Gehirn, Staub und Himmel gleich)
    const ca = Math.cos(angle);
    const sa = Math.sin(angle);
    const tilt = 0.32 + 0.07 * Math.sin(t * 0.5);
    const ct = Math.cos(tilt);
    const st = Math.sin(tilt);
    const cam = 4.5;
    function project(p, x, y, z, c, s) {
      const x1 = x * c + z * s;
      const z1 = -x * s + z * c;
      const y2 = y * ct - z1 * st;
      const z2 = y * st + z1 * ct;
      const f = cam / (cam - z2);
      p.sx = cx + x1 * R * f;
      p.sy = cy - y2 * R * f;
      p.d = Math.min(1, Math.max(0, (z2 + 1.1) / 2.2));
      return y2;
    }

    // Sternenhimmel hinter dem Gehirn: dreht langsam andersherum, Sterne funkeln
    const sca = Math.cos(-angle * 0.35);
    const ssa = Math.sin(-angle * 0.35);
    const maxR = S * 0.405;
    for (const s of stars) {
      project(s, s.x, s.y, s.z, sca, ssa);
      const dx = s.sx - cx;
      const dy = s.sy - cy;
      const dist = Math.sqrt(dx * dx + dy * dy);
      if (dist > maxR) continue;
      const edge = Math.min(1, (maxR - dist) / (S * 0.05)); // zum Rand hin ausblenden
      const tw = 0.45 + 0.55 * Math.abs(Math.sin(s.phase + t * s.rate));
      const r = (2.2 + s.size * 3.4) * dpr * (0.7 + s.d * 0.5);
      ctx.globalAlpha = Math.min(1, (0.3 + 0.7 * tw) * edge * (0.45 + s.d * 0.55));
      ctx.drawImage(sharp[s.c], s.sx - r, s.sy - r, r * 2, r * 2);
    }

    // Sternschnuppen
    updateMeteors(dt);
    ctx.lineCap = "round";
    for (const m of meteors) {
      const p = m.t / m.life;
      const hx = cx + Math.cos(m.a) * S * m.r + Math.cos(m.dir) * S * 0.32 * p;
      const hy = cy + Math.sin(m.a) * S * m.r + Math.sin(m.dir) * S * 0.32 * p;
      const tx = hx - Math.cos(m.dir) * S * m.len;
      const ty = hy - Math.sin(m.dir) * S * m.len;
      if (Math.hypot(hx - cx, hy - cy) > S * 0.43) continue;
      const fade = Math.sin(Math.PI * p);
      const g = ctx.createLinearGradient(tx, ty, hx, hy);
      g.addColorStop(0, `rgba(${tints[m.c]},0)`);
      g.addColorStop(1, `rgba(${tints[m.c]},${0.85 * fade})`);
      ctx.strokeStyle = g;
      ctx.lineWidth = 1.6 * dpr;
      ctx.globalAlpha = 1;
      ctx.beginPath();
      ctx.moveTo(tx, ty);
      ctx.lineTo(hx, hy);
      ctx.stroke();
      const r = 6 * dpr;
      ctx.globalAlpha = fade;
      ctx.drawImage(sprites[m.c], hx - r, hy - r, r * 2, r * 2);
    }
    ctx.globalAlpha = 1;

    // Gehirn
    const scan = Math.sin(t * 2.4) * 0.7;
    const sparkle = mode === "idle" ? 6 : mode === "thinking" ? 40 : 8 + level * 160;
    for (const n of nodes) {
      const wave = 1 + level * 0.06 * Math.sin(n.phase + t * 9);
      const y2 = project(n, n.x * wave, n.y * wave, n.z * wave, ca, sa);
      n.scan = thinkMix * Math.max(0, 1 - Math.abs(y2 - scan) / 0.08);
      if (Math.random() < (sparkle * dt) / nodes.length) n.flash = Math.max(n.flash, 0.8);
      n.flash = Math.max(0, n.flash - dt * 2.5);
    }

    // Farbiger Nebel im Inneren (zwei Wolken, die mit dem Gehirn kreisen)
    if (cfg.nebula > 0) {
      for (let i = 0; i < 2; i++) {
        const a = angle * 1.3 + i * Math.PI;
        const nx = cx + Math.cos(a) * R * 0.35;
        const ny = cy - Math.sin(a) * R * 0.12 - R * 0.05;
        const c = tints[(i * 2 + 1) % paletteSize];
        const neb = ctx.createRadialGradient(nx, ny, 0, nx, ny, R * 0.75);
        neb.addColorStop(0, `rgba(${c},${(0.11 + level * 0.08 + thinkMix * 0.05) * cfg.nebula})`);
        neb.addColorStop(1, `rgba(${c},0)`);
        ctx.fillStyle = neb;
        ctx.fillRect(nx - R, ny - R, R * 2, R * 2);
      }
    }

    // Verbindungen, nach Tiefe und Farbe gruppiert
    const groups = new Map();
    for (const e of edges) {
      const a = nodes[e[0]];
      const b = nodes[e[1]];
      const key = Math.min(3, ((a.d + b.d) * 2) | 0) * 100 + a.c;
      let list = groups.get(key);
      if (!list) groups.set(key, (list = []));
      list.push(e);
    }
    const act = 0.75 + level * 0.8 + thinkMix * 0.4;
    const alphas = [0.04, 0.08, 0.14, 0.22];
    ctx.lineWidth = 0.7 * dpr;
    for (const [key, list] of groups) {
      ctx.strokeStyle = `rgba(${tints[key % 100]},${Math.min(0.75, alphas[(key / 100) | 0] * act)})`;
      ctx.beginPath();
      for (const [i, j] of list) {
        ctx.moveTo(nodes[i].sx, nodes[i].sy);
        ctx.lineTo(nodes[j].sx, nodes[j].sy);
      }
      ctx.stroke();
    }

    // Umlaufbahn: dreht sich schneller als das Gehirn, leicht schraeg
    const oa = angle * 2.2 + t * 0.15 * cfg.speed;
    const oc = Math.cos(0.5);
    const os = Math.sin(0.5);
    for (const o of orbit) {
      const a = o.a + oa;
      const x = Math.cos(a) * o.r;
      const z = Math.sin(a) * o.r;
      project(o, x, o.h - z * os * 0.55, z * oc, 1, 0);
      const tw = 0.4 + 0.6 * Math.abs(Math.sin(o.phase + t * o.rate));
      const r = (2.2 + o.size * 3.2) * dpr * (0.6 + o.d * 0.7) * (1 + level * 0.4);
      ctx.globalAlpha = Math.min(1, (0.15 + 0.75 * o.d) * tw);
      ctx.drawImage(sharp[o.c], o.sx - r, o.sy - r, r * 2, r * 2);
    }

    // Sternenstaub im Gehirn
    for (const p of dust) {
      project(p, p.x, p.y, p.z, ca, sa);
      const tw = 0.35 + 0.65 * Math.abs(Math.sin(p.phase + t * p.rate));
      const r = (2 + p.size * 3) * dpr * (0.75 + p.d * 0.5);
      ctx.globalAlpha = Math.min(1, (0.2 + 0.6 * tw) * (0.45 + p.d * 0.55) * (1 + level * 0.6));
      ctx.drawImage(sharp[p.c], p.sx - r, p.sy - r, r * 2, r * 2);
    }

    // Scan-Linie beim Nachdenken
    if (thinkMix > 0.02) {
      const sy = cy - scan * R * ct;
      const grad = ctx.createLinearGradient(cx - R * 1.3, 0, cx + R * 1.3, 0);
      grad.addColorStop(0, `rgba(${rgb},0)`);
      grad.addColorStop(0.5, `rgba(${rgb},${0.5 * thinkMix})`);
      grad.addColorStop(1, `rgba(${rgb},0)`);
      ctx.strokeStyle = grad;
      ctx.lineWidth = 1.2 * dpr;
      ctx.globalAlpha = 1;
      ctx.beginPath();
      ctx.moveTo(cx - R * 1.3, sy);
      ctx.lineTo(cx + R * 1.3, sy);
      ctx.stroke();
    }

    // Signale
    spawnDebt += dt * (mode === "thinking" ? 55 : mode === "idle" ? 5 : 6 + level * 40);
    while (spawnDebt >= 1 && pulses.length < 220) {
      spawnPulse();
      spawnDebt -= 1;
    }
    spawnDebt = Math.min(spawnDebt, 1);
    updatePulses(dt, 1 + thinkMix * 0.8 + level * 0.6);
    for (const p of pulses) {
      const a = nodes[p.a];
      const b = nodes[p.b];
      const x = a.sx + (b.sx - a.sx) * p.t;
      const y = a.sy + (b.sy - a.sy) * p.t;
      const r = (5 + 5 * ((a.d + b.d) / 2)) * dpr;
      ctx.globalAlpha = 0.55 + 0.45 * ((a.d + b.d) / 2);
      ctx.drawImage(thinkMix > 0.5 ? stateSprite : sprites[b.c], x - r, y - r, r * 2, r * 2);
    }

    // Lichtpunkte des Gehirns
    for (const n of nodes) {
      const boost = Math.max(n.flash, n.scan);
      const r = (1.9 + n.d * 2.8 + boost * 5) * dpr;
      ctx.globalAlpha = Math.min(1, 0.16 + n.d * 0.6 + boost * 0.6);
      ctx.drawImage(n.scan > 0.3 ? stateSprite : sprites[n.c], n.sx - r, n.sy - r, r * 2, r * 2);
    }
    ctx.globalAlpha = 1;

    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  window.JarvisBrain = {
    setMode(m) {
      mode = m;
      if (m === "listening") micStart();
      else {
        micStop();
        speechActive = false;
      }
    },
    speech(on) {
      speechActive = on;
    },
    // Aussehen aendern, z. B. JarvisBrain.configure({ palette: [[255, 80, 80], [255, 200, 0]], stars: 800 })
    configure(options = {}) {
      const next = { ...cfg, ...options };
      const ok = Array.isArray(next.palette) && next.palette.length > 0 &&
        next.palette.every((c) => Array.isArray(c) && c.length === 3 && c.every((v) => Number.isFinite(v)));
      if (!ok) next.palette = cfg.palette;
      next.palette = next.palette.slice(0, 40).map((c) => c.map((v) => Math.max(0, Math.min(255, Math.round(v)))));
      for (const key of ["nodes", "dust", "stars", "orbit"]) next[key] = Math.max(0, Math.min(4000, Number(next[key]) || 0));
      next.nodes = Math.max(60, next.nodes);
      const rebuild = ["palette", "nodes", "dust", "stars", "orbit"].some((key) => JSON.stringify(next[key]) !== JSON.stringify(cfg[key]));
      cfg = next;
      if (rebuild) build();
      spriteKey = "";
      return { ...cfg };
    },
    config() {
      return JSON.parse(JSON.stringify(cfg));
    },
    // Zum Pruefen in der Browser-Konsole
    info() {
      return { mode, level: Math.round(level * 100) / 100, mikrofon: Boolean(micLive()),
               punkte: nodes.length, staub: dust.length, sterne: stars.length, umlaufbahn: orbit.length,
               qualitaet: Math.round(quality * 100) / 100 };
    },
  };
})();
