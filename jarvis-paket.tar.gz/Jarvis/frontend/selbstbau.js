// Selbst gebaute Fenster-Bausteine: eigene/*.js und eigene/*.css aus dem Jarvis-Ordner (nur am Mac).
// Baut Claude Code etwas um, laedt sich das Fenster neu, sobald Jarvis nichts zu tun hat.
(() => {
  fetch("/api/eigene")
    .then((r) => (r.ok ? r.json() : { js: [], css: [] }))
    .then((files) => {
      for (const file of files.css) {
        const link = document.createElement("link");
        link.rel = "stylesheet";
        link.href = `/eigene/${encodeURIComponent(file.name)}?v=${file.v}`;
        document.head.append(link);
      }
      for (const file of files.js) {
        const script = document.createElement("script");
        script.src = `/eigene/${encodeURIComponent(file.name)}?v=${file.v}`;
        script.onerror = () => console.warn("Eigener Baustein fehlerhaft:", file.name);
        document.body.append(script);
      }
    })
    .catch(() => {});

  let pending = false;
  window.onEigene = (data) => {
    if (!data.reload || pending) return;
    pending = true;
    const wait = setInterval(() => {
      if (typeof currentState === "undefined" || currentState === "idle") {
        clearInterval(wait);
        location.reload();
      }
    }, 500);
  };
})();
