// Datei-Fenster (reinziehen, Jarvis analysiert) und Arbeitsfenster (was Claude Code gerade tut).
// Nutzt addMessage, sendToJarvis und die Zustaende aus app.js.

const dropzone = document.getElementById("dropzone");
const overlay = document.getElementById("drop-overlay");
const picker = document.getElementById("picker");
const dropList = document.getElementById("drops");
const workEl = document.getElementById("work");

const MAX_FILES = 400;
const MAX_BYTES = 400 * 1024 * 1024;
const SKIP = new Set([".git", "node_modules", "venv", ".venv", "__pycache__", ".DS_Store"]);

// ---------- Reinziehen ----------

let dragDepth = 0;
addEventListener("dragenter", (e) => {
  if (!e.dataTransfer || ![...e.dataTransfer.types].includes("Files")) return;
  dragDepth++;
  overlay.firstElementChild.textContent = window.hhIsOpen?.()
    ? "Loslassen, Jarvis trägt es ins Haushaltsbuch ein"
    : "Loslassen, Jarvis schaut es sich an";
  overlay.hidden = false;
  dropzone.classList.add("over");
});
addEventListener("dragleave", () => {
  dragDepth = Math.max(0, dragDepth - 1);
  if (!dragDepth) hideOverlay();
});
addEventListener("dragover", (e) => e.preventDefault());
addEventListener("drop", (e) => {
  e.preventDefault();
  dragDepth = 0;
  hideOverlay();
  // Eintraege sofort holen: nach dem Ereignis gibt Chrome sie nicht mehr heraus
  const entries = [...e.dataTransfer.items]
    .filter((item) => item.kind === "file")
    .map((item) => item.webkitGetAsEntry && item.webkitGetAsEntry())
    .filter(Boolean);
  const plain = [...e.dataTransfer.files];
  handleDrop(entries, plain);
});

function hideOverlay() {
  overlay.hidden = true;
  dropzone.classList.remove("over");
}

document.getElementById("pick-btn").addEventListener("click", () => picker.click());
picker.addEventListener("change", () => {
  const files = [...picker.files].map((file) => ({ file, path: file.name }));
  picker.value = "";
  if (files.length) uploadAndAnalyze(files);
});

async function handleDrop(entries, plain) {
  let files = [];
  if (entries.length) {
    for (const entry of entries) await walk(entry, "", files);
  } else {
    files = plain.map((file) => ({ file, path: file.name }));
  }
  if (files.length) uploadAndAnalyze(files);
}

async function walk(entry, prefix, out) {
  if (out.length >= MAX_FILES || SKIP.has(entry.name) || entry.name.startsWith(".")) return;
  if (entry.isFile) {
    const file = await new Promise((resolve, reject) => entry.file(resolve, reject)).catch(() => null);
    if (file) out.push({ file, path: prefix + entry.name });
    return;
  }
  const reader = entry.createReader();
  for (;;) {
    const batch = await new Promise((resolve, reject) => reader.readEntries(resolve, reject)).catch(() => []);
    if (!batch.length) break;
    for (const child of batch) await walk(child, `${prefix}${entry.name}/`, out);
  }
}

function addDrop(label) {
  const li = document.createElement("li");
  const name = document.createElement("span");
  const state = document.createElement("span");
  name.textContent = label;
  name.title = label;
  li.append(name, state);
  dropList.prepend(li);
  while (dropList.children.length > 6) dropList.lastChild.remove();
  return state;
}

function waitUntilIdle() {
  return new Promise((resolve) => {
    const started = Date.now();
    const check = () => {
      if (currentState === "listening" && recognition) {
        conversation = false;
        recognition.abort();
      }
      if (currentState === "idle" || Date.now() - started > 120000) resolve();
      else setTimeout(check, 300);
    };
    check();
  });
}

async function uploadAndAnalyze(files) {
  const total = files.reduce((sum, f) => sum + f.file.size, 0);
  const first = files[0].path.split("/")[0];
  const state = addDrop(files.length === 1 ? first : `${first} (${files.length} Dateien)`);
  if (total > MAX_BYTES) {
    state.textContent = "zu groß";
    addMessage("jarvis", "Das sind mehr als 400 MB. Sag mir lieber, in welchem Ordner es liegt, dann schaue ich direkt dort.");
    return;
  }
  const batch = new Date().toISOString().slice(0, 19).replace(/[T:]/g, "-");
  let done = 0;
  for (const { file, path } of files) {
    state.textContent = `lädt ${done + 1}/${files.length}`;
    try {
      const res = await fetch(`/api/upload?batch=${encodeURIComponent(batch)}&path=${encodeURIComponent(path)}`, {
        method: "POST",
        body: file,
      });
      const data = await res.json();
      if (!data.ok) addMessage("jarvis", `Übersprungen: ${data.error}`);
    } catch {
      state.textContent = "Fehler";
      addMessage("jarvis", "Die Dateien kamen nicht beim Server an. Läuft Jarvis noch?");
      return;
    }
    done++;
  }
  const info = await fetch(`/api/upload/done?batch=${encodeURIComponent(batch)}`, { method: "POST" }).then((r) => r.json());
  if (!info.ok) {
    state.textContent = "Fehler";
    return;
  }
  state.textContent = "schaut rein";
  await waitUntilIdle();
  addMessage("user", `\u{1F4CE} ${info.label}`);
  const what = info.count === 1 ? "eine Datei" : `${info.count} Dateien`;
  const original = info.original ? ` Der Originalordner liegt vermutlich in ${info.original}.` : "";
  conversation = true;
  // Ist das Haushaltsbuch offen, sind es Belege: lesen und eintragen
  const task = window.hhIsOpen?.()
    ? "Das sind Belege fürs Haushaltsbuch (Kassenzettel, Rechnungen, Kontoauszüge oder Screenshots). Lies jede " +
      "Datei und trag jede Zahlung mit haushalt_buchen ein, datei = Dateiname. Ist etwas kein Beleg, sag kurz, was es ist."
    : "Schau sie dir an und sag mir kurz, was drin ist.";
  await sendToJarvis(`Ich habe dir ${what} gegeben: ${info.label}. Sie liegen in ${info.dir}.${original} ${task}`);
  state.textContent = "erledigt";
}

// ---------- Arbeitsfenster ----------

const jobs = new Map();

function renderJob(project) {
  const job = jobs.get(project);
  if (!job.el) {
    job.el = document.createElement("div");
    job.el.className = "job";
    const head = document.createElement("div");
    head.className = "job-head";
    const dot = document.createElement("span");
    dot.className = "dot";
    const name = document.createElement("span");
    name.className = "name";
    name.textContent = project;
    const open = document.createElement("button");
    open.className = "small-btn";
    open.type = "button";
    open.textContent = "In Claude öffnen";
    open.title = "Öffnet das Projekt im Terminal und in der Claude-App, mit dem bisherigen Gespräch";
    open.addEventListener("click", async () => {
      const res = await fetch(`/api/open?project=${encodeURIComponent(project)}`, { method: "POST" });
      const data = await res.json().catch(() => ({}));
      if (data.text) addMessage("jarvis", data.text);
    });
    head.append(dot, name, open);
    job.list = document.createElement("ol");
    job.el.append(head, job.list);
  }
  job.el.classList.toggle("running", job.running);
  job.el.classList.toggle("done", !job.running);
  job.list.replaceChildren(
    ...job.lines.slice(-12).map((line) => {
      const li = document.createElement("li");
      li.textContent = line;
      return li;
    })
  );
  job.list.scrollTop = job.list.scrollHeight;
  workEl.querySelector(".hint")?.remove();
  workEl.prepend(job.el);
}

function onWork(data) {
  const job = jobs.get(data.project) || { lines: [], running: true };
  jobs.set(data.project, job);
  job.lines.push(data.text);
  job.running = !data.done;
  renderJob(data.project);
}

fetch("/api/work")
  .then((r) => r.json())
  .then((list) => {
    for (const entry of list.reverse()) {
      jobs.set(entry.project, { lines: entry.lines, running: entry.running });
      renderJob(entry.project);
    }
  })
  .catch(() => {});

// ---------- Handy als Anzeige ----------

const displayDialog = document.getElementById("display-dialog");
const displayQr = document.getElementById("display-qr");

document.getElementById("display-btn").addEventListener("click", async () => {
  displayQr.replaceChildren();
  displayDialog.showModal();
  const info = await fetch("/api/anzeige").then((r) => r.json()).catch(() => null);
  if (!info || !info.url) {
    const p = document.createElement("p");
    p.className = "hint";
    p.textContent = info ? info.text : "Der Jarvis-Server ist nicht erreichbar.";
    displayQr.append(p);
    return;
  }
  if (info.qr) {
    const img = document.createElement("img");
    img.alt = "QR-Code für die Anzeige";
    img.src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(info.qr);
    displayQr.append(img);
  }
});

// "danke": Info-Fenster schliessen, zurueck zur Hauptansicht (Prioritaeten bleiben offen, falls gerade getippt wird)
addEventListener("jarvis-home", () => {
  for (const dialog of [displayDialog, document.getElementById("phone-dialog")]) if (dialog.open) dialog.close();
});

// ---------- Aufs iPhone schicken (App ntfy) ----------

const phoneDialog = document.getElementById("phone-dialog");
const phoneTopic = document.getElementById("phone-topic");
const phoneResult = document.getElementById("phone-result");

document.getElementById("phone-btn").addEventListener("click", async () => {
  phoneResult.textContent = "";
  phoneDialog.showModal();
  const info = await fetch("/api/handy").then((r) => r.json()).catch(() => null);
  phoneTopic.textContent = info ? info.topic : "Server nicht erreichbar";
  if (info && info.ready) phoneResult.textContent = "Schon eingerichtet. Zum Prüfen einfach nochmal testen.";
});

document.getElementById("phone-copy").addEventListener("click", async () => {
  // Mit Handoff liegt es dann auch in der Zwischenablage des iPhones
  try {
    await navigator.clipboard.writeText(phoneTopic.textContent);
    phoneResult.textContent = "Kopiert. Auf dem iPhone kannst du es direkt einsetzen.";
  } catch {
    phoneResult.textContent = "Kopieren ging nicht, bitte abtippen.";
  }
});

document.getElementById("phone-test").addEventListener("click", async () => {
  phoneResult.textContent = "Sende …";
  const res = await fetch("/api/handy/test", { method: "POST" }).then((r) => r.json()).catch(() => null);
  phoneResult.textContent = res ? res.text : "Der Jarvis-Server ist nicht erreichbar.";
});
