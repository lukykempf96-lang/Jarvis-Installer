// Notizfeld: Text, Links oder Kassenzettel einfügen und mit Jarvis besprechen.
(() => {
  const col = document.querySelector(".left-col");
  if (!col || document.getElementById("nf-panel")) return;

  const panel = document.createElement("section");
  panel.id = "nf-panel";
  panel.className = "panel nf-panel";
  panel.innerHTML = `
    <div class="panel-head"><h2>Notizfeld</h2><span class="head-actions"><span id="nf-meta" class="meta"></span><button id="nf-clear" class="icon-btn" type="button" title="Leeren">✕</button></span></div>
    <textarea id="nf-text" class="nf-text" spellcheck="false" placeholder="Text, Link oder Kassenzettel hier einfügen …"></textarea>
    <p class="hint">Dann sag z. B.: „Was steht im Notizfeld?“ oder „Buch den Kassenzettel.“</p>`;
  const files = col.querySelector(".files-panel");
  files ? files.after(panel) : col.append(panel);

  const box = panel.querySelector("#nf-text");
  const meta = panel.querySelector("#nf-meta");
  let timer = null;
  let lastSaved = "";

  const showMeta = (msg) => { meta.textContent = msg; };

  async function save() {
    clearTimeout(timer);
    timer = null;
    const text = box.value;
    if (text === lastSaved) return;
    try {
      await fetch("/api/eigene/notizfeld/speichern", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text }),
      });
      lastSaved = text;
      showMeta("gespeichert");
    } catch {
      showMeta("nicht gespeichert");
    }
  }

  async function load() {
    if (document.activeElement === box || timer) return; // nicht reinfunken, während Lukas tippt
    try {
      const d = await fetch("/api/eigene/notizfeld/stand").then((r) => r.json());
      const text = d.text || "";
      if (text !== lastSaved) {
        box.value = text;
        lastSaved = text;
        showMeta(text ? "von Jarvis aktualisiert" : "");
      }
    } catch {}
  }

  box.addEventListener("input", () => {
    showMeta("…");
    clearTimeout(timer);
    timer = setTimeout(save, 600);
  });
  box.addEventListener("paste", () => setTimeout(save, 50));
  box.addEventListener("blur", save);
  panel.querySelector("#nf-clear").addEventListener("click", () => {
    box.value = "";
    save();
  });

  load();
  setInterval(load, 3000); // Jarvis kann das Feld auch selbst beschreiben oder leeren
})();
