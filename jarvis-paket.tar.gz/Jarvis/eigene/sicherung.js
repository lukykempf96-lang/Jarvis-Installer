// Feld "Laufwerke" rechts: angeschlossene Laufwerke mit freiem Speicher, Sicherungsordner wählen, letzte Sicherungen.
(() => {
  const col = document.querySelector(".right-col");
  if (!col || document.getElementById("sl-panel")) return;

  const panel = document.createElement("section");
  panel.id = "sl-panel";
  panel.className = "panel sl-panel";
  panel.innerHTML = `
    <div class="panel-head"><h2>Laufwerke</h2><span id="sl-meta" class="meta"></span></div>
    <div id="sl-ziel" class="sl-ziel"></div>
    <ul id="sl-liste" class="sl-liste"></ul>
    <div id="sl-browser" class="sl-browser" hidden>
      <div class="sl-pfad"><button id="sl-hoch" class="icon-btn" type="button" title="Eine Ebene höher">‹</button><span id="sl-pfad"></span></div>
      <ul id="sl-ordner" class="sl-ordner"></ul>
      <div class="sl-aktionen">
        <button id="sl-neu" class="small-btn" type="button">Neuer Ordner</button>
        <button id="sl-hier" class="small-btn primary" type="button">Hier sichern</button>
        <button id="sl-zu" class="small-btn" type="button">Schließen</button>
      </div>
      <p id="sl-fehler" class="hint sl-fehler"></p>
    </div>
    <ul id="sl-verlauf" class="sl-verlauf"></ul>
    <p class="hint">Dann sag z. B.: „Sichere das Projekt Jarvis.“</p>`;
  col.append(panel);

  const $ = (id) => document.getElementById(id);
  let browserPfad = "";
  let browserOben = "";

  const post = (name, daten) => fetch(`/api/eigene/sicherung/${name}`, {
    method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(daten),
  }).then((r) => r.json());

  function zeigen(d) {
    const ziel = $("sl-ziel");
    if (d.ziel) {
      const teile = d.ziel.split("/");
      ziel.className = "sl-ziel " + (d.ziel_da ? "sl-ok" : "sl-weg");
      ziel.textContent = `Sicherungsziel: ${teile[2] || ""} › ${teile.slice(3).join(" › ") || "(oberste Ebene)"}` +
        (d.ziel_da ? "" : " · nicht angeschlossen");
      ziel.title = d.ziel;
    } else {
      ziel.className = "sl-ziel";
      ziel.textContent = "Noch kein Sicherungsordner gewählt: Laufwerk antippen und Ordner wählen.";
    }
    const laeuft = Object.keys(d.laeuft || {});
    $("sl-meta").textContent = laeuft.length ? `sichert ${laeuft.join(", ")} …` : "";

    $("sl-liste").replaceChildren(...(d.laufwerke.length ? d.laufwerke.map((lw) => {
      const li = document.createElement("li");
      li.className = "sl-lw" + (d.ziel && d.ziel.startsWith(lw.pfad + "/") || d.ziel === lw.pfad ? " sl-aktiv" : "");
      li.title = lw.beschreibbar ? "Antippen, um einen Sicherungsordner zu wählen" : "Schreibgeschützt";
      li.innerHTML = `<div class="sl-zeile"><b></b><span class="sl-art"></span><span class="sl-frei"></span></div>
        <div class="sl-bar"><span></span></div>`;
      li.querySelector("b").textContent = lw.name;
      li.querySelector(".sl-art").textContent = lw.art;
      li.querySelector(".sl-frei").textContent = `${lw.frei} frei von ${lw.gesamt}`;
      li.querySelector(".sl-bar span").style.width = lw.belegt_prozent + "%";
      li.querySelector(".sl-bar span").classList.toggle("sl-voll", lw.belegt_prozent > 90);
      li.addEventListener("click", () => oeffnen(lw.pfad));
      return li;
    }) : [Object.assign(document.createElement("li"), { className: "hint", textContent: "Kein Laufwerk angeschlossen." })]));

    $("sl-verlauf").replaceChildren(...(d.verlauf || []).map((v) => {
      const li = document.createElement("li");
      li.className = v.ok ? "" : "sl-fehlgeschlagen";
      li.textContent = `${v.ok ? "✓" : "✕"} ${v.projekt} · ${v.wann} · ${v.groesse}`;
      li.title = v.ziel;
      return li;
    }));
  }

  async function oeffnen(pfad) {
    const d = await fetch(`/api/eigene/sicherung/ordner?pfad=${encodeURIComponent(pfad)}`).then((r) => r.json()).catch(() => null);
    $("sl-fehler").textContent = "";
    if (!d || d.fehler) {
      $("sl-browser").hidden = false;
      $("sl-fehler").textContent = d ? d.fehler : "Server nicht erreichbar.";
      return;
    }
    browserPfad = d.pfad;
    browserOben = d.oben;
    $("sl-browser").hidden = false;
    $("sl-pfad").textContent = d.pfad.replace(/^\/Volumes\//, "").split("/").join(" › ");
    $("sl-hoch").disabled = !d.oben;
    $("sl-hier").disabled = !d.beschreibbar;
    $("sl-ordner").replaceChildren(...(d.ordner.length ? d.ordner.map((name) => {
      const li = document.createElement("li");
      li.textContent = "📁 " + name;
      li.addEventListener("click", () => oeffnen(`${d.pfad}/${name}`));
      return li;
    }) : [Object.assign(document.createElement("li"), { className: "hint", textContent: "Keine Unterordner." })]));
  }

  $("sl-hoch").addEventListener("click", () => browserOben && oeffnen(browserOben));
  $("sl-zu").addEventListener("click", () => { $("sl-browser").hidden = true; });
  $("sl-hier").addEventListener("click", async () => {
    const d = await post("ziel_setzen", { pfad: browserPfad }).catch(() => null);
    if (!d) return;
    if (d.fehler) { $("sl-fehler").textContent = d.fehler; return; }
    $("sl-browser").hidden = true;
    zeigen(d);
  });
  $("sl-neu").addEventListener("click", async () => {
    const name = prompt("Name des neuen Ordners:", "Jarvis-Sicherungen");
    if (!name) return;
    const d = await post("neuer_ordner", { pfad: browserPfad, name }).catch(() => null);
    if (d && d.fehler) { $("sl-fehler").textContent = d.fehler; return; }
    if (d) oeffnen(d.pfad);
  });

  async function laden() {
    try { zeigen(await fetch("/api/eigene/sicherung/stand").then((r) => r.json())); } catch {}
  }
  laden();
  setInterval(() => { if (!document.hidden) laden(); }, 8000);  // Laufwerke kommen und gehen
  addEventListener("jarvis-home", () => { $("sl-browser").hidden = true; });
})();
