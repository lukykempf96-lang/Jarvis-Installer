from __future__ import annotations

import json
import time
from pathlib import Path

BESCHREIBUNG = "Notizfeld im Jarvis-Fenster: Lukas fügt dort Text, Links oder Kassenzettel per Kopieren und Einfügen ein"
PROMPT = (
    "Links im Jarvis-Fenster gibt es ein Notizfeld, in das Lukas Text, Links oder Kassenzettel einfügt. "
    "Spricht er von 'dem eingefügten Text', 'dem Notizfeld', 'dem Zettel', 'dem Link da' oder 'dem Kassenzettel', "
    "lies es mit notizfeld_lesen und besprich mit ihm, was damit passieren soll (z. B. zusammenfassen, Link öffnen, "
    "Kassenzettel ins Haushaltsbuch buchen, Einkaufsliste anlegen). Mit notizfeld_schreiben kannst du ein Ergebnis "
    "ins Feld schreiben, mit notizfeld_leeren leerst du es, wenn Lukas das will."
)

DATEI = Path(__file__).parent / "daten" / "notizfeld.json"
MAX_ZEICHEN = 50000


def _laden() -> dict:
    try:
        return json.loads(DATEI.read_text(encoding="utf-8"))
    except Exception:
        return {"text": "", "zeit": 0}


def _speichern(text: str) -> dict:
    daten = {"text": (text or "")[:MAX_ZEICHEN], "zeit": time.time()}
    DATEI.parent.mkdir(parents=True, exist_ok=True)
    DATEI.write_text(json.dumps(daten, ensure_ascii=False), encoding="utf-8")
    return daten


TOOLS = [
    {
        "name": "notizfeld_lesen",
        "description": "Liest, was Lukas ins Notizfeld im Jarvis-Fenster eingefügt hat (Text, Links, Kassenzettel).",
        "input_schema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "notizfeld_schreiben",
        "description": "Ersetzt den Inhalt des Notizfelds, z. B. mit einer Zusammenfassung oder aufbereiteten Liste.",
        "input_schema": {"type": "object", "properties": {
            "text": {"type": "string", "description": "Neuer Inhalt des Notizfelds"}}, "required": ["text"]},
    },
    {
        "name": "notizfeld_leeren",
        "description": "Leert das Notizfeld.",
        "input_schema": {"type": "object", "properties": {}, "required": []},
    },
]


def notizfeld_lesen() -> str:
    text = _laden().get("text", "").strip()
    if not text:
        return "Das Notizfeld ist leer."
    return "Inhalt des Notizfelds:\n" + text


def notizfeld_schreiben(text: str) -> str:
    _speichern(text)
    return "Ins Notizfeld geschrieben."


def notizfeld_leeren() -> str:
    _speichern("")
    return "Notizfeld geleert."


def stand() -> dict:
    return _laden()


def speichern(text: str = "") -> dict:
    return _speichern(text)


API = {"stand": stand, "speichern": speichern}
