"""Claude-Verbrauch fürs Dashboard: was Claude Code auf diesem Mac verbraucht hat, und ob gerade ein Limit greift.

Quelle sind die Gesprächsprotokolle von Claude Code (~/.claude/projects/**/*.jsonl). Darin steht pro Antwort,
wie viele Tokens sie gebraucht hat, und wenn ein Limit erreicht war, die Meldung mit der Uhrzeit, wann es wieder
geht. Die echten Kontingente (wie viel Prozent vom Abo verbraucht sind) stehen dort nicht; die zeigt nur Claude
selbst (/usage in Claude Code oder Einstellungen > Nutzung in der Claude-App). Verbrauch in der Claude-App oder auf
claude.ai zählt hier nicht mit, obwohl er vom selben Kontingent abgeht.

Wie Claude rechnet: Ein 5-Stunden-Fenster beginnt mit der ersten Anfrage (zur vollen Stunde abgerundet) und endet
5 Stunden später. Die Woche zählt hier gleitend die letzten 7 Tage.
"""

from __future__ import annotations

import json
import os
import re
import threading
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

BESCHREIBUNG = "Claude-Verbrauch: Tokens im aktuellen 5-Stunden-Fenster und der Woche, Limits und wann sie zurückgesetzt werden"
PROMPT = (
    "Fragt Lukas, wie viel Claude er noch hat, ob sein Kontingent leer ist oder ob Claude Code gerade Aufgaben "
    "annehmen kann, nutze claude_verbrauch. Sag ehrlich, dass die echten Prozentwerte nur Claude selbst unter "
    "/usage zeigt."
)

BLOCK = timedelta(hours=5)
TAGE = 8  # so weit zurück lesen
WOCHENTAGE = ["Mo", "Di", "Mi", "Do", "Fr", "Sa", "So"]

_lock = threading.Lock()
_cache: dict = {"dateien": {}, "eintraege": {}, "limits": [], "at": 0.0, "ergebnis": None}


def _ordner() -> list[Path]:
    basen = [Path(p).expanduser() for p in os.environ.get("CLAUDE_CONFIG_DIR", "").split(",") if p.strip()]
    basen += [Path.home() / ".claude", Path.home() / ".config" / "claude"]
    return [b / "projects" for b in basen if (b / "projects").is_dir()]


def _zeit(text: str) -> datetime | None:
    try:
        dt = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except (ValueError, AttributeError):
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone().replace(tzinfo=None)


def _text_von(nachricht: dict) -> str:
    inhalt = nachricht.get("content")
    if isinstance(inhalt, str):
        return inhalt
    if isinstance(inhalt, list):
        return " ".join(b.get("text", "") for b in inhalt if isinstance(b, dict))
    return ""


_RESET_TS = re.compile(r"limit reached\|(\d{9,11})", re.I)
_RESET_UHR = re.compile(r"reset[s]?\s+(?:at\s+)?(\d{1,2})(?::(\d{2}))?\s*(am|pm)?", re.I)


def _limit(text: str, wann: datetime) -> dict | None:
    """Erkennt eine Limit-Meldung von Claude Code und rechnet aus, wann es wieder geht."""
    low = text.lower()
    if "limit" not in low or not any(w in low for w in ("reached", "hit your", "erreicht", "usage limit")):
        return None
    frei = None
    m = _RESET_TS.search(text)
    if m:
        frei = datetime.fromtimestamp(int(m.group(1)))
    else:
        m = _RESET_UHR.search(text)
        if m:
            stunde, minute, ampm = int(m.group(1)), int(m.group(2) or 0), (m.group(3) or "").lower()
            if ampm == "pm" and stunde < 12:
                stunde += 12
            if ampm == "am" and stunde == 12:
                stunde = 0
            if stunde < 24 and minute < 60:
                frei = wann.replace(hour=stunde, minute=minute, second=0, microsecond=0)
                while frei <= wann:
                    frei += timedelta(days=1)
    art = "woche" if any(w in low for w in ("weekly", "week", "woche", "7-day", "opus limit")) else "fenster"
    return {"wann": wann, "frei": frei, "art": art, "text": " ".join(text.split())[:160]}


def _einlesen():
    """Liest nur, was seit dem letzten Mal dazugekommen ist (die Protokolle wachsen nur)."""
    grenze = time.time() - TAGE * 86400
    for basis in _ordner():
        for pfad in basis.rglob("*.jsonl"):
            try:
                st = pfad.stat()
            except OSError:
                continue
            if st.st_mtime < grenze:
                continue
            bekannt = _cache["dateien"].get(str(pfad), 0)
            if st.st_size == bekannt:
                continue
            start = bekannt if st.st_size > bekannt else 0
            try:
                with open(pfad, "rb") as f:
                    f.seek(start)
                    daten = f.read()
            except OSError:
                continue
            ende = daten.rfind(b"\n") + 1  # nur vollständige Zeilen, der Rest kommt beim nächsten Mal
            _cache["dateien"][str(pfad)] = start + ende
            for zeile in daten[:ende].splitlines():
                if b'"usage"' not in zeile and b"imit" not in zeile:
                    continue
                try:
                    e = json.loads(zeile)
                except ValueError:
                    continue
                wann = _zeit(e.get("timestamp", ""))
                nachricht = e.get("message") if isinstance(e.get("message"), dict) else {}
                if wann is None:
                    continue
                if e.get("isApiErrorMessage") or e.get("type") == "assistant" and "limit" in _text_von(nachricht).lower():
                    gefunden = _limit(_text_von(nachricht), wann)
                    if gefunden:
                        _cache["limits"].append(gefunden)
                nutzung = nachricht.get("usage")
                if e.get("type") != "assistant" or not isinstance(nutzung, dict):
                    continue
                schluessel = f"{nachricht.get('id')}:{e.get('requestId')}"
                rein = int(nutzung.get("input_tokens") or 0)
                raus = int(nutzung.get("output_tokens") or 0)
                cache_neu = int(nutzung.get("cache_creation_input_tokens") or 0)
                cache_lesen = int(nutzung.get("cache_read_input_tokens") or 0)
                if rein + raus + cache_neu + cache_lesen == 0:
                    continue
                _cache["eintraege"][schluessel] = (wann, rein + raus + cache_neu, cache_lesen,
                                                   str(nachricht.get("model") or ""))
    alt = datetime.now() - timedelta(days=TAGE)
    _cache["eintraege"] = {k: v for k, v in _cache["eintraege"].items() if v[0] >= alt}
    _cache["limits"] = [l for l in _cache["limits"] if l["wann"] >= alt][-50:]


def _bloecke(eintraege: list[tuple]) -> list[dict]:
    """5-Stunden-Fenster wie bei Claude: Start zur vollen Stunde der ersten Anfrage, Ende 5 Stunden später."""
    bloecke: list[dict] = []
    for wann, tokens, cache, _ in eintraege:
        b = bloecke[-1] if bloecke else None
        if b is None or wann >= b["ende"]:
            start = wann.replace(minute=0, second=0, microsecond=0)
            b = {"start": start, "ende": start + BLOCK, "tokens": 0, "cache": 0, "anfragen": 0, "zuletzt": wann}
            bloecke.append(b)
        b["tokens"] += tokens
        b["cache"] += cache
        b["anfragen"] += 1
        b["zuletzt"] = wann
    return bloecke


def _uhr(dt: datetime, jetzt: datetime) -> str:
    tage = (dt.date() - jetzt.date()).days
    tag = {0: "", 1: "morgen "}.get(tage, f"{WOCHENTAGE[dt.weekday()]} ")
    return f"{tag}{dt.strftime('%H:%M')} Uhr"


def _dauer(sekunden: float) -> str:
    minuten = max(0, round(sekunden / 60))
    std, mins = divmod(minuten, 60)
    return f"{std} Std {mins} Min" if std else f"{mins} Min"


def stand() -> dict:
    with _lock:
        if time.time() - _cache["at"] < 20 and _cache["ergebnis"]:
            return _cache["ergebnis"]
        _einlesen()
        jetzt = datetime.now()
        eintraege = sorted(_cache["eintraege"].values(), key=lambda e: e[0])
        bloecke = _bloecke(eintraege)
        aktuell = bloecke[-1] if bloecke and bloecke[-1]["ende"] > jetzt else None
        frueher = [b["tokens"] for b in bloecke if b is not aktuell]
        rekord = max(frueher + ([aktuell["tokens"]] if aktuell else []), default=0)

        woche_ab = jetzt - timedelta(days=7)
        woche = [e for e in eintraege if e[0] >= woche_ab]
        tage = []
        for i in range(6, -1, -1):
            tag = (jetzt - timedelta(days=i)).date()
            summe = sum(e[1] for e in woche if e[0].date() == tag)
            tage.append({"label": WOCHENTAGE[tag.weekday()], "tokens": summe, "heute": i == 0})

        limits = [l for l in _cache["limits"] if l["frei"] and l["frei"] > jetzt]
        sperre = max(limits, key=lambda l: l["frei"]) if limits else None
        letzte_meldung = _cache["limits"][-1] if _cache["limits"] else None

        ergebnis = {
            "gefunden": bool(_ordner()),
            "bereit": sperre is None,
            "sperre": None if sperre is None else {
                "art": sperre["art"], "frei": _uhr(sperre["frei"], jetzt),
                "noch": _dauer((sperre["frei"] - jetzt).total_seconds()), "text": sperre["text"]},
            "fenster": None if aktuell is None else {
                "tokens": aktuell["tokens"], "cache": aktuell["cache"], "anfragen": aktuell["anfragen"],
                "start": aktuell["start"].strftime("%H:%M"), "reset": _uhr(aktuell["ende"], jetzt),
                "noch": _dauer((aktuell["ende"] - jetzt).total_seconds()),
                "anteil_rekord": round(100 * aktuell["tokens"] / rekord) if rekord else 0},
            "rekord": rekord,
            "woche": {"tokens": sum(e[1] for e in woche), "cache": sum(e[2] for e in woche),
                      "anfragen": len(woche), "tage": tage,
                      "limit_erreicht": bool(sperre and sperre["art"] == "woche")},
            "letzte_limit_meldung": None if letzte_meldung is None else _uhr(letzte_meldung["wann"], jetzt)
            if letzte_meldung["wann"].date() == jetzt.date() else None,
            "zuletzt": _uhr(eintraege[-1][0], jetzt) if eintraege else None,
        }
        _cache.update(at=time.time(), ergebnis=ergebnis)
        return ergebnis


def _tokens(n: int) -> str:
    if n >= 1_000_000:
        return f"{n / 1_000_000:.1f} Millionen".replace(".", ",")
    if n >= 1000:
        return f"{round(n / 1000)} Tausend"
    return str(n)


TOOLS = [{
    "name": "claude_verbrauch",
    "description": "Claude-Verbrauch von Claude Code auf diesem Mac: Tokens im aktuellen 5-Stunden-Fenster und in den "
                   "letzten 7 Tagen, ob gerade ein Limit greift und wann es zurückgesetzt wird.",
    "input_schema": {"type": "object", "properties": {}, "required": []},
}]


def claude_verbrauch() -> str:
    s = stand()
    if not s["gefunden"]:
        return "Ich finde keine Claude-Code-Protokolle auf diesem Mac."
    teile = []
    if s["sperre"]:
        art = "Wochenlimit" if s["sperre"]["art"] == "woche" else "Limit des 5-Stunden-Fensters"
        teile.append(f"Das {art} ist erreicht, Claude Code geht wieder ab {s['sperre']['frei']} (in {s['sperre']['noch']}).")
    else:
        teile.append("Claude Code kann gerade Aufgaben annehmen, es ist kein Limit gemeldet.")
    f = s["fenster"]
    if f:
        teile.append(f"Im aktuellen 5-Stunden-Fenster seit {f['start']} Uhr: {_tokens(f['tokens'])} Tokens bei "
                     f"{f['anfragen']} Anfragen, zurückgesetzt um {f['reset']}.")
    else:
        teile.append("Gerade läuft kein 5-Stunden-Fenster, die nächste Aufgabe startet ein neues.")
    teile.append(f"In den letzten 7 Tagen: {_tokens(s['woche']['tokens'])} Tokens.")
    teile.append("Wie viel Prozent vom Abo das sind, zeigt nur Claude selbst unter /usage.")
    return " ".join(teile)


API = {"stand": stand}
