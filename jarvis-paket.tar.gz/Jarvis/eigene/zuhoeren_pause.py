"""Zuhören pausieren: Jarvis reagiert weder auf Sprache noch auf Klatschen oder "Hey Jarvis" und spricht nicht.

Ausschalten per Knopf im Fenster oder per Sprache ("Jarvis, hör auf zuzuhören"), einschalten nur per Knopf.
Der Zustand gilt, bis Jarvis neu startet. Im laufenden Server werden dafür einige Stellen umgeleitet:
Klatschen und "Hey Jarvis" lösen nichts aus (kein Ton, kein Zuhören, kein Start), und Meldungen im Hintergrund
(z. B. Claude Code fertig) erscheinen nur im Fenster, ohne vorgelesen zu werden.
"""

from __future__ import annotations

import asyncio
import sys
import time
import types

BESCHREIBUNG = "Zuhören pausieren: Jarvis hört nicht mehr zu und antwortet nicht, bis Lukas ihn per Knopf wieder einschaltet"
PROMPT = (
    "Sagt Lukas 'hör auf zuzuhören', 'Pause', 'schalt dich stumm' oder 'hör nicht mehr zu', nutze zuhoeren_pausieren "
    "und sag nur kurz, dass du jetzt pausierst und er dich mit dem Knopf im Fenster wieder einschaltet. "
    "Nicht bei 'danke' oder 'stopp', das beendet nur das Gespräch."
)

_halter = sys.modules.setdefault("_jarvis_zuhoeren_pause_halter", types.ModuleType("_jarvis_zuhoeren_pause_halter"))
if not hasattr(_halter, "pausiert"):
    _halter.pausiert = False
    _halter.seit = 0.0
    _halter.orig = {}


def pausiert() -> bool:
    return bool(_halter.pausiert)


def _setzen(wert: bool) -> dict:
    _halter.pausiert = bool(wert)
    _halter.seit = time.time()
    print("Jarvis pausiert: hört nicht mehr zu." if wert else "Jarvis hört wieder zu.", flush=True)
    return stand()


# ---------- Server umleiten (nur im laufenden Jarvis, nicht bei der Prüfung) ----------

def _einhaengen():
    main = sys.modules.get("backend.main")
    if main is None:
        return
    from backend import claude_code

    orig = _halter.orig
    for name in ("_signal_listening", "_notify_listen", "_startup_session"):
        if not getattr(getattr(main, name), "_jarvis_pause", False):
            orig[name] = getattr(main, name)
    if not getattr(claude_code.on_done, "_jarvis_pause", False) and claude_code.on_done is not None:
        orig["on_done"] = claude_code.on_done

    def signal_listening():
        if not pausiert():
            orig["_signal_listening"]()

    async def notify_listen():
        if pausiert():
            return 0
        return await orig["_notify_listen"]()

    def startup_session(*args, **kwargs):
        if not pausiert():
            orig["_startup_session"](*args, **kwargs)

    def on_done(text):
        if not pausiert():
            return orig["on_done"](text)
        print(f"Meldung (pausiert, nur angezeigt): {text}", flush=True)
        if main._loop:
            asyncio.run_coroutine_threadsafe(main._broadcast({"type": "notice", "text": text}), main._loop)

    for fn in (signal_listening, notify_listen, startup_session, on_done):
        fn._jarvis_pause = True
    main._signal_listening = signal_listening
    main._notify_listen = notify_listen
    main._startup_session = startup_session
    if "on_done" in orig:
        claude_code.on_done = on_done


_einhaengen()


# ---------- Für Jarvis und das Fenster ----------

TOOLS = [{
    "name": "zuhoeren_pausieren",
    "description": "Schaltet Jarvis' Zuhören aus: keine Reaktion mehr auf Sprache, Klatschen oder 'Hey Jarvis', bis Lukas "
                   "ihn mit dem Knopf im Jarvis-Fenster wieder einschaltet. Für 'hör auf zuzuhören', 'Pause'.",
    "input_schema": {"type": "object", "properties": {}, "required": []},
}]


def zuhoeren_pausieren() -> str:
    _setzen(True)
    return "Pausiert. Ich höre nicht mehr zu, bis Lukas mich mit dem Knopf im Jarvis-Fenster wieder einschaltet."


def stand() -> dict:
    return {"pausiert": pausiert(), "seit": _halter.seit}


def setzen(pausiert: bool = False) -> dict:
    if isinstance(pausiert, str):
        pausiert = pausiert.lower() in ("1", "true", "ja", "an")
    return _setzen(pausiert)


API = {"stand": stand, "setzen": setzen}
