# Jarvis fuer Windows installieren. Start: Doppelklick auf "Jarvis installieren.cmd".
$ErrorActionPreference = "Continue"
$Export = $PSScriptRoot
$Quelle = Join-Path $Export "Jarvis"
$Ziel = Join-Path $env:USERPROFILE "Jarvis"
$Utf8 = New-Object System.Text.UTF8Encoding($false)

function Stopp($text) { Write-Host ""; Write-Host $text -ForegroundColor Yellow; Read-Host "Zum Schliessen Enter druecken"; exit 1 }
function Ok($text) { Write-Host "OK  $text" -ForegroundColor Green }
function JaNein($text) { $a = Read-Host "$text [j/n]"; return ($a -match '^[jJyY]') }
function Geheim($text) {
    $s = Read-Host $text -AsSecureString
    $b = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($s)
    try { return [Runtime.InteropServices.Marshal]::PtrToStringAuto($b).Trim() } finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($b) }
}
function PfadNeu { $env:Path = [Environment]::GetEnvironmentVariable("Path", "Machine") + ";" + [Environment]::GetEnvironmentVariable("Path", "User") }
function FindePython {
    foreach ($v in @("3.11", "3.12")) {
        try {
            $p = & py "-$v" -c "import sys; print(sys.executable)" 2>$null
            if ($LASTEXITCODE -eq 0 -and $p) { return ($p | Select-Object -First 1).Trim() }
        } catch {}
    }
    foreach ($p in @("$env:LOCALAPPDATA\Programs\Python\Python311\python.exe", "$env:LOCALAPPDATA\Programs\Python\Python312\python.exe")) {
        if (Test-Path $p) { return $p }
    }
    return $null
}

Clear-Host
Write-Host "=============================================="
Write-Host "   Jarvis fuer Windows installieren"
Write-Host "=============================================="
Write-Host ""

# 1. Python 3.11 (Pakete wie "Hey Jarvis" gibt es dafuer sicher fertig)
$Py = FindePython
if (-not $Py) {
    if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
        Start-Process "https://www.python.org/downloads/release/python-3119/"
        Stopp "Python fehlt. Bitte Python 3.11 von python.org installieren (Haken bei 'Add python.exe to PATH') und diese Datei nochmal starten."
    }
    Write-Host "Python 3.11 wird installiert ..."
    winget install -e --id Python.Python.3.11 --scope user --accept-package-agreements --accept-source-agreements
    PfadNeu
    $Py = FindePython
    if (-not $Py) { Stopp "Python ist installiert, wird aber noch nicht gefunden. Bitte den PC neu starten und diese Datei nochmal starten." }
}
Ok "Python: $Py"

# 2. Google Chrome (Jarvis-Fenster und Spracherkennung)
$Chrome = @("$env:ProgramFiles\Google\Chrome\Application\chrome.exe", "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
            "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $Chrome) {
    if (Get-Command winget -ErrorAction SilentlyContinue) {
        Write-Host "Google Chrome wird installiert ..."
        winget install -e --id Google.Chrome --accept-package-agreements --accept-source-agreements
    } else {
        Start-Process "https://www.google.com/chrome/"
        Stopp "Bitte Google Chrome installieren und diese Datei nochmal starten."
    }
}
Ok "Google Chrome vorhanden"

# 3. Programm an seinen Platz kopieren
if (Test-Path $Ziel) { Stopp "Es gibt schon den Ordner $Ziel. Damit nichts ueberschrieben wird, bitte ihn erst umbenennen oder loeschen." }
Copy-Item -Recurse $Quelle $Ziel
Get-ChildItem -Recurse -File $Ziel | Unblock-File
Set-Location $Ziel
Ok "Jarvis nach $Ziel kopiert"

# 4. Programmteile installieren
Write-Host ""
Write-Host "Jetzt werden die Programmteile geladen. Das dauert 5 bis 15 Minuten ..."
& $Py -m venv venv
$VPy = Join-Path $Ziel "venv\Scripts\python.exe"
if (-not (Test-Path $VPy)) { Stopp "Die Python-Umgebung liess sich nicht anlegen." }
& $VPy -m pip install --upgrade pip -q
& $VPy -m pip install -r requirements-windows.txt -q
if ($LASTEXITCODE -ne 0) { Stopp "Die Python-Pakete liessen sich nicht installieren (Fehler siehe oben)." }
& $VPy -m playwright install chromium
& $VPy -c "import openwakeword.utils as u; u.download_models(['hey_jarvis'])" 2>$null
Ok "Programmteile installiert"

# 5. Persoenliche Einstellungen (.env)
Write-Host ""
Write-Host "=== Deine Einstellungen ==="
$Name = Read-Host "Wie heisst du? (so spricht Jarvis dich an)"
if (-not $Name) { $Name = "Chef" }
$Stadt = Read-Host "Deine Stadt (fuer Wetter und Wege)"
if (-not $Stadt) { $Stadt = "Berlin" }
Write-Host ""
Write-Host "Anthropic-Schluessel (das Gehirn, kostet je nach Nutzung ein paar Euro im Monat):"
Write-Host "console.anthropic.com -> API Keys -> Create Key -> kopieren. Hier mit Rechtsklick einfuegen (man sieht nichts)."
$Key = Geheim "Anthropic-Schluessel"
Write-Host ""
$Eleven = Geheim "ElevenLabs-Schluessel fuer die Jarvis-Stimme (freiwillig, sonst einfach Enter)"
Write-Host ""
Write-Host "Mails, Kalender, Kontakte und Aufgaben:"
Write-Host "  1 = klassisches Outlook fuer Windows ist installiert und eingerichtet (empfohlen, dann geht alles)"
Write-Host "  2 = ohne Outlook: Mails ueber IMAP (Gmail, GMX, web.de ...), Kalender nur lesen ueber einen Kalender-Link"
$Wahl = Read-Host "1 oder 2"
$Mail = "outlook"; $Imap = ""; $ImapUser = ""; $ImapPw = ""; $Ics = ""; $Aufgaben = ""
if ($Wahl -eq "2") {
    $Mail = "imap"; $Aufgaben = "lokal"
    $Imap = Read-Host "IMAP-Server (z. B. imap.gmail.com, imap.gmx.net, imap.web.de)"
    $ImapUser = Read-Host "Mailadresse"
    Write-Host "Bei Gmail ein App-Passwort nehmen: myaccount.google.com -> Sicherheit -> App-Passwoerter."
    $ImapPw = Geheim "Passwort bzw. App-Passwort"
    Write-Host "Kalender-Link (freiwillig). Google Kalender: Einstellungen -> dein Kalender -> 'Privatadresse im iCal-Format'."
    $Ics = Read-Host "Kalender-Link"
}
$EnvText = @"
# Jarvis-Einstellungen. Aendern mit "Einstellungen bearbeiten.cmd", danach Jarvis neu starten.
ANTHROPIC_API_KEY=$Key
ELEVENLABS_API_KEY=$Eleven
ELEVENLABS_VOICE_ID=rDmv3mOhK6TnhYWckFaD
CLAUDE_MODEL=claude-sonnet-5-5
JARVIS_FAST_MODEL=claude-haiku-4-5
JARVIS_EFFORT=low
JARVIS_NAME=$Name
JARVIS_CITY=$Stadt
JARVIS_WIN_VOICE=
JARVIS_STARTUP_APPS=
JARVIS_PROJECTS_DIR=~/Projekte
JARVIS_PORT=8000
JARVIS_HOST=0.0.0.0
JARVIS_MAIL=$Mail
JARVIS_AUFGABEN=$Aufgaben
JARVIS_IMAP_SERVER=$Imap
JARVIS_IMAP_USER=$ImapUser
JARVIS_IMAP_PASSWORT=$ImapPw
JARVIS_KALENDER_ICS=$Ics
"@
[IO.File]::WriteAllText((Join-Path $Ziel ".env"), $EnvText, $Utf8)
icacls (Join-Path $Ziel ".env") /inheritance:r /grant:r "${env:USERNAME}:(F)" | Out-Null
$Key = $null; $ImapPw = $null; $Eleven = $null
Ok "Einstellungen gespeichert (nur fuer dein Windows-Konto lesbar)"

# Namen in Jarvis' Bauanleitung und den eigenen Funktionen einsetzen
$Gen = if ($Name -match '[sxzß]$') { "$Name'" } else { "${Name}s" }
$Dateien = @(Join-Path $Ziel "CLAUDE.md") + (Get-ChildItem (Join-Path $Ziel "eigene") -File -Include *.js, *.py -Recurse | ForEach-Object { $_.FullName })
foreach ($f in $Dateien) {
    $t = [IO.File]::ReadAllText($f, [Text.Encoding]::UTF8)
    [IO.File]::WriteAllText($f, $t.Replace("Lukas'", $Gen).Replace("Lukas", $Name), $Utf8)
}

# 6. Startdateien und Verknuepfungen
Set-Content -Encoding ASCII (Join-Path $Ziel "Jarvis starten.cmd") @'
@echo off
title Jarvis
cd /d "%~dp0"
set PYTHONUTF8=1
"venv\Scripts\python.exe" -m backend.clap_daemon
pause
'@
Set-Content -Encoding ASCII (Join-Path $Ziel "Jarvis neu starten.cmd") @'
@echo off
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match 'backend\.(clap_daemon|main)' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }"
timeout /t 1 >nul
start "" "%~dp0Jarvis starten.cmd"
'@
Set-Content -Encoding ASCII (Join-Path $Ziel "Einstellungen bearbeiten.cmd") @'
@echo off
start "" notepad "%~dp0.env"
'@
$Shell = New-Object -ComObject WScript.Shell
function Verknuepfung($ordner) {
    $l = $Shell.CreateShortcut((Join-Path $ordner "Jarvis.lnk"))
    $l.TargetPath = Join-Path $Ziel "Jarvis starten.cmd"
    $l.WorkingDirectory = $Ziel
    $l.WindowStyle = 7
    $l.Save()
}
Verknuepfung ([Environment]::GetFolderPath("Desktop"))
Ok "Verknuepfung 'Jarvis' auf dem Desktop angelegt"
if (JaNein "Jarvis automatisch beim Anmelden starten?") {
    Verknuepfung ([Environment]::GetFolderPath("Startup"))
    Ok "Startet ab jetzt beim Anmelden"
}

# 7. Berechtigungen
Write-Host ""
Write-Host "=== Fast fertig ==="
Write-Host "* Mikrofon: Einstellungen -> Datenschutz und Sicherheit -> Mikrofon -> 'Desktop-Apps den Zugriff erlauben' einschalten."
Write-Host "* Beim ersten Start fragt die Windows-Firewall nach Python: 'Private Netzwerke' erlauben"
Write-Host "  (fuer Handy-Anzeige und Handy-Mikro im WLAN). Wer das nicht braucht, kann ablehnen."
Write-Host "* Chrome fragt im Jarvis-Fenster nach dem Mikrofon: erlauben."
Write-Host "* Anrufen: die App 'Smartphone-Link' mit dem Handy verbinden."
if (JaNein "Mikrofon-Einstellungen jetzt oeffnen?") { Start-Process "ms-settings:privacy-microphone" }
Write-Host ""
Write-Host "Fertig! Was persoenlich ist und was unter Windows anders geht, steht in FUNKTIONEN.txt."
if (JaNein "Jarvis jetzt starten?") { Start-Process (Join-Path $Ziel "Jarvis starten.cmd") -WorkingDirectory $Ziel }
