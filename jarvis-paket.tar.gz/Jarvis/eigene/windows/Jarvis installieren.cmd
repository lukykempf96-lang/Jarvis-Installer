@echo off
rem Jarvis fuer Windows installieren: startet install.ps1 (PowerShell) aus diesem Ordner.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
if errorlevel 1 pause
