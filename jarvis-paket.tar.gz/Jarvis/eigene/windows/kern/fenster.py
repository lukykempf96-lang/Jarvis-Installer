"""Das Jarvis-Fenster in Chrome oeffnen und nach vorne holen (Windows-Fassung).

Am Mac steuert Jarvis Chrome per AppleScript (Tab suchen, neu laden, doppelte schliessen). Das geht unter
Windows nicht: Jarvis oeffnet einen Tab und holt das Fenster ueber den Fenstertitel nach vorne. Doppelte Tabs
schaltet der Server weiterhin stumm (nur ein Tab ist aktiv), schliessen muss man sie selbst.
"""
from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path

import psutil

from . import plattform

CHROME_PATHS = [
    Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "Google/Chrome/Application/chrome.exe",
    Path(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")) / "Google/Chrome/Application/chrome.exe",
    Path(os.environ.get("LOCALAPPDATA", "")) / "Google/Chrome/Application/chrome.exe",
]


def _chrome() -> str | None:
    for path in CHROME_PATHS:
        if path.is_file():
            return str(path)
    return shutil.which("chrome")


def chrome_running() -> bool:
    return any((p.info.get("name") or "").lower() == "chrome.exe" for p in psutil.process_iter(["name"]))


def open_jarvis(url: str) -> str:
    chrome = _chrome()
    if chrome:
        subprocess.Popen([chrome, url], creationflags=plattform.NO_WINDOW)
    else:  # ohne Chrome im Standardbrowser (die Spracherkennung braucht aber Chrome oder Edge)
        plattform.open_uri(url)
    return "opened"


def show(tab: str = ""):
    """Holt das Fenster mit dem Titel "Jarvis" nach vorne."""
    try:
        plattform.powershell("(New-Object -ComObject WScript.Shell).AppActivate('Jarvis') | Out-Null", timeout=8)
    except (OSError, subprocess.SubprocessError):
        pass


def close_tab(tab: str) -> str | None:
    return None  # Chrome laesst sich unter Windows nicht fernsteuern
