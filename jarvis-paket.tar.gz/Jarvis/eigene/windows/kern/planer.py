"""Termine und Aufgaben anlegen, Kontakte zeigen, anrufen, Websites und Programme oeffnen (Windows-Fassung).

Termine und Aufgaben gehen in das klassische Outlook (bei einem Microsoft-Konto auch in Microsoft To Do und aufs
Handy). Ohne Outlook fuehrt Jarvis Listen wie die Einkaufsliste selbst (listen.json, nur auf diesem PC).
Kontakte kommen aus Outlook. Angerufen wird ueber einen tel:-Link, den die App Smartphone-Link uebernimmt.
Programme findet Jarvis im Startmenue (auch deutsche Namen).
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import threading
import time
import unicodedata
import uuid
import webbrowser
from datetime import datetime, timedelta
from difflib import get_close_matches
from pathlib import Path
from urllib.parse import quote, urlparse

from . import alltag, plattform

WEEKDAYS = alltag.WEEKDAYS
MONTHS = ["Januar", "Februar", "Maerz", "April", "Mai", "Juni", "Juli", "August", "September",
          "Oktober", "November", "Dezember"]
JARVIS_DIR = Path(__file__).resolve().parent.parent
LISTS_FILE = JARVIS_DIR / "listen.json"
CONTACTS_HINT = ("Kontakte lese ich unter Windows aus dem klassischen Outlook. Das ist nicht erreichbar oder "
                 "nicht eingerichtet.")


def _norm(text: str) -> str:
    text = (text or "").lower()
    for umlaut, plain in (("ä", "ae"), ("ö", "oe"), ("ü", "ue"), ("ß", "ss")):
        text = text.replace(umlaut, plain)
    text = "".join(ch for ch in unicodedata.normalize("NFKD", text) if not unicodedata.combining(ch))
    return " ".join("".join(ch if ch.isalnum() else " " for ch in text).split())


def _when(dt: datetime, with_time: bool = True) -> str:
    today = datetime.now()
    days = (dt.date() - today.date()).days
    day = {0: "heute", 1: "morgen", 2: "uebermorgen"}.get(days) or f"{WEEKDAYS[dt.weekday()]}, {dt.day}. {MONTHS[dt.month - 1]}"
    if dt.year != today.year and days > 2:
        day += f" {dt.year}"
    return f"{day} um {dt.strftime('%H:%M')} Uhr" if with_time else day


def _parse(value: str, field: str) -> tuple[datetime, bool]:
    text = (value or "").strip().replace(" ", "T")
    if not text:
        raise ValueError(f"{field} fehlt")
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        dt = datetime.fromisoformat(text)
    except ValueError:
        raise ValueError(f"{field} '{value}' bitte als 2026-10-06T14:00 angeben") from None
    if dt.tzinfo is not None:
        dt = dt.astimezone().replace(tzinfo=None)
    return dt, "T" in text


def _dashboard_stale(section: str):
    try:
        from . import dashboard

        dashboard._sections[section]["at"] = 0.0
    except Exception:
        pass


def _similar(a: str, b: str) -> bool:
    if not a or not b:
        return False
    if a in b or b in a:
        return True
    common = 0
    for x, y in zip(a, b):
        if x != y:
            break
        common += 1
    return common >= 5 and common >= 0.7 * min(len(a), len(b))


def _pick_by_name(candidates: list, name: str, title=lambda c: c):
    wanted = _norm(name)
    for test in (lambda t: t == wanted, lambda t: wanted in t, lambda t: _similar(wanted, t)):
        for c in candidates:
            if test(_norm(title(c))):
                return c
    return None


# ---------------------------------------------------------------- Kalender (Outlook)

def _calendars(ns) -> list:
    found = []
    for folder in alltag._default_folders(ns, 9):
        found.append(folder)
        try:
            found += list(folder.Folders)
        except Exception:
            pass
    return found


def add_event(title: str, start: str, end: str = "", duration_min: int | None = None, location: str = "",
              notes: str = "", calendar: str = "", alert_min: int | None = None) -> str:
    title = (title or "").strip() or "Termin"
    try:
        begin, timed = _parse(start, "Beginn")
        if end:
            finish, end_timed = _parse(end, "Ende")
            if not end_timed:
                finish += timedelta(days=1)
        elif timed:
            finish = begin + timedelta(minutes=int(duration_min or 60))
        else:
            finish = begin + timedelta(days=1)
    except (TypeError, ValueError) as exc:
        return f"Termin nicht eingetragen: {exc}."
    if finish <= begin:
        return "Termin nicht eingetragen: Das Ende liegt vor dem Beginn."
    try:
        ns = alltag.outlook()
    except alltag.PermissionMissing:
        return "Termine trage ich in das klassische Outlook ein, das ist hier nicht erreichbar oder nicht eingerichtet."
    cals = _calendars(ns)
    folder = (_pick_by_name(cals, calendar, lambda c: str(c.Name)) if calendar else None) or (cals[0] if cals else None)
    if folder is None:
        return "Ich finde in Outlook keinen Kalender."
    try:
        item = folder.Items.Add(1)  # Termin
        item.Subject = title
        item.AllDayEvent = not timed
        item.Start = alltag.com_text(begin)
        item.End = alltag.com_text(finish)
        if location:
            item.Location = location
        if notes:
            item.Body = notes
        if alert_min is not None and timed:
            item.ReminderSet = True
            item.ReminderMinutesBeforeStart = max(0, int(alert_min))
        else:
            item.ReminderSet = False
        item.Save()
    except Exception as exc:
        return f"Outlook hat den Termin nicht angenommen ({exc})."
    _dashboard_stale("calendar")
    if timed:
        when = _when(begin) + (f" bis {finish.strftime('%H:%M')} Uhr" if finish.date() == begin.date() else "")
    else:
        last = finish - timedelta(days=1)
        when = _when(begin, False) + (f" bis {_when(last, False)}" if last.date() > begin.date() else "") + ", ganztaegig"
    past = " Achtung, das liegt in der Vergangenheit." if finish < datetime.now() else ""
    return (f"Eingetragen: {title}, {when}" + (f", Ort {location}" if location else "")
            + (f", Erinnerung {int(alert_min)} Minuten vorher" if alert_min is not None and timed else "")
            + f" (Kalender {folder.Name}).{past}")


def _matching_events(ns, query: str, day: str) -> list:
    words = _norm(query).split()
    if day:
        start = _parse(day, "Tag")[0].replace(hour=0, minute=0, second=0, microsecond=0)
        end = start + timedelta(days=1)
    else:
        start = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0) - timedelta(days=1)
        end = start + timedelta(days=120)
    found = []
    for folder in _calendars(ns):
        try:
            items = folder.Items
            items.IncludeRecurrences = True
            items.Sort("[Start]")
            items = alltag.restrict_between(items, "Start", "End", start, end)
        except Exception:
            continue
        e, guard = items.GetFirst(), 0
        while e is not None and guard < 3000:
            guard += 1
            try:
                s = alltag.com_time(e.Start)
                if s > end:
                    break
                if s >= start - timedelta(days=1) and all(w in _norm(e.Subject or "") for w in words):
                    found.append(e)
            except Exception:
                pass
            e = items.GetNext()
    found.sort(key=lambda e: alltag.com_time(e.Start))
    return found


def change_event(query: str, day: str = "", new_title: str = "", new_start: str = "", new_end: str = "",
                 new_day: str = "", shift_min: int | None = None, new_location: str = "", delete: bool = False) -> str:
    try:
        ns = alltag.outlook()
    except alltag.PermissionMissing:
        return alltag.OUTLOOK_HINT
    try:
        found = _matching_events(ns, query, day)
    except ValueError as exc:
        return f"Nichts geaendert: {exc}."
    if not found:
        return f"Ich finde keinen Termin mit '{query}'" + (" an dem Tag." if day else " in den naechsten Monaten.")
    if len(found) > 1:
        lines = [f"{e.Subject} {_when(alltag.com_time(e.Start), not e.AllDayEvent)}" for e in found[:6]]
        return "Mehrere Termine passen, frag Lukas welcher (oder gib den Tag mit): " + "; ".join(lines) + "."
    event = found[0]
    old_title = str(event.Subject or "Termin")
    old_start, old_end = alltag.com_time(event.Start), alltag.com_time(event.End)
    all_day = bool(event.AllDayEvent)
    if delete:
        try:
            event.Delete()
        except Exception as exc:
            return f"Konnte den Termin nicht loeschen ({exc})."
        _dashboard_stale("calendar")
        return f"Geloescht: {old_title}, {_when(old_start, not all_day)}."
    length = old_end - old_start
    try:
        if new_start:
            begin, timed = _parse(new_start, "Neuer Beginn")
            if new_end:
                finish = _parse(new_end, "Neues Ende")[0]
            elif timed:
                finish = begin + (length if not all_day else timedelta(hours=1))
            else:
                finish = begin + timedelta(days=max(1, round(length.total_seconds() / 86400)))
            all_day = not timed
        elif new_day:
            target = _parse(new_day, "Neuer Tag")[0]
            begin = old_start.replace(year=target.year, month=target.month, day=target.day)
            finish = begin + length
        elif shift_min:
            begin, finish = old_start + timedelta(minutes=int(shift_min)), old_end + timedelta(minutes=int(shift_min))
        else:
            begin = old_start
            finish = _parse(new_end, "Neues Ende")[0] if new_end else old_end
    except ValueError as exc:
        return f"Nichts geaendert: {exc}."
    if finish <= begin:
        return "Nichts geaendert: Das Ende laege vor dem Beginn."
    try:
        event.AllDayEvent = all_day
        event.Start = alltag.com_text(begin)
        event.End = alltag.com_text(finish)
        if new_title:
            event.Subject = new_title
        if new_location:
            event.Location = new_location
        event.Save()
    except Exception as exc:
        return f"Outlook hat die Aenderung nicht angenommen ({exc})."
    _dashboard_stale("calendar")
    return f"Geaendert: {new_title or old_title}, jetzt {_when(begin, not all_day)}."


# ---------------------------------------------------------------- Aufgaben und Listen (Outlook oder eigene Liste)

class _OutlookTasks:
    """Aufgaben-Ordner in Outlook: der Standardordner und seine Unterordner sind die Listen."""

    label = "Outlook-Aufgaben"

    def __init__(self):
        self.root = alltag.outlook().GetDefaultFolder(13)

    def lists(self) -> list:
        found = [self.root]
        try:
            found += list(self.root.Folders)
        except Exception:
            pass
        return found

    @staticmethod
    def name(handle) -> str:
        return str(handle.Name)

    def default(self):
        return self.root

    def items(self, lists=None) -> list[dict]:
        out = []
        for folder in lists or self.lists():
            try:
                entries = folder.Items
                count = entries.Count
            except Exception:
                continue
            for i in range(1, count + 1):
                try:
                    t = entries.Item(i)
                    if t.Class != 48 or t.Complete:
                        continue
                    due, timed = None, False
                    if t.ReminderSet:
                        due, timed = alltag.com_time(t.ReminderTime), True
                    else:
                        d = alltag.com_time(t.DueDate)
                        if d.year < 4000:  # 4501 heisst: ohne Termin
                            due = d
                    out.append({"title": t.Subject or "Aufgabe", "due": due, "timed": timed,
                                "list": str(folder.Name), "ref": t})
                except Exception:
                    continue
        return out

    @staticmethod
    def _set_due(t, when: datetime | None, timed: bool):
        if when is None:
            return
        t.DueDate = alltag.com_text(when, False)
        t.ReminderSet = bool(timed)
        if timed:
            t.ReminderTime = alltag.com_text(when)

    def add(self, handle, title: str, when, timed: bool, notes: str):
        t = handle.Items.Add(3)  # Aufgabe
        t.Subject = title
        if notes:
            t.Body = notes
        self._set_due(t, when, timed)
        t.Save()

    def complete(self, item: dict):
        item["ref"].MarkComplete()
        item["ref"].Save()

    def delete(self, item: dict):
        item["ref"].Delete()

    def update(self, item: dict, title: str, when, timed: bool, target):
        t = item["ref"]
        if title:
            t.Subject = title
        self._set_due(t, when, timed)
        t.Save()
        if target is not None:
            t.Move(target)

    def create_list(self, name: str):
        return self.root.Folders.Add(name.strip(), 13)


_local_lock = threading.Lock()


class _LocalTasks:
    """Ohne Outlook: Listen in listen.json im Jarvis-Ordner (nur auf diesem PC, ohne Erinnerungston)."""

    label = "Jarvis-Listen"

    def __init__(self):
        try:
            self.data = json.loads(LISTS_FILE.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            self.data = {}
        self.data.setdefault("Erinnerungen", [])

    def _save(self):
        tmp = LISTS_FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(self.data, ensure_ascii=False, indent=1), encoding="utf-8")
        os.replace(tmp, LISTS_FILE)

    def lists(self) -> list:
        return list(self.data)

    @staticmethod
    def name(handle) -> str:
        return handle

    def default(self):
        return "Erinnerungen"

    def items(self, lists=None) -> list[dict]:
        out = []
        for name in lists or self.lists():
            for e in self.data.get(name, []):
                due = datetime.fromisoformat(e["due"]) if e.get("due") else None
                out.append({"title": e["title"], "due": due, "timed": bool(e.get("timed")), "list": name,
                            "ref": (name, e["id"])})
        return out

    def _entry(self, item: dict) -> dict:
        name, ident = item["ref"]
        return next(e for e in self.data[name] if e["id"] == ident)

    def add(self, handle, title: str, when, timed: bool, notes: str):
        self.data[handle].append({"id": uuid.uuid4().hex[:10], "title": title, "notes": notes,
                                  "due": when.isoformat() if when else None, "timed": timed})
        self._save()

    def complete(self, item: dict):
        self.delete(item)

    def delete(self, item: dict):
        name, ident = item["ref"]
        self.data[name] = [e for e in self.data[name] if e["id"] != ident]
        self._save()

    def update(self, item: dict, title: str, when, timed: bool, target):
        entry = self._entry(item)
        if title:
            entry["title"] = title
        if when is not None:
            entry["due"], entry["timed"] = when.isoformat(), timed
        if target is not None and target != item["list"]:
            self.data[item["list"]].remove(entry)
            self.data[target].append(entry)
        self._save()

    def create_list(self, name: str):
        self.data.setdefault(name.strip(), [])
        self._save()
        return name.strip()


def _tasks():
    choice = os.environ.get("JARVIS_AUFGABEN", "").lower()
    if choice != "lokal" and (choice == "outlook" or alltag.has_outlook()):
        try:
            return _OutlookTasks()
        except Exception:
            if choice == "outlook":
                raise
    return _LocalTasks()


def _find_list(store, name: str):
    return _pick_by_name(store.lists(), name, store.name) if name else None


def _list_names(store) -> str:
    return ", ".join(store.name(h) for h in store.lists()) or "keine"


def _item_line(item: dict) -> str:
    return f"{item['title']} ({_when(item['due'], item['timed'])})" if item["due"] else item["title"]


def _sorted(items: list[dict]) -> list[dict]:
    return sorted(items, key=lambda i: (i["due"] or datetime.max, _norm(i["title"])))


def due_items(until: datetime) -> list[dict]:
    """Fuers Dashboard: offene Eintraege, die bis `until` faellig sind."""
    with _local_lock:
        store = _tasks()
        items = [i for i in store.items() if i["due"] and i["due"] <= until]
    return [{"title": i["title"], "due": i["due"], "has_time": i["timed"]} for i in _sorted(items)]


def get_reminder_list(list_name: str = "") -> str:
    with _local_lock:
        store = _tasks()
        if list_name:
            handle = _find_list(store, list_name)
            if handle is None:
                return f"Keine Liste '{list_name}'. Vorhanden: {_list_names(store)}."
            items = _sorted(store.items([handle]))
            if not items:
                return f"Die Liste {store.name(handle)} ist leer, alles erledigt."
            return f"{store.name(handle)}, {len(items)} offen: " + ", ".join(_item_line(i) for i in items[:40]) + "."
        parts = []
        everything = store.items()
        for handle in store.lists():
            mine = _sorted([i for i in everything if i["list"] == store.name(handle)])
            if mine:
                preview = ", ".join(_item_line(i) for i in mine[:5]) + (" und mehr" if len(mine) > 5 else "")
                parts.append(f"{store.name(handle)} ({len(mine)} offen: {preview})")
            else:
                parts.append(f"{store.name(handle)} (leer)")
        return "Listen: " + "; ".join(parts) + "." if parts else "Es gibt noch keine Listen."


def add_reminder(title: str = "", due: str = "", list_name: str = "", notes: str = "",
                 items: list | None = None, create_list: bool = False) -> str:
    titles = [str(t).strip() for t in (items or []) if str(t).strip()] or ([title.strip()] if (title or "").strip() else [])
    if not titles:
        return "Woran soll ich erinnern? Der Text fehlt."
    try:
        when, timed = _parse(due, "Zeitpunkt") if due else (None, False)
    except ValueError as exc:
        return f"Erinnerung nicht angelegt: {exc}."
    with _local_lock:
        store = _tasks()
        if list_name:
            handle = _find_list(store, list_name)
            if handle is None and create_list:
                try:
                    handle = store.create_list(list_name)
                except Exception as exc:
                    return f"Die Liste {list_name} liess sich nicht anlegen ({exc})."
            if handle is None:
                return (f"Es gibt keine Liste '{list_name}'. Vorhanden: {_list_names(store)}. "
                        "Frag Lukas, ob du eine davon nehmen oder die Liste neu anlegen sollst (create_list).")
        else:
            handle = store.default()
        saved, failed = [], ""
        for text in titles[:30]:
            try:
                store.add(handle, text, when, timed, notes)
                saved.append(text)
            except Exception as exc:
                failed = f" ({exc})"
    if not saved:
        return f"Das hat nicht geklappt{failed}."
    _dashboard_stale("reminders")
    where = store.name(handle)
    past = " Achtung, der Zeitpunkt liegt in der Vergangenheit." if when and timed and when < datetime.now() else ""
    missing = f" Nicht geklappt bei den restlichen{failed}." if failed else ""
    phone = " Sie kommt ueber das Outlook-Konto auch aufs Handy." if store.label.startswith("Outlook") else ""
    if len(saved) > 1:
        return f"Auf {where}: {', '.join(saved)}.{missing}"
    return (f"Erinnerung angelegt: {saved[0]}" + (f", {_when(when, timed)}" if when else "")
            + f" (Liste {where}).{phone}{past}{missing}")


def _pick(store, query: str, list_name: str):
    lists = None
    if list_name:
        handle = _find_list(store, list_name)
        if handle is None:
            return None, f"Keine Liste '{list_name}'. Vorhanden: {_list_names(store)}."
        lists = [handle]
    words = _norm(query).split()
    found = [i for i in store.items(lists) if all(w in _norm(i["title"]) for w in words)]
    exact = [i for i in found if _norm(i["title"]) == _norm(query)]
    if len(exact) == 1:
        found = exact
    if not found:
        return None, f"Keine offene Erinnerung mit '{query}' gefunden" + (f" auf {list_name}." if list_name else ".")
    if len(found) > 1:
        return None, "Mehrere Erinnerungen passen, frag Lukas welche: " + "; ".join(
            f"{i['title']} ({i['list']})" for i in found[:6]) + "."
    return found[0], None


def complete_reminder(query: str = "", list_name: str = "", everything: bool = False) -> str:
    with _local_lock:
        store = _tasks()
        if everything:
            if not list_name:
                return "Welche Liste soll ich komplett abhaken?"
            handle = _find_list(store, list_name)
            if handle is None:
                return f"Keine Liste '{list_name}'. Vorhanden: {_list_names(store)}."
            items = store.items([handle])
            if not items:
                return f"Auf {store.name(handle)} ist nichts mehr offen."
            for item in items:
                store.complete(item)
            _dashboard_stale("reminders")
            return f"Alle {len(items)} auf {store.name(handle)} abgehakt."
        if not (query or "").strip():
            return "Was soll ich abhaken?"
        item, problem = _pick(store, query, list_name)
        if item is None:
            return problem
        try:
            store.complete(item)
        except Exception as exc:
            return f"Konnte sie nicht abhaken ({exc})."
    _dashboard_stale("reminders")
    return f"Erledigt und abgehakt: {item['title']}."


def change_reminder(query: str, list_name: str = "", new_title: str = "", due: str = "", move_to: str = "",
                    delete: bool = False) -> str:
    with _local_lock:
        store = _tasks()
        item, problem = _pick(store, query, list_name)
        if item is None:
            return problem
        if delete:
            try:
                store.delete(item)
            except Exception as exc:
                return f"Konnte {item['title']} nicht loeschen ({exc})."
            _dashboard_stale("reminders")
            return f"Geloescht: {item['title']} (Liste {item['list']})."
        target = None
        if move_to:
            target = _find_list(store, move_to)
            if target is None:
                return f"Keine Liste '{move_to}'. Vorhanden: {_list_names(store)}."
        try:
            when = _parse(due, "Zeitpunkt") if due else None
        except ValueError as exc:
            return f"Nichts geaendert: {exc}."
        if not (new_title or "").strip() and when is None and target is None:
            return "Was soll ich an der Erinnerung aendern?"
        try:
            store.update(item, (new_title or "").strip(), when[0] if when else None, when[1] if when else False, target)
        except Exception as exc:
            return f"Die Aenderung hat nicht geklappt ({exc})."
    _dashboard_stale("reminders")
    title = (new_title or "").strip() or item["title"]
    where = store.name(target) if target is not None else item["list"]
    return f"Geaendert: {title} (Liste {where})."


# ---------------------------------------------------------------- Kontakte und Anrufe

WHICH = {"handy": "mobil", "mobil": "mobil", "mobile": "mobil", "iphone": "mobil", "privat": "privat",
         "zuhause": "privat", "festnetz": "privat", "daheim": "privat", "arbeit": "arbeit", "geschaeftlich": "arbeit",
         "buero": "arbeit", "dienstlich": "arbeit", "firma": "arbeit", "work": "arbeit", "home": "privat"}


def _score(person: dict, query: str) -> int | None:
    words = _norm(query).split()
    names = [_norm(person["name"]), _norm(person["nick"]), _norm(person["org"])]
    if _norm(query) in names[:2]:
        return 0
    tokens = " ".join(names).split()
    if all(w in tokens for w in words):
        return 1
    if all(any(t.startswith(w) for t in tokens) for w in words):
        return 2
    if all(w in " ".join(names) for w in words):
        return 3
    return None


def find_contacts(query: str) -> tuple[list[tuple[int, dict]] | None, str]:
    if not _norm(query):
        return [], ""
    everyone = alltag.load_people()
    if everyone is None:
        return None, CONTACTS_HINT
    scored = [(s, p) for p in everyone for s in [_score(p, query)] if s is not None]
    scored.sort(key=lambda sp: (sp[0], sp[1]["name"]))
    return scored, ""


def _choose(scored: list[tuple[int, dict]]) -> dict | None:
    if len(scored) == 1:
        return scored[0][1]
    best = [p for s, p in scored if s == scored[0][0]]
    return best[0] if len(best) == 1 and scored[0][0] <= 1 else None


def _phone_line(person: dict) -> str:
    phones = ", ".join(f"{p['label']} {p['number']}" for p in person["phones"]) or "keine Nummer"
    return f"{person['name']} ({phones})"


def open_contact(name: str) -> str:
    scored, hint = find_contacts(name)
    if scored is None:
        return hint
    if not scored:
        return f"Keinen Kontakt '{name}' in Outlook gefunden."
    person = _choose(scored)
    if person is None:
        return "Mehrere Kontakte passen, frag Lukas welcher: " + "; ".join(p["name"] for _, p in scored[:6]) + "."
    try:
        alltag.outlook().GetItemFromID(person["id"]).Display()
    except Exception:
        pass
    return f"Kontakt geoeffnet: {_phone_line(person)}."


def _pick_number(person: dict, which: str):
    phones = person["phones"]
    if not phones:
        return None
    if which:
        wanted = _norm(which)
        if len(re.sub(r"\D", "", which)) >= 3:
            hits = [p for p in phones if alltag._digits(p["number"]).endswith(alltag._digits(which))]
        else:
            kind = WHICH.get(wanted.replace(" ", ""), wanted)
            hits = [p for p in phones if kind in _norm(p["label"])]
        if len(hits) == 1:
            return hits[0]
        if hits:
            return hits
    if len(phones) == 1:
        return phones[0]
    mobile = [p for p in phones if p["label"] == "Mobil"]
    return mobile[0] if len(mobile) == 1 else phones


def _dial_string(number: str) -> str:
    raw = number.strip()
    digits = re.sub(r"\D", "", raw)
    if raw.startswith("+"):
        return "+" + digits
    if raw.startswith("00"):
        return "+" + digits[2:]
    return digits


def _looks_like_number(text: str) -> bool:
    return bool(re.fullmatch(r"\+?\d{3,20}", re.sub(r"[\s/()\-.]", "", text)))


def call(target: str, which: str = "", facetime: bool = False) -> str:
    """Ruft ueber einen tel:-Link an; Smartphone-Link (Handy per Bluetooth verbunden) waehlt dann."""
    target = (target or "").strip()
    if not target:
        return "Wen soll ich anrufen?"
    if facetime:
        return "FaceTime gibt es unter Windows nicht. Soll ich normal anrufen?"
    if _looks_like_number(target):
        name, number = None, target
    else:
        scored, hint = find_contacts(target)
        if scored is None:
            return hint
        if not scored:
            return f"Keinen Kontakt '{target}' gefunden. Sag mir die Nummer oder den genauen Namen."
        person = _choose(scored)
        if person is None:
            return "Mehrere Kontakte passen, frag Lukas wen: " + "; ".join(p["name"] for _, p in scored[:6]) + "."
        choice = _pick_number(person, which)
        if choice is None:
            return f"Bei {person['name']} ist keine Telefonnummer gespeichert."
        if isinstance(choice, list):
            return (f"{person['name']} hat mehrere Nummern, frag Lukas welche: "
                    + ", ".join(f"{p['label']} {p['number']}" for p in choice) + ".")
        name, number = person["name"], choice["number"]
    dial = _dial_string(number)
    if len(dial.lstrip("+")) < 3:
        return f"'{number}' ist keine gueltige Telefonnummer."
    if not plattform.open_uri("tel:" + dial):
        return "Der Anruf liess sich nicht starten. Ist das Handy mit der App Smartphone-Link verbunden?"
    who = f"{name} ({number})" if name else number
    return f"Anruf an {who} ist vorbereitet. In Smartphone-Link auf Anrufen klicken, dann waehlt dein Handy."


# ---------------------------------------------------------------- Websites und Programme

def open_website(url: str) -> str:
    text = (url or "").strip()
    if not text:
        return "Welche Seite soll ich oeffnen?"
    if not re.match(r"^[a-z][a-z0-9+.-]*://", text, re.I):
        if text.lower().startswith("localhost"):
            text = "http://" + text
        elif " " in text or "." not in text:
            text = "https://www.google.com/search?q=" + quote(text)
        else:
            text = "https://" + text
    parsed = urlparse(text)
    if parsed.scheme.lower() not in ("http", "https") or not parsed.netloc:
        return "Ich oeffne nur normale Internetseiten (http oder https)."
    if not webbrowser.open(text):
        return f"Konnte {parsed.netloc} nicht oeffnen."
    host = parsed.netloc[4:] if parsed.netloc.startswith("www.") else parsed.netloc
    return f"{host} ist im Browser offen."


# Was man sagt -> wie das Programm im Startmenue heisst (deutsches und englisches Windows)
APP_ALIASES = {
    "rechner": ["Rechner", "Calculator"], "taschenrechner": ["Rechner", "Calculator"],
    "einstellungen": ["Einstellungen", "Settings"], "systemeinstellungen": ["Einstellungen", "Settings"],
    "explorer": ["Datei-Explorer", "File Explorer"], "dateien": ["Datei-Explorer", "File Explorer"],
    "finder": ["Datei-Explorer", "File Explorer"], "editor": ["Editor", "Notepad"], "notizen": ["OneNote", "Kurznotizen"],
    "kalender": ["Outlook", "Outlook (classic)", "Kalender"], "mail": ["Outlook", "Outlook (classic)"],
    "kontakte": ["Outlook", "Outlook (classic)", "Personen"], "fotos": ["Fotos", "Photos"],
    "aktivitaetsanzeige": ["Task-Manager", "Task Manager"], "taskmanager": ["Task-Manager", "Task Manager"],
    "systemsteuerung": ["Systemsteuerung", "Control Panel"], "terminal": ["Terminal", "Windows PowerShell"],
    "chrome": ["Google Chrome"], "word": ["Word"], "excel": ["Excel"], "powerpoint": ["PowerPoint"],
    "outlook": ["Outlook (classic)", "Outlook"], "teams": ["Microsoft Teams", "Teams"],
    "vs code": ["Visual Studio Code"], "vscode": ["Visual Studio Code"], "karten": ["Karten", "Maps"],
    "telefon": ["Smartphone-Link", "Phone Link"], "smartphone link": ["Smartphone-Link", "Phone Link"],
    "wetter": ["Wetter", "Weather"], "uhr": ["Uhr", "Clock"], "musik": ["Spotify", "Media Player"],
    "kamera": ["Kamera", "Camera"], "paint": ["Paint"], "store": ["Microsoft Store"], "app store": ["Microsoft Store"],
}

_apps: dict = {"at": 0.0, "list": {}}


def _start_apps() -> dict[str, str]:
    """Programme aus dem Startmenue: normierter Name -> AppID (10 Minuten gemerkt)."""
    if time.time() - _apps["at"] < 600 and _apps["list"]:
        return _apps["list"]
    found = {}
    try:
        out = plattform.powershell("Get-StartApps | ForEach-Object { $_.Name + [char]9 + $_.AppID }", timeout=20).stdout
        for line in out.splitlines():
            name, _, appid = line.partition("\t")
            if name.strip() and appid.strip():
                found.setdefault(_norm(name), (name.strip(), appid.strip()))
    except (subprocess.SubprocessError, OSError):
        pass
    _apps.update(at=time.time(), list=found)
    return found


def find_app(name: str) -> tuple[str, str] | None:
    """(Anzeigename, AppID) aus dem Startmenue: genauer Name, deutscher Name, Woerter, Wortanfang, aehnlich."""
    wanted = re.sub(r"^(die|das|den|der) | app$|^app ", "", _norm(name)).strip()
    if not wanted:
        return None
    apps = _start_apps()
    for key in [_norm(a) for a in APP_ALIASES.get(wanted, [])] + [wanted]:
        if key in apps:
            return apps[key]
    words = wanted.split()
    candidates = [k for k in apps if all(w in k.split() for w in words)] or [k for k in apps if k.startswith(wanted)]
    if candidates:
        return apps[min(candidates, key=len)]
    close = get_close_matches(wanted, list(apps), n=1, cutoff=0.75)
    return apps[close[0]] if close else None


def open_app(app_name: str) -> str:
    name = (app_name or "").strip()
    if not name:
        return "Welches Programm soll ich oeffnen?"
    hit = find_app(name)
    if hit:
        shown, appid = hit
        try:
            subprocess.Popen(["explorer.exe", f"shell:AppsFolder\\{appid}"])
            return f"{shown} ist offen."
        except OSError:
            pass
    if plattform.open_uri(name):  # z. B. "notepad" oder ein Pfad
        return f"{name} ist offen."
    return f"Ich finde kein Programm '{name}' auf dem PC."
