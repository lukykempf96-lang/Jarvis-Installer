"""Mails, Kalender und Kontakte unter Windows lesen (Windows-Fassung von alltag.py).

Quellen, je nachdem, was eingerichtet ist (.env):
- Outlook (klassisches Outlook fuer Windows, ueber COM/pywin32): Mails aller Konten, Kalender, Kontakte, Aufgaben.
  Das "neue Outlook" und die Web-Version haben diese Schnittstelle nicht.
- IMAP (JARVIS_IMAP_SERVER, JARVIS_IMAP_USER, JARVIS_IMAP_PASSWORT): Mails lesen ohne Outlook (z. B. Gmail, GMX, web.de).
- Kalender-Link (JARVIS_KALENDER_ICS, ICS-Adresse, z. B. "Geheime Adresse im iCal-Format" von Google): Termine nur lesen.
iMessage und SMS gibt es unter Windows nicht. Gesendet oder geloescht wird hier nichts.
"""
from __future__ import annotations

import email
import email.policy
import imaplib
import os
import re
import threading
import time
from datetime import date, datetime, timedelta
from email.header import decode_header, make_header
from email.utils import parsedate_to_datetime

WEEKDAYS = ["Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag", "Sonntag"]
MONTHS_EN = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

OUTLOOK_HINT = (
    "Ich komme nicht an Outlook. Unter Windows lese ich Mails, Kalender und Kontakte aus dem klassischen "
    "Outlook fuer Windows; es muss installiert und eingerichtet sein. Ohne Outlook gehen Mails ueber IMAP und "
    "der Kalender ueber einen Kalender-Link, beides in der Datei .env."
)
CALENDAR_HINT = OUTLOOK_HINT
MAIL_HINT = (
    "Mails sind noch nicht eingerichtet. Entweder das klassische Outlook einrichten oder in der Datei .env "
    "JARVIS_IMAP_SERVER, JARVIS_IMAP_USER und JARVIS_IMAP_PASSWORT eintragen und Jarvis neu starten."
)
MESSAGES_HINT = ("iMessage und SMS kann ich unter Windows nicht lesen. Nachrichten vom Handy zeigt die App "
                 "Smartphone-Link, die hat aber keine Schnittstelle fuer mich.")


class PermissionMissing(Exception):
    """Quelle nicht eingerichtet oder nicht erreichbar (wie die fehlende Erlaubnis am Mac)."""


def _open_privacy_settings(pane: str):
    pass  # unter Windows braucht Outlook keine Datenschutz-Freigabe


def _fmt_time(dt: datetime, now: datetime | None = None) -> str:
    now = now or datetime.now()
    days = (dt.date() - now.date()).days
    clock = dt.strftime("%H:%M")
    if days == 0:
        return f"heute {clock}"
    if days == -1:
        return f"gestern {clock}"
    if days == 1:
        return f"morgen {clock}"
    if -7 < days < 7:
        return f"{WEEKDAYS[dt.weekday()]} {clock}"
    return dt.strftime("%d.%m. %H:%M")


def _short(text: str, limit: int) -> str:
    text = re.sub(r"\s+", " ", text or "").strip()
    return text if len(text) <= limit else text[: limit - 1].rstrip() + "…"


def _digits(number: str) -> str:
    d = re.sub(r"\D", "", number or "")
    return d[-9:] if len(d) >= 6 else d


def _naive(value) -> datetime:
    """COM- oder ICS-Zeit als lokale Zeit ohne Zeitzone."""
    if isinstance(value, datetime):
        if value.tzinfo is not None:
            try:
                return value.astimezone().replace(tzinfo=None)
            except (ValueError, OSError):
                value = value.replace(tzinfo=None)
        return datetime(value.year, value.month, value.day, value.hour, value.minute, value.second)
    if isinstance(value, date):
        return datetime(value.year, value.month, value.day)
    return datetime.now()


def com_time(value) -> datetime:
    """Zeit aus Outlook: ist schon Ortszeit, pywin32 haengt aber oft eine falsche Zeitzone an. Also nur abschneiden."""
    try:
        return datetime(value.year, value.month, value.day, value.hour, value.minute, value.second)
    except (AttributeError, ValueError):
        return datetime.now()


def com_text(dt: datetime, with_time: bool = True) -> str:
    """Zeit fuer Outlook (wird als Ortszeit gelesen, unabhaengig vom Datumsformat des Systems)."""
    return dt.strftime("%Y-%m-%d %H:%M" if with_time else "%Y-%m-%d")


# ---------------------------------------------------------------- Outlook (COM)

def outlook():
    """MAPI-Namespace des klassischen Outlook, oder PermissionMissing. Pro Thread COM einschalten."""
    try:
        import pythoncom
        import win32com.client
    except ImportError:
        raise PermissionMissing("pywin32 fehlt")
    pythoncom.CoInitialize()
    try:
        app = win32com.client.Dispatch("Outlook.Application")
        return app.GetNamespace("MAPI")
    except Exception as exc:
        raise PermissionMissing(f"Outlook nicht erreichbar ({exc})")


def has_outlook() -> bool:
    if os.environ.get("JARVIS_MAIL", "").lower() == "imap":
        return False
    try:
        outlook()
        return True
    except PermissionMissing:
        return False


def _default_folders(ns, kind: int) -> list:
    """Standardordner (6 Posteingang, 9 Kalender, 10 Kontakte, 13 Aufgaben) aller Konten in Outlook."""
    found, seen = [], set()
    try:
        main = ns.GetDefaultFolder(kind)
        found.append(main)
        seen.add(main.EntryID)
    except Exception:
        pass
    try:
        for store in ns.Stores:
            try:
                folder = store.GetDefaultFolder(kind)
            except Exception:
                continue
            if folder.EntryID not in seen:
                seen.add(folder.EntryID)
                found.append(folder)
    except Exception:
        pass
    return found


def restrict_between(items, field_start: str, field_end: str, start: datetime, end: datetime):
    """Outlook-Filter fuer einen Zeitraum; klappt der nicht, alle Eintraege (es wird danach ohnehin gefiltert)."""
    try:
        return items.Restrict(f"[{field_end}] >= '{com_text(start)}' AND [{field_start}] <= '{com_text(end)}'")
    except Exception:
        return items


# ---------------------------------------------------------------- Kontakte

_contacts: dict = {"at": 0.0, "people": [], "phones": {}, "emails": {}}
_contacts_lock = threading.Lock()

PHONE_FIELDS = [("MobileTelephoneNumber", "Mobil"), ("HomeTelephoneNumber", "Privat"),
                ("BusinessTelephoneNumber", "Arbeit"), ("PrimaryTelephoneNumber", "Haupt"),
                ("Home2TelephoneNumber", "Privat"), ("Business2TelephoneNumber", "Arbeit"),
                ("OtherTelephoneNumber", "Sonstige"), ("CarTelephoneNumber", "Auto")]


def load_people() -> list[dict] | None:
    """Alle Outlook-Kontakte (10 Minuten gemerkt). None = Outlook nicht erreichbar."""
    with _contacts_lock:
        if time.time() - _contacts["at"] < 600:
            return _contacts["people"]
        try:
            ns = outlook()
        except PermissionMissing:
            return None
        people, phones, emails = [], {}, {}
        for folder in _default_folders(ns, 10):
            try:
                items = folder.Items
                count = items.Count
            except Exception:
                continue
            for i in range(1, min(count, 5000) + 1):
                try:
                    c = items.Item(i)
                    if c.Class != 40:  # nur Kontakte, keine Verteilerlisten
                        continue
                    name = (c.FullName or c.CompanyName or "").strip()
                    if not name:
                        continue
                    nums = []
                    for field, label in PHONE_FIELDS:
                        value = (getattr(c, field, "") or "").strip()
                        if value and _digits(value) not in {_digits(n["number"]) for n in nums}:
                            nums.append({"number": value, "label": label})
                    mails = [m.strip() for m in (c.Email1Address, c.Email2Address, c.Email3Address) if m and "@" in m]
                    people.append({"name": name, "nick": (c.NickName or "").strip(), "org": (c.CompanyName or "").strip(),
                                   "id": c.EntryID, "phones": nums, "emails": mails})
                    for n in nums:
                        phones[_digits(n["number"])] = name
                    for m in mails:
                        emails[m.lower()] = name
                except Exception:
                    continue
        _contacts.update(at=time.time(), people=people, phones=phones, emails=emails)
        return people


def contact_name(handle: str) -> str | None:
    if not handle or load_people() is None:
        return None
    if "@" in handle:
        return _contacts["emails"].get(handle.strip().lower())
    return _contacts["phones"].get(_digits(handle))


# ---------------------------------------------------------------- Mail

_AUTOMATED = re.compile(
    r"no-?reply|do-?not-?reply|newsletter|news@|info@|noti(fy|fication)|mailer|marketing|"
    r"service@|support@|hello@|team@|updates?@|angebote|werbung|deals|promo",
    re.I,
)


def _mail_dict(msg_id, name, address, subject, received, flagged, account, content, read) -> dict:
    known = contact_name(address) is not None
    return {
        "id": str(msg_id), "name": contact_name(address) or name or address, "address": address,
        "subject": (subject or "").strip() or "(ohne Betreff)", "received": received,
        "flagged": bool(flagged), "account": account or "", "preview": _short(content, 220), "known": known,
        "automated": bool(_AUTOMATED.search(address or "")), "read": bool(read),
    }


def _sender_address(m) -> str:
    try:
        if m.SenderEmailType == "EX":  # Exchange-intern: echte Adresse nachschlagen
            user = m.Sender.GetExchangeUser()
            if user is not None and user.PrimarySmtpAddress:
                return user.PrimarySmtpAddress
    except Exception:
        pass
    return m.SenderEmailAddress or ""


def _outlook_mails(days: int, limit: int, unread_only: bool, with_text: bool) -> tuple[int, list[dict]]:
    ns = outlook()
    cutoff = datetime.now() - timedelta(days=days)
    mails, total = [], 0
    for inbox in _default_folders(ns, 6):
        try:
            account = inbox.Store.DisplayName
            items = inbox.Items
            items.Sort("[ReceivedTime]", True)
        except Exception:
            continue
        m = items.GetFirst()
        while m is not None:
            try:
                if m.Class == 43:  # Mail
                    received = com_time(m.ReceivedTime)
                    if received < cutoff:
                        break
                    if not (unread_only and not m.UnRead):
                        total += 1
                        if len(mails) < limit * 3:
                            text = (m.Body or "")[:400] if with_text else ""
                            mails.append(_mail_dict(m.EntryID, m.SenderName, _sender_address(m), m.Subject, received,
                                                    m.FlagStatus == 2, account, text, not m.UnRead))
            except Exception:
                pass
            m = items.GetNext()
    mails.sort(key=lambda x: x["received"], reverse=True)
    return total, mails[:limit]


# IMAP ----------------------------------------------------------------

def _imap_config() -> tuple[str, str, str] | None:
    server, user = os.environ.get("JARVIS_IMAP_SERVER", ""), os.environ.get("JARVIS_IMAP_USER", "")
    password = os.environ.get("JARVIS_IMAP_PASSWORT", "")
    return (server, user, password) if server and user and password else None


def _imap():
    cfg = _imap_config()
    if not cfg:
        raise PermissionMissing("IMAP nicht eingerichtet")
    server, user, password = cfg
    host, _, port = server.partition(":")
    con = imaplib.IMAP4_SSL(host, int(port or 993), timeout=20)
    try:
        con.login(user, password)
    except imaplib.IMAP4.error as exc:
        raise RuntimeError(f"IMAP-Anmeldung abgelehnt ({exc}). Bei Gmail ein App-Passwort nehmen.")
    con.select("INBOX", readonly=True)
    return con


def _header(value) -> str:
    try:
        return str(make_header(decode_header(value or "")))
    except Exception:
        return value or ""


def _body_text(msg) -> str:
    try:
        part = msg.get_body(preferencelist=("plain", "html"))
        text = part.get_content() if part is not None else ""
        if part is not None and part.get_content_type() == "text/html":
            text = re.sub(r"<(script|style).*?</\1>", " ", text, flags=re.S | re.I)
            text = re.sub(r"<[^>]+>", " ", text)
        return text
    except Exception:
        return ""


def _imap_fetch(con, uid: bytes, full: bool):
    what = "(FLAGS BODY.PEEK[])" if full else "(FLAGS BODY.PEEK[HEADER.FIELDS (FROM SUBJECT DATE)])"
    status, data = con.uid("fetch", uid, what)
    if status != "OK" or not data or not isinstance(data[0], tuple):
        return None, b""
    return email.message_from_bytes(data[0][1], policy=email.policy.default), data[0][0]


def _imap_mails(days: int, limit: int, unread_only: bool, with_text: bool) -> tuple[int, list[dict]]:
    since = datetime.now() - timedelta(days=days)
    crit = f"(SINCE {since.day:02d}-{MONTHS_EN[since.month - 1]}-{since.year})" + (" UNSEEN" if unread_only else "")
    con = _imap()
    try:
        status, data = con.uid("search", None, crit)
        uids = data[0].split() if status == "OK" and data and data[0] else []
        mails = []
        for uid in reversed(uids[-limit:]):
            msg, meta = _imap_fetch(con, uid, with_text)
            if msg is None:
                continue
            name, address = email.utils.parseaddr(_header(msg.get("From")))
            try:
                received = _naive(parsedate_to_datetime(msg.get("Date")))
            except Exception:
                received = datetime.now()
            text = _body_text(msg)[:400] if with_text else ""
            mails.append(_mail_dict(uid.decode(), name, address, _header(msg.get("Subject")), received,
                                    b"\\Flagged" in meta, "", text, b"\\Seen" in meta))
        return len(uids), sorted(mails, key=lambda x: x["received"], reverse=True)
    finally:
        try:
            con.logout()
        except Exception:
            pass


def _mail_source() -> str:
    choice = os.environ.get("JARVIS_MAIL", "").lower()
    if choice in ("outlook", "imap"):
        return choice
    if _imap_config() and not has_outlook():
        return "imap"
    return "outlook"


def fetch_mails(days: int = 3, limit: int = 30, unread_only: bool = True) -> tuple[int, list[dict]]:
    if _mail_source() == "imap":
        return _imap_mails(days, limit, unread_only, True)
    return _outlook_mails(days, limit, unread_only, True)


def fetch_mail_headers(days: int = 3, limit: int = 80) -> list[dict]:
    if _mail_source() == "imap":
        return _imap_mails(days, limit, False, False)[1]
    return _outlook_mails(days, limit, False, False)[1]


def fetch_mail_preview(message_id: str, length: int = 400) -> str:
    if _mail_source() == "imap":
        con = _imap()
        try:
            msg, _ = _imap_fetch(con, message_id.encode(), True)
            return _short(_body_text(msg) if msg else "", length)
        finally:
            con.logout()
    return _short((outlook().GetItemFromID(message_id).Body or "")[:length * 2], length)


def fetch_unread_mails(days: int = 3, limit: int = 30) -> tuple[int, list[dict]]:
    return fetch_mails(days, limit, unread_only=True)


def _mail_line(m: dict) -> str:
    tags = [t for t, on in (("markiert", m["flagged"]), ("Kontakt", m["known"]), ("automatisch", m["automated"])) if on]
    tag = f" [{', '.join(tags)}]" if tags else ""
    return (f"- {_fmt_time(m['received'])}, von {m['name']} <{m['address']}>{tag}: "
            f"„{m['subject']}“ — {m['preview']} (id: {m['id']})")


def get_mails(days: int = 3) -> str:
    try:
        total, mails = fetch_unread_mails(days)
    except PermissionMissing:
        return MAIL_HINT
    except Exception as exc:
        return f"Mails konnten nicht gelesen werden: {exc}"
    if not mails:
        return f"Keine ungelesenen Mails im Posteingang der letzten {days} Tage."
    head = f"{total} ungelesene Mails der letzten {days} Tage"
    if total > len(mails):
        head += f", hier die {len(mails)} neuesten"
    return head + ":\n" + "\n".join(_mail_line(m) for m in mails)


def read_mail(message_id: str) -> str:
    try:
        if _mail_source() == "imap":
            con = _imap()
            try:
                msg, _ = _imap_fetch(con, message_id.encode(), True)
            finally:
                con.logout()
            if msg is None:
                return "Diese Mail habe ich nicht gefunden."
            sender, subject, when, content = _header(msg.get("From")), _header(msg.get("Subject")), msg.get("Date"), _body_text(msg)
        else:
            m = outlook().GetItemFromID(message_id)
            sender = f"{m.SenderName} <{_sender_address(m)}>"
            subject, when, content = m.Subject, com_time(m.ReceivedTime).strftime("%d.%m.%Y %H:%M"), m.Body or ""
    except PermissionMissing:
        return MAIL_HINT
    except Exception as exc:
        return f"Diese Mail habe ich nicht gefunden ({exc})."
    content = (content or "").strip()
    if len(content) > 6000:
        content = content[:6000] + " …(gekuerzt)"
    return f"Von: {sender}\nBetreff: {subject}\nDatum: {when}\n\n{content}"


def open_mail(message_id: str) -> str:
    if _mail_source() == "imap":
        return "Mails ueber IMAP kann ich nur vorlesen, nicht in einem Programm oeffnen."
    try:
        outlook().GetItemFromID(message_id).Display()
        return "Die Mail ist in Outlook geoeffnet."
    except Exception:
        return "Konnte die Mail nicht oeffnen."


# ---------------------------------------------------------------- Nachrichten (gibt es unter Windows nicht)

def fetch_recent_chats(hours: int = 24) -> list[dict]:
    return []


def get_messages(hours: int = 24) -> str:
    return MESSAGES_HINT


# ---------------------------------------------------------------- Kalender

def _outlook_events(start: datetime, end: datetime) -> list[dict]:
    ns = outlook()
    events, seen = [], set()
    for folder in _default_folders(ns, 9):
        try:
            name = folder.Name
            items = folder.Items
            items.IncludeRecurrences = True
            items.Sort("[Start]")
            items = restrict_between(items, "Start", "End", start, end)
        except Exception:
            continue
        e, guard = items.GetFirst(), 0
        while e is not None and guard < 2000:
            guard += 1
            try:
                s, f = com_time(e.Start), com_time(e.End)
                if s > end:
                    break
                key = (e.Subject, s)
                if f > start and key not in seen:
                    seen.add(key)
                    events.append({"title": e.Subject or "Termin", "start": s, "end": f, "all_day": bool(e.AllDayEvent),
                                   "location": e.Location or "", "calendar": name, "color": ""})
            except Exception:
                pass
            e = items.GetNext()
    return events


def _ics_events(start: datetime, end: datetime) -> list[dict]:
    urls = [u.strip() for u in os.environ.get("JARVIS_KALENDER_ICS", "").split(",") if u.strip()]
    if not urls:
        return []
    import httpx
    import icalendar
    import recurring_ical_events

    events = []
    for url in urls:
        url = "https://" + url[len("webcal://"):] if url.startswith("webcal://") else url
        cal = icalendar.Calendar.from_ical(httpx.get(url, timeout=15, follow_redirects=True).content)
        title = str(cal.get("X-WR-CALNAME", "Kalender"))
        for ev in recurring_ical_events.of(cal).between(start, end):
            s = ev.get("DTSTART").dt
            f = ev.get("DTEND").dt if ev.get("DTEND") else s
            all_day = not isinstance(s, datetime)
            s, f = _naive(s), _naive(f)
            if all_day and f <= s:
                f = s + timedelta(days=1)
            events.append({"title": str(ev.get("SUMMARY", "Termin")), "start": s, "end": f, "all_day": all_day,
                           "location": str(ev.get("LOCATION", "") or ""), "calendar": title, "color": ""})
    return events


def fetch_events_between(start: datetime, end: datetime) -> list[dict]:
    events = []
    outlook_ok = False
    if os.environ.get("JARVIS_MAIL", "").lower() != "imap" or not os.environ.get("JARVIS_KALENDER_ICS"):
        try:
            events += _outlook_events(start, end)
            outlook_ok = True
        except PermissionMissing:
            pass
    events += _ics_events(start, end)
    if not outlook_ok and not os.environ.get("JARVIS_KALENDER_ICS"):
        raise PermissionMissing("kein Kalender eingerichtet")
    events.sort(key=lambda e: (e["start"], not e["all_day"]))
    return events


def fetch_events(days: int = 1) -> list[dict]:
    start = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
    return fetch_events_between(start, start + timedelta(days=max(1, days)))


def fetch_reminders(until: datetime) -> list[dict]:
    """Offene Aufgaben, die bis `until` faellig sind (Outlook-Aufgaben oder Jarvis' eigene Listen)."""
    from . import planer
    return planer.due_items(until)


def get_calendar(days: int = 1) -> str:
    try:
        events = fetch_events(days)
    except PermissionMissing:
        return CALENDAR_HINT
    except Exception as exc:
        return f"Der Kalender liess sich nicht lesen: {exc}"
    span = "heute" if days <= 1 else f"in den naechsten {days} Tagen"
    if not events:
        return f"Keine Termine {span}."
    now = datetime.now()
    lines = []
    for e in events:
        if e["all_day"]:
            when = "ganztaegig" + ("" if e["start"].date() == now.date() else f" {WEEKDAYS[e['start'].weekday()]}")
        else:
            when = f"{_fmt_time(e['start'], now)} bis {e['end'].strftime('%H:%M')}"
            if e["end"] < now:
                when += " (vorbei)"
        where = f", Ort: {e['location']}" if e["location"] else ""
        lines.append(f"- {when}: {e['title']}{where} [{e['calendar']}]")
    return f"Termine {span}:\n" + "\n".join(lines)
