"""Windows-Helfer fuer Jarvis: PowerShell, Ton, Einstellungen, Bildschirmfoto, Bilder, Zertifikat, Texte.

Ersetzt die macOS-Bordmittel (afplay, open, screencapture, sips, openssl). Nur in der Windows-Fassung.
"""
from __future__ import annotations

import io
import json
import os
import re
import subprocess
import tempfile
from pathlib import Path

NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
JARVIS_DIR = Path(__file__).resolve().parent.parent

# Tools, die es unter Windows nicht gibt (werden Claude gar nicht erst angeboten)
UNSUPPORTED = {"get_messages"}

# ms-settings-Seiten statt der macOS-Datenschutz-Einstellungen
PRIVACY = {
    "Privacy_Automation": "ms-settings:privacy",
    "Privacy_Calendars": "ms-settings:privacy-calendar",
    "Privacy_Reminders": "ms-settings:privacy",
    "Privacy_AllFiles": "ms-settings:privacy-broadfilesystemaccess",
    "Privacy_Microphone": "ms-settings:privacy-microphone",
    "Privacy_Contacts": "ms-settings:privacy-contacts",
}


def powershell(script: str, timeout: int = 60, env: dict | None = None) -> subprocess.CompletedProcess:
    """Fuehrt ein PowerShell-Skript aus (ohne Fenster), Ausgabe als UTF-8."""
    full = "[Console]::OutputEncoding = [Text.Encoding]::UTF8\n" + script
    return subprocess.run(
        ["powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", full],
        capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=timeout,
        creationflags=NO_WINDOW, env={**os.environ, **(env or {})},
    )


def open_uri(target: str) -> bool:
    """Wie 'open' am Mac: Datei, Ordner, Internetadresse oder tel:-Link mit dem Standardprogramm."""
    try:
        os.startfile(target)  # type: ignore[attr-defined]  # gibt es nur unter Windows
        return True
    except OSError:
        return False


def known_folder(name: str) -> str:
    """Desktop, Documents, Pictures: liegen bei OneDrive-Sicherung unter OneDrive statt direkt im Benutzerordner."""
    home = Path.home()
    for base in (home, home / "OneDrive"):
        if (base / name).is_dir():
            return str(base / name)
    return name


def open_privacy(pane: str) -> bool:
    return open_uri(PRIVACY.get(pane, "ms-settings:privacy"))


_PLAY = r"""
Add-Type -AssemblyName PresentationCore
$p = New-Object System.Windows.Media.MediaPlayer
$p.Open([Uri]$env:JARVIS_AUDIO)
$p.Volume = 1.0
$p.Play()
$t = 0
while (-not $p.NaturalDuration.HasTimeSpan -and $t -lt 100) { Start-Sleep -Milliseconds 50; $t++ }
if ($p.NaturalDuration.HasTimeSpan) {
    Start-Sleep -Milliseconds ([int]$p.NaturalDuration.TimeSpan.TotalMilliseconds + 150)
} else { Start-Sleep -Seconds 2 }
$p.Close()
"""


def play(path: str) -> subprocess.Popen:
    """Spielt eine Audiodatei (mp3, wav, m4a) ab; der Prozess endet, wenn sie fertig ist (terminate = Stopp)."""
    return subprocess.Popen(
        ["powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-STA", "-Command", _PLAY],
        env={**os.environ, "JARVIS_AUDIO": Path(path).resolve().as_uri()},
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=NO_WINDOW,
    )


def beep():
    """Kurzer Ton: Jarvis hoert zu."""
    try:
        import winsound
        sound = Path(os.environ.get("WINDIR", r"C:\Windows")) / "Media" / "Windows Notify System Generic.wav"
        if sound.exists():
            winsound.PlaySound(str(sound), winsound.SND_FILENAME | winsound.SND_ASYNC)
        else:
            winsound.MessageBeep()
    except Exception:
        pass


# ---------- Bilder ----------

def _pillow():
    from PIL import Image, ImageOps
    try:
        import pillow_heif  # iPhone-Fotos (HEIC)
        pillow_heif.register_heif_opener()
    except Exception:
        pass
    return Image, ImageOps


def _jpeg(img, size: int = 1568) -> bytes:
    img = img.convert("RGB")
    img.thumbnail((size, size))
    buf = io.BytesIO()
    img.save(buf, "JPEG", quality=85)
    return buf.getvalue()


def shrink_image(path: Path) -> bytes | None:
    """Verkleinert ein Bild auf hoechstens 1568 Pixel und macht JPEG daraus (auch HEIC, TIFF, BMP)."""
    try:
        Image, ImageOps = _pillow()
        with Image.open(path) as img:
            return _jpeg(ImageOps.exif_transpose(img))
    except Exception:
        return None


def screenshot(out: Path) -> None:
    """Bildschirmfoto aller Bildschirme, verkleinert als JPEG."""
    from PIL import ImageGrab
    img = ImageGrab.grab(all_screens=True)
    out.write_bytes(_jpeg(img))


# ---------- Zertifikat fuers Handy-Mikro ----------

def make_cert(ip: str, cert_path: Path, key_path: Path) -> None:
    """Selbst signiertes Zertifikat fuer die WLAN-Adresse (ersetzt openssl vom Mac)."""
    import datetime
    import ipaddress

    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.x509.oid import ExtendedKeyUsageOID, NameOID

    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "Jarvis")])
    now = datetime.datetime.now(datetime.timezone.utc)
    cert = (
        x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now - datetime.timedelta(days=1)).not_valid_after(now + datetime.timedelta(days=825))
        .add_extension(x509.SubjectAlternativeName([x509.IPAddress(ipaddress.ip_address(ip))]), critical=False)
        .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
        .add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH]), critical=False)
        .sign(key, hashes.SHA256())
    )
    key_path.write_bytes(key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.TraditionalOpenSSL,
                                           serialization.NoEncryption()))
    cert_path.write_bytes(cert.public_bytes(serialization.Encoding.PEM))


# ---------- Claude Code sichtbar im Terminal ----------

def open_terminal(folder: Path, command_line: str) -> None:
    """Oeffnet ein neues Konsolenfenster im Ordner und fuehrt dort den Befehl aus."""
    script = Path(tempfile.gettempdir()) / "jarvis_claude.cmd"
    script.write_text(f'@echo off\r\nchcp 65001 >nul\r\ncd /d "{folder}"\r\n{command_line}\r\n', encoding="utf-8")
    os.startfile(str(script))  # type: ignore[attr-defined]


# ---------- Texte fuer Claude an Windows und den Namen anpassen ----------

_REPLACE = [
    (r"ueber Lukas' iPhone an", "ueber das mit Smartphone-Link verbundene Handy an"),
    (r"Der Mac zeigt dann 'Anrufen' zum Bestaetigen", "Smartphone-Link zeigt dann 'Anrufen' zum Bestaetigen"),
    (r", ungelesene Mails und die Nachrichten \(iMessage/SMS\) der letzten Stunden", " und ungelesene Mails"),
    (r"get_messages, ", ""),
    (r"fuer Abfahrt jetzt, mit aktueller Verkehrslage", "fuer Abfahrt jetzt (ohne aktuelle Verkehrslage)"),
    (r"Apple Karten", "OpenStreetMap"),
    (r"Mail-App", "Outlook"),
    (r"Kalender-App", "Outlook-Kalender"),
    (r"Erinnerungen-App", "Aufgaben in Outlook"),
    (r"Kontakte-App", "Outlook-Kontakte"),
    (r"\(kommt per iCloud auch aufs iPhone\)", "(kommt ueber das Outlook-Konto auch aufs Handy)"),
    (r"\bMacs\b", "PCs"),
    (r"\bMac\b", "PC"),
]


def _genitive(name: str) -> str:
    return name + ("'" if name[-1:].lower() in ("s", "x", "z", "ß") else "s")


def personalize(value):
    """Ersetzt Mac-Begriffe und den Namen Lukas in Prompts und Tool-Beschreibungen (Text, Liste oder Dict)."""
    if not isinstance(value, str):
        return json.loads(personalize(json.dumps(value, ensure_ascii=False)))
    from .config import settings

    name = (settings.user_name or "").strip() or "Lukas"
    for pattern, new in _REPLACE:
        value = re.sub(pattern, new, value)
    if name != "Lukas":
        value = re.sub(r"\bLukas'", _genitive(name).replace("\\", ""), value)
        value = re.sub(r"\bLukas\b", name, value)
    return value
