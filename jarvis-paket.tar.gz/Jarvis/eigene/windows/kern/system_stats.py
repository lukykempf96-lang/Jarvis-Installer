"""Live-Auslastung des PCs fuers Dashboard: CPU, Arbeitsspeicher, Grafik (GPU), Speicherplatz, Akku, Netz.

Windows-Fassung: GPU ueber nvidia-smi (NVIDIA) oder die Windows-Leistungsindikatoren (alle Grafikkarten).
"""
from __future__ import annotations

import os
import shutil
import subprocess
import threading
import time

import psutil

from . import plattform

_lock = threading.Lock()
_procs: dict[int, psutil.Process] = {}
_net_last: tuple | None = None
_gpu = {"at": 0.0, "value": None, "running": False}

psutil.cpu_percent(interval=None)

_GPU_COUNTER = (
    "$s = (Get-Counter '\\GPU Engine(*engtype_3D)\\Utilization Percentage' -ErrorAction SilentlyContinue).CounterSamples;"
    "if ($s) { [math]::Round(($s | Measure-Object -Property CookedValue -Sum).Sum) }"
)


def _measure_gpu():
    value = None
    try:
        if shutil.which("nvidia-smi"):
            out = subprocess.run(["nvidia-smi", "--query-gpu=utilization.gpu", "--format=csv,noheader,nounits"],
                                 capture_output=True, text=True, timeout=5, creationflags=plattform.NO_WINDOW).stdout
            found = [int(v) for v in out.split() if v.strip().isdigit()]
            value = max(found) if found else None
        if value is None:
            out = plattform.powershell(_GPU_COUNTER, timeout=10).stdout.strip()
            value = min(100, int(float(out))) if out else None
    except (OSError, subprocess.SubprocessError, ValueError):
        value = None
    _gpu.update(at=time.time(), value=value, running=False)


def _gpu_percent() -> int | None:
    """Wird im Hintergrund gemessen (der Leistungsindikator braucht etwa eine Sekunde), hoechstens alle 5 Sekunden."""
    if time.time() - _gpu["at"] > 5 and not _gpu["running"]:
        _gpu["running"] = True
        threading.Thread(target=_measure_gpu, daemon=True).start()
    return _gpu["value"]


def _top_processes(count: int = 4) -> list[dict]:
    seen = set()
    usage: dict[str, float] = {}
    for proc in psutil.process_iter(["name"]):
        seen.add(proc.pid)
        cached = _procs.get(proc.pid)
        if cached is None:
            _procs[proc.pid] = proc
            try:
                proc.cpu_percent(None)
            except psutil.Error:
                pass
            continue
        try:
            cpu = cached.cpu_percent(None)
        except psutil.Error:
            continue
        name = (proc.info.get("name") or "?")
        if name.lower() in ("system idle process", "leerlaufprozess", "idle"):
            continue
        name = name[:-4] if name.lower().endswith(".exe") else name
        usage[name] = usage.get(name, 0.0) + cpu
    for pid in list(_procs):
        if pid not in seen:
            _procs.pop(pid, None)
    cores = psutil.cpu_count() or 1
    top = sorted(usage.items(), key=lambda kv: -kv[1])[:count]
    return [{"name": n, "cpu": round(c / cores, 1)} for n, c in top if c > 0.5]


def _disk() -> dict:
    drive = os.environ.get("SystemDrive", "C:") + "\\"
    try:
        d = psutil.disk_usage(drive)
        return {"percent": round(d.percent), "free_gb": round(d.free / 1e9), "total_gb": round(d.total / 1e9)}
    except OSError:
        return {}


def _network() -> dict:
    global _net_last
    io = psutil.net_io_counters()
    now = time.time()
    rate = {"down_kbs": 0, "up_kbs": 0}
    if _net_last:
        dt = max(0.5, now - _net_last[0])
        rate = {"down_kbs": round((io.bytes_recv - _net_last[1]) / dt / 1024),
                "up_kbs": round((io.bytes_sent - _net_last[2]) / dt / 1024)}
    _net_last = (now, io.bytes_recv, io.bytes_sent)
    return rate


def snapshot() -> dict:
    with _lock:
        mem = psutil.virtual_memory()
        battery = None
        try:
            b = psutil.sensors_battery()
            if b:
                battery = {"percent": round(b.percent), "plugged": bool(b.power_plugged)}
        except (AttributeError, OSError):
            pass
        return {
            "cpu": round(psutil.cpu_percent(interval=None)),
            "cores": psutil.cpu_percent(interval=None, percpu=True),
            "ram": round(mem.percent),
            "ram_used_gb": round((mem.total - mem.available) / 2**30, 1),
            "ram_total_gb": round(mem.total / 2**30),
            "gpu": _gpu_percent(),
            "disk": _disk(),
            "battery": battery,
            "net": _network(),
            "top": _top_processes(),
            "uptime_h": round((time.time() - psutil.boot_time()) / 3600),
        }


def describe() -> str:
    s = snapshot()
    time.sleep(1.5)
    s = snapshot()
    parts = [f"CPU {s['cpu']} Prozent", f"Arbeitsspeicher {s['ram']} Prozent ({s['ram_used_gb']} von {s['ram_total_gb']} GB)"]
    if s["gpu"] is not None:
        parts.append(f"Grafik {s['gpu']} Prozent")
    if s["disk"]:
        parts.append(f"Festplatte {s['disk']['percent']} Prozent voll, {s['disk']['free_gb']} GB frei")
    if s["battery"]:
        parts.append(f"Akku {s['battery']['percent']} Prozent" + (" (am Strom)" if s["battery"]["plugged"] else ""))
    top = ", ".join(f"{p['name']} {p['cpu']} %" for p in s["top"][:3])
    return "PC-Auslastung: " + ", ".join(parts) + (f". Am meisten Leistung brauchen: {top}." if top else ".")
