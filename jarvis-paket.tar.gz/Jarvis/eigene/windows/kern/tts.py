"""Sprachausgabe (Windows-Fassung): ElevenLabs wie am Mac, sonst die eingebaute Windows-Stimme (System.Speech)."""
from __future__ import annotations

import hashlib
import os
import subprocess
import tempfile
from pathlib import Path

import httpx

from . import plattform
from .config import settings

ELEVENLABS_URL = "https://api.elevenlabs.io/v1/text-to-speech/{voice_id}"
CACHE_DIR = Path(__file__).resolve().parent.parent / "stimmen-cache"

# Deutsche Stimme nehmen (Hedda, Katja, Stefan ...), oder die in JARVIS_WIN_VOICE genannte
_SPEAK = r"""
Add-Type -AssemblyName System.Speech
$s = New-Object System.Speech.Synthesis.SpeechSynthesizer
$chosen = $false
if ($env:JARVIS_VOICE) { try { $s.SelectVoice($env:JARVIS_VOICE); $chosen = $true } catch {} }
if (-not $chosen) {
    $v = $s.GetInstalledVoices() | Where-Object { $_.Enabled -and $_.VoiceInfo.Culture.Name -like 'de*' } | Select-Object -First 1
    if ($v) { $s.SelectVoice($v.VoiceInfo.Name) }
}
$s.Rate = 1
$s.SetOutputToWaveFile($env:JARVIS_OUT)
$s.Speak([IO.File]::ReadAllText($env:JARVIS_IN, [Text.Encoding]::UTF8))
$s.Dispose()
"""


def _elevenlabs(text: str) -> bytes | None:
    url = ELEVENLABS_URL.format(voice_id=settings.elevenlabs_voice_id)
    headers = {"xi-api-key": settings.elevenlabs_api_key, "Content-Type": "application/json", "Accept": "audio/mpeg"}
    payload = {"text": text, "model_id": "eleven_multilingual_v2",
               "voice_settings": {"stability": 0.4, "similarity_boost": 0.8}}
    try:
        resp = httpx.post(url, headers=headers, json=payload, timeout=30)
        resp.raise_for_status()
        return resp.content
    except httpx.HTTPError as exc:
        print(f"ElevenLabs-Fehler, nehme Windows-Stimme: {exc}")
        return None


def _windows_voice(text: str) -> bytes | None:
    tmp = Path(tempfile.mkdtemp(prefix="jarvis_say_"))
    source, wav = tmp / "text.txt", tmp / "stimme.wav"
    source.write_text(text, encoding="utf-8")
    try:
        plattform.powershell(_SPEAK, timeout=60, env={"JARVIS_IN": str(source), "JARVIS_OUT": str(wav),
                                                       "JARVIS_VOICE": settings.mac_voice or ""})
        return wav.read_bytes() if wav.exists() and wav.stat().st_size > 100 else None
    except (OSError, subprocess.SubprocessError):
        return None
    finally:
        for f in (source, wav):
            try:
                f.unlink()
            except OSError:
                pass
        try:
            os.rmdir(tmp)
        except OSError:
            pass


def synthesize_speech(text: str, cache: bool = False) -> tuple[bytes, str] | None:
    """Liefert (Audio, Medientyp) oder None. Mit cache=True wird der Satz nur einmal erzeugt."""
    if not cache:
        return _synthesize(text)
    voice = settings.elevenlabs_voice_id if settings.elevenlabs_api_key else (settings.mac_voice or "windows")
    stem = hashlib.sha1(f"{voice}|{text}".encode()).hexdigest()[:20]
    for suffix, media_type in ((".mp3", "audio/mpeg"), (".wav", "audio/wav")):
        cached = CACHE_DIR / (stem + suffix)
        if cached.exists():
            return cached.read_bytes(), media_type
    result = _synthesize(text)
    if result:
        CACHE_DIR.mkdir(exist_ok=True)
        (CACHE_DIR / (stem + (".mp3" if result[1] == "audio/mpeg" else ".wav"))).write_bytes(result[0])
    return result


def _synthesize(text: str) -> tuple[bytes, str] | None:
    if settings.elevenlabs_api_key:
        audio = _elevenlabs(text)
        if audio:
            return audio, "audio/mpeg"
    audio = _windows_voice(text)
    if audio:
        return audio, "audio/wav"
    return None
