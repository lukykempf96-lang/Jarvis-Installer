"""Fahrzeit und Strecke unter Windows (Windows-Fassung von karten.py, statt Apple Karten).

Orte sucht OpenStreetMap (Nominatim), die Strecke rechnet OSRM; beides kostenlos und ohne Schluessel, aber
ohne aktuelle Verkehrslage. Bus und Bahn kann es nicht: dann oeffnet Jarvis Google Maps im Browser.
Links aufs Handy sind Google-Maps-Links (gehen auf iPhone und Android).
"""
from __future__ import annotations

import time
import webbrowser
from datetime import datetime, timedelta
from pathlib import Path
from urllib.parse import quote

import httpx

from .config import settings

JARVIS_DIR = Path(__file__).resolve().parent.parent
HOME_FILE = JARVIS_DIR / "heimadresse.txt"

MODES = {"auto": ("Mit dem Auto", "driving"), "zu_fuss": ("Zu Fuss", "walking"), "oepnv": ("Mit Bus und Bahn", "transit")}
ROUTERS = {
    "auto": "https://router.project-osrm.org/route/v1/driving/",
    "zu_fuss": "https://routing.openstreetmap.de/routed-foot/route/v1/foot/",
}
HEADERS = {"User-Agent": "Jarvis-Sprachassistent/1.0 (privat)"}
_last_lookup = [0.0]


def home_address() -> str:
    try:
        value = HOME_FILE.read_text(encoding="utf-8").strip()
        if value:
            return value
    except OSError:
        pass
    return settings.weather_city


def set_home_address(address: str) -> str:
    address = " ".join(address.split())
    if not address:
        return "Keine Adresse genannt."
    HOME_FILE.write_text(address + "\n", encoding="utf-8")
    return f"Gemerkt: Zuhause ist {address}. Ohne Startpunkt rechne ich ab dort."


def maps_link(start: str, destination: str, mode: str = "auto") -> str:
    """Google-Maps-Link mit Route; oeffnet auf dem Handy die Karten-App."""
    travel = MODES.get(mode, MODES["auto"])[1]
    return (f"https://www.google.com/maps/dir/?api=1&origin={quote(start)}&destination={quote(destination)}"
            f"&travelmode={travel}")


def _geocode(place: str) -> tuple[float, float, str] | None:
    wait = 1.1 - (time.monotonic() - _last_lookup[0])  # Nominatim erlaubt eine Anfrage pro Sekunde
    if wait > 0:
        time.sleep(wait)
    _last_lookup[0] = time.monotonic()
    resp = httpx.get("https://nominatim.openstreetmap.org/search", headers=HEADERS, timeout=15,
                     params={"q": place, "format": "json", "limit": 1, "accept-language": "de"})
    hits = resp.json() if resp.status_code == 200 else []
    if not hits:
        return None
    name = hits[0].get("display_name", place).split(",")[0]
    return float(hits[0]["lat"]), float(hits[0]["lon"]), name


def _duration(seconds: float) -> str:
    minutes = max(1, round(seconds / 60))
    if minutes < 60:
        return f"{minutes} Minuten" if minutes != 1 else "1 Minute"
    hours, rest = divmod(minutes, 60)
    text = "1 Stunde" if hours == 1 else f"{hours} Stunden"
    if not rest:
        return text
    return f"{text} {rest} Minute" if rest == 1 else f"{text} {rest} Minuten"


def route(destination: str, start: str = "", mode: str = "auto", show: bool = False) -> str:
    destination = destination.strip()
    if not destination:
        return "Kein Ziel genannt."
    start = start.strip() or home_address()
    mode = mode if mode in MODES else "auto"
    how = MODES[mode][0]
    link = maps_link(start, destination, mode)
    if show or mode not in ROUTERS:
        webbrowser.open(link)
    if mode not in ROUTERS:
        return (f"Fahrplaene fuer Bus und Bahn kann ich unter Windows nicht selbst abfragen. Ich habe die Verbindung "
                f"von {start} nach {destination} in Google Maps im Browser geoeffnet.")
    try:
        a, b = _geocode(start), _geocode(destination)
        if a is None or b is None:
            missing = start if a is None else destination
            return f"Ich finde den Ort {missing} nicht. Frag Lukas nach einer genaueren Adresse."
        resp = httpx.get(f"{ROUTERS[mode]}{a[1]},{a[0]};{b[1]},{b[0]}", headers=HEADERS, timeout=20,
                         params={"overview": "false"})
        data = resp.json()
        if data.get("code") != "Ok" or not data.get("routes"):
            raise RuntimeError(data.get("message") or data.get("code") or "keine Route")
    except Exception as exc:
        print(f"Fahrzeit nicht moeglich: {exc!r}", flush=True)
        if not show:
            webbrowser.open(link)
        return (f"Die Fahrzeit konnte ich nicht abfragen. Ich habe die Route von {start} nach {destination} "
                "in Google Maps im Browser geoeffnet.")
    best = data["routes"][0]
    arrival = (datetime.now() + timedelta(seconds=best["duration"])).strftime("%H:%M")
    km = best["distance"] / 1000
    distance = f"{km:.0f} Kilometer" if km >= 10 else f"{km:.1f} Kilometer".replace(".", ",")
    traffic = " ohne aktuelle Verkehrslage" if mode == "auto" else ""
    return (f"{how} von {a[2]} nach {b[2]}: etwa {_duration(best['duration'])}{traffic} "
            f"(Abfahrt jetzt, Ankunft gegen {arrival} Uhr), {distance}. Quelle: OpenStreetMap.")


def _ensure_helper():
    """Gibt es unter Windows nicht (am Mac das Apple-Karten-Hilfsprogramm)."""
    return None
