"""Eingang-Liste fürs Jarvis-Fenster: zeigt die eingefügten und reingezogenen Dateien (Ordner eingang/) und löscht
einzelne wieder. Gelöscht wird nur, was wirklich im Eingang liegt; leere Unterordner verschwinden mit."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

BESCHREIBUNG = "Eingang-Liste im Fenster: eingefügte Dateien sehen und per X wieder löschen"

EINGANG = Path(__file__).resolve().parent.parent / "eingang"
ANZAHL = 40


def _wann(ts: float) -> str:
    dt, jetzt = datetime.fromtimestamp(ts), datetime.now()
    tage = (jetzt.date() - dt.date()).days
    if tage == 0:
        return dt.strftime("heute %H:%M")
    if tage == 1:
        return dt.strftime("gestern %H:%M")
    return dt.strftime("%d.%m. %H:%M")


def _groesse(n: int) -> str:
    for einheit in ("Bytes", "KB", "MB", "GB"):
        if n < 1024 or einheit == "GB":
            return f"{n:.0f} {einheit}" if einheit == "Bytes" else f"{n:.1f} {einheit}".replace(".", ",")
        n /= 1024
    return ""


def liste() -> dict:
    if not EINGANG.is_dir():
        return {"dateien": [], "gesamt": 0}
    dateien = []
    for pfad in EINGANG.rglob("*"):
        rel = pfad.relative_to(EINGANG)
        if pfad.is_file() and not any(teil.startswith(".") for teil in rel.parts):
            try:
                st = pfad.stat()
            except OSError:
                continue
            dateien.append((st.st_mtime, st.st_size, rel))
    dateien.sort(key=lambda d: d[0], reverse=True)
    return {"gesamt": len(dateien), "dateien": [
        {"pfad": rel.as_posix(), "name": rel.name, "ordner": rel.parts[0] if len(rel.parts) > 1 else "",
         "groesse": _groesse(groesse), "wann": _wann(zeit)}
        for zeit, groesse, rel in dateien[:ANZAHL]]}


def loeschen(pfad: str = "") -> dict:
    basis = EINGANG.resolve()
    ziel = (EINGANG / str(pfad)).resolve()
    if basis not in ziel.parents or not ziel.is_file():
        return {**liste(), "fehler": "Diese Datei liegt nicht im Eingang."}
    ziel.unlink()
    ordner = ziel.parent
    while ordner != basis and basis in ordner.parents:  # leere Upload-Ordner mit aufräumen
        try:
            if any(p for p in ordner.iterdir() if p.name != ".DS_Store"):
                break
            for p in ordner.iterdir():
                p.unlink()
            ordner.rmdir()
        except OSError:
            break
        ordner = ordner.parent
    return {**liste(), "geloescht": ziel.name}


API = {"liste": liste, "loeschen": loeschen}
