"""Urlaub aus dem Dashboard filtern: Urlaubs-Einträge erscheinen nicht mehr unter Termine (auch nicht in der
Wochenauslastung), und der Kalender im Dashboard wird alle 30 Sekunden neu gelesen statt alle 5 Minuten.

Erkannt wird Urlaub am Titel oder am Kalendernamen (Wörter unten). Feiertage bleiben stehen.
Jarvis selbst sieht Urlaub weiterhin, wenn Lukas nach seinen Terminen fragt; gefiltert wird nur die Anzeige.
Dafür wird im laufenden Jarvis der Kalender-Teil des Dashboards umgeleitet (der Kern bleibt unverändert).
"""

from __future__ import annotations

import re
import sys
import types
import unicodedata
from datetime import datetime, timedelta

BESCHREIBUNG = "Dashboard ohne Urlaub: Urlaubs-Einträge werden unter Termine automatisch ausgeblendet"

# Woran Urlaub erkannt wird (klein, ä = ae usw.)
URLAUB = re.compile(r"urlaub|ferien|vacation|\bholiday\b|abwesen|out of office|\booo\b|\bpto\b|elternzeit|sonderurlaub")
NEU_LADEN_NACH = 30  # Sekunden: so alt darf der Kalender im Dashboard höchstens sein

_halter = sys.modules.setdefault("_jarvis_urlaub_filter_halter", types.ModuleType("_jarvis_urlaub_filter_halter"))
if not hasattr(_halter, "orig"):
    _halter.orig = None


def _norm(text: str) -> str:
    text = (text or "").lower()
    for umlaut, plain in (("ä", "ae"), ("ö", "oe"), ("ü", "ue"), ("ß", "ss")):
        text = text.replace(umlaut, plain)
    return "".join(c for c in unicodedata.normalize("NFKD", text) if not unicodedata.combining(c))


def ist_urlaub(event: dict) -> bool:
    return bool(URLAUB.search(_norm(event.get("title", ""))) or URLAUB.search(_norm(event.get("calendar", ""))))


def _calendar_section(publish) -> dict:
    """Wie im Kern (dashboard._calendar_section), nur ohne Urlaub."""
    from backend import alltag, dashboard

    now = datetime.now()
    monday = (now - timedelta(days=now.weekday())).replace(hour=0, minute=0, second=0, microsecond=0)
    today = now.replace(hour=0, minute=0, second=0, microsecond=0)
    events = alltag.fetch_events_between(min(monday, today), max(monday + timedelta(days=7), today + timedelta(days=5)))
    events = [e for e in events if not ist_urlaub(e)]
    return {"agenda": dashboard._agenda(events, now), "week": dashboard.week_load(events, now)}


_calendar_section._jarvis_urlaub = True


def _einhaengen():
    from backend import dashboard

    eintrag = dashboard.SECTIONS.get("calendar")
    if not eintrag:
        return
    fn, _alter, *rest = eintrag
    if not getattr(fn, "_jarvis_urlaub", False):
        _halter.orig = eintrag  # den Kern-Eintrag merken
    dashboard.SECTIONS["calendar"] = (_calendar_section, NEU_LADEN_NACH, *rest)
    dashboard._sections["calendar"]["at"] = 0.0  # sofort neu laden, damit der Urlaub gleich verschwindet


_einhaengen()
