"""Datensicherung auf ein Laufwerk: angeschlossene Laufwerke zeigen, Sicherungsordner wählen, Projekte dorthin sichern.

Jede Sicherung kommt in einen eigenen Ordner mit Datum (<Ziel>/<Projekt>/<Projekt> 2026-10-07 14-30), ältere bleiben
liegen. Nicht mitkopiert wird, was sich jederzeit neu erzeugen lässt (venv, node_modules, __pycache__ ...) und Dateien
mit Schlüsseln oder Passwörtern (.env, Schlüsseldateien), damit die nicht ungeschützt auf einem Stick landen.
Erst wird in einen Ordner "… (unvollständig)" kopiert und nachgezählt; nur wenn alles da ist, bekommt er den
richtigen Namen.
"""

from __future__ import annotations

import json
import os
import plistlib
import shutil
import subprocess
import threading
import time
from datetime import datetime
from pathlib import Path

BESCHREIBUNG = "Datensicherung: Projekte in den gewählten Sicherungsordner auf einem Laufwerk kopieren"
PROMPT = (
    "Will Lukas ein Projekt sichern, auf die Festplatte oder den Stick kopieren, nutze projekt_sichern und sag danach "
    "kurz, ob es geklappt hat, wohin und wie viel. Den Sicherungsordner wählt er rechts im Fenster im Feld Laufwerke. "
    "Will er eine Datei oder einen Ordner (z. B. den Jarvis-Export vom Schreibtisch oder die Installationsanleitung) auf "
    "ein Laufwerk legen, nutze auf_laufwerk_kopieren, für mehreres nacheinander."
)

VOLUMES = Path("/Volumes")
DATEI = Path(__file__).resolve().parent / "daten" / "sicherung.json"
WEGLASSEN = {"venv", ".venv", "node_modules", "__pycache__", ".DS_Store", ".cache", ".Trash", ".pytest_cache",
             ".mypy_cache", "stimmen-cache", ".eigene-sicherung"}
GROSS = 400 * 1024 * 1024  # darüber läuft die Sicherung im Hintergrund und Jarvis meldet sich danach

_lock = threading.Lock()
_laeuft: dict[str, str] = {}  # Projekt -> Zielordner, solange gesichert wird
_info_cache: dict = {}


# ---------- Einstellungen ----------

def _laden() -> dict:
    try:
        return json.loads(DATEI.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {"ziel": "", "verlauf": []}


def _speichern(daten: dict):
    DATEI.parent.mkdir(parents=True, exist_ok=True)
    tmp = DATEI.with_suffix(".tmp")
    tmp.write_text(json.dumps(daten, ensure_ascii=False, indent=1), encoding="utf-8")
    os.replace(tmp, DATEI)


def _auf_laufwerk(pfad: Path) -> bool:
    """Nur Ordner auf angeschlossenen Laufwerken (/Volumes/...), nicht die interne Festplatte."""
    try:
        echt = pfad.resolve()
    except OSError:
        return False
    return len(echt.parts) >= 3 and echt.parts[1] == "Volumes" and echt != Path("/")


# ---------- Laufwerke ----------

def _gb(n: float) -> str:
    if n < 1e9:
        return f"{max(1, round(n / 1e6))} MB" if n >= 1e5 else "unter 1 MB"
    return f"{n / 1e9:.0f} GB" if n >= 10e9 else f"{n / 1e9:.1f} GB".replace(".", ",")


def _diskutil(mount: str) -> dict:
    """Extern, USB, auswerfbar? (diskutil, eine Minute gemerkt)"""
    gemerkt = _info_cache.get(mount)
    if gemerkt and time.time() - gemerkt[0] < 60:
        return gemerkt[1]
    info = {}
    try:
        roh = subprocess.run(["diskutil", "info", "-plist", mount], capture_output=True, timeout=8).stdout
        info = plistlib.loads(roh) if roh else {}
    except (OSError, subprocess.SubprocessError, ValueError):
        info = {}
    _info_cache[mount] = (time.time(), info)
    return info


def laufwerke() -> list[dict]:
    gefunden = []
    if not VOLUMES.is_dir():
        return gefunden
    for eintrag in sorted(VOLUMES.iterdir()):
        try:
            if eintrag.is_symlink() or not eintrag.is_dir() or eintrag.name.startswith("."):
                continue  # "Macintosh HD" ist nur ein Verweis auf die interne Festplatte
            nutzung = shutil.disk_usage(eintrag)
        except OSError:
            continue
        info = _diskutil(str(eintrag))
        intern = bool(info.get("Internal")) and not info.get("Ejectable") and not info.get("RemovableMedia")
        if intern:
            continue  # nur angeschlossene Laufwerke, nicht Teile der eingebauten Festplatte
        art = ("USB" if info.get("BusProtocol") == "USB" else
               "Netzwerk" if info.get("FilesystemType") in ("smbfs", "afpfs", "nfs", "webdav") else
               "Disk-Image" if info.get("BusProtocol") == "Disk Image" else "extern")
        gefunden.append({"name": eintrag.name, "pfad": str(eintrag), "art": art,
                         "frei": _gb(nutzung.free), "gesamt": _gb(nutzung.total),
                         "belegt_prozent": round(100 * nutzung.used / nutzung.total) if nutzung.total else 0,
                         "beschreibbar": os.access(eintrag, os.W_OK)})
    return gefunden


# ---------- Für das Fenster ----------

def stand() -> dict:
    daten = _laden()
    ziel = daten.get("ziel", "")
    return {"laufwerke": laufwerke(), "ziel": ziel, "ziel_da": bool(ziel) and Path(ziel).is_dir(),
            "laeuft": dict(_laeuft), "verlauf": daten.get("verlauf", [])[-5:][::-1]}


def ordner(pfad: str = "") -> dict:
    basis = Path(pfad)
    if not _auf_laufwerk(basis) or not basis.is_dir():
        return {"fehler": "Kein Ordner auf einem Laufwerk."}
    try:
        unter = sorted((p.name for p in basis.iterdir()
                        if p.is_dir() and not p.name.startswith(".") and not p.is_symlink()), key=str.lower)
    except OSError as exc:
        return {"fehler": f"Ordner lässt sich nicht lesen ({exc.strerror or exc})."}
    teile = basis.resolve().parts
    oben = str(Path(*teile[:-1])) if len(teile) > 3 else ""
    return {"pfad": str(basis), "oben": oben, "ordner": unter[:300], "beschreibbar": os.access(basis, os.W_OK)}


def ziel_setzen(pfad: str = "") -> dict:
    ordner_pfad = Path(pfad)
    if not _auf_laufwerk(ordner_pfad) or not ordner_pfad.is_dir():
        return {**stand(), "fehler": "Bitte einen Ordner auf einem angeschlossenen Laufwerk wählen."}
    if not os.access(ordner_pfad, os.W_OK):
        return {**stand(), "fehler": "In diesen Ordner darf ich nicht schreiben (schreibgeschützt?)."}
    daten = _laden()
    daten["ziel"] = str(ordner_pfad)
    _speichern(daten)
    return stand()


def neuer_ordner(pfad: str = "", name: str = "") -> dict:
    basis = Path(pfad)
    sauber = "".join(c for c in (name or "").strip() if c.isalnum() or c in " -_.")[:80].strip(" .")
    if not sauber or not _auf_laufwerk(basis) or not basis.is_dir():
        return {"fehler": "Ungültiger Name oder Ort."}
    try:
        (basis / sauber).mkdir(exist_ok=True)
    except OSError as exc:
        return {"fehler": f"Ordner ließ sich nicht anlegen ({exc.strerror or exc})."}
    return ordner(str(basis / sauber))


API = {"stand": stand, "ordner": ordner, "ziel_setzen": ziel_setzen, "neuer_ordner": neuer_ordner}


# ---------- Sichern ----------

def _geheim(pfad: Path) -> bool:
    from backend import files
    return files._is_secret(pfad)


def _auswahl(quelle: Path) -> tuple[int, int, int]:
    """(Dateien, Bytes, weggelassene Geheimnisse) dessen, was kopiert wird."""
    dateien = bytes_ = geheim = 0
    for wurzel, ordner_liste, namen in os.walk(quelle):
        ordner_liste[:] = [o for o in ordner_liste if o not in WEGLASSEN and not os.path.islink(os.path.join(wurzel, o))]
        for name in namen:
            p = Path(wurzel) / name
            if name in WEGLASSEN:
                continue
            if _geheim(p):
                geheim += 1
                continue
            try:
                bytes_ += p.lstat().st_size
                dateien += 1
            except OSError:
                pass
    return dateien, bytes_, geheim


def _ignorieren(ordner_pfad, namen):
    return [n for n in namen if n in WEGLASSEN or _geheim(Path(ordner_pfad) / n)]


def _kopieren(name: str, quelle: Path, ziel_basis: Path, erwartet: tuple[int, int, int]) -> str:
    stempel = datetime.now().strftime("%Y-%m-%d %H-%M")
    fertig = ziel_basis / name / f"{name} {stempel}"
    halb = fertig.with_name(fertig.name + " (unvollständig)")
    start = time.time()
    fehler = []
    try:
        halb.parent.mkdir(parents=True, exist_ok=True)
        if halb.exists():
            shutil.rmtree(halb)
        shutil.copytree(quelle, halb, symlinks=True, ignore=_ignorieren)
    except shutil.Error as exc:
        fehler = [str(e[0]) for e in exc.args[0]][:5] if exc.args and isinstance(exc.args[0], list) else [str(exc)]
    except OSError as exc:
        return f"Sicherung von {name} fehlgeschlagen: {exc.strerror or exc}. Ist das Laufwerk noch angeschlossen?"
    # nachzählen
    anzahl = groesse = 0
    for wurzel, _, namen in os.walk(halb):
        for n in namen:
            try:
                groesse += (Path(wurzel) / n).lstat().st_size
                anzahl += 1
            except OSError:
                pass
    vollstaendig = not fehler and anzahl >= erwartet[0] and groesse >= erwartet[1]
    if vollstaendig:
        halb.rename(fertig)
    ziel_text = fertig if vollstaendig else halb
    daten = _laden()
    daten.setdefault("verlauf", []).append({"projekt": name, "ziel": str(ziel_text), "ok": vollstaendig,
                                            "wann": datetime.now().strftime("%d.%m. %H:%M"),
                                            "groesse": _gb(groesse), "dateien": anzahl})
    daten["verlauf"] = daten["verlauf"][-30:]
    _speichern(daten)
    sekunden = round(time.time() - start)
    weg = f" Schlüsseldateien ({erwartet[2]}) habe ich bewusst nicht mitkopiert." if erwartet[2] else ""
    laufwerk = Path(ziel_text).parts[2] if len(Path(ziel_text).parts) > 2 else "dem Laufwerk"
    if vollstaendig:
        return (f"Sicherung von {name} hat geklappt: {anzahl} Dateien, {_gb(groesse)}, in {sekunden} Sekunden auf "
                f"{laufwerk}, Ordner {fertig.name}.{weg}")
    grund = f" Probleme mit: {', '.join(fehler)}." if fehler else f" Es fehlen Dateien ({anzahl} von {erwartet[0]})."
    return f"Sicherung von {name} ist unvollständig.{grund} Der Ordner heißt {halb.name}."


def _im_hintergrund(name: str, quelle: Path, ziel: Path, erwartet: tuple):
    try:
        text = _kopieren(name, quelle, ziel, erwartet)
    except Exception as exc:
        text = f"Sicherung von {name} fehlgeschlagen: {exc}"
    finally:
        _laeuft.pop(name, None)
    print(text, flush=True)
    from backend import claude_code
    if claude_code.on_done:
        claude_code.on_done(text)  # im Fenster zeigen und vorlesen


ANLEITUNG = Path(__file__).resolve().parent / "INSTALLATIONSANLEITUNG-MAC.txt"


def _ordner_suchen(name: str, laufwerk: str = "") -> list[Path]:
    """Ordner mit diesem Namen auf den Laufwerken (zuerst im Sicherungsziel), höchstens 4 Ebenen tief."""
    gesucht = name.strip().strip("/").lower()
    basen = []
    ziel = _laden().get("ziel", "")
    if ziel and Path(ziel).is_dir():
        basen.append(Path(ziel))
    basen += [lw for lw in (Path(l["pfad"]) for l in laufwerke())
              if not laufwerk or laufwerk.lower() in lw.name.lower()]
    treffer, besucht = [], 0
    for basis in basen:
        stapel = [(basis, 0)]
        while stapel and besucht < 20000:
            ordner_pfad, tiefe = stapel.pop()
            try:
                eintraege = list(os.scandir(ordner_pfad))
            except OSError:
                continue
            for e in eintraege:
                besucht += 1
                if not e.is_dir(follow_symlinks=False) or e.name.startswith("."):
                    continue
                if e.name.lower() == gesucht and Path(e.path) not in treffer:
                    treffer.append(Path(e.path))
                if tiefe < 4:
                    stapel.append((Path(e.path), tiefe + 1))
    return treffer


def auf_laufwerk_kopieren(quelle: str, ziel: str, laufwerk: str = "") -> str:
    from backend import files

    if (quelle or "").strip().lower() in ("anleitung", "installationsanleitung", "installationsanleitung mac",
                                          "installationsanleitung-mac.txt"):
        quelle_pfad = ANLEITUNG
    else:
        quelle_pfad = files.resolve(quelle or "")
    if not quelle_pfad.exists():
        return f"{quelle} gibt es nicht."
    if _geheim(quelle_pfad):
        return "Das ist eine Datei mit Schlüsseln oder Passwörtern, die kopiere ich nicht auf ein Laufwerk."
    ziel_pfad = Path(ziel or "")
    if not (ziel_pfad.is_absolute() and ziel_pfad.is_dir()):
        gefunden = _ordner_suchen(ziel_pfad.name or ziel, laufwerk)
        if not gefunden:
            return f"Ich finde keinen Ordner '{ziel}' auf den angeschlossenen Laufwerken."
        if len(gefunden) > 1:
            return "Mehrere Ordner passen, frag Lukas welcher: " + "; ".join(str(g) for g in gefunden[:5])
        ziel_pfad = gefunden[0]
    if not _auf_laufwerk(ziel_pfad):
        return "Ich kopiere nur auf angeschlossene Laufwerke (externe Festplatten, Sticks)."
    if not os.access(ziel_pfad, os.W_OK):
        return f"In {ziel_pfad} darf ich nicht schreiben."
    neu = ziel_pfad / quelle_pfad.name
    n = 2
    while neu.exists():
        neu = ziel_pfad / f"{quelle_pfad.stem} ({n}){quelle_pfad.suffix}"
        n += 1
    try:
        if quelle_pfad.is_dir():
            dateien, groesse, geheim = _auswahl(quelle_pfad)
            if groesse * 1.05 + 20e6 > shutil.disk_usage(ziel_pfad).free:
                return f"Zu wenig Platz: gebraucht werden etwa {_gb(groesse)}."
            shutil.copytree(quelle_pfad, neu, symlinks=True, ignore=_ignorieren)
            weg = f" Schlüsseldateien ({geheim}) habe ich weggelassen." if geheim else ""
            return f"Kopiert: Ordner {quelle_pfad.name} ({dateien} Dateien, {_gb(groesse)}) nach {neu}.{weg}"
        shutil.copy2(quelle_pfad, neu)
        return f"Kopiert: {quelle_pfad.name} nach {neu}."
    except (OSError, shutil.Error) as exc:
        return f"Kopieren fehlgeschlagen: {exc}. Ist das Laufwerk noch angeschlossen?"


TOOLS = [{
    "name": "auf_laufwerk_kopieren",
    "description": "Kopiert eine Datei oder einen Ordner vom Mac in einen Ordner auf einem angeschlossenen Laufwerk "
                   "(externe Festplatte, Stick). quelle = Pfad wie 'Schreibtisch/Jarvis-Export' oder 'anleitung' für "
                   "die Installationsanleitung von Jarvis. ziel = Ordnerpfad oder nur der Ordnername, z. B. "
                   "'Jarvis 2026-10-06 19-09'. Dateien mit Schlüsseln werden nie kopiert.",
    "input_schema": {"type": "object", "properties": {
        "quelle": {"type": "string"},
        "ziel": {"type": "string"},
        "laufwerk": {"type": "string", "description": "Name des Laufwerks, falls genannt, z. B. Schnitt SSD 2T"}},
        "required": ["quelle", "ziel"]},
}, {
    "name": "projekt_sichern",
    "description": "Sichert ein Projekt (Name wie bei Claude Code, z. B. Jarvis, oder ein Ordnerpfad) als Kopie mit "
                   "Datum in den Sicherungsordner, den Lukas rechts im Fenster unter Laufwerke gewählt hat. Meldet, "
                   "ob es geklappt hat. Grosse Projekte laufen im Hintergrund, das Ergebnis kommt dann als Meldung.",
    "input_schema": {"type": "object", "properties": {
        "projekt": {"type": "string", "description": "Projektname oder Ordnerpfad"}}, "required": ["projekt"]},
}]


def projekt_sichern(projekt: str) -> str:
    from backend import claude_code

    ziel_text = _laden().get("ziel", "")
    if not ziel_text:
        return ("Es ist noch kein Sicherungsordner gewählt. Rechts im Fenster im Feld Laufwerke ein Laufwerk antippen, "
                "einen Ordner wählen und 'Hier sichern' klicken.")
    ziel = Path(ziel_text)
    if not ziel.is_dir():
        return f"Das Laufwerk mit dem Sicherungsordner ({ziel_text}) ist gerade nicht angeschlossen."
    treffer = claude_code._match(projekt or "")
    if not treffer:
        return f"Projekt '{projekt}' nicht gefunden. {claude_code.list_projects()}"
    name, quelle = treffer
    if ziel.resolve() == quelle.resolve() or quelle.resolve() in ziel.resolve().parents:
        return "Der Sicherungsordner liegt im Projekt selbst, das geht nicht."
    with _lock:
        if name in _laeuft:
            return f"{name} wird gerade schon gesichert."
        _laeuft[name] = str(ziel)
    try:
        erwartet = _auswahl(quelle)
        frei = shutil.disk_usage(ziel).free
        if erwartet[1] * 1.05 + 50e6 > frei:
            _laeuft.pop(name, None)
            return (f"Auf dem Laufwerk ist zu wenig Platz: {name} braucht etwa {_gb(erwartet[1])}, frei sind {_gb(frei)}. "
                    "Alte Sicherungen löschen oder ein anderes Laufwerk wählen.")
        if erwartet[1] > GROSS:
            threading.Thread(target=_im_hintergrund, args=(name, quelle, ziel, erwartet), daemon=True,
                             name=f"sicherung-{name}").start()
            return (f"{name} ist mit {_gb(erwartet[1])} gross, die Sicherung läuft im Hintergrund. "
                    "Ich sage Bescheid, wenn sie fertig ist.")
        try:
            return _kopieren(name, quelle, ziel, erwartet)
        finally:
            _laeuft.pop(name, None)
    except Exception:
        _laeuft.pop(name, None)
        raise
