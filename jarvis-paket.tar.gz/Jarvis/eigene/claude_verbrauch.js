// Claude-Verbrauch im Dashboard links: 5-Stunden-Fenster, Woche, Limits und ob Claude Code bereit ist.
(() => {
  const col = document.querySelector(".left-col");
  if (!col || document.getElementById("cv-panel")) return;

  const panel = document.createElement("section");
  panel.id = "cv-panel";
  panel.className = "panel cv-panel";
  panel.innerHTML = `
    <div class="panel-head"><h2>Claude</h2><span id="cv-meta" class="meta"></span></div>
    <div id="cv-status" class="cv-status"></div>
    <div class="cv-block">
      <div class="cv-row"><span>5-Stunden-Fenster</span><b id="cv-fenster-zahl">–</b></div>
      <div class="cv-bar" title="Verglichen mit deinem stärksten 5-Stunden-Fenster der letzten Tage"><span id="cv-fenster-bar"></span></div>
      <div id="cv-fenster-info" class="cv-info"></div>
    </div>
    <div class="cv-block">
      <div class="cv-row"><span>Letzte 7 Tage</span><b id="cv-woche-zahl">–</b></div>
      <div id="cv-tage" class="cv-tage"></div>
      <div id="cv-woche-info" class="cv-info"></div>
    </div>
    <p class="hint cv-hint">Verbrauch von Claude Code auf diesem Mac. Wie viel Prozent vom Abo das ist,
      zeigt nur Claude selbst (in Claude Code: /usage). Die Claude-App zählt hier nicht mit.</p>`;
  const week = col.querySelector(".week-panel");
  week ? week.after(panel) : col.prepend(panel);

  const $ = (id) => document.getElementById(id);
  const tok = (n) => n >= 1e6 ? (n / 1e6).toFixed(1).replace(".", ",") + " Mio." : n >= 1000 ? Math.round(n / 1000) + " Tsd." : String(n);

  function zeigen(d) {
    if (!d.gefunden) {
      $("cv-status").className = "cv-status";
      $("cv-status").textContent = "Keine Claude-Code-Protokolle gefunden.";
      return;
    }
    const st = $("cv-status");
    if (d.sperre) {
      st.className = "cv-status cv-rot";
      st.textContent = `${d.sperre.art === "woche" ? "Wochenlimit" : "Limit"} erreicht · wieder frei ${d.sperre.frei} (in ${d.sperre.noch})`;
      st.title = d.sperre.text;
    } else {
      st.className = "cv-status cv-gruen";
      st.textContent = "Claude Code bereit · kein Limit gemeldet";
      st.title = "";
    }

    const f = d.fenster;
    $("cv-fenster-zahl").textContent = f ? tok(f.tokens) + " Tokens" : "kein aktives";
    const bar = $("cv-fenster-bar");
    const anteil = f ? Math.min(100, f.anteil_rekord) : 0;
    bar.style.width = anteil + "%";
    bar.className = d.sperre && d.sperre.art !== "woche" ? "cv-voll" : anteil > 80 ? "cv-hoch" : "";
    $("cv-fenster-info").textContent = f
      ? `seit ${f.start} Uhr, ${f.anfragen} Anfragen · Reset ${f.reset} (noch ${f.noch}) · ${f.anteil_rekord} % deines bisher stärksten Fensters`
      : "Die nächste Aufgabe startet ein neues Fenster (5 Stunden).";

    const w = d.woche;
    $("cv-woche-zahl").textContent = tok(w.tokens) + " Tokens";
    const max = Math.max(1, ...w.tage.map((t) => t.tokens));
    $("cv-tage").replaceChildren(...w.tage.map((t) => {
      const el = document.createElement("div");
      el.className = "cv-tag" + (t.heute ? " cv-heute" : "");
      el.title = `${t.label}: ${tok(t.tokens)} Tokens`;
      el.innerHTML = `<i style="height:${Math.max(t.tokens ? 6 : 2, Math.round(100 * t.tokens / max))}%"></i><span>${t.label}</span>`;
      return el;
    }));
    $("cv-woche-info").textContent = w.limit_erreicht
      ? "Wochenlimit erreicht."
      : `${w.anfragen} Anfragen · Wochenlimit: kein Hinweis auf Erreichen`;
    $("cv-meta").textContent = d.zuletzt ? `zuletzt ${d.zuletzt}` : "";
  }

  async function laden() {
    try {
      zeigen(await fetch("/api/eigene/claude_verbrauch/stand").then((r) => r.json()));
    } catch {}
  }
  laden();
  setInterval(laden, 60000);
})();
