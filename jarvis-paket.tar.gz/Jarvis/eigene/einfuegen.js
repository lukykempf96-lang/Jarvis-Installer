// Einfügen mit Command+V: Bilder (Screenshots, Grafiken) und Dateien aus der Zwischenablage landen wie beim
// Reinziehen im Eingang, und Jarvis schaut sie sich an. Text im Notizfeld wird weiter ganz normal eingefügt.
(() => {
  if (typeof uploadAndAnalyze !== "function" || window.__jarvisEinfuegen) return;
  window.__jarvisEinfuegen = true;

  const dropzone = document.getElementById("dropzone");
  if (dropzone) {
    dropzone.tabIndex = 0;  // anklickbar, damit Command+V "hier" ankommt
    dropzone.title = "Klicken und Command+V drücken, um ein kopiertes Bild oder eine Datei einzufügen";
    const tipp = document.createElement("small");
    tipp.className = "ef-tipp";
    tipp.textContent = "oder kopieren, hier klicken und ⌘V drücken";
    dropzone.querySelector("small")?.after(tipp);
  }

  const stempel = () => new Date().toLocaleString("sv-SE").replace(/[ :]/g, "-");
  const ENDUNG = { "image/png": "png", "image/jpeg": "jpg", "image/gif": "gif", "image/webp": "webp",
                   "image/heic": "heic", "image/tiff": "tiff", "application/pdf": "pdf" };

  function dateienAus(daten) {
    const gefunden = [];
    const gesehen = new Set();
    for (const item of daten.items || []) {
      if (item.kind !== "file") continue;
      const file = item.getAsFile();
      if (file && !gesehen.has(file.name + file.size)) {
        gesehen.add(file.name + file.size);
        gefunden.push(file);
      }
    }
    for (const file of daten.files || []) {
      if (!gesehen.has(file.name + file.size)) gefunden.push(file);
    }
    // Kopierte Bilder heißen in Chrome nur "image.png": verständlichen Namen mit Datum geben
    return gefunden.map((file, i) => {
      const generisch = !file.name || /^image\.(png|jpe?g|gif|webp|tiff?)$/i.test(file.name);
      if (!generisch) return { file, path: file.name };
      const endung = ENDUNG[file.type] || (file.name.split(".").pop() || "png");
      const name = `Eingefuegt-${stempel()}${gefunden.length > 1 ? "-" + (i + 1) : ""}.${endung}`;
      return { file: new File([file], name, { type: file.type }), path: name };
    });
  }

  function editierbar(el) {
    return el && (el.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(el.tagName));
  }

  function rueckmeldung(dateien) {
    if (dropzone) {
      dropzone.classList.add("over");
      setTimeout(() => dropzone.classList.remove("over"), 600);
    }
    const meta = document.getElementById("nf-meta");
    if (meta && document.activeElement?.id === "nf-text") {
      meta.textContent = dateien.length === 1 ? "Bild/Datei in den Eingang gelegt" : `${dateien.length} Dateien in den Eingang gelegt`;
    }
  }

  document.addEventListener("paste", (e) => {
    const daten = e.clipboardData;
    if (!daten) return;
    const dateien = dateienAus(daten);
    if (!dateien.length) return;  // nur Text: Browser macht es wie immer
    const ziel = e.target;
    const imNotizfeld = ziel?.id === "nf-text";
    if (editierbar(ziel) && !imNotizfeld) return;  // andere Eingabefelder (z. B. Haushaltsbuch) nicht stören
    if (imNotizfeld) {
      // Echter Text hat Vorrang (z. B. aus Excel kommt Text und ein Bild davon). Aus dem Finder kommt als
      // "Text" nur der Dateiname, dann die Datei nehmen.
      const text = (daten.getData("text/plain") || "").trim();
      const namen = new Set(dateien.map((d) => d.file.name));
      const nurNamen = text && text.split(/\r?\n/).every((zeile) => namen.has(zeile.trim().split("/").pop()));
      if (text && !nurNamen) return;
    }
    e.preventDefault();
    rueckmeldung(dateien);
    uploadAndAnalyze(dateien);
  });
})();
