"""Jarvis fuer Windows exportieren: legt auf dem Schreibtisch "Jarvis-Export-Windows" an.

Nimmt den aktuellen Jarvis (Kern und eigene Funktionen), ersetzt die Mac-Bausteine durch die Windows-Fassungen
aus eigene/windows/kern/ und passt einzelne Stellen im Kern an (Ton abspielen, Bildschirmfoto, Terminal usw.).
Passt eine Stelle nach einem Jarvis-Update nicht mehr, bricht der Export ab und sagt, wo.
Schluessel und persoenliche Daten kommen nicht mit.
"""

from __future__ import annotations

import os
import re
import shutil
import time
from pathlib import Path

BESCHREIBUNG = "Jarvis für Windows exportieren: Ordner Jarvis-Export-Windows mit Installationsskript und Anleitung"
PROMPT = (
    "Will Lukas Jarvis für Windows exportieren oder an jemanden mit Windows-PC weitergeben, nutze "
    "jarvis_exportieren_windows und sag kurz, wo der Ordner liegt und dass FUNKTIONEN.txt erklärt, was unter "
    "Windows geht."
)

JARVIS = Path(__file__).resolve().parent.parent
WIN = Path(__file__).resolve().parent / "windows"
ZIEL_NAME = "Jarvis-Export-Windows"
MARKE = ".jarvis-export"
NIE = {"__pycache__", ".DS_Store", "daten", "karten", ".env", ".env.tmp"}

TOOLS = [{
    "name": "jarvis_exportieren_windows",
    "description": "Legt auf dem Schreibtisch den Ordner Jarvis-Export-Windows an: Jarvis für einen Windows-PC "
                   "umgebaut, mit Installationsskript, Anleitung und einer Liste, was unter Windows geht. "
                   "Ohne Schlüssel und persönliche Daten.",
    "input_schema": {"type": "object", "properties": {}, "required": []},
}]

# ---------- Anpassungen am Kern: (Datei, alt, neu, Anzahl) ----------
# "Anzahl" = wie oft "alt" genau vorkommen muss. Bloecke: ("block", Anfang, Ende) ersetzt Anfang bis Ende (inklusive).

SCREENSHOT_ALT = '''    subprocess.run(["screencapture", "-x", str(tmp_path)], check=True)
    # Retina-Screenshots sind mehrere MB gross; verkleinert geht es schneller
    # und bleibt sicher unter dem Bild-Limit der API.
    subprocess.run(
        ["sips", "-Z", "1568", "-s", "format", "jpeg", str(tmp_path), "--out", str(small_path)],
        check=True, capture_output=True,
    )
'''

TERMINAL_NEU = '''    resume = ["--resume", session] if session else []
    # Kennt Claude Code Remote Control nicht oder ist es gesperrt, startet es normal
    line = (subprocess.list2cmdline([claude, "--remote-control", "--name", "Jarvis: " + key] + resume)
            + " || " + subprocess.list2cmdline([claude] + resume))
    try:
        plattform.open_terminal(path, line)
    except OSError as exc:
        return f"Konnte das Terminal nicht oeffnen: {exc}"
'''

PATCHES = [
    # main.py: Ton, Einstellungen, Programme starten
    ("backend/main.py", "from . import alltag, anzeige, claude_code,",
     "from . import plattform, planer\nfrom . import alltag, anzeige, claude_code,", 1),
    ("backend/main.py", 'subprocess.run(["open", f"x-apple.systempreferences:com.apple.preference.security?{pane}"], '
                        'capture_output=True)', "plattform.open_privacy(pane)", 1),
    ("backend/main.py", 'suffix = ".mp3" if media_type == "audio/mpeg" else ".m4a"',
     'suffix = {"audio/mpeg": ".mp3", "audio/wav": ".wav"}.get(media_type, ".m4a")', 1),
    ("backend/main.py", '_player = subprocess.Popen(["afplay", f.name])', "_player = plattform.play(f.name)", 1),
    ("backend/main.py", 'subprocess.run(["open", "-a", app_name], capture_output=True)', "planer.open_app(app_name)", 1),
    ("backend/main.py", 'subprocess.Popen(["afplay", "/System/Library/Sounds/Tink.aiff"], stdout=subprocess.DEVNULL, '
                        'stderr=subprocess.DEVNULL)', "plattform.beep()", 2),
    # tools.py: Bildschirmfoto, keine iMessage, Antworten an den Namen anpassen
    ("backend/tools.py", "from . import alltag, claude_code,", "from . import plattform\nfrom . import alltag, claude_code,", 1),
    ("backend/tools.py", SCREENSHOT_ALT, "    plattform.screenshot(small_path)  # alle Bildschirme, als JPEG verkleinert\n", 1),
    ("backend/tools.py", '        "Nachrichten": lambda: alltag.get_messages(18),\n', "", 1),
    ("backend/tools.py", "_DISPATCH = {", 'TOOLS = [t for t in TOOLS if t["name"] not in plattform.UNSUPPORTED]\n\n_DISPATCH = {', 1),
    ("backend/tools.py", "        return handler(tool_input)\n",
     "        result = handler(tool_input)\n        return plattform.personalize(result) if isinstance(result, str) else result\n", 1),
    # claude_agent.py: Prompts und Tool-Beschreibungen an Windows und den Namen anpassen
    ("backend/claude_agent.py", "from . import eigene\n", "from . import eigene, plattform\n", 1),
    ("backend/claude_agent.py", 'kwargs["tools"] = TOOLS + eigene.tools() + _web_tools(kwargs["model"])',
     'kwargs["tools"] = plattform.personalize(TOOLS + eigene.tools()) + _web_tools(kwargs["model"])', 1),
    ("backend/claude_agent.py", "    own = eigene.prompt()\n    return (", "    own = eigene.prompt()\n    return plattform.personalize(", 1),
    # claude_code.py: Claude Code finden und sichtbar im Konsolenfenster oeffnen
    ("backend/claude_code.py", "from . import eigene, files\n", "from . import eigene, files, plattform\n", 1),
    ("backend/claude_code.py", '    for candidate in ("~/.local/bin/claude", ',
     '    for candidate in ("~/.local/bin/claude.exe", "~/AppData/Roaming/npm/claude.cmd", "~/.local/bin/claude", ', 1),
    ("backend/claude_code.py", ("block", '    base = f"cd {shlex.quote(str(path))}',
                                '        return f"Konnte das Terminal nicht oeffnen: {exc}"\n'), TERMINAL_NEU, 1),
    ("backend/claude_code.py", 'SELF_CHECK = "venv/bin/python -m backend.eigene"',
     'SELF_CHECK = "venv/Scripts/python -m backend.eigene"', 1),
    ("backend/claude_code.py", '    cmd += ["--append-system-prompt", SPOKEN_HINT]',
     '    cmd += ["--append-system-prompt", plattform.personalize(SPOKEN_HINT)]', 1),
    # files.py: Windows-Pfade, OneDrive, Bilder mit Pillow
    ("backend/files.py", "from pathlib import Path\n\nJARVIS_DIR", "from pathlib import Path\n\nfrom . import plattform\n\nJARVIS_DIR", 1),
    ("backend/files.py", '    if text.startswith("/"):\n', '    if text.startswith("/") or os.path.isabs(text):\n', 1),
    ("backend/files.py", 'base = Path(alias) if alias.startswith("/") else HOME / alias',
     "base = Path(alias) if os.path.isabs(alias) else HOME / alias", 1),
    ("backend/files.py", '"schreibtisch": "Desktop", "desktop": "Desktop",',
     '"schreibtisch": plattform.known_folder("Desktop"), "desktop": plattform.known_folder("Desktop"),', 1),
    ("backend/files.py", '"dokumente": "Documents", "documents": "Documents",',
     '"dokumente": plattform.known_folder("Documents"), "documents": plattform.known_folder("Documents"),', 1),
    ("backend/files.py", '"bilder": "Pictures", "pictures": "Pictures",',
     '"bilder": plattform.known_folder("Pictures"), "pictures": plattform.known_folder("Pictures"),', 1),
    ("backend/files.py", '"Library/Mobile Documents/com~apple~CloudDocs"', '"iCloudDrive"', 2),
    ("backend/files.py", '    "jarvis": str(JARVIS_DIR),', '    "onedrive": "OneDrive", "jarvis": str(JARVIS_DIR),', 1),
    ("backend/files.py", ("block", '    if not shutil.which("sips"):', "    return data\n"),
     "    return plattform.shrink_image(path)\n", 1),
    # config.py: Windows-Stimme statt Mac-Stimme
    ("backend/config.py", 'mac_voice: str = os.getenv("JARVIS_MAC_VOICE", "Markus")',
     'mac_voice: str = os.getenv("JARVIS_WIN_VOICE", "")  # leer = erste deutsche Windows-Stimme', 1),
    # handy.py: Link geht jetzt zu Google Maps
    ("backend/handy.py", "Tippen startet Apple Karten.", "Tippen startet die Navigation.", 1),
    # Handy-Mikro: Zertifikat mit Python statt openssl
    ("eigene/handy_mikro.py", ("block", '    cfg = DATEN / "handy_mikro_openssl.cnf"\n',
                               "        check=True, capture_output=True, timeout=30,\n    )\n"),
     "    from backend import plattform\n    plattform.make_cert(ip, CERT, KEY)\n", 1),
]

REGEX_PATCHES = [
    ("backend/dashboard.py", r'"Erlaubnis fehlt \(Datenschutz & Sicherheit[^"]*\)\."',
     '"Nicht eingerichtet: klassisches Outlook einrichten oder IMAP bzw. Kalender-Link in .env eintragen."', 3),
]


def _ignorieren(ordner, namen):
    return [n for n in namen if n in NIE or n.endswith((".log", ".pyc", ".command"))]


def _block(text: str, start: str, end: str, new: str) -> tuple[str, int]:
    a = text.find(start)
    if a < 0 or text.find(start, a + 1) >= 0:
        return text, 0 if a < 0 else 2
    b = text.find(end, a)
    if b < 0:
        return text, 0
    return text[:a] + new + text[b + len(end):], 1


def _anpassen(programm: Path) -> list[str]:
    fehler = []
    for datei, alt, neu, anzahl in PATCHES:
        pfad = programm / datei
        text = pfad.read_text(encoding="utf-8")
        if isinstance(alt, tuple):
            text, gefunden = _block(text, alt[1], alt[2], neu)
        else:
            gefunden = text.count(alt)
            text = text.replace(alt, neu) if gefunden == anzahl else text
        if gefunden != anzahl:
            fehler.append(f"{datei}: {str(alt)[:60]!r} {gefunden}x statt {anzahl}x")
            continue
        pfad.write_text(text, encoding="utf-8")
    for datei, muster, neu, anzahl in REGEX_PATCHES:
        pfad = programm / datei
        text, gefunden = re.subn(muster, neu, pfad.read_text(encoding="utf-8"))
        if gefunden != anzahl:
            fehler.append(f"{datei}: Muster {gefunden}x statt {anzahl}x")
            continue
        pfad.write_text(text, encoding="utf-8")
    return fehler


def _mac_zu_pc(pfad: Path):
    text = pfad.read_text(encoding="utf-8")
    neu = re.sub(r"\bMacs\b", "PCs", re.sub(r"\bMac\b", "PC", text))
    if neu != text:
        pfad.write_text(neu, encoding="utf-8")


def _claude_md(text: str) -> str:
    text = text.replace("venv/bin/python", "venv/Scripts/python")
    text = text.replace("(macOS, Python 3.9, FastAPI-Backend, Chrome-Fenster)", "(Windows, Python 3.11, FastAPI-Backend, Chrome-Fenster)")
    text = text.replace("`anthropic`, `qrcode`.", "`anthropic`, `qrcode`, `pywin32`, `Pillow`.")
    text = text.replace("# Jarvis baut sich selbst aus\n", "# Jarvis baut sich selbst aus\n\n"
                        "Windows-Fassung. Mac-Bausteine sind durch Windows-Fassungen ersetzt (backend/plattform.py). "
                        "Jarvis-Updates fuer den Mac kommen hier nicht automatisch an.\n", 1)
    return re.sub(r"\bMac\b", "PC", text)


def _geheimnisse() -> list[bytes]:
    werte = [os.environ.get("ANTHROPIC_API_KEY", ""), os.environ.get("ELEVENLABS_API_KEY", "")]
    for datei in ("anzeige-schluessel.txt", "handy-thema.txt", "eigene/daten/handy_mikro_schluessel.txt"):
        try:
            werte.append((JARVIS / datei).read_text().strip())
        except OSError:
            pass
    return [w.encode() for w in werte if len(w) >= 8]


def _zielordner() -> Path:
    for basis in (Path.home() / "Desktop", JARVIS):
        ziel = basis / ZIEL_NAME
        try:
            if ziel.exists():
                if not (ziel / MARKE).exists():
                    ziel = basis / f"{ZIEL_NAME} {time.strftime('%Y-%m-%d %H-%M')}"
                else:
                    shutil.rmtree(ziel)
            ziel.mkdir(parents=True)
            return ziel
        except OSError:
            continue
    raise OSError("Weder auf dem Schreibtisch noch im Jarvis-Ordner darf ich schreiben.")


def jarvis_exportieren_windows() -> str:
    if not (WIN / "kern").is_dir():
        return "Die Windows-Bausteine fehlen (eigene/windows/kern). Sag Claude im Projekt Jarvis Bescheid."
    try:
        ziel = _zielordner()
    except OSError as exc:
        return str(exc)
    programm = ziel / "Jarvis"
    try:
        # 1. Kern und Fenster kopieren
        programm.mkdir()
        for name in ("backend", "frontend", ".claude"):
            shutil.copytree(JARVIS / name, programm / name, ignore=_ignorieren)
        shutil.copy2(JARVIS / "VERSION", programm / "VERSION")
        (programm / "CLAUDE.md").write_text(_claude_md((JARVIS / "CLAUDE.md").read_text(encoding="utf-8")),
                                            encoding="utf-8")
        # 2. Eigene Funktionen (ohne die Export-Funktionen, die gibt es nur am Mac)
        (programm / "eigene").mkdir()
        for pfad in sorted((JARVIS / "eigene").iterdir()):
            if pfad.is_file() and pfad.suffix in (".py", ".js", ".css") and not pfad.stem.startswith("jarvis_export"):
                shutil.copy2(pfad, programm / "eigene" / pfad.name)
        # 3. Windows-Bausteine einsetzen und Kern anpassen
        for pfad in sorted((WIN / "kern").glob("*.py")):
            shutil.copy2(pfad, programm / "backend" / pfad.name)
        fehler = _anpassen(programm)
        if fehler:
            raise RuntimeError("Diese Stellen im Kern passen nicht mehr: " + "; ".join(fehler))
        neu = {p.name for p in (WIN / "kern").glob("*.py")}
        for pfad in list((programm / "backend").glob("*.py")) + list((programm / "frontend").glob("*.*")) \
                + list((programm / "eigene").glob("*.*")):
            if pfad.suffix in (".py", ".js", ".html", ".css") and not (pfad.parent.name == "backend" and pfad.name in neu):
                _mac_zu_pc(pfad)
        # 4. Installation und Anleitung
        shutil.copy2(WIN / "requirements-windows.txt", programm / "requirements-windows.txt")
        shutil.copy2(WIN / "env-vorlage.txt", programm / ".env.example")
        (ziel / "install.ps1").write_text((WIN / "install.ps1").read_text(encoding="utf-8"), encoding="utf-8-sig")
        cmd = (WIN / "Jarvis installieren.cmd").read_text(encoding="utf-8")
        (ziel / "Jarvis installieren.cmd").write_bytes(cmd.replace("\r\n", "\n").replace("\n", "\r\n").encode("ascii"))
        version = (JARVIS / "VERSION").read_text().strip()
        anleitung = (WIN / "ANLEITUNG.txt").read_text(encoding="utf-8")
        anleitung = anleitung.replace("@DATUM@", time.strftime("%d.%m.%Y")).replace("@VERSION@", version)
        (ziel / "ANLEITUNG.txt").write_text(anleitung, encoding="utf-8-sig")
        (ziel / "FUNKTIONEN.txt").write_text((WIN / "FUNKTIONEN.txt").read_text(encoding="utf-8"), encoding="utf-8-sig")
        (ziel / MARKE).write_text("Von Jarvis angelegt.\n")
        # 5. Kein Schluessel darf drinstehen
        geheim = _geheimnisse()
        for pfad in ziel.rglob("*"):
            if pfad.is_file() and any(g in pfad.read_bytes() for g in geheim):
                raise RuntimeError(f"In {pfad.relative_to(ziel)} stand ein Schlüssel")
    except Exception as exc:
        shutil.rmtree(ziel, ignore_errors=True)
        return f"Windows-Export abgebrochen und wieder gelöscht: {exc}. Sag Claude im Projekt Jarvis Bescheid."

    wo = "auf dem Schreibtisch" if ziel.parent == Path.home() / "Desktop" else "im Jarvis-Ordner"
    return (f"Der Ordner {ziel.name} liegt {wo}, ohne Schlüssel und persönliche Daten. Auf dem Windows-PC "
            "Jarvis installieren doppelklicken; was unter Windows geht, steht in FUNKTIONEN.")
