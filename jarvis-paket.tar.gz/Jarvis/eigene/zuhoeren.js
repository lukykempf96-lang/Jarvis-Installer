// Längeres Zuhören: Jarvis wartet eine längere Pause ab, bevor er die Frage abschickt.
// Chrome beendet die Spracheingabe sonst schon nach knapp einer Sekunde Stille.
(() => {
  const PAUSE_MS = 2500;   // so lange Stille, bis die Eingabe als fertig gilt
  const MAX_MS = 45000;    // spätestens dann abschicken (z. B. bei laufendem Fernseher)

  if (typeof recognition === "undefined" || !recognition || recognition.__langePause) return;
  const rec = recognition;
  rec.__langePause = true;

  const sendOriginal = rec.onresult;  // Jarvis' eigene Verarbeitung (Stoppwörter, "danke", abschicken)
  const nativeStart = rec.start.bind(rec);
  const nativeStop = rec.stop.bind(rec);
  const nativeAbort = rec.abort.bind(rec);
  const onEndOriginal = rec.onend;

  rec.continuous = true;      // nicht bei der ersten Pause aufhören
  rec.interimResults = true;  // auch halbe Sätze zählen als "spricht noch"

  let text = "", done = true, pauseTimer = null, maxTimer = null;

  function clearTimers() {
    clearTimeout(pauseTimer);
    clearTimeout(maxTimer);
    pauseTimer = maxTimer = null;
  }

  function finish() {
    if (done) return;
    done = true;
    clearTimers();
    const said = text.trim();
    if (said) sendOriginal.call(rec, { results: [[{ transcript: said }]] });
    nativeStop();
  }

  rec.start = () => {
    text = "";
    done = false;
    clearTimers();
    maxTimer = setTimeout(finish, MAX_MS);
    return nativeStart();
  };

  // Knopf gedrückt, während er zuhört: das bisher Gesagte gleich abschicken
  rec.stop = () => (done ? nativeStop() : finish());

  rec.abort = () => {
    done = true;
    clearTimers();
    return nativeAbort();
  };

  rec.onresult = (event) => {
    if (done) return;
    text = Array.from(event.results, (r) => r[0].transcript).join(" ").replace(/\s+/g, " ");
    clearTimeout(pauseTimer);
    pauseTimer = setTimeout(finish, PAUSE_MS);
  };

  rec.onend = (event) => {
    // Beendet Chrome selbst (z. B. Netz weg), das bisher Gesagte trotzdem nicht verlieren
    if (!done) {
      done = true;
      clearTimers();
      const said = text.trim();
      if (said) sendOriginal.call(rec, { results: [[{ transcript: said }]] });
    }
    return onEndOriginal && onEndOriginal.call(rec, event);
  };
})();
