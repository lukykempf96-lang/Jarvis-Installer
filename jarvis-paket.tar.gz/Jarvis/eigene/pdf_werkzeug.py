"""PDFs richtig lesen: Text pro Seite (mit Texterkennung bei gescannten Seiten), Begriffe suchen, Seiten ansehen
und rot oder gelb markierte Stellen finden (z. B. Retrofit-Änderungen in Stromlaufplänen).

Ohne Zusatzpakete: Ein kleines Swift-Programm nutzt die macOS-Bordmittel PDFKit (Text, Seitenbilder) und Vision
(Texterkennung). Es wird beim ersten Gebrauch einmal übersetzt (swiftc, Xcode-Befehlszeilentools) und liegt dann in
eigene/daten/werkzeuge/. Gelesener Text bleibt im Gespräch erhalten (read_file schickt PDFs als Ganzes, die fallen
danach aus dem Verlauf heraus).
"""

from __future__ import annotations

import hashlib
import json
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import base64
from pathlib import Path

BESCHREIBUNG = "PDFs lesen (Text pro Seite, auch gescannt), Begriffe darin suchen, Seiten ansehen, rote/gelbe Markierungen finden"
PROMPT = (
    "PDFs liest du mit pdf_lesen statt read_file (Text mit Seitenzahlen, bei langen PDFs seitenweise weiter). "
    "Fragt Lukas, wo etwas in einem PDF oder einem Ordner voller PDFs steht (z. B. eine Kabelbezeichnung wie W51152a), "
    "nutze pdf_suchen. Für Zeichnungen und Stromlaufpläne kannst du mit pdf_seite_ansehen eine Seite oder einen "
    "Ausschnitt als Bild ansehen. Nach markierten Änderungen (rot oder gelb, z. B. Retrofit) suchst du mit "
    "pdf_markierungen und nennst Seiten und Beschriftungen."
)

HIER = Path(__file__).resolve().parent
JARVIS = HIER.parent
WERKZEUG_DIR = HIER / "daten" / "werkzeuge"
WERKZEUG = WERKZEUG_DIR / "JarvisPDF"
STEMPEL = WERKZEUG_DIR / "JarvisPDF.sha1"
MAX_ZEICHEN = 40000
_bau_lock = threading.Lock()
_cache: dict = {}  # (pfad, mtime, groesse) -> {seite: (text, ocr)}
_cache_lock = threading.Lock()

SWIFT = r'''
import Foundation
import PDFKit
import Vision
import AppKit
import ImageIO

func out(_ obj: Any) {
    let d = try! JSONSerialization.data(withJSONObject: obj, options: [])
    FileHandle.standardOutput.write(d)
    FileHandle.standardOutput.write("\n".data(using: .utf8)!)
}
func fail(_ msg: String) -> Never { out(["ok": false, "error": msg]); exit(1) }

let args = CommandLine.arguments
if args.count < 3 { fail("Aufruf: JarvisPDF befehl datei ...") }
let cmd = args[1]
guard let doc = PDFDocument(url: URL(fileURLWithPath: args[2])) else { fail("PDF laesst sich nicht oeffnen") }
if doc.isLocked { fail("PDF ist mit einem Passwort geschuetzt") }
let count = doc.pageCount

func intArg(_ i: Int, _ dflt: Int) -> Int { return args.count > i ? (Int(args[i]) ?? dflt) : dflt }
func pages(_ a: Int, _ b: Int) -> [Int] {
    let lo = max(1, a), hi = min(count, b)
    return lo <= hi ? Array(lo...hi) : []
}

// Seite als Bild (beruecksichtigt die Drehung der Seite)
func render(_ page: PDFPage, maxSide: CGFloat) -> CGImage? {
    let box = page.bounds(for: .mediaBox)
    let rot = ((page.rotation % 360) + 360) % 360
    let w = rot == 90 || rot == 270 ? box.height : box.width
    let h = rot == 90 || rot == 270 ? box.width : box.height
    let scale = maxSide / max(w, h)
    let size = NSSize(width: max(1, w * scale), height: max(1, h * scale))
    let img = page.thumbnail(of: size, for: .mediaBox)
    var rect = NSRect(origin: .zero, size: img.size)
    return img.cgImage(forProposedRect: &rect, context: nil, hints: nil)
}

func rgba(_ img: CGImage) -> (UnsafeMutablePointer<UInt8>, Int, Int) {
    let w = img.width, h = img.height
    let buf = UnsafeMutablePointer<UInt8>.allocate(capacity: w * h * 4)
    buf.initialize(repeating: 255, count: w * h * 4)
    let ctx = CGContext(data: buf, width: w, height: h, bitsPerComponent: 8, bytesPerRow: w * 4,
                        space: CGColorSpace(name: CGColorSpace.sRGB)!,
                        bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)!
    ctx.setFillColor(CGColor(red: 1, green: 1, blue: 1, alpha: 1))
    ctx.fill(CGRect(x: 0, y: 0, width: w, height: h))
    ctx.draw(img, in: CGRect(x: 0, y: 0, width: w, height: h))
    return (buf, w, h)
}

// Bildpunkt (u, v von oben links, 0..1) -> Seitenkoordinaten
func toPage(_ page: PDFPage, _ u: CGFloat, _ v: CGFloat) -> CGPoint {
    let box = page.bounds(for: .mediaBox)
    let rot = ((page.rotation % 360) + 360) % 360
    var x = u, y = 1 - v
    if rot == 90 { x = v; y = u }
    if rot == 180 { x = 1 - u; y = v }
    if rot == 270 { x = 1 - v; y = 1 - u }
    return CGPoint(x: box.minX + x * box.width, y: box.minY + y * box.height)
}
func pageRect(_ page: PDFPage, _ r: CGRect) -> CGRect {
    let a = toPage(page, r.minX, r.minY), b = toPage(page, r.maxX, r.maxY)
    return CGRect(x: min(a.x, b.x), y: min(a.y, b.y), width: abs(a.x - b.x), height: abs(a.y - b.y))
}

func ocrLines(_ img: CGImage) -> [(String, CGRect)] {
    let req = VNRecognizeTextRequest()
    req.recognitionLevel = .accurate
    req.usesLanguageCorrection = false
    if let langs = try? req.supportedRecognitionLanguages() {
        req.recognitionLanguages = ["de-DE", "en-US"].filter { langs.contains($0) }
    }
    let handler = VNImageRequestHandler(cgImage: img, options: [:])
    try? handler.perform([req])
    var lines: [(String, CGRect)] = []
    for obs in req.results ?? [] {
        if let top = obs.topCandidates(1).first { lines.append((top.string, obs.boundingBox)) }
    }
    lines.sort { abs($0.1.midY - $1.1.midY) > 0.008 ? $0.1.midY > $1.1.midY : $0.1.minX < $1.1.minX }
    return lines
}
func ocrText(_ img: CGImage) -> String { return ocrLines(img).map { $0.0 }.joined(separator: "\n") }

func clean(_ s: String?) -> String {
    return (s ?? "").components(separatedBy: .whitespacesAndNewlines).filter { !$0.isEmpty }.joined(separator: " ")
}

func writeJPEG(_ img: CGImage, _ path: String) -> Bool {
    guard let dest = CGImageDestinationCreateWithURL(URL(fileURLWithPath: path) as CFURL, "public.jpeg" as CFString, 1, nil)
    else { return false }
    CGImageDestinationAddImage(dest, img, [kCGImageDestinationLossyCompressionQuality: 0.85] as CFDictionary)
    return CGImageDestinationFinalize(dest)
}

if cmd == "info" {
    out(["ok": true, "seiten": count, "titel": (doc.documentAttributes?[PDFDocumentAttribute.titleAttribute] as? String) ?? ""])
} else if cmd == "text" {
    let mode = args.count > 5 ? args[5] : "auto"
    var result: [[String: Any]] = []
    for n in pages(intArg(3, 1), intArg(4, count)) {
        guard let page = doc.page(at: n - 1) else { continue }
        var text = page.string ?? ""
        var ocr = false
        let wenig = text.trimmingCharacters(in: .whitespacesAndNewlines).count < 25
        if mode == "force" || (mode == "auto" && wenig) {
            if let img = render(page, maxSide: 2600) {
                let erkannt = ocrText(img)
                if erkannt.count > text.count { text = erkannt; ocr = true }
            }
        }
        result.append(["seite": n, "text": text, "ocr": ocr])
    }
    out(["ok": true, "seiten": count, "text": result])
} else if cmd == "render" {
    let n = intArg(3, 1)
    guard args.count > 4, let page = doc.page(at: n - 1) else { fail("Seite \(n) gibt es nicht (das PDF hat \(count) Seiten)") }
    let outPath = args[4]
    let maxSide = CGFloat(intArg(5, 1568))
    var crop: CGRect? = nil
    if args.count > 9, let x = Double(args[6]), let y = Double(args[7]), let w = Double(args[8]), let h = Double(args[9]) {
        crop = CGRect(x: x, y: y, width: w, height: h)
    }
    var side = maxSide
    if let c = crop { side = min(9000, maxSide / CGFloat(max(c.width, c.height, 0.05))) }
    guard var img = render(page, maxSide: side) else { fail("Seite liess sich nicht zeichnen") }
    if let c = crop {
        let r = CGRect(x: c.minX * CGFloat(img.width), y: c.minY * CGFloat(img.height),
                       width: c.width * CGFloat(img.width), height: c.height * CGFloat(img.height)).integral
        if let cut = img.cropping(to: r) { img = cut }
    }
    if !writeJPEG(img, outPath) { fail("Bild liess sich nicht speichern") }
    out(["ok": true, "breite": img.width, "hoehe": img.height])
} else if cmd == "marks" {
    var result: [[String: Any]] = []
    for n in pages(intArg(3, 1), intArg(4, count)) {
        guard let page = doc.page(at: n - 1), let img = render(page, maxSide: 2000) else { continue }
        let (buf, w, h) = rgba(img)
        let cell = 6
        let cw = (w + cell - 1) / cell, ch = (h + cell - 1) / cell
        var red = [Int](repeating: 0, count: cw * ch), yellow = [Int](repeating: 0, count: cw * ch)
        for y in 0..<h {
            for x in 0..<w {
                let i = (y * w + x) * 4
                let r = Int(buf[i]), g = Int(buf[i + 1]), b = Int(buf[i + 2])
                let c = (y / cell) * cw + (x / cell)
                if r >= 170 && r - max(g, b) >= 70 && g <= 170 && b <= 170 { red[c] += 1 }
                else if r >= 190 && g >= 170 && (r + g) / 2 - b >= 70 && abs(r - g) <= 80 { yellow[c] += 1 }
            }
        }
        buf.deallocate()
        var marks: [[String: Any]] = []
        var lowText = clean(page.string).count < 25
        var pageOCR: [(String, CGRect)]? = nil
        for (farbe, grid) in [("rot", red), ("gelb", yellow)] {
            var seen = [Bool](repeating: false, count: cw * ch)
            var regions: [(Int, Int, Int, Int, Int)] = []  // minX, minY, maxX, maxY (Zellen), Punkte
            for start in 0..<(cw * ch) where grid[start] >= 4 && !seen[start] {
                var stack = [start]; seen[start] = true
                var x0 = cw, y0 = ch, x1 = 0, y1 = 0, total = 0
                while let c = stack.popLast() {
                    let cx = c % cw, cy = c / cw
                    x0 = min(x0, cx); y0 = min(y0, cy); x1 = max(x1, cx); y1 = max(y1, cy); total += grid[c]
                    for dy in -3...3 { for dx in -3...3 {
                        let nx = cx + dx, ny = cy + dy
                        if nx < 0 || ny < 0 || nx >= cw || ny >= ch { continue }
                        let nc = ny * cw + nx
                        if !seen[nc] && grid[nc] >= 4 { seen[nc] = true; stack.append(nc) }
                    } }
                }
                if total >= 40 { regions.append((x0, y0, x1, y1, total)) }
            }
            regions.sort { $0.4 > $1.4 }
            for (x0, y0, x1, y1, total) in regions.prefix(40) {
                let pad = 0.012
                let u0 = max(0, Double(x0 * cell) / Double(w) - pad), v0 = max(0, Double(y0 * cell) / Double(h) - pad)
                let u1 = min(1, Double((x1 + 1) * cell) / Double(w) + pad), v1 = min(1, Double((y1 + 1) * cell) / Double(h) + pad)
                let norm = CGRect(x: u0, y: v0, width: u1 - u0, height: v1 - v0)
                var text = clean(page.selection(for: pageRect(page, norm))?.string)
                if text.isEmpty || lowText {
                    if pageOCR == nil, let big = render(page, maxSide: 3000) { pageOCR = ocrLines(big) }
                    // Vision: Ursprung unten links, 0..1
                    text = (pageOCR ?? []).filter { line in
                        let mid = CGPoint(x: line.1.midX, y: 1 - line.1.midY)
                        return norm.contains(mid)
                    }.map { $0.0 }.joined(separator: " ")
                    lowText = lowText || text.isEmpty
                }
                marks.append(["farbe": farbe, "quelle": "Zeichnung", "punkte": total,
                              "box": [u0, v0, u1 - u0, v1 - v0].map { (($0 * 1000).rounded()) / 1000 },
                              "text": String(text.prefix(300))])
            }
        }
        for a in page.annotations {
            guard let col = a.color.usingColorSpace(.sRGB) else { continue }
            let r = col.redComponent, g = col.greenComponent, b = col.blueComponent
            var farbe = ""
            if r > 0.65 && r - max(g, b) > 0.3 { farbe = "rot" }
            else if r > 0.7 && g > 0.6 && (r + g) / 2 - b > 0.3 { farbe = "gelb" }
            if farbe.isEmpty { continue }
            let text = clean(page.selection(for: a.bounds.insetBy(dx: -4, dy: -4))?.string)
            marks.append(["farbe": farbe, "quelle": "Anmerkung " + (a.type ?? ""), "punkte": 0, "box": [],
                          "text": String((text + (a.contents.map { " " + $0 } ?? "")).prefix(300))])
        }
        if !marks.isEmpty { result.append(["seite": n, "markierungen": marks]) }
    }
    out(["ok": true, "seiten": count, "ergebnis": result])
} else {
    fail("Unbekannter Befehl \(cmd)")
}
'''


# ---------- Hilfsprogramm bauen und aufrufen ----------

def _quelle_hash() -> str:
    return hashlib.sha1(SWIFT.encode()).hexdigest()


def _werkzeug() -> str | None:
    """None, wenn das Hilfsprogramm bereit ist, sonst der Grund."""
    with _bau_lock:
        try:
            if WERKZEUG.exists() and STEMPEL.read_text().strip() == _quelle_hash():
                return None
        except OSError:
            pass
        if not shutil.which("swiftc"):
            return "swiftc fehlt (Xcode-Befehlszeilentools: im Terminal xcode-select --install)"
        WERKZEUG_DIR.mkdir(parents=True, exist_ok=True)
        quelle = WERKZEUG_DIR / "JarvisPDF.swift"
        quelle.write_text(SWIFT, encoding="utf-8")
        ergebnis = subprocess.run(["swiftc", "-O", "-o", str(WERKZEUG), str(quelle)],
                                  capture_output=True, text=True, timeout=600)
        if ergebnis.returncode != 0 or not WERKZEUG.exists():
            print(f"PDF-Werkzeug liess sich nicht bauen: {ergebnis.stderr[-1500:]}", flush=True)
            return "Übersetzen fehlgeschlagen: " + ergebnis.stderr.strip().splitlines()[-1][:200] if ergebnis.stderr else "Übersetzen fehlgeschlagen"
        STEMPEL.write_text(_quelle_hash() + "\n")
        return None


def _aufruf(*argumente: str, timeout: int = 600) -> dict:
    problem = _werkzeug()
    if problem:
        raise RuntimeError(problem)
    ergebnis = subprocess.run([str(WERKZEUG), *argumente], capture_output=True, text=True, timeout=timeout)
    zeilen = [z for z in ergebnis.stdout.splitlines() if z.startswith("{")]
    if not zeilen:
        raise RuntimeError(ergebnis.stderr.strip()[-300:] or "keine Antwort vom PDF-Werkzeug")
    daten = json.loads(zeilen[-1])
    if not daten.get("ok"):
        raise RuntimeError(daten.get("error", "unbekannter Fehler"))
    return daten


def _pfad(pfad: str) -> Path:
    from backend import files
    datei = files.resolve(pfad)
    if not datei.exists():
        # nur ein Dateiname? Dann im Eingang suchen (neueste zuerst)
        treffer = sorted((JARVIS / "eingang").rglob(Path(pfad).name), key=lambda p: p.stat().st_mtime, reverse=True)
        if treffer:
            return treffer[0]
        raise FileNotFoundError(f"{pfad} gibt es nicht.")
    return datei


def _kurz(datei: Path) -> str:
    try:
        return "~/" + str(datei.resolve().relative_to(Path.home()))
    except ValueError:
        return str(datei)


def _seiten_text(datei: Path, ab: int, bis: int, ocr: str = "auto") -> tuple[int, dict]:
    """Text der Seiten ab..bis, gemerkt, damit Suchen und Weiterlesen nicht neu erkennen müssen."""
    st = datei.stat()
    schluessel = (str(datei), st.st_mtime, st.st_size, ocr)
    with _cache_lock:
        eintrag = _cache.setdefault(schluessel, {"seiten": None, "text": {}})
        if eintrag["seiten"]:
            bis = min(bis, eintrag["seiten"])
        fehlen = [n for n in range(ab, bis + 1) if n not in eintrag["text"]] if eintrag["seiten"] else None
    if fehlen is None or fehlen:
        von, nach = (min(fehlen), max(fehlen)) if fehlen else (ab, bis)
        daten = _aufruf("text", str(datei), str(von), str(nach), ocr)
        with _cache_lock:
            eintrag["seiten"] = daten["seiten"]
            for s in daten["text"]:
                eintrag["text"][s["seite"]] = (s["text"], s["ocr"])
            while len(_cache) > 8:
                _cache.pop(next(iter(_cache)))
    return eintrag["seiten"], {n: eintrag["text"][n] for n in range(ab, min(bis, eintrag["seiten"]) + 1)
                               if n in eintrag["text"]}


# ---------- Tools ----------

TOOLS = [
    {
        "name": "pdf_lesen",
        "description": "Liest ein PDF als Text, Seite für Seite mit Seitenzahl. Gescannte Seiten werden per Texterkennung "
                       "gelesen. Lange PDFs in Abschnitten: mit ab_seite weiterlesen.",
        "input_schema": {"type": "object", "properties": {
            "pfad": {"type": "string", "description": "Pfad zum PDF, z. B. ~/Downloads/Jarvis/eingang/.../plan.pdf"},
            "ab_seite": {"type": "integer", "description": "Erste Seite, Standard 1"},
            "bis_seite": {"type": "integer", "description": "Letzte Seite, leer = so viele, wie in einen Abschnitt passen"},
            "texterkennung": {"type": "string", "enum": ["auto", "immer", "nie"],
                              "description": "auto = nur Seiten ohne Text erkennen (Standard), immer = auch bei Text"},
        }, "required": ["pfad"]},
    },
    {
        "name": "pdf_suchen",
        "description": "Sucht einen Begriff (z. B. Kabelbezeichnung W51152a, Betriebsmittel, Wort) in einem PDF oder in allen "
                       "PDFs eines Ordners. Liefert Seitenzahlen und den Text drumherum. Gross/klein und Leerzeichen "
                       "innerhalb des Begriffs sind egal.",
        "input_schema": {"type": "object", "properties": {
            "pfad": {"type": "string", "description": "PDF oder Ordner mit PDFs"},
            "begriff": {"type": "string"},
        }, "required": ["pfad", "begriff"]},
    },
    {
        "name": "pdf_seite_ansehen",
        "description": "Zeigt dir eine PDF-Seite als Bild (für Zeichnungen, Stromlaufpläne, Tabellen). Mit ausschnitt nur "
                       "einen Teil vergrössert, z. B. eine markierte Stelle.",
        "input_schema": {"type": "object", "properties": {
            "pfad": {"type": "string"},
            "seite": {"type": "integer"},
            "ausschnitt": {"type": "array", "items": {"type": "number"},
                           "description": "Optional [x, y, breite, hoehe] als Anteil der Seite 0..1, von oben links"},
        }, "required": ["pfad", "seite"]},
    },
    {
        "name": "pdf_markierungen",
        "description": "Findet rot oder gelb markierte Stellen in einem PDF (z. B. Retrofit-Änderungen in Stromlaufplänen, "
                       "Textmarker, farbige Anmerkungen). Liefert je Seite die Stellen mit Farbe, Lage und der "
                       "Beschriftung dort.",
        "input_schema": {"type": "object", "properties": {
            "pfad": {"type": "string"},
            "ab_seite": {"type": "integer"},
            "bis_seite": {"type": "integer"},
            "farbe": {"type": "string", "enum": ["rot", "gelb", "beide"], "description": "Standard beide"},
        }, "required": ["pfad"]},
    },
]


def pdf_lesen(pfad: str, ab_seite: int = 1, bis_seite: int | None = None, texterkennung: str = "auto"):
    datei = _pfad(pfad)
    ocr = {"immer": "force", "nie": "off"}.get(texterkennung, "auto")
    ab = max(1, int(ab_seite or 1))
    seiten = _aufruf("info", str(datei))["seiten"]
    if ab > seiten:
        return f"{_kurz(datei)} hat nur {seiten} Seiten."
    ende = min(seiten, int(bis_seite) if bis_seite else seiten)
    teile, laenge, letzte = [], 0, ab - 1
    n = ab
    while n <= ende:
        block_ende = min(ende, n + 9)  # in Zehnerschritten lesen, bis der Abschnitt voll ist
        _, texte = _seiten_text(datei, n, block_ende, ocr)
        for s in range(n, block_ende + 1):
            text, erkannt = texte.get(s, ("", False))
            stueck = f"--- Seite {s}{' (Texterkennung)' if erkannt else ''} ---\n{text.strip() or '(kein Text auf dieser Seite)'}\n"
            if teile and laenge + len(stueck) > MAX_ZEICHEN:
                break
            teile.append(stueck[:MAX_ZEICHEN])
            laenge += len(stueck)
            letzte = s
        else:
            n = block_ende + 1
            continue
        break
    kopf = f"PDF {_kurz(datei)}, {seiten} Seiten. Hier Seite {ab} bis {letzte}.\n"
    rest = f"\n[Weiterlesen mit pdf_lesen ab_seite={letzte + 1}]" if letzte < ende else ""
    return kopf + "\n".join(teile) + rest


def _muster(begriff: str) -> re.Pattern:
    zeichen = [re.escape(c) for c in begriff.strip() if not c.isspace()]
    return re.compile(r"[\s\-_]{0,2}".join(zeichen), re.I)


def _suche_in(datei: Path, muster: re.Pattern) -> list[dict]:
    seiten, texte = _seiten_text(datei, 1, 100000)
    treffer = []
    for s, (text, erkannt) in sorted(texte.items()):
        flach = " ".join(text.split())
        stellen = [m for m in muster.finditer(flach)]
        if stellen:
            umfeld = []
            for m in stellen[:3]:
                a, b = max(0, m.start() - 110), min(len(flach), m.end() + 110)
                umfeld.append(("…" if a else "") + flach[a:b] + ("…" if b < len(flach) else ""))
            treffer.append({"seite": s, "anzahl": len(stellen), "umfeld": umfeld, "ocr": erkannt})
    return treffer


def pdf_suchen(pfad: str, begriff: str) -> str:
    if not (begriff or "").strip():
        return "Welcher Begriff soll gesucht werden?"
    ziel = _pfad(pfad)
    dateien = sorted(ziel.rglob("*.pdf")) if ziel.is_dir() else [ziel]
    if not dateien:
        return f"In {_kurz(ziel)} liegen keine PDFs."
    muster = _muster(begriff)
    zeilen, gesamt, fehler = [], 0, []
    for datei in dateien[:60]:
        try:
            treffer = _suche_in(datei, muster)
        except Exception as exc:
            fehler.append(f"{datei.name}: {exc}")
            continue
        for t in treffer:
            gesamt += t["anzahl"]
            ort = f"{datei.name}, Seite {t['seite']}" if len(dateien) > 1 else f"Seite {t['seite']}"
            zeilen.append(f"- {ort} ({t['anzahl']}x{', Texterkennung' if t['ocr'] else ''}): " + " | ".join(t["umfeld"]))
    wo = _kurz(ziel) if len(dateien) == 1 else f"{len(dateien)} PDFs in {_kurz(ziel)}"
    if not zeilen:
        antwort = f"'{begriff}' kommt in {wo} nicht vor."
    else:
        antwort = f"'{begriff}' in {wo}: {gesamt} Treffer auf {len(zeilen)} Seiten.\n" + "\n".join(zeilen[:80])
    if fehler:
        antwort += "\nNicht lesbar: " + "; ".join(fehler[:5])
    return antwort


def pdf_seite_ansehen(pfad: str, seite: int, ausschnitt: list | None = None):
    datei = _pfad(pfad)
    ziel = Path(tempfile.gettempdir()) / f"jarvis_pdf_{hashlib.sha1(str(datei).encode()).hexdigest()[:8]}.jpg"
    argumente = ["render", str(datei), str(int(seite)), str(ziel), "1568"]
    if ausschnitt and len(ausschnitt) == 4:
        x, y, b, h = (min(1.0, max(0.0, float(v))) for v in ausschnitt)
        argumente += [str(x), str(y), str(max(0.02, min(b, 1 - x))), str(max(0.02, min(h, 1 - y)))]
    daten = _aufruf(*argumente)
    bild = ziel.read_bytes()
    ziel.unlink(missing_ok=True)
    teil = f", Ausschnitt {ausschnitt}" if ausschnitt else ""
    return [{"type": "text", "text": f"{_kurz(datei)}, Seite {seite}{teil} ({daten['breite']}x{daten['hoehe']} Pixel)."},
            {"type": "image", "source": {"type": "base64", "media_type": "image/jpeg",
                                         "data": base64.standard_b64encode(bild).decode()}}]


def _lage(box: list) -> str:
    if len(box) != 4:
        return ""
    mx, my = box[0] + box[2] / 2, box[1] + box[3] / 2
    senkrecht = "oben" if my < 0.34 else "unten" if my > 0.66 else "Mitte"
    waagrecht = "links" if mx < 0.34 else "rechts" if mx > 0.66 else "mittig"
    return f"{senkrecht} {waagrecht}" if not (senkrecht == "Mitte" and waagrecht == "mittig") else "Mitte"


_marks_cache: dict = {}


def _vorlagen_schluessel(m: dict) -> tuple:
    if m["box"]:
        # Ecke oben links im Raster von 2 % der Seite: Schriftfeld-Texte sind je nach Blatt verschieden lang
        return (m["farbe"], round(m["box"][0] * 50), round(m["box"][1] * 50))
    return (m["farbe"], m["quelle"], m["text"][:40])


def _markierungen_ohne_vorlage(datei: Path) -> tuple[int, list[dict], int]:
    """Alle Seiten auswerten und Stellen weglassen, die an derselben Stelle auf vielen Seiten wiederkehren
    (Schriftfeld, Logos, Vorlage). Gemerkt pro Datei."""
    st = datei.stat()
    schluessel = (str(datei), st.st_mtime, st.st_size)
    if schluessel not in _marks_cache:
        seiten = _aufruf("info", str(datei))["seiten"]
        daten = _aufruf("marks", str(datei), "1", str(seiten), timeout=1800)
        zaehler: dict = {}
        for eintrag in daten["ergebnis"]:
            for k in {_vorlagen_schluessel(m) for m in eintrag["markierungen"]}:
                zaehler[k] = zaehler.get(k, 0) + 1
        grenze = max(3, 0.3 * seiten)
        vorlage = {k for k, n in zaehler.items() if n >= grenze} if seiten >= 4 else set()
        ergebnis, weg = [], 0
        for eintrag in daten["ergebnis"]:
            bleiben = [m for m in eintrag["markierungen"] if _vorlagen_schluessel(m) not in vorlage]
            weg += len(eintrag["markierungen"]) - len(bleiben)
            if bleiben:
                ergebnis.append({"seite": eintrag["seite"], "markierungen": bleiben})
        _marks_cache[schluessel] = (seiten, ergebnis, weg)
        while len(_marks_cache) > 8:
            _marks_cache.pop(next(iter(_marks_cache)))
    return _marks_cache[schluessel]


def pdf_markierungen(pfad: str, ab_seite: int = 1, bis_seite: int | None = None, farbe: str = "beide") -> str:
    datei = _pfad(pfad)
    seiten, alle, vorlage = _markierungen_ohne_vorlage(datei)
    ab = max(1, int(ab_seite or 1))
    bis = min(seiten, int(bis_seite) if bis_seite else seiten)
    zeilen, anzahl = [], 0
    for eintrag in alle:
        if not ab <= eintrag["seite"] <= bis:
            continue
        stellen = [m for m in eintrag["markierungen"] if farbe in ("beide", "", None) or m["farbe"] == farbe]
        if not stellen:
            continue
        anzahl += len(stellen)
        teile = []
        for m in stellen[:15]:
            lage = _lage(m["box"])
            box = f" [Ausschnitt {[round(v, 2) for v in m['box']]}]" if m["box"] else ""
            text = m["text"] or "(keine Beschriftung erkannt)"
            teile.append(f"{m['farbe']}{' ' + lage if lage else ''}{' (' + m['quelle'] + ')' if m['quelle'] != 'Zeichnung' else ''}: "
                         f"{text}{box}")
        mehr = f" … und {len(stellen) - 15} weitere" if len(stellen) > 15 else ""
        menge = "1 Stelle" if len(stellen) == 1 else f"{len(stellen)} Stellen"
        zeilen.append(f"- Seite {eintrag['seite']} ({menge}): " + " | ".join(teile) + mehr)
    bereich = f"Seite {ab} bis {bis}" if (ab, bis) != (1, seiten) else f"allen {seiten} Seiten"
    hinweis = (f" {vorlage} farbige Stellen, die auf vielen Seiten gleich sind (Schriftfeld, Vorlage), habe ich weggelassen."
               if vorlage else "")
    if not zeilen:
        return (f"Keine {'roten oder gelben' if farbe in ('beide', '', None) else farbe + 'en'} Markierungen in "
                f"{_kurz(datei)} ({bereich}).{hinweis}")
    return (f"{_kurz(datei)}: {anzahl} markierte Stellen auf {len(zeilen)} Seiten ({bereich} durchsucht).{hinweis} "
            "Mit pdf_seite_ansehen und dem Ausschnitt kannst du dir eine Stelle genau ansehen.\n" + "\n".join(zeilen))


# Im laufenden Jarvis das Hilfsprogramm schon mal im Hintergrund bauen (nicht bei der Prüfung)
if not sys.argv[0].endswith("eigene.py"):
    threading.Thread(target=_werkzeug, name="pdf-werkzeug-bauen", daemon=True).start()
