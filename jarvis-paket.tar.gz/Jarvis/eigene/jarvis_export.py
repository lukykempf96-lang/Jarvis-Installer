"""Jarvis exportieren: legt auf dem Schreibtisch den Ordner "Jarvis-Export" an, mit dem sich Jarvis
auf einem anderen Mac installieren lässt.

Mitgenommen wird nur Programmcode (Liste unten, nichts sonst). Schlüssel, Haushaltsbuch, Mails, Heimadresse,
iPhone-Verbindung, Logs und reingezogene Dateien bleiben auf diesem Mac. Wer sie mitnehmen will, sichert sie
mit "Persönliche Daten sichern.command" in ein Disk-Image mit Passwort, das der Installer wieder einspielt.
"""

from __future__ import annotations

import os
import shlex
import shutil
import time
from pathlib import Path

BESCHREIBUNG = "Jarvis exportieren: Ordner Jarvis-Export auf dem Schreibtisch zum Installieren auf einem anderen Mac"
PROMPT = (
    "Will Lukas Jarvis exportieren, sichern, mitnehmen oder auf einem anderen Mac installieren, nutze "
    "jarvis_exportieren und sag kurz, was im Ordner liegt und dass er zuerst LIES MICH ZUERST öffnen soll."
)

JARVIS = Path(__file__).resolve().parent.parent
ZIEL_NAME = "Jarvis-Export"
MARKE = ".jarvis-export"

# Nur das hier kommt in den Export (Programmcode). Alles andere im Jarvis-Ordner ist persönlich oder entsteht neu.
DATEIEN = ["CLAUDE.md", "README.md", "AENDERUNGEN.md", "VERSION", "install.sh", "update.sh", ".gitignore"]
ORDNER = ["backend", "frontend", "eigene", ".claude"]
NIE = {"__pycache__", ".DS_Store", "daten", ".env", ".env.tmp"}  # auch nicht in Unterordnern

# Was "Persönliche Daten sichern" ins verschlüsselte Disk-Image legt (falls vorhanden)
PERSOENLICH = [".env", "haushaltsbuch.json", "heimadresse.txt", "mail-prioritaeten.json",
               "handy-thema.txt", "handy-eingerichtet.txt", "eigene/daten/notizfeld.json"]

TOOLS = [{
    "name": "jarvis_exportieren",
    "description": "Legt auf dem Schreibtisch den Ordner Jarvis-Export an: ganzes Programm mit eigenen Funktionen, "
                   "Installationsskript und Anleitung für einen anderen Mac. Ohne Schlüssel und persönliche Daten.",
    "input_schema": {"type": "object", "properties": {}, "required": []},
}]


def _ignorieren(ordner, namen):
    return [n for n in namen if n in NIE or n.endswith((".log", ".pyc", ".command"))]


def _env_vorlage() -> str:
    """.env-Vorlage ohne Schlüssel, mit Lukas' Einstellungen (Stadt, Name, Apps, Stimme ...)."""
    from backend.config import settings
    return f"""# Jarvis-Einstellungen. Die Schlüssel fragt die Installation ab (oder Doppelklick auf "Schlüssel eintragen.command").
ANTHROPIC_API_KEY=
ELEVENLABS_API_KEY=
ELEVENLABS_VOICE_ID={settings.elevenlabs_voice_id}
CLAUDE_MODEL={settings.claude_model}
JARVIS_FAST_MODEL={settings.fast_model}
JARVIS_EFFORT={settings.claude_effort}
JARVIS_MAC_VOICE={settings.mac_voice}
JARVIS_CITY={settings.weather_city}
JARVIS_NAME={settings.user_name}
JARVIS_STARTUP_APPS={",".join(settings.startup_apps)}
JARVIS_PROJECTS_DIR={settings.projects_dir}
JARVIS_NTFY_SERVER={settings.ntfy_server}
JARVIS_PORT={settings.port}
JARVIS_HOST={settings.host}
"""


def _geheimnisse() -> list[bytes]:
    """Werte, die auf keinen Fall im Export landen dürfen (nur zum Prüfen, wird nirgends gespeichert)."""
    werte = [os.environ.get("ANTHROPIC_API_KEY", ""), os.environ.get("ELEVENLABS_API_KEY", "")]
    for datei in ("anzeige-schluessel.txt", "handy-thema.txt", "eigene/daten/handy_mikro_schluessel.txt"):
        try:
            werte.append((JARVIS / datei).read_text().strip())
        except OSError:
            pass
    return [w.encode() for w in werte if len(w) >= 8]


def _pruefen(ziel: Path) -> str | None:
    geheim = _geheimnisse()
    for pfad in ziel.rglob("*"):
        if pfad.is_file():
            inhalt = pfad.read_bytes()
            if any(g in inhalt for g in geheim):
                return str(pfad.relative_to(ziel))
    return None


def _schreiben(pfad: Path, text: str, ausfuehrbar: bool = False):
    pfad.write_text(text, encoding="utf-8")
    if ausfuehrbar:
        pfad.chmod(0o755)


def jarvis_exportieren() -> str:
    desktop = Path.home() / "Desktop"
    ziel = desktop / ZIEL_NAME
    behalten = None
    if ziel.exists():
        if not (ziel / MARKE).exists():
            ziel = desktop / f"{ZIEL_NAME} {time.strftime('%Y-%m-%d %H-%M')}"
        else:
            # alter Export von Jarvis selbst: ein dort angelegtes Disk-Image mit persönlichen Daten bleibt erhalten
            dmg = ziel / "Jarvis-Persoenlich.dmg"
            behalten = dmg.read_bytes() if dmg.exists() else None
            shutil.rmtree(ziel)
    ziel.mkdir(parents=True)
    programm = ziel / "Jarvis"
    programm.mkdir()

    for name in DATEIEN:
        if (JARVIS / name).is_file():
            shutil.copy2(JARVIS / name, programm / name)
    for name in ORDNER:
        if (JARVIS / name).is_dir():
            shutil.copytree(JARVIS / name, programm / name, ignore=_ignorieren, symlinks=True)
    _schreiben(programm / ".env.example", _env_vorlage())
    if behalten:
        (ziel / "Jarvis-Persoenlich.dmg").write_bytes(behalten)

    jarvis_pfad = shlex.quote(str(JARVIS))
    _schreiben(ziel / "Jarvis installieren.command", INSTALLER, ausfuehrbar=True)
    _schreiben(ziel / "Persönliche Daten sichern.command",
               SICHERN.replace("@JARVIS@", jarvis_pfad).replace("@DATEIEN@", " ".join(PERSOENLICH)),
               ausfuehrbar=True)
    from backend.config import settings
    _schreiben(ziel / "LIES MICH ZUERST.txt", ANLEITUNG.replace("@DATUM@", time.strftime("%d.%m.%Y")))
    _schreiben(ziel / "Persönlich - neu einrichten.txt", PERSOENLICH_LISTE.replace("@STADT@", settings.weather_city))
    anleitung = Path(__file__).resolve().parent / "INSTALLATIONSANLEITUNG-MAC.txt"
    if anleitung.is_file():
        shutil.copy2(anleitung, ziel / anleitung.name)
    (ziel / MARKE).write_text("Von Jarvis angelegt.\n")

    fund = _pruefen(ziel)
    if fund:
        shutil.rmtree(ziel, ignore_errors=True)
        return (f"Abgebrochen: In {fund} stand ein Schlüssel. Ich habe den Export wieder gelöscht, "
                "damit nichts Geheimes herumliegt. Sag Claude im Projekt Jarvis Bescheid.")

    groesse = sum(p.stat().st_size for p in ziel.rglob("*") if p.is_file()) / 1e6
    return (f"Der Ordner {ziel.name} liegt auf dem Schreibtisch ({groesse:.1f} MB), ohne Schlüssel und persönliche "
            "Daten. Zuerst LIES MICH ZUERST öffnen; persönliche Daten nimmst du mit Persönliche Daten sichern "
            "verschlüsselt mit.")


# ---------- Installationsskript für den neuen Mac ----------

INSTALLER = r"""#!/bin/bash
# Jarvis auf diesem Mac installieren. Doppelklick genügt.
cd "$(dirname "$0")" || exit 1
EXPORT="$(pwd)"
ZIEL="$HOME/Downloads/Jarvis"   # hier sucht Jarvis später auch seine Updates
stopp() { echo; echo "$1"; read -r -p "Zum Schließen Enter drücken ..." _; exit 1; }

clear
echo "=============================================="
echo "   Jarvis installieren"
echo "=============================================="
echo

# 1. Werkzeuge von Apple (Python, Swift, git). Bringt auch Python 3 mit.
if ! xcode-select -p >/dev/null 2>&1; then
    echo "Zuerst braucht der Mac die Befehlszeilentools von Apple."
    echo "Gleich öffnet sich ein Fenster: auf „Installieren“ klicken und warten (ein paar Minuten)."
    xcode-select --install 2>/dev/null
    stopp "Wenn die Installation fertig ist, diese Datei noch einmal doppelklicken."
fi
echo "✓ Befehlszeilentools vorhanden"

# 2. Google Chrome (das Jarvis-Fenster läuft in Chrome, die Spracherkennung auch)
if [ ! -d "/Applications/Google Chrome.app" ] && [ ! -d "$HOME/Applications/Google Chrome.app" ]; then
    echo "Google Chrome fehlt. Die Download-Seite öffnet sich, bitte Chrome installieren."
    open "https://www.google.com/chrome/"
    stopp "Danach diese Datei noch einmal doppelklicken."
fi
echo "✓ Google Chrome vorhanden"

# 3. Programm an seinen Platz kopieren
if [ -e "$ZIEL" ]; then
    stopp "Es gibt schon einen Ordner $ZIEL. Damit nichts überschrieben wird, bitte ihn erst umbenennen oder löschen."
fi
ditto "$EXPORT/Jarvis" "$ZIEL" || stopp "Kopieren hat nicht geklappt."
xattr -dr com.apple.quarantine "$ZIEL" 2>/dev/null
echo "✓ Jarvis nach $ZIEL kopiert"

# 4. Persönliche Daten aus dem verschlüsselten Disk-Image (falls am alten Mac gesichert)
DMG="$EXPORT/Jarvis-Persoenlich.dmg"
if [ -f "$DMG" ]; then
    echo
    read -r -p "Persönliche Daten (Schlüssel, Haushaltsbuch ...) aus der Sicherung übernehmen? [j/n] " A
    if [ "$A" = "j" ] || [ "$A" = "J" ]; then
        MNT="$(mktemp -d)"
        for VERSUCH in 1 2 3; do
            read -r -s -p "Passwort der Sicherung: " PW; echo
            if printf '%s' "$PW" | hdiutil attach -stdinpass -nobrowse -readonly -quiet -mountpoint "$MNT" "$DMG" 2>/dev/null; then
                ditto "$MNT" "$ZIEL"
                hdiutil detach -quiet "$MNT"
                [ -f "$ZIEL/.env" ] && chmod 600 "$ZIEL/.env"
                [ -f "$ZIEL/haushaltsbuch.json" ] && chmod 600 "$ZIEL/haushaltsbuch.json"
                echo "✓ Persönliche Daten übernommen"
                break
            fi
            echo "Das Passwort passt nicht."
        done
        unset PW
        rmdir "$MNT" 2>/dev/null
    fi
fi

# 5. Pakete installieren, Schlüssel abfragen, Startdateien anlegen (dauert ein paar Minuten)
echo
echo "Jetzt werden die Programmteile geladen. Das dauert ein paar Minuten ..."
echo "Falls nach dem Anthropic-Schlüssel gefragt wird: von console.anthropic.com → API Keys kopieren und einfügen."
echo
cd "$ZIEL" && bash install.sh || stopp "Die Installation ist mit einem Fehler stehen geblieben (siehe oben)."

# 6. Berechtigungen
echo
echo "=============================================="
echo "   Fast fertig: Berechtigungen"
echo "=============================================="
echo "Beim ersten Start fragt macOS mehrmals nach. Bitte immer „Erlauben“ bzw. „OK“:"
echo "  • Mikrofon (für Terminal und für Chrome)"
echo "  • Kalender und Erinnerungen"
echo "  • Kontakte"
echo "  • Steuern von Mail, Chrome, Kontakte, System Events (Automation)"
echo "Von Hand einschalten (Systemeinstellungen → Datenschutz & Sicherheit):"
echo "  • Festplattenvollzugriff → Terminal (für iMessage/SMS)"
echo "  • Bildschirm- und Systemaudioaufnahme → Terminal (für „Was ist auf meinem Bildschirm?“)"
echo "  • Ortungsdienste → JarvisKarten (für Fahrzeiten), falls gefragt"
echo
read -r -p "Datenschutz-Einstellungen jetzt öffnen? [j/n] " A
if [ "$A" = "j" ] || [ "$A" = "J" ]; then
    open "x-apple.systempreferences:com.apple.preference.security?Privacy_AllFiles"
fi

echo
echo "Fertig! Was persönlich ist und neu eingerichtet werden muss, steht in „Persönlich - neu einrichten.txt“."
read -r -p "Jarvis jetzt starten? [j/n] " A
if [ "$A" = "j" ] || [ "$A" = "J" ]; then
    open "$ZIEL/Jarvis.command"
fi
"""


# ---------- Persönliche Daten verschlüsselt sichern (am alten Mac) ----------

SICHERN = r"""#!/bin/bash
# Am ALTEN Mac doppelklicken: legt Schlüssel, Haushaltsbuch & Co. in ein Disk-Image mit Passwort
# (Jarvis-Persoenlich.dmg, AES-256) neben diese Datei. Der Installer am neuen Mac spielt es wieder ein.
cd "$(dirname "$0")" || exit 1
QUELLE=@JARVIS@
DMG="$(pwd)/Jarvis-Persoenlich.dmg"
[ -d "$QUELLE" ] || { echo "Jarvis-Ordner nicht gefunden: $QUELLE"; read -r _; exit 1; }

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/Jarvis-Persoenlich"
GEFUNDEN=""
for F in @DATEIEN@; do
    if [ -f "$QUELLE/$F" ]; then
        mkdir -p "$TMP/Jarvis-Persoenlich/$(dirname "$F")"
        cp -p "$QUELLE/$F" "$TMP/Jarvis-Persoenlich/$F"
        GEFUNDEN="$GEFUNDEN  • $F\n"
    fi
done
[ -n "$GEFUNDEN" ] || { echo "Keine persönlichen Daten gefunden."; read -r _; exit 0; }
printf "Wird verschlüsselt gesichert:\n$GEFUNDEN\n"

frage() { osascript -e "text returned of (display dialog \"$1\" default answer \"\" with hidden answer with title \"Jarvis\")" 2>/dev/null; }
PW="$(frage "Passwort für die Sicherung wählen (gut merken, ohne geht sie nicht auf):")"
PW2="$(frage "Passwort noch einmal:")"
if [ -z "$PW" ] || [ "$PW" != "$PW2" ]; then
    echo "Die Passwörter stimmen nicht überein oder sind leer. Nichts gesichert."; read -r _; exit 1
fi
rm -f "$DMG"
if printf '%s' "$PW" | hdiutil create -quiet -encryption AES-256 -stdinpass \
        -volname "Jarvis-Persoenlich" -srcfolder "$TMP/Jarvis-Persoenlich" "$DMG"; then
    echo "✓ Gesichert: $DMG"
    echo "Diesen Ordner jetzt auf den neuen Mac bringen und dort „Jarvis installieren“ doppelklicken."
else
    echo "Sichern hat nicht geklappt."
fi
unset PW PW2
read -r -p "Zum Schließen Enter drücken ..." _
"""


# ---------- Anleitung ----------

ANLEITUNG = """JARVIS AUF EINEN ANDEREN MAC BRINGEN
Export vom @DATUM@

Was in diesem Ordner liegt
• Jarvis/ – das ganze Programm, mit allen selbst gebauten Funktionen (z. B. Notizfeld, Handy-Mikro,
  längeres Zuhören). Ohne Schlüssel und ohne persönliche Daten.
• Jarvis installieren.command – richtet Jarvis auf dem neuen Mac ein.
• Persönliche Daten sichern.command – nur am ALTEN Mac: sichert Schlüssel, Haushaltsbuch & Co.
  verschlüsselt mit Passwort (freiwillig).
• Persönlich - neu einrichten.txt – was du auf dem neuen Mac selbst einrichten musst.

SO GEHT'S

1. Am alten Mac (freiwillig, aber spart Arbeit)
   „Persönliche Daten sichern.command“ doppelklicken und ein Passwort wählen.
   Danach liegt hier „Jarvis-Persoenlich.dmg“. Ohne Passwort kommt da niemand ran.

2. Ordner auf den neuen Mac bringen
   Den ganzen Ordner „Jarvis-Export“ per AirDrop, USB-Stick oder iCloud auf den neuen Mac kopieren.

3. Am neuen Mac installieren
   „Jarvis installieren.command“ doppelklicken.
   Sagt macOS „kann nicht geöffnet werden“: Rechtsklick auf die Datei → „Öffnen“ → „Öffnen“.
   (Oder: Systemeinstellungen → Datenschutz & Sicherheit → unten „Trotzdem öffnen“.)
   Das Skript erledigt der Reihe nach:
   • prüft die Apple-Befehlszeilentools (bringen Python mit) und installiert sie bei Bedarf,
   • prüft Google Chrome,
   • kopiert Jarvis nach „Downloads/Jarvis“ (dort sucht Jarvis auch seine Updates),
   • spielt auf Wunsch die verschlüsselte Sicherung ein,
   • lädt alle Programmteile (Python-Pakete, Browser für die Webseiten-Steuerung, „Hey Jarvis“-Erkennung),
   • fragt nach dem Anthropic-Schlüssel, der Stadt und optional dem ElevenLabs-Schlüssel,
   • legt „Jarvis.command“ (Start) und „Jarvis neu starten.command“ an.
   Dauer: etwa 5 bis 15 Minuten, je nach Internet.

4. Erster Start
   „Downloads/Jarvis/Jarvis.command“ doppelklicken, dann zweimal klatschen oder „Hey Jarvis“ sagen.
   macOS fragt nach Mikrofon, Kalender, Erinnerungen, Kontakten und dem Steuern anderer Apps:
   immer erlauben. Von Hand einschalten (Systemeinstellungen → Datenschutz & Sicherheit):
   • Festplattenvollzugriff → Terminal (damit Jarvis iMessage/SMS lesen kann)
   • Bildschirm- und Systemaudioaufnahme → Terminal (damit Jarvis den Bildschirm sehen kann)
   Automatisch beim Anmelden starten: Systemeinstellungen → Allgemein → Anmeldeobjekte → „Jarvis.command“.

5. Persönliches einrichten
   Siehe „Persönlich - neu einrichten.txt“.

Was der neue Mac braucht
• macOS mit Internet, Google Chrome
• Apple-Befehlszeilentools (installiert das Skript selbst)
• Für den Selbstausbau („Bau dir …“): Claude Code, siehe Liste
"""


PERSOENLICH_LISTE = """WAS PERSÖNLICH IST UND NEU EINGERICHTET WERDEN MUSS

Nichts davon steckt ungeschützt im Export. Hast du am alten Mac „Persönliche Daten sichern“ benutzt,
sind die mit (S) markierten Dinge in der verschlüsselten Sicherung und kommen bei der Installation von selbst.

SCHLÜSSEL
• Anthropic-API-Schlüssel (Pflicht, das „Gehirn“) (S)
  console.anthropic.com → API Keys. Fragt die Installation ab. Später ändern: Schlüssel kopieren,
  dann „Schlüssel eintragen.command“ im Jarvis-Ordner doppelklicken.
• ElevenLabs-Schlüssel (freiwillig, die Jarvis-Stimme) (S)
  elevenlabs.io → Profil → API Keys. Ohne ihn spricht Jarvis mit der Mac-Stimme.

EINSTELLUNGEN (Datei .env im Jarvis-Ordner)
• Stadt fürs Wetter (bisher: @STADT@), Name, Apps beim Klatschen, Modelle, Stimme:
  sind in der Vorlage schon wie bisher eingestellt, nur die Stadt fragt die Installation nochmal.

ZUHAUSE UND HANDY
• Heimadresse für Fahrzeiten (S): sonst einfach sagen „Mein Zuhause ist …“.
• Mitteilungen aufs iPhone (App „ntfy“) (S): Mit Sicherung geht es weiter wie bisher.
  Ohne: im Jarvis-Fenster bei „Mac“ auf „iPhone“ klicken und das neue Thema in der ntfy-App abonnieren.
• Handy als Anzeige: im Jarvis-Fenster auf „Anzeige“ klicken und den QR-Code neu scannen
  (neuer Schlüssel, der alte Link geht nicht mehr).
• Handy-Mikro: im Jarvis-Fenster auf „Handy-Mikro“ klicken, QR-Code neu scannen und die
  Zertifikat-Warnung in Safari einmal neu bestätigen (der neue Mac hat ein eigenes Zertifikat).

DEINE DATEN
• Haushaltsbuch (S): ohne Sicherung startet es leer.
• Mail-Prioritäten (welche Absender wichtig sind) (S): ohne Sicherung Jarvis neu sagen.
• Inhalt des Notizfelds (S).
• Mails, Kalender, Erinnerungen, Kontakte, iMessage: kommen nicht aus Jarvis, sondern aus den Apps des Macs.
  Am neuen Mac mit deiner Apple-ID anmelden (iCloud: Kalender, Erinnerungen, Kontakte, Nachrichten) und
  in der Mail-App deine Postfächer einrichten. Dann sieht Jarvis alles wieder.
• Reingezogene Dateien (Ordner „eingang“) und Jarvis' Protokolle werden nicht mitgenommen.
  Brauchst du eine Datei davon, kopier sie selbst.

SELBSTAUSBAU
• Claude Code (für „Bau dir …“): claude.ai/code → für den Mac installieren, dann einmal im Terminal
  „claude“ eingeben und anmelden. Die selbst gebauten Funktionen sind schon im Export dabei.
• Updates: Jarvis-Updates wie gewohnt in „Downloads“ legen, Jarvis spielt sie beim Start ein.
"""
