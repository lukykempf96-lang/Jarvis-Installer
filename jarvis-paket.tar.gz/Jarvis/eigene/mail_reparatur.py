"""Reparatur fürs Dashboard: Mail-Abruf ohne AppleScript-Syntaxfehler, mit sauberem Zeitlimit.

Ursache: Im Kern (backend/alltag.py, fetch_mail_headers) heißt eine Variable "rd". Das ist in AppleScript ein
reservierter Teil von Ordnungszahlen ("3rd"), das ganze Skript lässt sich deshalb nicht übersetzen
("Ausdruck erwartet, aber 'rd' gefunden", -2741). Diese Datei ersetzt die Funktion im laufenden Jarvis durch eine
korrigierte Fassung, aber nur solange der Kern den Fehler noch hat. Kommt ein Update mit der Korrektur,
tut diese Datei nichts mehr und kann weg.

Zusätzlich: fehlende Betreffe oder Absender ("missing value") brechen nichts mehr, die Mail-App bekommt ein
Zeitlimit, und hängt sie, versucht das Dashboard nicht noch zwölf Mal einzeln den Mailtext zu holen.
"""

from __future__ import annotations

import inspect
import sys
import time
import types

BESCHREIBUNG = "Reparatur: Mails im Dashboard ohne AppleScript-Fehler abrufen (wichtige Mails wieder sichtbar)"

APPLE_TIMEOUT = 60      # Sekunden, die die Mail-App pro Abruf hat (danach Fehler -1712 statt Hängen)
PAUSE_NACH_HAENGER = 120  # so lange keine einzelnen Mailtexte nachladen, wenn die Mail-App gerade hängt

_halter = sys.modules.setdefault("_jarvis_mail_reparatur_halter", types.ModuleType("_jarvis_mail_reparatur_halter"))
if not hasattr(_halter, "orig"):
    _halter.orig = {}
    _halter.haenger = 0.0

_KOPF = f"""
on txt(x)
    if x is missing value then return ""
    return x as text
end txt

set US to character id 31
set RS to character id 30
set cutoff to (current date) - (%DAYS% * days)
with timeout of {APPLE_TIMEOUT} seconds
    tell application "Mail"
        set msgIds to message id of (messages of inbox whose date received > cutoff)
        set msgSenders to sender of (messages of inbox whose date received > cutoff)
        set msgSubjects to subject of (messages of inbox whose date received > cutoff)
        set msgDates to date received of (messages of inbox whose date received > cutoff)
        set msgFlags to flagged status of (messages of inbox whose date received > cutoff)
        set msgRead to read status of (messages of inbox whose date received > cutoff)
    end tell
end timeout
set n to count of msgIds
set out to ""
repeat with i from 1 to n
    set out to out & my txt(item i of msgIds) & US & my txt(item i of msgSenders) & US & my txt(item i of msgSubjects) & US & ((item i of msgDates) as «class isot» as string) & US & my txt(item i of msgFlags) & US & "" & US & "" & US & my txt(item i of msgRead) & RS
end repeat
return (n as string) & RS & out
"""


def _osascript(script: str, timeout: int):
    """Wie im Kern, aber ein Zeitlimit der Mail-App (-1712) wird zu einem verständlichen Satz."""
    from backend import alltag

    try:
        return alltag._osascript(script, timeout=timeout)
    except RuntimeError as exc:
        text = str(exc)
        if "Zeitlimit" in text or "-1712" in text:
            _halter.haenger = time.time()
            raise RuntimeError("Die Mail-App antwortet gerade nicht (Zeitlimit). Die Mails zeige ich, "
                               "sobald sie wieder reagiert.") from None
        raise


def fetch_mail_headers(days: int = 3, limit: int = 80) -> list[dict]:
    """Erst der Weg des Kerns (z. B. Mails Datenbank); nur wenn der am 'rd'-Fehler scheitert, das korrigierte Skript."""
    from backend import alltag

    try:
        return _halter.orig["fetch_mail_headers"](days, limit)
    except RuntimeError as exc:
        if "-2741" not in str(exc) and "'rd'" not in str(exc):
            if "Zeitlimit" in str(exc) or "-1712" in str(exc):
                _halter.haenger = time.time()
            raise
    _, mails = alltag._parse_mails(_osascript(_KOPF.replace("%DAYS%", str(int(days))), timeout=APPLE_TIMEOUT + 15))
    return mails[:limit]


def fetch_mail_preview(message_id: str, length: int = 400) -> str:
    """Textanfang einer Mail; hängt die Mail-App gerade, sofort abbrechen statt pro Mail 30 Sekunden zu warten."""
    if time.time() - _halter.haenger < PAUSE_NACH_HAENGER:
        raise RuntimeError("Mail-App hängt gerade")
    try:
        return _halter.orig["fetch_mail_preview"](message_id, length)
    except RuntimeError as exc:
        if "Zeitlimit" in str(exc) or "-1712" in str(exc):
            _halter.haenger = time.time()
        raise


fetch_mail_headers._jarvis_reparatur = True
fetch_mail_preview._jarvis_reparatur = True


def _kern_hat_fehler(fn) -> bool:
    try:
        return "set rd to" in inspect.getsource(fn)
    except (OSError, TypeError):
        return False


def _einhaengen():
    from backend import alltag

    for name in ("fetch_mail_headers", "fetch_mail_preview"):
        aktuell = getattr(alltag, name)
        if not getattr(aktuell, "_jarvis_reparatur", False):
            _halter.orig[name] = aktuell  # die echte Kern-Funktion merken (nicht unsere von vorher)
    original = _halter.orig.get("fetch_mail_headers")
    if original is None or not _kern_hat_fehler(original):
        # Kern ist repariert (oder unbekannt): nichts ersetzen, Originale zurück
        for name, fn in _halter.orig.items():
            setattr(alltag, name, fn)
        return
    alltag.fetch_mail_headers = fetch_mail_headers
    alltag.fetch_mail_preview = fetch_mail_preview
    try:  # gleich neu laden, damit die Fehlermeldung im Dashboard verschwindet
        from backend import dashboard
        dashboard._sections["mails"]["at"] = 0.0
    except Exception:
        pass


_einhaengen()
