"""Online-Installer: Jarvis mit einem einzigen Terminal-Befehl (curl … | bash) auf einem Mac installieren.

Erzeugt drei Dateien im Ordner "Online-Installation" (im Jarvis-Export auf dem Schreibtisch):
- jarvis-install.sh      das Startskript, das hinter dem Link liegt
- jarvis-paket.tar.gz    das Programm mit allen eigenen Funktionen, ohne Schlüssel und persönliche Daten
- ANLEITUNG-ONLINE-INSTALLATION.txt   wo hochladen, wie der Einzeiler lautet
Das Startskript kennt die Prüfsumme des Pakets und installiert nur genau dieses.
"""

from __future__ import annotations

import hashlib
import importlib.util
import io
import os
import re
import shutil
import tarfile
import time
from pathlib import Path

BESCHREIBUNG = "Online-Installer bauen: Jarvis per curl-Einzeiler auf einem Mac installieren"
PROMPT = (
    "Will Lukas einen Online-Installer oder einen Installationslink für Jarvis, nutze jarvis_installer_bauen. "
    "Hat er schon einen Link (z. B. raw.githubusercontent.com/... oder einen Dropbox-Link), gib ihn mit."
)

HIER = Path(__file__).resolve().parent
JARVIS = HIER.parent
PLATZHALTER = "HIER-DEN-LINK-EINTRAGEN"

TOOLS = [{
    "name": "jarvis_installer_bauen",
    "description": "Baut den Online-Installer für Jarvis (Startskript, Programmpaket, Anleitung) und legt ihn in den "
                   "Jarvis-Export auf dem Schreibtisch, Ordner Online-Installation. link_basis = Adresse des Ordners, "
                   "in dem die Dateien online liegen (z. B. https://raw.githubusercontent.com/NAME/jarvis-installer/main). "
                   "Alternativ paket_link = direkter Link nur zum Paket (z. B. Dropbox mit dl=1).",
    "input_schema": {"type": "object", "properties": {
        "link_basis": {"type": "string"},
        "paket_link": {"type": "string"}}, "required": []},
}]


def _export_modul():
    spec = importlib.util.spec_from_file_location("_jarvis_export_fuer_installer", HIER / "jarvis_export.py")
    modul = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(modul)
    return modul


ENV_NEUTRAL = """# Jarvis-Einstellungen. Schlüssel trägt der Installer ein (oder Doppelklick auf "Schlüssel eintragen.command").
ANTHROPIC_API_KEY=
ELEVENLABS_API_KEY=
ELEVENLABS_VOICE_ID=rDmv3mOhK6TnhYWckFaD
CLAUDE_MODEL=claude-sonnet-5-5
JARVIS_FAST_MODEL=claude-haiku-4-5
JARVIS_EFFORT=low
JARVIS_MAC_VOICE=Markus
JARVIS_STARTUP_APPS=Spotify,Visual Studio Code,Obsidian
JARVIS_PROJECTS_DIR=~/Projekte
JARVIS_NTFY_SERVER=https://ntfy.sh
JARVIS_PORT=8000
JARVIS_HOST=0.0.0.0
"""


def _paket() -> bytes:
    """tar.gz mit dem Ordner Jarvis/ (gleiche Auswahl wie der Mac-Export), gleicher Inhalt = gleiche Bytes."""
    ex = _export_modul()
    eintraege: list[tuple[str, Path]] = []
    for name in ex.DATEIEN:
        if (JARVIS / name).is_file():
            eintraege.append((name, JARVIS / name))
    for name in ex.ORDNER:
        basis = JARVIS / name
        for wurzel, ordner, dateien in os.walk(basis):
            ordner[:] = sorted(o for o in ordner if o not in ex.NIE)
            for datei in sorted(dateien):
                if datei in ex.NIE or datei.endswith((".log", ".pyc", ".command")):
                    continue
                pfad = Path(wurzel) / datei
                eintraege.append((str(pfad.relative_to(JARVIS)), pfad))
    roh = io.BytesIO()
    with tarfile.open(fileobj=roh, mode="w", format=tarfile.PAX_FORMAT) as tar:
        def hinzu(name: str, daten: bytes, ausfuehrbar: bool = False):
            info = tarfile.TarInfo("Jarvis/" + name)
            info.size, info.mtime, info.mode = len(daten), 0, 0o755 if ausfuehrbar else 0o644
            tar.addfile(info, io.BytesIO(daten))
        for name, pfad in sorted(eintraege):
            hinzu(name, pfad.read_bytes(), name.endswith(".sh"))
        hinzu(".env.example", ENV_NEUTRAL.encode())
    import gzip
    return gzip.compress(roh.getvalue(), mtime=0)


def _geheimnisse_pruefen(daten: bytes) -> str | None:
    ex = _export_modul()
    entpackt = tarfile.open(fileobj=io.BytesIO(daten), mode="r:gz")
    geheim = ex._geheimnisse()
    for mitglied in entpackt.getmembers():
        if mitglied.isfile():
            inhalt = entpackt.extractfile(mitglied).read()
            if any(g in inhalt for g in geheim):
                return mitglied.name
    return None


def _zielordner() -> Path:
    desktop = Path.home() / "Desktop"
    export = desktop / "Jarvis-Export"
    return (export if export.is_dir() else desktop / "Jarvis-Online-Installation") / "Online-Installation"


def jarvis_installer_bauen(link_basis: str = "", paket_link: str = "") -> str:
    link_basis = (link_basis or "").strip().rstrip("/")
    paket_url = (paket_link or "").strip() or (f"{link_basis}/jarvis-paket.tar.gz" if link_basis else PLATZHALTER)
    skript_url = f"{link_basis}/jarvis-install.sh" if link_basis else "LINK-ZU/jarvis-install.sh"
    if paket_url != PLATZHALTER and not paket_url.startswith("https://"):
        return "Der Link muss mit https:// beginnen."

    paket = _paket()
    fund = _geheimnisse_pruefen(paket)
    if fund:
        return f"Abgebrochen: In {fund} stand ein Schlüssel. Sag Claude im Projekt Jarvis Bescheid."
    pruefsumme = hashlib.sha256(paket).hexdigest()
    version = (JARVIS / "VERSION").read_text().strip()
    datum = time.strftime("%d.%m.%Y")

    skript = (SKRIPT.replace("@PAKET_URL@", paket_url).replace("@PAKET_SHA256@", pruefsumme)
              .replace("@VERSION@", version).replace("@DATUM@", datum))
    einzeiler = f"curl -fsSL {skript_url} | bash"
    anleitung = (ANLEITUNG.replace("@EINZEILER@", einzeiler).replace("@DATUM@", datum).replace("@VERSION@", version)
                 .replace("@GROESSE@", f"{len(paket) / 1e6:.1f} MB".replace(".", ","))
                 .replace("@LINK_STATUS@", "Der Link ist schon eingetragen." if paket_url != PLATZHALTER else
                          "ACHTUNG: Es ist noch KEIN Link eingetragen. Erst Schritt 1 machen, dann Jarvis sagen: "
                          "„Bau den Online-Installer mit dem Link https://raw.githubusercontent.com/DEINNAME/jarvis-installer/main“."))

    ziel = _zielordner()
    ziel.mkdir(parents=True, exist_ok=True)
    (ziel / "jarvis-paket.tar.gz").write_bytes(paket)
    (ziel / "jarvis-install.sh").write_text(skript, encoding="utf-8")
    (ziel / "jarvis-install.sh").chmod(0o755)
    (ziel / "ANLEITUNG-ONLINE-INSTALLATION.txt").write_text(anleitung, encoding="utf-8")
    if ziel.parent.name == "Jarvis-Export":  # zusätzlich direkt in den Export-Ordner, wie gewünscht
        shutil.copy2(ziel / "jarvis-install.sh", ziel.parent / "jarvis-install.sh")

    wo = "im Jarvis-Export auf dem Schreibtisch" if ziel.parent.name == "Jarvis-Export" else "auf dem Schreibtisch"
    if paket_url == PLATZHALTER:
        return (f"Der Online-Installer liegt {wo} im Ordner Online-Installation, aber noch ohne Link. Leg zuerst das "
                "GitHub-Repository an, wie in der Anleitung dort steht, und sag mir dann den Link, dann trage ich ihn ein.")
    return (f"Der Online-Installer liegt {wo} im Ordner Online-Installation, mit Link und Prüfsumme. Lade die beiden "
            "Dateien jarvis-install.sh und jarvis-paket.tar.gz hoch; der Einzeiler steht in der Anleitung dort.")


# ---------------------------------------------------------------- das Startskript

SKRIPT = r'''#!/bin/bash
# Jarvis-Installer für den Mac (Jarvis Version @VERSION@, erstellt am @DATUM@).
# Aufruf im Terminal:   curl -fsSL <Link>/jarvis-install.sh | bash
# Enthält keine Schlüssel und keine persönlichen Daten. Die Schlüssel fragt es ab und speichert sie nur auf diesem Mac.

PAKET_URL="${JARVIS_PAKET_URL:-@PAKET_URL@}"
PAKET_SHA256="@PAKET_SHA256@"
ZIEL="$HOME/Downloads/Jarvis"   # nur hier findet Jarvis später seine Updates

main() {
set -uo pipefail
TTY=/dev/tty                     # Antworten kommen von der Tastatur, nicht aus dem Skript
fett() { printf '\n\033[1m%s\033[0m\n' "$1"; }
ok() { printf '  \033[32m✓\033[0m %s\n' "$1"; }
hinweis() { printf '  %s\n' "$1"; }
stopp() { printf '\n\033[31m✗ %s\033[0m\n' "$1"; exit 1; }
frage() { local a; read -r -p "  $1 " a < "$TTY" || true; printf '%s' "$a"; }
geheim() { local a; read -r -s -p "  $1 " a < "$TTY" || true; echo > "$TTY"; printf '%s' "$a" | tr -d '[:space:]'; }
ja() { local a; a="$(frage "$1 [j/n]")"; [[ "$a" =~ ^[jJyY] ]]; }

clear 2>/dev/null || true
echo "=============================================="
echo "   Jarvis installieren (Version @VERSION@)"
echo "=============================================="
[ "$(uname)" = "Darwin" ] || stopp "Dieses Skript ist nur für den Mac."
[ -r "$TTY" ] || stopp "Bitte direkt im Terminal ausführen."
[ "$PAKET_URL" != "HIER-DEN-LINK-EINTRAGEN" ] || stopp "In diesem Skript ist noch kein Link zum Jarvis-Paket eingetragen."

# 1. Apple-Befehlszeilentools (Python, Swift, git)
fett "1/7  Apple-Befehlszeilentools"
if ! xcode-select -p >/dev/null 2>&1; then
    hinweis "Es öffnet sich gleich ein Fenster von Apple: auf „Installieren“ klicken und warten."
    xcode-select --install >/dev/null 2>&1 || true
    hinweis "Ich warte, bis die Installation fertig ist (das kann 5 bis 20 Minuten dauern) ..."
    for _ in $(seq 1 240); do xcode-select -p >/dev/null 2>&1 && break; sleep 10; done
    xcode-select -p >/dev/null 2>&1 || stopp "Die Befehlszeilentools fehlen noch. Nach der Installation den Befehl nochmal einfügen."
fi
ok "Befehlszeilentools vorhanden"

# 2. Homebrew und Python
fett "2/7  Homebrew und Python"
BREW=""
for b in /opt/homebrew/bin/brew /usr/local/bin/brew; do [ -x "$b" ] && BREW="$b" && break; done
if [ -z "$BREW" ]; then
    hinweis "Homebrew (die Paketverwaltung für den Mac) fehlt. Damit bekommt Jarvis ein aktuelles Python."
    if ja "Homebrew jetzt installieren? (fragt nach deinem Mac-Passwort)"; then
        /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)" < "$TTY" \
            || hinweis "Homebrew ließ sich nicht installieren, ich nehme das Python von Apple."
        for b in /opt/homebrew/bin/brew /usr/local/bin/brew; do [ -x "$b" ] && BREW="$b" && break; done
    fi
fi
if [ -n "$BREW" ]; then
    eval "$("$BREW" shellenv)"
    if ! command -v python3.12 >/dev/null 2>&1; then
        hinweis "Python 3.12 wird installiert ..."
        "$BREW" install python@3.12 >/dev/null 2>&1 || hinweis "Python über Homebrew ging nicht, ich nehme das Python von Apple."
    fi
    ok "Homebrew vorhanden"
fi
PY=""
for c in python3.13 python3.12 python3.11 python3.10 python3; do
    if command -v "$c" >/dev/null 2>&1 && "$c" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)' 2>/dev/null; then
        PY="$(command -v "$c")"; break
    fi
done
[ -n "$PY" ] || stopp "Kein Python 3.9 oder neuer gefunden."
ok "Python: $("$PY" --version 2>&1)"

if [ ! -d "/Applications/Google Chrome.app" ] && [ ! -d "$HOME/Applications/Google Chrome.app" ]; then
    hinweis "Google Chrome fehlt (das Jarvis-Fenster und die Spracherkennung brauchen es)."
    if [ -n "$BREW" ] && ja "Google Chrome jetzt installieren?"; then
        "$BREW" install --cask google-chrome >/dev/null 2>&1 && ok "Google Chrome installiert" \
            || hinweis "Bitte Chrome selbst von google.com/chrome installieren."
    else
        hinweis "Bitte Chrome von google.com/chrome installieren, das geht auch später."
    fi
else
    ok "Google Chrome vorhanden"
fi

# 3. Programm laden und prüfen
fett "3/7  Jarvis laden"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
curl -fL --progress-bar "$PAKET_URL" -o "$TMP/jarvis.tar.gz" < /dev/null || stopp "Das Jarvis-Paket ließ sich nicht laden. Internet und Link prüfen."
SUMME="$(shasum -a 256 "$TMP/jarvis.tar.gz" | cut -d' ' -f1)"
[ "$SUMME" = "$PAKET_SHA256" ] || stopp "Das Paket ist nicht das erwartete (Prüfsumme passt nicht). Abgebrochen, sicherheitshalber."
tar -xzf "$TMP/jarvis.tar.gz" -C "$TMP" || stopp "Das Paket ließ sich nicht entpacken."
ok "Paket geladen und geprüft"

# 4. Programmordner einrichten
fett "4/7  Programmordner $ZIEL"
UPDATE=0
if [ -d "$ZIEL" ]; then
    hinweis "Es gibt schon einen Jarvis in $ZIEL."
    if ja "Diesen Jarvis auf den neuen Stand bringen? Schlüssel, Haushaltsbuch und eigene Daten bleiben"; then
        UPDATE=1
        pkill -f "uvicorn backend.main" 2>/dev/null || true
        pkill -f backend.clap_daemon 2>/dev/null || true
        (cd "$TMP/Jarvis" && tar -cf - .) | (cd "$ZIEL" && tar -xf -) || stopp "Kopieren hat nicht geklappt."
    else
        stopp "Nichts verändert. Den alten Ordner erst umbenennen, dann den Befehl nochmal einfügen."
    fi
else
    mkdir -p "$(dirname "$ZIEL")"
    mv "$TMP/Jarvis" "$ZIEL" || stopp "Der Ordner ließ sich nicht anlegen."
fi
xattr -dr com.apple.quarantine "$ZIEL" 2>/dev/null || true
ok "Programmdateien eingerichtet (mit allen eigenen Funktionen)"

# 5. Schlüssel und Einstellungen
fett "5/7  Schlüssel und Einstellungen"
cd "$ZIEL" || stopp "Ordner fehlt."
umask 077
NEUE_ENV=0
if [ -f .env ] && grep -q '^ANTHROPIC_API_KEY=..' .env; then
    ok "Schlüssel sind schon eingetragen"
    ja "Trotzdem neue Schlüssel eingeben?" && NEUE_ENV=1
else
    NEUE_ENV=1
fi
if [ "$NEUE_ENV" = 1 ]; then
    hinweis "Anthropic-Schlüssel (Jarvis' Gehirn): console.anthropic.com -> API Keys -> Create Key -> kopieren."
    hinweis "Hier mit ⌘V einfügen. Man sieht beim Einfügen nichts, das ist Absicht. Dann Enter."
    while true; do
        KEY="$(geheim "Anthropic-Schlüssel:")"
        case "$KEY" in sk-ant-*) ;; *) hinweis "Das sieht nicht wie ein Anthropic-Schlüssel aus (beginnt mit sk-ant-)."; continue ;; esac
        CODE="$(printf 'header = "x-api-key: %s"\nheader = "anthropic-version: 2023-06-01"\n' "$KEY" \
                | curl -s -o /dev/null -w '%{http_code}' --config - https://api.anthropic.com/v1/models || echo 000)"
        if [ "$CODE" = "200" ]; then ok "Schlüssel funktioniert"; break; fi
        if [ "$CODE" = "401" ]; then hinweis "Anthropic lehnt diesen Schlüssel ab. Bitte nochmal kopieren."; continue; fi
        hinweis "Konnte den Schlüssel nicht prüfen (Code $CODE), ich speichere ihn trotzdem."; break
    done
    EKEY="$(geheim "ElevenLabs-Schlüssel für die Jarvis-Stimme (freiwillig, sonst nur Enter):")"
    NAME="$(frage "Wie heißt du? (so spricht Jarvis dich an)")"
    STADT="$(frage "Deine Stadt (für Wetter und Wege):")"
    [ -f .env ] || cp .env.example .env
    KEY="$KEY" EKEY="$EKEY" NAME="$NAME" STADT="$STADT" /usr/bin/python3 - <<'PYEOF'
import os, re
p = ".env"
s = open(p, encoding="utf-8").read()
def setze(name, wert, s):
    if not wert:
        return s
    zeile = f"{name}={wert}"
    return re.sub(rf"^{name}=.*$", lambda m: zeile, s, flags=re.M) if re.search(rf"^{name}=", s, re.M) else s.rstrip("\n") + "\n" + zeile + "\n"
for name, env in (("ANTHROPIC_API_KEY", "KEY"), ("ELEVENLABS_API_KEY", "EKEY"), ("JARVIS_NAME", "NAME"), ("JARVIS_CITY", "STADT")):
    s = setze(name, os.environ.get(env, "").strip(), s)
open(p, "w", encoding="utf-8").write(s)
PYEOF
    unset KEY EKEY
    chmod 600 .env
    ok "Gespeichert in $ZIEL/.env (nur für dich lesbar, nie weitergeben)"
fi
umask 022

# 6. Programmteile installieren
fett "6/7  Programmteile installieren (5 bis 15 Minuten)"
bash install.sh --update < "$TTY" || stopp "Die Installation ist stehen geblieben (Fehler siehe oben). Einfach den Befehl nochmal einfügen."
venv/bin/python -m backend.eigene > "$TMP/eigene.txt" 2>&1
if grep -q "FEHLER" "$TMP/eigene.txt"; then
    hinweis "Diese eigenen Funktionen melden einen Fehler (die anderen laufen trotzdem):"
    grep "FEHLER" "$TMP/eigene.txt" | sed 's/^/    /'
else
    ok "Alle eigenen Funktionen sind bereit ($(grep -c '^ok .*\.py' "$TMP/eigene.txt") Funktionen)"
fi

# 7. Berechtigungen und Start
fett "7/7  Berechtigungen"
cat <<'TEXT'
  macOS fragt beim ersten Start mehrmals nach. Immer „Erlauben“ bzw. „OK“ klicken.
  Von Hand einschalten unter Systemeinstellungen -> Datenschutz & Sicherheit:
    • Mikrofon ............................ Terminal und Google Chrome
    • Kalender (Vollzugriff), Erinnerungen, Kontakte ... Terminal
    • Festplattenvollzugriff .............. Terminal (Nachrichten, Kontakte, schnelles Mail-Lesen)
    • Automation .......................... Terminal -> Mail, Google Chrome, Kontakte, Terminal
    • Bildschirm- & Systemaudioaufnahme ... Terminal („Was ist auf meinem Bildschirm?“)
    • Lokales Netzwerk .................... Terminal (Handy-Anzeige, Handy-Mikro)
    • Bedienungshilfen .................... braucht Jarvis normalerweise nicht
  Nach jeder Änderung: „Jarvis neu starten.command“ im Jarvis-Ordner doppelklicken.
  Mail, Kalender und Nachrichten müssen in den Apple-Apps eingerichtet sein.
TEXT
if ja "Die Datenschutz-Einstellungen jetzt öffnen?"; then
    open "x-apple.systempreferences:com.apple.preference.security?Privacy_Microphone" 2>/dev/null || true
fi

fett "Fertig!"
hinweis "Jarvis liegt in $ZIEL. Starten: Doppelklick auf „Jarvis.command“, dann zweimal klatschen oder „Hey Jarvis“ sagen."
hinweis "Eine ausführliche Anleitung steht in eigene/INSTALLATIONSANLEITUNG-MAC.txt."
if ja "Jarvis jetzt starten?"; then
    open "$ZIEL/Jarvis.command"
    hinweis "Jarvis startet in einem eigenen Terminal-Fenster. Dieses Fenster kannst du schließen."
fi
}

main "$@"
'''


# ---------------------------------------------------------------- Anleitung zum Hochladen

ANLEITUNG = """JARVIS PER LINK INSTALLIEREN – SO RICHTEST DU DEN LINK EIN
Erstellt am @DATUM@ aus Jarvis Version @VERSION@.

@LINK_STATUS@

IN DIESEM ORDNER
  jarvis-install.sh        das Startskript (liegt hinter dem Link)
  jarvis-paket.tar.gz      das Programm mit allen eigenen Funktionen (@GROESSE@),
                           ohne Schlüssel und ohne persönliche Daten
Beide Dateien gehören zusammen: Das Skript installiert nur genau dieses Paket
(es prüft die Prüfsumme). Nach jedem neuen Bau beide neu hochladen.

DER EINZEILER (im Terminal einfügen und Enter drücken)

    @EINZEILER@

WAS DAS SKRIPT MACHT
  1. Apple-Befehlszeilentools prüfen oder installieren
  2. Homebrew und Python 3.12 prüfen oder (nach Rückfrage) installieren, Chrome anbieten
  3. Das Paket laden und die Prüfsumme kontrollieren
  4. Jarvis nach ~/Downloads/Jarvis legen (gibt es ihn schon: auf Wunsch aktualisieren,
     Schlüssel und Daten bleiben)
  5. Anthropic-Schlüssel abfragen und prüfen, ElevenLabs freiwillig, Name, Stadt;
     gespeichert in ~/Downloads/Jarvis/.env, nur für dich lesbar
  6. Alle Programmteile installieren und die eigenen Funktionen prüfen
  7. Berechtigungen erklären und Jarvis starten

WO HOCHLADEN – EMPFOHLEN: GITHUB
  Wichtig zu wissen: Ein Einzeiler mit curl funktioniert nur, wenn die Dateien
  ohne Anmeldung erreichbar sind. Bei einem PRIVATEN GitHub-Repository bräuchte
  der Befehl einen Zugangsschlüssel (Token), und der gehört in keinen Einzeiler.
  Darum: ein öffentliches Repository. Das ist unbedenklich, weil das Paket weder
  Schlüssel noch persönliche Daten enthält. Sichtbar ist nur der Programmcode
  (darin kommt dein Vorname vor, weil Jarvis dich so anspricht).

  1. Auf github.com ein kostenloses Konto anlegen und anmelden.
  2. Oben rechts „+“ -> „New repository“.
     Name: jarvis-installer   ·   „Public“ auswählen   ·   „Create repository“.
  3. Dein Link lautet dann:
         https://raw.githubusercontent.com/DEINNAME/jarvis-installer/main
     (DEINNAME = dein GitHub-Benutzername)
  4. Jarvis sagen: „Bau den Online-Installer mit dem Link
     https://raw.githubusercontent.com/DEINNAME/jarvis-installer/main“
     Dann sind Link und Prüfsumme im Skript eingetragen.
  5. Im Repository auf „uploading an existing file“ bzw. „Add file“ -> „Upload files“,
     die beiden Dateien jarvis-install.sh und jarvis-paket.tar.gz hineinziehen,
     unten „Commit changes“.
  6. Fertig. Der Einzeiler lautet:
         curl -fsSL https://raw.githubusercontent.com/DEINNAME/jarvis-installer/main/jarvis-install.sh | bash

WENN ES PRIVAT BLEIBEN SOLL: DROPBOX
  1. Beide Dateien in Dropbox hochladen.
  2. Für jede Datei „Teilen“ -> „Link kopieren“. Am Ende des Links „dl=0“ durch „dl=1“ ersetzen.
  3. Jarvis sagen: „Bau den Online-Installer mit dem Paket-Link <Link zu jarvis-paket.tar.gz>“.
  4. Das neue jarvis-install.sh in Dropbox ersetzen (gleicher Link bleibt).
  5. Einzeiler:   curl -fsSL "<Link zu jarvis-install.sh mit dl=1>" | bash
  Wer den Link kennt, kann das Paket laden. Den Link also nur gezielt weitergeben.

SICHERHEIT
  - Im Skript und im Paket stehen keine Schlüssel und keine persönlichen Daten
    (Jarvis prüft das vor dem Speichern).
  - Das Skript lädt nur das Paket mit der eingetragenen Prüfsumme.
  - „curl … | bash“ führt das Skript sofort aus. Nur Links benutzen, die du selbst angelegt hast.
"""
