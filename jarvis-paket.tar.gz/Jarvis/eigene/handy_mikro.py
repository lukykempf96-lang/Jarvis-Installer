"""iPhone als Mikrofon: eine eigene HTTPS-Seite im WLAN, über die Lukas mit Jarvis spricht.

Warum ein eigener Server: Safari gibt Mikrofon und Spracherkennung nur über HTTPS frei, und der Jarvis-Kern
lässt Geräte im WLAN nur zusehen. Dieser Server läuft im Jarvis-Prozess auf Port 8443 mit einem
selbst erzeugten Zertifikat und eigenem Schlüssel (steckt im QR-Code). Das Handy schickt den erkannten
Text, Jarvis arbeitet am Mac damit und die Antwort wird am Handy angezeigt und vorgelesen.
"""

from __future__ import annotations

import json
import secrets
import ssl
import subprocess
import sys
import threading
import time
import types
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

BESCHREIBUNG = "iPhone als Mikrofon: Lukas spricht über eine Seite im WLAN mit Jarvis, die Antwort kommt am Handy"
PROMPT = (
    "Lukas kann auch übers iPhone mit dir sprechen (Seite im WLAN). Will er das einrichten oder den QR-Code sehen, "
    "nutze handy_mikro_zeigen. Antworten aufs Handy sind wie immer kurz und zum Vorlesen."
)

DATEN = Path(__file__).parent / "daten"
SCHLUESSEL = DATEN / "handy_mikro_schluessel.txt"
CERT = DATEN / "handy_mikro_cert.pem"
KEY = DATEN / "handy_mikro_key.pem"
CERT_INFO = DATEN / "handy_mikro_cert.json"
COOKIE = "jarvis_mikro"
PORTS = range(8443, 8450)
MAX_TOENE = 6

# Bleibt über das Neuladen der Datei hinweg bestehen, damit nie zwei Server laufen
_halter = sys.modules.setdefault("_jarvis_handy_mikro_halter", types.ModuleType("_jarvis_handy_mikro_halter"))
for _name, _wert in (("server", None), ("port", None), ("fehler", ""), ("verlauf", []), ("toene", {}),
                     ("letzte", None), ("zeigen", 0.0), ("lock", threading.Lock()),
                     ("startlock", threading.Lock())):
    if not hasattr(_halter, _name):
        setattr(_halter, _name, _wert)


# ---------- Schlüssel, Zertifikat, Adresse ----------

def _schluessel() -> str:
    try:
        wert = SCHLUESSEL.read_text().strip()
        if len(wert) >= 20:
            return wert
    except OSError:
        pass
    DATEN.mkdir(parents=True, exist_ok=True)
    wert = secrets.token_urlsafe(24)
    SCHLUESSEL.write_text(wert + "\n")
    SCHLUESSEL.chmod(0o600)
    return wert


def _lan_ip() -> str | None:
    from backend import anzeige
    return anzeige.lan_ip()


def _zertifikat(ip: str) -> None:
    """Selbst signiertes Zertifikat für die WLAN-Adresse des Macs; neu, wenn sich die Adresse ändert."""
    try:
        if json.loads(CERT_INFO.read_text()).get("ip") == ip and CERT.exists() and KEY.exists():
            return
    except Exception:
        pass
    DATEN.mkdir(parents=True, exist_ok=True)
    cfg = DATEN / "handy_mikro_openssl.cnf"
    cfg.write_text(
        "[req]\ndistinguished_name=dn\nprompt=no\n[dn]\nCN=Jarvis\n"
        f"[v3]\nsubjectAltName=IP:{ip}\nbasicConstraints=CA:FALSE\n"
        "keyUsage=digitalSignature,keyEncipherment\nextendedKeyUsage=serverAuth\n"
    )
    subprocess.run(
        ["/usr/bin/openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes", "-sha256", "-days", "825",
         "-keyout", str(KEY), "-out", str(CERT), "-config", str(cfg), "-extensions", "v3"],
        check=True, capture_output=True, timeout=30,
    )
    KEY.chmod(0o600)
    CERT_INFO.write_text(json.dumps({"ip": ip}))


def _url() -> str | None:
    ip = _lan_ip()
    if not ip or not _halter.port:
        return None
    return f"https://{ip}:{_halter.port}/?k={_schluessel()}"


# ---------- Jarvis fragen ----------

def _frage(text: str) -> dict:
    from backend.claude_agent import friendly_error, run_agent
    from backend.tts import synthesize_speech

    with _halter.lock:
        verlauf = list(_halter.verlauf)
    try:
        antwort, verlauf = run_agent(text, verlauf, [])
    except Exception as exc:
        print(f"Handy-Mikro: Fehler bei Claude: {exc!r}", flush=True)
        antwort = friendly_error(exc)
    with _halter.lock:
        _halter.verlauf = verlauf
        _halter.letzte = {"frage": text, "antwort": antwort, "zeit": time.time()}

    ton = None
    try:
        audio = synthesize_speech(antwort)
    except Exception as exc:
        print(f"Handy-Mikro: Vorlesen ging nicht: {exc!r}", flush=True)
        audio = None
    if audio:
        ton = secrets.token_urlsafe(9)
        with _halter.lock:
            _halter.toene[ton] = audio
            while len(_halter.toene) > MAX_TOENE:
                _halter.toene.pop(next(iter(_halter.toene)))
    return {"antwort": antwort, "ton": ton}


# ---------- Der kleine HTTPS-Server ----------

class _Handler(BaseHTTPRequestHandler):
    server_version = "Jarvis"

    def setup(self):
        self.request.settimeout(30)
        self.request.do_handshake()  # erst hier, damit ein abgelehntes Zertifikat den Server nicht aufhält
        super().setup()

    def log_message(self, *args):
        pass

    def _erlaubt(self) -> tuple[bool, bool]:
        """(Schlüssel stimmt, kam aus dem QR-Code-Link)"""
        erwartet = _schluessel()
        aus_link = (parse_qs(urlparse(self.path).query).get("k") or [""])[0]
        if aus_link and secrets.compare_digest(aus_link, erwartet):
            return True, True
        jar = SimpleCookie()
        try:
            jar.load(self.headers.get("Cookie", ""))
        except Exception:
            return False, False
        keks = jar[COOKIE].value if COOKIE in jar else ""
        return bool(keks) and secrets.compare_digest(keks, erwartet), False

    def _senden(self, status: int, body: bytes, typ: str, keks: bool = False):
        self.send_response(status)
        self.send_header("Content-Type", typ)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        if keks:
            self.send_header("Set-Cookie", f"{COOKIE}={_schluessel()}; Max-Age=31536000; Path=/; "
                                           "HttpOnly; Secure; SameSite=Strict")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, daten: dict, status: int = 200):
        self._senden(status, json.dumps(daten, ensure_ascii=False).encode(), "application/json; charset=utf-8")

    def do_GET(self):
        ok, aus_link = self._erlaubt()
        pfad = urlparse(self.path).path
        if not ok:
            return self._senden(403, GESPERRT.encode(), "text/html; charset=utf-8")
        if pfad == "/":
            return self._senden(200, SEITE.encode(), "text/html; charset=utf-8", keks=aus_link)
        if pfad.startswith("/ton/"):
            with _halter.lock:
                audio = _halter.toene.get(pfad[5:])
            if not audio:
                return self._senden(404, b"", "text/plain")
            return self._senden(200, audio[0], audio[1])
        self._senden(404, b"", "text/plain")

    def do_POST(self):
        ok, _ = self._erlaubt()
        if not ok:
            return self._json({"fehler": "nicht freigegeben"}, 403)
        laenge = min(int(self.headers.get("Content-Length") or 0), 20000)
        try:
            daten = json.loads(self.rfile.read(laenge) or b"{}")
        except ValueError:
            daten = {}
        pfad = urlparse(self.path).path
        if pfad == "/frage":
            text = str(daten.get("text") or "").strip()[:2000]
            if not text:
                return self._json({"fehler": "Kein Text"}, 400)
            pause = sys.modules.get("_jarvis_zuhoeren_pause_halter")
            if pause is not None and getattr(pause, "pausiert", False):
                return self._json({"antwort": "Jarvis ist gerade pausiert. Einschalten geht mit dem Knopf "
                                              "im Jarvis-Fenster am Mac.", "ton": None})
            return self._json(_frage(text))
        if pfad == "/neu":
            with _halter.lock:
                _halter.verlauf = []
            return self._json({"ok": True})
        self._json({"fehler": "unbekannt"}, 404)


class _Server(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def handle_error(self, request, client_address):
        pass  # z. B. das iPhone lehnt beim ersten Mal das Zertifikat ab: kein Grund für eine Fehlermeldung


def _starten():
    with _halter.startlock:
        server = _einrichten()
    if server is not None:
        server.serve_forever(poll_interval=0.5)


def _einrichten():
    alt = _halter.server
    if alt is not None:
        alt.shutdown()
        alt.server_close()
        _halter.server = None
    try:
        from backend.config import settings
        if settings.host in ("127.0.0.1", "localhost"):
            _halter.fehler = "Jarvis ist nur am Mac erreichbar (JARVIS_HOST in .env), deshalb geht das Handy-Mikro nicht."
            return
        ip = _lan_ip()
        if not ip:
            _halter.fehler = "Der Mac ist in keinem WLAN. Verbinde ihn und das iPhone mit demselben WLAN."
            return
        _zertifikat(ip)
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.load_cert_chain(str(CERT), str(KEY))
        server = None
        for port in ([_halter.port] if _halter.port else []) + list(PORTS):
            try:
                server = _Server(("0.0.0.0", port), _Handler)
                break
            except OSError:
                continue
        if server is None:
            _halter.fehler = "Kein freier Anschluss für das Handy-Mikro gefunden."
            return
        server.socket = ctx.wrap_socket(server.socket, server_side=True, do_handshake_on_connect=False)
        _halter.server, _halter.port, _halter.fehler = server, server.server_address[1], ""
        return server
    except Exception as exc:
        _halter.fehler = f"Handy-Mikro konnte nicht starten: {exc}"
        print(_halter.fehler, flush=True)
    return None


# Nur im laufenden Jarvis starten, nicht bei der Prüfung mit python -m backend.eigene
if not sys.argv[0].endswith("eigene.py"):
    threading.Thread(target=_starten, name="handy-mikro", daemon=True).start()


# ---------- Für Jarvis und das Jarvis-Fenster ----------

TOOLS = [{
    "name": "handy_mikro_zeigen",
    "description": "Zeigt im Jarvis-Fenster am Mac den QR-Code, mit dem Lukas das iPhone als Mikrofon für Jarvis verbindet.",
    "input_schema": {"type": "object", "properties": {}, "required": []},
}]


def handy_mikro_zeigen() -> str:
    _halter.zeigen = time.time()
    if _halter.fehler:
        return _halter.fehler
    return "Der QR-Code ist im Jarvis-Fenster. Mit der iPhone-Kamera scannen und in Safari öffnen."


def stand() -> dict:
    url = None if _halter.fehler else _url()
    qr = None
    if url:
        from backend import anzeige
        qr = anzeige.qr_svg(url)
    text = _halter.fehler or ("" if url else "Das Handy-Mikro startet gerade, gleich nochmal versuchen.")
    return {"url": url, "qr": qr, "text": text, "letzte": _halter.letzte}


def offen() -> dict:
    return {"zeigen": _halter.zeigen}


API = {"stand": stand, "offen": offen}


GESPERRT = """<!DOCTYPE html><html lang="de"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>Jarvis</title></head>
<body style="background:#0a0e17;color:#e6ecff;font-family:-apple-system,sans-serif;display:grid;place-items:center;
min-height:100vh;margin:0;padding:16px;text-align:center"><div><h2 style="color:#5ec8ff">Jarvis</h2>
<p>Dieses Gerät ist nicht freigegeben.</p><p>Am Mac im Jarvis-Fenster auf <b>Handy-Mikro</b> klicken
und den QR-Code mit dem iPhone scannen.</p></div></body></html>"""


SEITE = r"""<!DOCTYPE html>
<html lang="de"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#0a0e17"><title>Jarvis</title>
<style>
:root{--bg:#0a0e17;--panel:#121826;--text:#e6ecff;--muted:#7c88a8;--hud:#5ec8ff;--listen:#e0405f;--think:#b06bf0;--speak:#35c98f}
*{box-sizing:border-box}
html,body{margin:0;height:100%}
body{background:radial-gradient(circle at 50% 20%,#16203a 0%,var(--bg) 70%) fixed;color:var(--text);
font-family:-apple-system,BlinkMacSystemFont,sans-serif;display:flex;flex-direction:column;
padding:env(safe-area-inset-top) 16px calc(12px + env(safe-area-inset-bottom))}
h1{margin:18px 0 0;text-align:center;font-size:13px;letter-spacing:.4em;color:var(--hud);font-weight:600}
.mitte{display:flex;flex-direction:column;align-items:center;gap:14px;padding:22px 0 10px}
#knopf{width:148px;height:148px;border-radius:50%;border:2px solid var(--hud);background:rgba(94,200,255,.08);
color:var(--hud);display:grid;place-items:center;box-shadow:0 0 40px rgba(94,200,255,.25);transition:all .25s;
-webkit-tap-highlight-color:transparent}
#knopf svg{width:56px;height:56px}
#knopf.listening{border-color:var(--listen);color:var(--listen);box-shadow:0 0 60px rgba(224,64,95,.5);animation:puls 1.2s infinite}
#knopf.thinking{border-color:var(--think);color:var(--think);box-shadow:0 0 50px rgba(176,107,240,.45)}
#knopf.speaking{border-color:var(--speak);color:var(--speak);box-shadow:0 0 50px rgba(53,201,143,.45)}
@keyframes puls{50%{transform:scale(1.05)}}
#status{font-size:15px;color:var(--muted);min-height:1.3em;text-align:center}
#log{flex:1;overflow-y:auto;display:flex;flex-direction:column;gap:8px;padding:6px 0}
.m{max-width:88%;padding:9px 12px;border-radius:14px;font-size:15px;line-height:1.4;white-space:pre-wrap}
.du{align-self:flex-end;background:rgba(94,200,255,.15)}
.er{align-self:flex-start;background:var(--panel);border:1px solid rgba(94,200,255,.2)}
.hinweis{font-size:13px;color:var(--muted);text-align:center;margin:0 10px}
form{display:flex;gap:8px;margin-top:8px}
input{flex:1;min-width:0;padding:12px 14px;border-radius:999px;border:1px solid rgba(94,200,255,.35);
background:rgba(10,14,23,.7);color:var(--text);font-size:16px;outline:none}
button.klein{padding:0 16px;border-radius:999px;border:1px solid rgba(94,200,255,.45);background:transparent;color:var(--hud);font-size:15px}
</style></head>
<body>
<h1>J.A.R.V.I.S.</h1>
<div class="mitte">
  <button id="knopf" type="button" aria-label="Sprechen"><svg viewBox="0 0 24 24" fill="currentColor">
  <path d="M12 14a3 3 0 0 0 3-3V6a3 3 0 0 0-6 0v5a3 3 0 0 0 3 3z"/>
  <path d="M19 11a1 1 0 1 0-2 0 5 5 0 0 1-10 0 1 1 0 1 0-2 0 7 7 0 0 0 6 6.92V20H9a1 1 0 1 0 0 2h6a1 1 0 1 0 0-2h-2v-2.08A7 7 0 0 0 19 11z"/></svg></button>
  <div id="status">Tippen und sprechen</div>
</div>
<div id="log"></div>
<p id="hinweis" class="hinweis"></p>
<form id="form" autocomplete="off">
  <input id="feld" type="text" placeholder="Oder hier tippen bzw. diktieren …" enterkeyhint="send">
  <button class="klein" type="submit">Senden</button>
</form>
<script>
if (location.search) history.replaceState(null, "", "/");
const knopf = document.getElementById("knopf"), statusEl = document.getElementById("status");
const log = document.getElementById("log"), feld = document.getElementById("feld"), hinweis = document.getElementById("hinweis");
const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
const spracheOk = !!SR && window.isSecureContext;
if (!spracheOk) hinweis.textContent = "Tipp: Ins Feld tippen und auf der Tastatur das Mikrofon drücken.";

let zustand = "idle", rec = null, beschaeftigt = false;
const player = new Audio();
player.playsInline = true;
let freigeschaltet = false;

function stille() {  // kurzer leiser Ton: schaltet am iPhone das Abspielen frei
  const n = 400, b = new ArrayBuffer(44 + n * 2), v = new DataView(b);
  const w = (o, s) => [...s].forEach((c, i) => v.setUint8(o + i, c.charCodeAt(0)));
  w(0, "RIFF"); v.setUint32(4, 36 + n * 2, true); w(8, "WAVE"); w(12, "fmt "); v.setUint32(16, 16, true);
  v.setUint16(20, 1, true); v.setUint16(22, 1, true); v.setUint32(24, 8000, true); v.setUint32(28, 16000, true);
  v.setUint16(32, 2, true); v.setUint16(34, 16, true); w(36, "data"); v.setUint32(40, n * 2, true);
  return URL.createObjectURL(new Blob([b], { type: "audio/wav" }));
}
function freischalten() {
  if (freigeschaltet) return;
  player.src = stille();
  player.play().then(() => { freigeschaltet = true; }).catch(() => {});
}

function setze(z, text) {
  zustand = z;
  knopf.className = z;
  statusEl.textContent = text || { idle: "Tippen und sprechen", listening: "Ich höre zu …",
    thinking: "Jarvis denkt nach …", speaking: "Jarvis spricht (tippen zum Stoppen)" }[z];
}
function zeige(wer, text) {
  const d = document.createElement("div");
  d.className = "m " + wer;
  d.textContent = text;
  log.append(d);
  while (log.children.length > 20) log.firstChild.remove();
  log.scrollTop = log.scrollHeight;
}

async function senden(text) {
  if (!text || beschaeftigt) return;
  beschaeftigt = true;
  feld.value = "";
  zeige("du", text);
  setze("thinking");
  try {
    const r = await fetch("/frage", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text }) });
    const d = await r.json();
    if (!r.ok) throw new Error(d.fehler || r.status);
    zeige("er", d.antwort);
    if (d.ton) {
      player.src = "/ton/" + d.ton;
      setze("speaking");
      try { await player.play(); } catch { setze("idle"); }
    } else setze("idle");
  } catch (e) {
    zeige("er", "Jarvis ist gerade nicht erreichbar. Läuft er am Mac und ist das iPhone im selben WLAN?");
    setze("idle");
  } finally {
    beschaeftigt = false;
  }
}
player.addEventListener("ended", () => { if (zustand === "speaking") setze("idle"); });

function zuhoeren() {
  if (!spracheOk) { feld.focus(); return; }
  rec = new SR();
  rec.lang = "de-DE";
  rec.interimResults = true;
  rec.continuous = true;  // nicht bei der ersten Pause aufhören, das entscheidet der Zeitgeber unten
  let text = "", ruhe = null;
  rec.onresult = (e) => {
    text = [...e.results].map((r) => r[0].transcript).join("");
    statusEl.textContent = text;
    clearTimeout(ruhe);
    ruhe = setTimeout(() => rec && rec.stop(), 2500);  // erst nach längerer Pause ist der Satz fertig
  };
  rec.onerror = (e) => {
    if (e.error === "not-allowed" || e.error === "service-not-allowed")
      hinweis.textContent = "Mikrofon oder Diktieren ist nicht erlaubt. Einstellungen > Safari > Mikrofon, und Diktieren unter Allgemein > Tastaturen einschalten. Solange: ins Feld tippen und diktieren.";
  };
  rec.onend = () => {
    clearTimeout(ruhe);
    rec = null;
    setze("idle");
    if (text.trim()) senden(text.trim());
  };
  try { rec.start(); setze("listening"); } catch { rec = null; feld.focus(); }
}

knopf.addEventListener("click", () => {
  freischalten();
  if (zustand === "speaking") { player.pause(); setze("idle"); return; }
  if (zustand === "listening") { rec && rec.stop(); return; }
  if (zustand === "thinking") return;
  zuhoeren();
});
document.getElementById("form").addEventListener("submit", (e) => {
  e.preventDefault();
  freischalten();
  senden(feld.value.trim());
});
</script>
</body></html>"""
