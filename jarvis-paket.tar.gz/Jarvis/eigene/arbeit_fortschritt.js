// Fortschritt im Arbeitsfenster: ungefährer Ladebalken je Claude-Code-Auftrag, grüner Rahmen, wenn er fertig ist.
// Eine echte Prozentzahl liefert Claude Code nicht. Geschätzt wird aus Laufzeit und Anzahl der Schritte,
// verglichen mit früheren Aufträgen (im Browser gemerkt). Die Anzeige bleibt bis zum Ende unter 95 % und geht nie zurück.
(() => {
  if (typeof renderJob !== "function" || typeof jobs === "undefined" || window.__jarvisFortschritt) return;
  window.__jarvisFortschritt = true;

  const SPEICHER = "jarvis-auftraege";
  const STANDARD = { schritte: 25, sekunden: 360 };  // ohne Erfahrung: etwa 25 Schritte, 6 Minuten
  const stand = new Map();  // Projekt -> { auftrag, start, prozent, fertig, live }
  const geladen = Date.now();

  function erfahrung() {
    try {
      const alle = JSON.parse(localStorage.getItem(SPEICHER) || "[]").slice(-12);
      if (alle.length < 2) return STANDARD;
      const median = (werte) => { const s = [...werte].sort((a, b) => a - b); return s[Math.floor(s.length / 2)]; };
      return { schritte: Math.max(5, median(alle.map((a) => a.schritte))), sekunden: Math.max(60, median(alle.map((a) => a.sekunden))) };
    } catch {
      return STANDARD;
    }
  }

  function merken(schritte, sekunden) {
    try {
      const alle = JSON.parse(localStorage.getItem(SPEICHER) || "[]");
      alle.push({ schritte, sekunden: Math.round(sekunden) });
      localStorage.setItem(SPEICHER, JSON.stringify(alle.slice(-20)));
    } catch {}
  }

  function zeilenDesAuftrags(job) {
    let ab = -1;
    job.lines.forEach((zeile, i) => { if (String(zeile).startsWith("Auftrag:")) ab = i; });
    return { auftrag: ab >= 0 ? job.lines[ab] : "", zeilen: job.lines.slice(ab + 1).filter((z) => z !== "Fertig") };
  }

  const dauer = (s) => (s < 60 ? `${Math.round(s)} s` : `${Math.floor(s / 60)} Min`);

  function anzeigen(project) {
    const job = jobs.get(project);
    if (!job || !job.el) return;
    const { auftrag, zeilen } = zeilenDesAuftrags(job);
    let st = stand.get(project);
    if (!st || st.auftrag !== auftrag || (st.fertig && job.running)) {
      // Lief der Auftrag schon, als das Fenster aufging: Startzeit grob zurückrechnen (etwa 12 s pro Schritt).
      // Kommt er neu dazu, zählt er ab jetzt und darf hinterher als Erfahrung gemerkt werden.
      const schonDa = Date.now() - geladen < 3000;
      st = { auftrag, start: Date.now() - (schonDa ? zeilen.length * 12000 : 0), prozent: 0, fertig: !job.running,
             live: !schonDa };
      stand.set(project, st);
    }
    const sekunden = (Date.now() - st.start) / 1000;
    const schritte = zeilen.length;

    if (!job.running) {
      if (!st.fertig && st.live) merken(schritte, sekunden);  // nur selbst miterlebte Aufträge lernen
      st.fertig = true;
      st.prozent = 100;
    } else {
      const e = erfahrung();
      const x = 0.55 * (schritte / e.schritte) + 0.45 * (sekunden / e.sekunden);
      let p = 100 * (1 - Math.exp(-1.8 * x));
      // Prüft Claude Code am Ende seine Arbeit, ist er meist kurz vor fertig
      if (zeilen.slice(-3).some((z) => /backend\.eigene|prüf|teste|test/i.test(z))) p = Math.max(p, 85);
      st.prozent = Math.max(st.prozent, Math.min(95, Math.max(3, p)));
      st.fertig = false;
    }

    let box = job.el.querySelector(".af-box");
    if (!box) {
      box = document.createElement("div");
      box.className = "af-box";
      box.innerHTML = '<div class="af-bar"><span></span></div><div class="af-text"></div>';
      job.el.querySelector(".job-head").after(box);
    }
    const prozent = Math.round(st.prozent);
    box.querySelector(".af-bar span").style.width = prozent + "%";
    box.querySelector(".af-text").textContent = st.fertig
      ? `Fertig · ${schritte} Schritte`
      : `ca. ${prozent} % (geschätzt) · ${dauer(sekunden)} · ${schritte} Schritte`;
    box.title = st.fertig ? "" : "Ungefähre Schätzung aus Laufzeit und Schritten im Vergleich zu früheren Aufträgen";
    job.el.classList.toggle("af-fertig", st.fertig);
  }

  const original = renderJob;
  renderJob = function (project) {
    const ergebnis = original.apply(this, arguments);
    anzeigen(project);
    return ergebnis;
  };

  // Schon vorhandene Aufträge gleich ausstatten, laufende jede Sekunde weiterschätzen (Zeit läuft auch ohne neue Schritte)
  for (const project of jobs.keys()) anzeigen(project);
  setInterval(() => {
    for (const [project, job] of jobs) if (job.running) anzeigen(project);
  }, 1000);
})();
