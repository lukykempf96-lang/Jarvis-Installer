// Eingang-Liste im Feld Dateien: jede eingefügte oder reingezogene Datei mit X zum Löschen.
(() => {
  const panel = document.querySelector(".files-panel");
  if (!panel || document.getElementById("el-liste")) return;

  const kopf = document.createElement("div");
  kopf.className = "el-kopf";
  kopf.innerHTML = '<span>Im Eingang</span><span id="el-anzahl" class="meta"></span>';
  const ul = document.createElement("ul");
  ul.id = "el-liste";
  ul.className = "el-liste";
  const drops = document.getElementById("drops");
  (drops || panel.querySelector("#dropzone")).after(kopf, ul);

  let letzte = "";

  function zeigen(d) {
    const schluessel = JSON.stringify(d.dateien.map((f) => f.pfad)) + d.gesamt;
    if (schluessel === letzte) return;
    letzte = schluessel;
    document.getElementById("el-anzahl").textContent =
      d.gesamt > d.dateien.length ? `${d.dateien.length} von ${d.gesamt}` : d.gesamt ? String(d.gesamt) : "";
    kopf.hidden = !d.gesamt;
    ul.replaceChildren(...d.dateien.map((f) => {
      const li = document.createElement("li");
      const name = document.createElement("span");
      name.className = "el-name";
      name.textContent = f.name;
      name.title = `eingang/${f.pfad}`;
      const info = document.createElement("span");
      info.className = "el-info";
      info.textContent = `${f.wann} · ${f.groesse}`;
      const x = document.createElement("button");
      x.type = "button";
      x.className = "el-x";
      x.textContent = "✕";
      x.title = "Aus der Liste entfernen und aus dem Eingang löschen";
      x.addEventListener("click", () => loeschen(f, li));
      li.append(name, info, x);
      return li;
    }));
  }

  async function laden() {
    try {
      zeigen(await fetch("/api/eigene/eingang_liste/liste").then((r) => r.json()));
    } catch {}
  }

  async function loeschen(f, li) {
    li.classList.add("el-weg");
    try {
      const d = await fetch("/api/eigene/eingang_liste/loeschen", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ pfad: f.pfad }),
      }).then((r) => r.json());
      if (d.fehler) li.classList.remove("el-weg");
      letzte = "";
      zeigen(d);
    } catch {
      li.classList.remove("el-weg");
    }
  }

  // Nach Reinziehen oder Einfügen gleich und dann noch ein paar Mal nachsehen (Hochladen dauert etwas)
  const bald = () => [300, 1500, 4000, 10000].forEach((ms) => setTimeout(laden, ms));
  addEventListener("drop", bald);
  addEventListener("paste", bald);
  document.getElementById("picker")?.addEventListener("change", bald);
  laden();
  setInterval(() => { if (!document.hidden) laden(); }, 15000);
})();
