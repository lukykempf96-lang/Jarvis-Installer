# Wünsche an den Jarvis-Kern (brauchen ein Jarvis-Update)

## Mail-Abruf fürs Dashboard: AppleScript-Fehler „'rd' gefunden“ (-2741)
- `backend/alltag.py`, `fetch_mail_headers`: Die Variable `rd` (`set rd to read status of …`) ist in AppleScript
  reserviert (Ordnungszahl „3rd“), das Skript lässt sich nicht übersetzen. Variable umbenennen, z. B. `msgRead`.
- Dabei gleich: `missing value` bei Betreff/Absender abfangen und den Mail-Teil in `with timeout of 60 seconds` setzen.
- Bis dahin repariert `eigene/mail_reparatur.py` das im laufenden Jarvis; nach dem Update kann die Datei weg.
