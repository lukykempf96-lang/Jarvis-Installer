// Zuhören pausieren: Schalter unter dem Mikrofon-Knopf. Pausiert hört Jarvis nicht zu und antwortet nicht.
// Ausschalten per Knopf oder Sprache ("hör auf zuzuhören"), einschalten nur per Knopf.
(() => {
  if (typeof startListening !== "function" || window.__jarvisPause) return;
  window.__jarvisPause = true;

  const talk = document.getElementById("talk-btn");
  const orbWrap = document.querySelector(".orb-wrap");
  let paused = false;

  // Schalter und Hinweis ins Fenster
  const btn = document.createElement("button");
  btn.id = "jp-btn";
  btn.type = "button";
  btn.className = "jp-btn";
  btn.innerHTML = '<span class="jp-dot"></span><span class="jp-text"></span>';
  (talk || document.querySelector(".center")).after(btn);
  const banner = document.createElement("div");
  banner.className = "jp-banner";
  banner.textContent = "Pausiert · Jarvis hört nicht zu";
  if (orbWrap) orbWrap.append(banner);

  function zeigen() {
    document.body.classList.toggle("jp-paused", paused);
    btn.querySelector(".jp-text").textContent = paused ? "Pausiert · Klicken zum Einschalten" : "Hört zu · Klicken zum Pausieren";
    btn.title = paused ? "Jarvis wieder zuhören lassen" : "Jarvis stumm schalten (z. B. beim Videoschnitt)";
    if (paused && typeof currentState !== "undefined" && currentState === "idle") statusEl.textContent = "Pausiert";
  }

  function anhalten() {
    // Gespräch beenden, laufendes Zuhören abbrechen, laufende Antwort stoppen
    try { conversation = false; } catch {}
    try { if (listening && recognition) recognition.abort(); } catch {}
    try {
      if (currentState === "speaking") fetch("/api/stop", { method: "POST" }).catch(() => {});
    } catch {}
    if (window.speechSynthesis) speechSynthesis.cancel();
  }

  function uebernehmen(state) {
    const neu = !!state.pausiert;
    if (neu === paused) return;
    paused = neu;
    if (paused) anhalten();
    else if (typeof currentState !== "undefined" && currentState === "idle") statusEl.textContent = "Bereit";
    zeigen();
  }

  // Jeder Weg zum Zuhören läuft über startListening (Knopf, Gesprächsmodus, Klatschen, "Hey Jarvis")
  const originalStart = startListening;
  startListening = function () {
    if (paused) {
      try { conversation = false; } catch {}
      return;
    }
    return originalStart.apply(this, arguments);
  };

  // Mikrofon-Knopf tut pausiert nichts, nur kurzer Hinweis
  if (talk) {
    talk.addEventListener("click", (e) => {
      if (!paused) return;
      e.stopImmediatePropagation();
      btn.classList.remove("jp-flash");
      void btn.offsetWidth;
      btn.classList.add("jp-flash");
    }, true);
  }

  btn.addEventListener("click", async () => {
    const wanted = !paused;
    uebernehmen({ pausiert: wanted });  // sofort zeigen, der Server bestätigt
    try {
      const d = await fetch("/api/eigene/zuhoeren_pause/setzen", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ pausiert: wanted }),
      }).then((r) => r.json());
      uebernehmen(d);
    } catch {}
  });

  // Pausiert per Sprache (Tool im Server): hier sofort übernehmen
  async function abgleichen() {
    try {
      uebernehmen(await fetch("/api/eigene/zuhoeren_pause/stand").then((r) => r.json()));
    } catch {}
  }
  zeigen();
  abgleichen();
  setInterval(abgleichen, 1000);
})();
