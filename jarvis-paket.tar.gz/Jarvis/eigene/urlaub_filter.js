// Termine im Dashboard aktuell halten: alle 30 Sekunden neu laden (der Server liest den Kalender dann frisch).
(() => {
  if (typeof loadDashboard !== "function" || window.__jarvisUrlaubFilter) return;
  window.__jarvisUrlaubFilter = true;
  loadDashboard();  // gleich einmal, damit Urlaub sofort verschwindet
  setInterval(() => {
    if (!document.hidden) loadDashboard();
  }, 30000);
})();
