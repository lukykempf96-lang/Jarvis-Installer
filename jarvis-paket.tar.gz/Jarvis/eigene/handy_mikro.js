// Handy-Mikro: QR-Code, mit dem Lukas das iPhone als Mikrofon für Jarvis verbindet.
(() => {
  const actions = document.querySelector(".sys-panel .head-actions");
  if (!actions || document.getElementById("hm-btn")) return;

  const btn = document.createElement("button");
  btn.id = "hm-btn";
  btn.className = "icon-btn";
  btn.type = "button";
  btn.title = "Mit dem iPhone zu Jarvis sprechen";
  btn.textContent = "Handy-Mikro";
  actions.append(btn);

  const dialog = document.createElement("dialog");
  dialog.className = "prio-dialog display-dialog";
  dialog.innerHTML = `
    <form method="dialog">
      <h3>iPhone als Mikrofon</h3>
      <div class="display-qr hm-qr"></div>
      <ol class="display-steps">
        <li>iPhone ins selbe WLAN wie den Mac.</li>
        <li>QR-Code mit der Kamera scannen und in Safari öffnen.</li>
        <li>Nur beim ersten Mal: Bei „Diese Verbindung ist nicht privat“ auf „Details einblenden“, dann „diese Website besuchen“ und bestätigen. Das Zertifikat kommt von deinem Mac.</li>
        <li>Auf den runden Knopf tippen, Mikrofon erlauben und sprechen. Die Antwort kommt am Handy.</li>
      </ol>
      <p class="hint hm-last"></p>
      <div class="dialog-actions"><button value="close" class="small-btn primary" type="submit">Fertig</button></div>
    </form>`;
  document.body.append(dialog);
  const qrBox = dialog.querySelector(".hm-qr");
  const last = dialog.querySelector(".hm-last");

  async function oeffnen() {
    qrBox.replaceChildren();
    last.textContent = "";
    if (!dialog.open) dialog.showModal();
    const info = await fetch("/api/eigene/handy_mikro/stand").then((r) => r.json()).catch(() => null);
    if (!info || !info.url) {
      const p = document.createElement("p");
      p.className = "hint";
      p.textContent = info ? info.text : "Der Jarvis-Server ist nicht erreichbar.";
      qrBox.append(p);
      return;
    }
    if (info.qr) {
      const img = document.createElement("img");
      img.alt = "QR-Code für das Handy-Mikro";
      img.src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(info.qr);
      qrBox.append(img);
    }
    if (info.letzte) last.textContent = `Zuletzt vom iPhone: „${info.letzte.frage}“`;
  }

  btn.addEventListener("click", oeffnen);
  addEventListener("jarvis-home", () => dialog.open && dialog.close());

  // Sagt Lukas "Zeig den QR-Code fürs Handy-Mikro", öffnet Jarvis den Dialog von selbst
  let seen = null;
  setInterval(async () => {
    const d = await fetch("/api/eigene/handy_mikro/offen").then((r) => r.json()).catch(() => null);
    if (!d) return;
    if (seen !== null && d.zeigen > seen) oeffnen();
    seen = d.zeigen;
  }, 2000);
})();
