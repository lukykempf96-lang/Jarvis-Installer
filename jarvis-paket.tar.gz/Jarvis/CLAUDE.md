# Jarvis baut sich selbst aus

Du arbeitest im Ordner von Jarvis, dem Sprachassistenten von Lukas (macOS, Python 3.9, FastAPI-Backend, Chrome-Fenster).
Meist kommt der Auftrag per Sprache über Jarvis. Lukas ist kein Programmierer. Deine Schlussantwort wird ihm vorgelesen.

## Die wichtigste Regel: Neues nur in `eigene/`

- Neue Funktionen baust du **nur im Ordner `eigene/`**. Den Kern (`backend/`, `frontend/`, `install.sh`, `update.sh`,
  `.claude/`, diese Datei) änderst du nicht. Er kommt als Update aus Lukas' Claude-Projekt und wird dabei jedes Mal
  überschrieben. `eigene/` fasst kein Update an. Das Ändern des Kerns ist dir per Einstellung ohnehin gesperrt.
- Geht ein Wunsch nur mit einer Änderung am Kern (z. B. den Start ändern, eine neue Gehirn-Form), dann bau nichts
  Halbes. Schreib den Wunsch in `eigene/WUENSCHE.md` und sag Lukas: „Das braucht ein Jarvis-Update, sag es Claude im
  Projekt.“ Aussehen lässt sich aber oft mit einer CSS-Datei in `eigene/` überschreiben, und Farben, Punkte und
  Sterne des Gehirns stellst du mit `eigene/gehirn.js` ein (siehe unten).
- `.env` (Schlüssel) liest und änderst du nie. Braucht ein Dienst einen Schlüssel, lies ihn in Python mit
  `os.environ.get("NAME")` und sag Lukas, dass er ihn selbst in `.env` eintragen muss. Schreib nie Schlüssel in Dateien.
- Keine neuen Pakete installieren. Vorhanden: Standardbibliothek, `httpx`, `psutil`, `numpy`, `anthropic`, `qrcode`.

## Das kann Jarvis schon (nicht nachbauen)

Wetter, Internet-Suche, Mails, Nachrichten, Kalender lesen, Termine eintragen, verschieben und löschen, Erinnerungen und Listen wie die Einkaufsliste, Kontakte zeigen, anrufen, Websites und Programme öffnen, Routen, Mitteilungen aufs iPhone, Haushaltsbuch, Dateien lesen, Bildschirm ansehen. Wünscht Lukas dazu etwas anders, als es der Kern macht, schreib es in `eigene/WUENSCHE.md` und sag ihm, dass es ein Jarvis-Update braucht.

## So sieht eine eigene Funktion aus

Eine Datei `eigene/<name>.py` (Name nur aus Buchstaben, Ziffern, `_`). Jarvis lädt sie selbst, ohne Neustart.

```python
from __future__ import annotations  # Python 3.9: kein match, kein X | Y außerhalb von Typangaben

import random

BESCHREIBUNG = "Würfeln mit beliebig vielen Würfeln"            # Pflicht: steht in Jarvis' Anweisungen
PROMPT = "Will Lukas würfeln, nutze wuerfeln und sag nur das Ergebnis."  # optional: wann und wie benutzen

TOOLS = [{
    "name": "wuerfeln",                                        # eindeutig, nicht wie ein Jarvis-Tool
    "description": "Würfelt. Gibt die Augenzahlen zurück.",
    "input_schema": {"type": "object", "properties": {
        "anzahl": {"type": "integer", "description": "Wie viele Würfel, Standard 1"}}, "required": []},
}]


def wuerfeln(anzahl: int = 1) -> str:                       # gleicher Name wie das Tool, Eingaben als Parameter
    augen = [random.randint(1, 6) for _ in range(max(1, min(anzahl, 10)))]
    return f"Gewürfelt: {', '.join(map(str, augen))}"         # kurzer deutscher Text (oder ein dict)
```

- Beim Laden nichts Langsames tun (kein Netz, keine Schleifen). Netzaufrufe mit `httpx` und `timeout=15`.
- Daten, die bleiben sollen, als JSON in `eigene/daten/` speichern (Ordner bei Bedarf anlegen).
- Vorhandenes darfst du benutzen, aber nicht ändern, z. B. `from backend.config import settings`
  (`settings.weather_city`), `from backend import handy` (`handy.send(titel, text)` schickt eine Mitteilung aufs iPhone).
- Ergebnisse, die vorgelesen werden: kurz, ohne Markdown, ohne Internetadressen.

## Etwas im Jarvis-Fenster zeigen

- `eigene/<name>.js` und `eigene/<name>.css` lädt das Jarvis-Fenster am Mac automatisch nach `app.js`.
  Ändern sie sich, lädt sich das Fenster neu, sobald Jarvis nichts zu tun hat.
- Daten aus Python holst du über `API = {"stand": funktion}` in der `.py`-Datei und im Browser mit
  `fetch("/api/eigene/<name>/stand")` (GET mit Parametern in der URL oder POST mit JSON). Die Funktion gibt ein dict zurück.
- Gehirn in der Mitte einstellen (`eigene/gehirn.js`), alle Angaben sind freiwillig:
  ```js
  window.JarvisBrain?.configure({
    palette: [[70, 200, 255], [160, 100, 255], [255, 80, 200]], // Farben der Lichtpunkte (RGB)
    nodes: 820,      // Punkte auf dem Gehirn (60 bis 4000)
    dust: 650,       // Sternenstaub im Inneren
    stars: 650,      // Sterne rundherum
    orbit: 180,      // Lichtteilchen auf der Umlaufbahn (0 = aus)
    colorMix: 0.2,   // wie stark die Zustandsfarbe (zuhören, denken, sprechen) die Punkte einfärbt, 0 bis 1
    nebula: 1,       // farbiger Nebel im Gehirn, 0 = aus
    shootingStars: true,
    speed: 1,        // Drehgeschwindigkeit
  });
  ```
  `JarvisBrain.config()` in der Browser-Konsole zeigt die aktuellen Werte. Viele Punkte kosten Leistung; ruckelt es,
  nimmt das Gehirn selbst weniger.
- Stil: dunkel, Farben aus `frontend/style.css` (`var(--hud)` = Cyan, `var(--panel)`, `var(--text)`, `var(--muted)`).
- Eigene Fenster schließen sich, wenn Lukas „danke“ sagt: `window.addEventListener("jarvis-home", schliessen)`.
- Keine Haushalts- oder Mail-Daten an die Anzeige im WLAN schicken (die lädt `eigene/` ohnehin nicht).

## Prüfen, bevor du fertig bist

```
venv/bin/python -m backend.eigene
```

Muss jede Datei mit `ok` zeigen und darf kein `FEHLER` melden. Sonst reparieren und nochmal prüfen.

## Entfernen und rückgängig machen

- Vor jedem Auftrag über Jarvis wird `eigene/` in `.eigene-sicherung/` gesichert.
- Eine Funktion löschen: `venv/bin/python -m backend.eigene --entfernen <name>`
- Den letzten Umbau rückgängig machen: `venv/bin/python -m backend.eigene --zurueck`

## Zum Schluss

Sag in höchstens drei kurzen Sätzen, was Jarvis jetzt neu kann und wie Lukas es auslöst
(z. B. „Sag einfach: Würfel mal zwei Würfel.“). Ging etwas nicht, sag ehrlich, was fehlt.
