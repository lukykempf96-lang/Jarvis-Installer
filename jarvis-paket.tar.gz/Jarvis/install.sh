#!/bin/bash
# Jarvis einrichten. Aufruf im Terminal im Jarvis-Ordner:  bash install.sh
set -e
cd "$(dirname "$0")"
DIR="$(pwd)"
echo "== Jarvis einrichten in $DIR =="

# 1. Python finden (Homebrew-Python bevorzugt)
PY=""
for c in python3.13 python3.12 python3.11 python3.10 python3; do
    if command -v "$c" >/dev/null 2>&1 && "$c" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)' 2>/dev/null; then
        PY="$(command -v "$c")"; break
    fi
done
[ -z "$PY" ] && { echo "Python 3 fehlt. Installiere es mit: xcode-select --install"; exit 1; }
echo "Python: $PY ($("$PY" --version))"

# 2. Pakete: beim Update das vorhandene venv behalten, sonst frisch anlegen
if [ "$1" = "--update" ] && venv/bin/python -c "import fastapi, anthropic, sounddevice, numpy, httpx, dotenv, playwright" 2>/dev/null; then
    echo "Vorhandene Pakete werden weiterverwendet."
    venv/bin/pip install -r backend/requirements.txt -q
else
    rm -rf venv
    "$PY" -m venv venv
    venv/bin/pip install --upgrade pip -q
    venv/bin/pip install -r backend/requirements.txt -q
    venv/bin/python -m playwright install chromium
fi
# Sprachmodell für „Hey Jarvis“ (einmalig, wenige MB)
venv/bin/python -c "import openwakeword.utils as u; u.download_models(['hey_jarvis'])" >/dev/null 2>&1 \
    || echo "Hinweis: Das Sprachmodell für „Hey Jarvis“ wird beim ersten Start geladen."

# Fahrzeiten über Apple Karten: kleines Hilfsprogramm einmal übersetzen (Xcode-Befehlszeilentools)
if command -v swiftc >/dev/null 2>&1; then
    venv/bin/python -c "from backend import karten; p = karten._ensure_helper(); print('Karten-Hilfe bereit.' if p is None else 'Hinweis: Fahrzeiten zeigt Jarvis in der Karten-App (' + p + ').')" 2>/dev/null \
        || echo "Hinweis: Fahrzeiten zeigt Jarvis in der Karten-App."
fi

# 3. .env: alten Stand vom Schreibtisch übernehmen oder neu anlegen
OLD_ENV="$HOME/Desktop/Claude Case/jarvis/.env"
if [ ! -f .env ] && [ -f "$OLD_ENV" ]; then
    cp "$OLD_ENV" .env
    echo ".env vom alten Ordner übernommen."
fi
if [ ! -f .env ]; then
    cp .env.example .env
    read -r -s -p "Anthropic-API-Schlüssel: " KEY; echo
    read -r -p "Stadt fürs Wetter [Aschaffenburg]: " CITY
    KEY="$KEY" CITY="${CITY:-Aschaffenburg}" venv/bin/python - <<'PYEOF'
import os, re
p = ".env"; s = open(p).read()
s = re.sub(r"^ANTHROPIC_API_KEY=.*$", "ANTHROPIC_API_KEY=" + os.environ["KEY"].strip(), s, flags=re.M)
s = re.sub(r"^JARVIS_CITY=.*$", "JARVIS_CITY=" + os.environ["CITY"].strip(), s, flags=re.M)
open(p, "w").write(s)
PYEOF
fi
# veraltete Modell-ID und englische Standardstimme ersetzen
sed -i '' 's/^CLAUDE_MODEL=claude-sonnet-5$/CLAUDE_MODEL=claude-sonnet-5-5/' .env
sed -i '' 's/^ELEVENLABS_VOICE_ID=21m00Tcm4TlvDq8ikWAM$/ELEVENLABS_VOICE_ID=rDmv3mOhK6TnhYWckFaD/' .env
# ElevenLabs-Schlüssel für die Stimme aus dem Video (optional)
if [ "$1" != "--update" ] && ! grep -q '^ELEVENLABS_API_KEY=..' .env; then
    echo
    echo "Für die Jarvis-Stimme aus dem Video brauchst du einen ElevenLabs-Schlüssel"
    echo "(elevenlabs.io → Profil → API Keys). Ohne Schlüssel einfach Enter drücken."
    read -r -s -p "ElevenLabs-Schlüssel: " EKEY; echo
    if [ -n "$EKEY" ]; then
        grep -v '^ELEVENLABS_API_KEY=' .env > .env.tmp || true
        echo "ELEVENLABS_API_KEY=$EKEY" >> .env.tmp
        mv .env.tmp .env
        grep -q '^ELEVENLABS_VOICE_ID=' .env || echo "ELEVENLABS_VOICE_ID=rDmv3mOhK6TnhYWckFaD" >> .env
        echo "ElevenLabs-Schlüssel gespeichert."
    fi
fi
chmod 600 .env

# 4. Startdatei zum Doppelklicken. Liegt ein Jarvis-Update in „Downloads“, spielt sie es vorher ein.
{ printf '#!/bin/bash\nJARVIS_DIR=%q\n' "$DIR"; cat <<'CMD'
cd "$JARVIS_DIR" || exit 1
# Nur Update-Pakete mit VERSION-Datei zaehlen (aeltere Pakete ohne werden ignoriert)
FOUND="$(ls -t "$HOME"/Downloads/Jarvis-Update-*/VERSION 2>/dev/null | head -1)"
ZIP="$(ls -t "$HOME"/Downloads/Jarvis-Update-*.zip 2>/dev/null | head -1)"
if [ -z "$FOUND" ] && [ -n "$ZIP" ]; then
    TMP="$(mktemp -d)"
    unzip -q "$ZIP" -d "$TMP" && rm -f "$ZIP"
    FOUND="$(ls "$TMP"/*/VERSION 2>/dev/null | head -1)"
fi
if [ -n "$FOUND" ] && [ -f "$(dirname "$FOUND")/update.sh" ]; then
    echo "Jarvis-Update gefunden, wird eingespielt ..."
    exec bash "$(dirname "$FOUND")/update.sh"
fi
venv/bin/python -m backend.clap_daemon
CMD
} > Jarvis.command
chmod +x Jarvis.command

# 4b. Neustart per Doppelklick: beendet einen haengenden Jarvis und startet ihn frisch
cat > "Jarvis neu starten.command" <<'CMD'
#!/bin/bash
cd "$(dirname "$0")" || exit 1
echo "Jarvis wird neu gestartet ..."
pkill -f backend.clap_daemon
pkill -f "uvicorn backend.main"
sleep 1
exec bash ./Jarvis.command
CMD
chmod +x "Jarvis neu starten.command"

# 5. Schlüssel per Doppelklick eintragen: liest den kopierten Schlüssel aus der Zwischenablage
cat > "Schlüssel eintragen.command" <<'CMD'
#!/bin/bash
# Erst den Schlüssel bei Anthropic oder ElevenLabs kopieren, dann diese Datei doppelklicken.
# Ist nichts Passendes kopiert, öffnet sich ein Fenster zum Einfügen.
cd "$(dirname "$0")"
erkenne() {
    case "$1" in
        sk-ant-*) NAME=ANTHROPIC_API_KEY; LABEL="Anthropic (Claude)" ;;
        sk_*) NAME=ELEVENLABS_API_KEY; LABEL="ElevenLabs (Stimme)" ;;
        *) [[ "$1" =~ ^[0-9a-f]{32}$ ]] || return 1
           NAME=ELEVENLABS_API_KEY; LABEL="ElevenLabs (Stimme)" ;;
    esac
}
K="$(pbpaste | tr -d '[:space:]')"
if ! erkenne "$K"; then
    K="$(osascript -e 'text returned of (display dialog "Schlüssel von Anthropic oder ElevenLabs einfügen (⌘ + V) und auf OK klicken:" default answer "" with hidden answer with title "Jarvis")' 2>/dev/null | tr -d '[:space:]')"
    if ! erkenne "$K"; then
        osascript -e 'display alert "Das war kein Schlüssel." message "Bitte den Schlüssel kopieren und diese Datei noch einmal doppelklicken."' >/dev/null 2>&1
        echo "Kein Schlüssel gespeichert."
        exit 1
    fi
fi
touch .env
grep -v "^$NAME=" .env > .env.tmp || true
echo "$NAME=$K" >> .env.tmp
mv .env.tmp .env
chmod 600 .env
pbcopy < /dev/null  # Zwischenablage leeren, damit der Schlüssel nirgends versehentlich landet
echo "$LABEL-Schlüssel gespeichert (endet auf ...$(printf '%s' "$K" | tail -c 4))."
echo "Jarvis wird neu gestartet ..."
osascript -e "display notification \"$LABEL-Schlüssel gespeichert. Jarvis startet neu.\" with title \"Jarvis\"" >/dev/null 2>&1
pkill -f "uvicorn backend.main"
pkill -f backend.clap_daemon
sleep 1
open Jarvis.command
CMD
chmod +x "Schlüssel eintragen.command"

echo
echo "Fertig. Doppelklick auf »Jarvis.command«, dann zweimal klatschen oder „Hey Jarvis“ sagen."
echo "macOS fragt beim ersten Mal nach dem Mikrofon: bitte erlauben."
