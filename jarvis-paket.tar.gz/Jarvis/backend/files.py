"""Dateien und Ordner fuer Jarvis: Reingezogenes speichern, Ordner finden, Inhalte lesen.

Jarvis liest PDFs, Bilder, Texte, Webseiten (HTML), Word, Excel und PowerPoint direkt
mit Claude. Alles bleibt auf dem Mac; nur der gelesene Inhalt geht an Claude.
"""
from __future__ import annotations

import base64
import os
import re
import shutil
import subprocess
import tempfile
import zipfile
from pathlib import Path

JARVIS_DIR = Path(__file__).resolve().parent.parent
INBOX = JARVIS_DIR / "eingang"
HOME = Path.home()

MAX_UPLOAD = 200 * 1024 * 1024
MAX_TEXT = 60000
MAX_PDF = 25 * 1024 * 1024
MAX_IMAGE = 3_500_000

SKIP_DIRS = {".git", "node_modules", "venv", ".venv", "__pycache__", ".Trash", "Library", ".cache"}
# Schluessel und Passwoerter liest Jarvis nie, auch nicht auf Wunsch
SECRET = re.compile(r"(^\.env)|(\.(pem|p12|pfx)$)|(^id_(rsa|dsa|ecdsa|ed25519))|(\.keychain)|(^\.netrc$)|(^\.npmrc$)", re.I)
SECRET_DIRS = {".ssh", ".gnupg", "Keychains", ".aws"}

# Deutsche Ordnernamen, wie Lukas sie sagt
ALIASES = {
    "schreibtisch": "Desktop", "desktop": "Desktop",
    "dokumente": "Documents", "documents": "Documents",
    "downloads": "Downloads",
    "bilder": "Pictures", "pictures": "Pictures",
    "musik": "Music", "filme": "Movies", "projekte": "Projekte",
    "icloud": "Library/Mobile Documents/com~apple~CloudDocs",
    "icloud drive": "Library/Mobile Documents/com~apple~CloudDocs",
    "jarvis": str(JARVIS_DIR),
    "eingang": str(INBOX),
}

IMAGE_TYPES = {".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".gif": "image/gif", ".webp": "image/webp"}
CONVERT_IMAGES = {".heic", ".heif", ".tif", ".tiff", ".bmp"}
TEXTUTIL = {".doc", ".docx", ".rtf", ".rtfd", ".odt", ".webarchive", ".wordml"}
APPLE_DOCS = {".pages", ".numbers", ".key"}


def _short(path: Path) -> str:
    try:
        return "~/" + str(path.resolve().relative_to(HOME))
    except ValueError:
        return str(path)


def _size(n: float) -> str:
    for unit in ("Bytes", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return f"{n:.0f} {unit}" if unit == "Bytes" else f"{n:.1f} {unit}"
        n /= 1024
    return ""


def _is_secret(path: Path) -> bool:
    return bool(SECRET.search(path.name)) or any(part in SECRET_DIRS for part in path.parts)


def resolve(path_text: str) -> Path:
    """Macht aus "Schreibtisch/Rechnungen" oder "~/Downloads/x" einen echten Pfad."""
    text = path_text.strip().strip('"').strip("'")
    if text.startswith("~"):
        return Path(os.path.expanduser(text))
    if text.startswith("/"):
        return Path(text)
    first, _, rest = text.replace("\\", "/").partition("/")
    alias = ALIASES.get(first.lower())
    if alias:
        base = Path(alias) if alias.startswith("/") else HOME / alias
        return base / rest if rest else base
    return HOME / text


# ---------- Reingezogene Dateien ----------

def _batch_dir(batch: str) -> Path:
    safe = re.sub(r"[^A-Za-z0-9_-]", "", batch)[:40] or "ohne-name"
    return INBOX / safe


def _safe_rel(rel: str) -> Path:
    parts = [p for p in rel.replace("\\", "/").split("/") if p not in ("", ".", "..")]
    if not parts:
        raise ValueError("Leerer Dateiname")
    return Path(*parts)


async def save_upload(batch: str, rel: str, chunks) -> dict:
    """Speichert eine reingezogene Datei unter eingang/<batch>/<Pfad>."""
    target = _batch_dir(batch) / _safe_rel(rel)
    target.parent.mkdir(parents=True, exist_ok=True)
    written = 0
    with open(target, "wb") as f:
        async for chunk in chunks:
            written += len(chunk)
            if written > MAX_UPLOAD:
                f.close()
                target.unlink(missing_ok=True)
                return {"ok": False, "error": f"{rel} ist groesser als {_size(MAX_UPLOAD)}"}
            f.write(chunk)
    return {"ok": True}


def _find_original(folder: Path) -> Path | None:
    """Sucht per Spotlight den Originalordner zu einem reingezogenen Ordner (gleicher Name, gleicher Inhalt)."""
    if not shutil.which("mdfind"):
        return None
    names = {p.name for p in folder.iterdir()}
    try:
        out = subprocess.run(
            ["mdfind", "-onlyin", str(HOME), f'kMDItemFSName == "{folder.name.replace(chr(34), "")}" && kMDItemContentType == "public.folder"'],
            capture_output=True, text=True, timeout=10,
        ).stdout
    except (subprocess.SubprocessError, OSError):
        return None
    for line in out.splitlines():
        candidate = Path(line)
        if INBOX in candidate.parents or not candidate.is_dir():
            continue
        try:
            have = {p.name for p in candidate.iterdir() if not p.name.startswith(".")}
        except OSError:
            continue
        if names and names <= have | names and len(names & have) >= max(1, int(len(names) * 0.8)):
            return candidate
    return None


def finish_batch(batch: str) -> dict:
    """Fasst zusammen, was reingezogen wurde, fuer die Nachricht an Jarvis."""
    root = _batch_dir(batch)
    if not root.is_dir():
        return {"ok": False, "error": "Nichts angekommen"}
    top = sorted(root.iterdir())
    files = [p for p in root.rglob("*") if p.is_file()]
    label = ", ".join(p.name + ("/" if p.is_dir() else "") for p in top[:4]) + (" ..." if len(top) > 4 else "")
    original = None
    if len(top) == 1 and top[0].is_dir():
        found = _find_original(top[0])
        original = _short(found) if found else None
    return {"ok": True, "dir": _short(root), "label": label, "count": len(files), "original": original}


# ---------- Ordner finden und auflisten ----------

def find_folder(name: str) -> str:
    direct = resolve(name)
    if direct.is_dir():
        return f"Gefunden: {_short(direct)}"
    hits: list[Path] = []
    wanted = name.strip().rstrip("/").split("/")[-1].replace('"', "")
    if shutil.which("mdfind"):
        try:
            out = subprocess.run(
                ["mdfind", "-onlyin", str(HOME), f'kMDItemFSName == "*{wanted}*"cd && kMDItemContentType == "public.folder"'],
                capture_output=True, text=True, timeout=10,
            ).stdout
            hits = [Path(line) for line in out.splitlines() if line]
        except (subprocess.SubprocessError, OSError):
            pass
    if not hits:
        hits = _walk_for(wanted)
    hits = [h for h in hits if not any(part in SKIP_DIRS or part.startswith(".") for part in h.relative_to(HOME).parts)
            and INBOX not in h.parents]
    if not hits:
        return f"Keinen Ordner '{name}' gefunden."
    key = wanted.lower()
    hits.sort(key=lambda p: (p.name.lower() != key, len(p.parts)))
    return "Passende Ordner: " + "; ".join(_short(h) for h in hits[:8])


def _walk_for(wanted: str, max_depth: int = 4) -> list[Path]:
    key = wanted.lower()
    found = []
    stack = [(HOME, 0)]
    while stack and len(found) < 20:
        folder, depth = stack.pop()
        try:
            entries = list(os.scandir(folder))
        except OSError:
            continue
        for entry in entries:
            if not entry.is_dir(follow_symlinks=False) or entry.name.startswith(".") or entry.name in SKIP_DIRS:
                continue
            if key in entry.name.lower():
                found.append(Path(entry.path))
            if depth < max_depth:
                stack.append((Path(entry.path), depth + 1))
    return found


def list_folder(path: str, depth: int = 2) -> str:
    root = resolve(path)
    if not root.is_dir():
        return f"Ordner {path} gibt es nicht. Mit find_folder suchen."
    if _is_secret(root):
        return "Diesen Ordner lese ich nicht, dort liegen Schluessel oder Passwoerter."
    lines: list[str] = []
    counts: dict[str, int] = {}
    total_files = 0
    total_size = 0

    def walk(folder: Path, level: int):
        nonlocal total_files, total_size
        try:
            entries = sorted(folder.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower()))
        except OSError:
            return
        for entry in entries:
            if entry.name.startswith(".") or entry.name in SKIP_DIRS:
                continue
            indent = "  " * level
            if entry.is_dir():
                if len(lines) < 250:
                    lines.append(f"{indent}{entry.name}/")
                if level + 1 < depth:
                    walk(entry, level + 1)
            else:
                total_files += 1
                try:
                    size = entry.stat().st_size
                except OSError:
                    size = 0
                total_size += size
                ext = entry.suffix.lower() or "ohne Endung"
                counts[ext] = counts.get(ext, 0) + 1
                if len(lines) < 250:
                    lines.append(f"{indent}{entry.name} ({_size(size)})")

    walk(root, 0)
    kinds = ", ".join(f"{n}x {ext}" for ext, n in sorted(counts.items(), key=lambda kv: -kv[1])[:10])
    more = "\n(Liste gekuerzt)" if len(lines) >= 250 else ""
    count = "1 Datei" if total_files == 1 else f"{total_files} Dateien"
    return (f"Ordner {_short(root)}: {count} (bis Tiefe {depth}), {_size(total_size)}. "
            f"Typen: {kinds or 'keine'}.\n" + "\n".join(lines) + more)


# ---------- Dateien lesen ----------

def _image_block(data: bytes, media_type: str) -> dict:
    return {"type": "image", "source": {"type": "base64", "media_type": media_type,
                                        "data": base64.standard_b64encode(data).decode()}}


def _shrink_image(path: Path) -> bytes | None:
    """Verkleinert Bilder mit dem Mac-Bordmittel sips (wandelt auch HEIC in JPEG)."""
    if not shutil.which("sips"):
        return None
    out = Path(tempfile.gettempdir()) / "jarvis_bild.jpg"
    result = subprocess.run(["sips", "-Z", "1568", "-s", "format", "jpeg", str(path), "--out", str(out)],
                            capture_output=True)
    if result.returncode != 0 or not out.exists():
        return None
    data = out.read_bytes()
    out.unlink(missing_ok=True)
    return data


def _xml_text(xml: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", xml)).strip()


def _office_text(path: Path) -> str:
    """Text aus Excel (.xlsx) und PowerPoint (.pptx), ohne Zusatzpakete."""
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        if path.suffix.lower() == ".pptx":
            slides = sorted((n for n in names if re.match(r"ppt/slides/slide\d+\.xml$", n)),
                            key=lambda n: int(re.findall(r"\d+", n)[-1]))
            parts = []
            for i, name in enumerate(slides, 1):
                texts = re.findall(r"<a:t>([^<]*)</a:t>", z.read(name).decode("utf-8", "replace"))
                parts.append(f"Folie {i}: " + " ".join(texts))
            return "\n".join(parts)
        shared = []
        if "xl/sharedStrings.xml" in names:
            for si in re.findall(r"<si>(.*?)</si>", z.read("xl/sharedStrings.xml").decode("utf-8", "replace"), re.S):
                shared.append(_xml_text(si))
        parts = []
        sheets = sorted(n for n in names if re.match(r"xl/worksheets/sheet\d+\.xml$", n))
        for name in sheets:
            xml = z.read(name).decode("utf-8", "replace")
            rows = []
            for row in re.findall(r"<row[^>]*>(.*?)</row>", xml, re.S):
                cells = []
                for attrs, body in re.findall(r"<c([^>]*)>(.*?)</c>", row, re.S):
                    value = re.search(r"<v>(.*?)</v>", body, re.S)
                    if 't="s"' in attrs and value:
                        idx = int(value.group(1))
                        cells.append(shared[idx] if idx < len(shared) else "")
                    elif value:
                        cells.append(value.group(1))
                    else:
                        cells.append(_xml_text(body))
                rows.append("\t".join(cells))
            parts.append(f"Tabelle {Path(name).stem}:\n" + "\n".join(rows))
        return "\n\n".join(parts)


def _text_of(path: Path) -> str | None:
    with open(path, "rb") as f:
        raw = f.read(20 * 1024 * 1024)
    if b"\x00" in raw[:8000]:
        return None
    for enc in ("utf-8", "cp1252"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return None


def _clip(text: str, start: int) -> str:
    part = text[start:start + MAX_TEXT]
    if start + MAX_TEXT < len(text):
        part += f"\n[... gekuerzt. Weiterlesen mit read_file und start={start + MAX_TEXT}, insgesamt {len(text)} Zeichen]"
    return part


def read_file(path: str, start: int = 0):
    """Liest eine Datei so, dass Claude sie verstehen kann. Gibt Text oder Inhaltsbloecke zurueck."""
    file = resolve(path)
    if file.is_dir():
        return list_folder(path)
    if not file.is_file():
        return f"Datei {path} gibt es nicht."
    if _is_secret(file):
        return "Diese Datei lese ich nicht, sie enthaelt Schluessel oder Passwoerter."
    ext = file.suffix.lower()
    size = file.stat().st_size
    head = f"Datei {_short(file)} ({_size(size)})"

    if ext == ".pdf":
        if size > MAX_PDF:
            return f"{head} ist zu gross zum Lesen (Grenze {_size(MAX_PDF)})."
        doc = {"type": "document", "source": {"type": "base64", "media_type": "application/pdf",
                                              "data": base64.standard_b64encode(file.read_bytes()).decode()}}
        return [{"type": "text", "text": head}, doc]

    if ext in IMAGE_TYPES or ext in CONVERT_IMAGES:
        data, media = None, IMAGE_TYPES.get(ext)
        if ext in CONVERT_IMAGES or size > MAX_IMAGE:
            data, media = _shrink_image(file), "image/jpeg"
        elif media:
            data = file.read_bytes()
        if not data:
            return f"{head}: Bild kann ich hier nicht umwandeln."
        return [{"type": "text", "text": head}, _image_block(data, media)]

    if ext in APPLE_DOCS:
        with zipfile.ZipFile(file) as z:
            for name in ("preview.jpg", "QuickLook/Thumbnail.jpg", "preview-web.jpg"):
                if name in z.namelist():
                    return [{"type": "text", "text": f"{head}: Apple-Dokument, nur die Vorschau der ersten Seite."},
                            _image_block(z.read(name), "image/jpeg")]
        return f"{head}: Apple-Dokument ohne Vorschau. Bitte als PDF exportieren."

    text = None
    if ext in TEXTUTIL and shutil.which("textutil"):
        result = subprocess.run(["textutil", "-convert", "txt", "-stdout", str(file)], capture_output=True)
        text = result.stdout.decode("utf-8", "replace") if result.returncode == 0 else None
    elif ext == ".docx":
        with zipfile.ZipFile(file) as z:
            text = _xml_text(z.read("word/document.xml").decode("utf-8", "replace").replace("</w:p>", "\n"))
    elif ext in (".xlsx", ".pptx"):
        text = _office_text(file)
    else:
        text = _text_of(file)

    if text is None:
        return f"{head}: Inhalt kann ich nicht lesen (Typ {ext or 'unbekannt'})."
    return f"{head}:\n{_clip(text, start)}"
