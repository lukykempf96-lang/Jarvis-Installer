"""Genau ein Jarvis-Fenster in Chrome: vorhandenen Tab nach vorne holen statt einen zweiten zu oeffnen.

Braucht einmal die macOS-Erlaubnis "Terminal darf Google Chrome steuern". Ohne sie oeffnet Jarvis
wie bisher einen Tab; doppelte Tabs schaltet dann der Server stumm (nur ein Tab ist aktiv).
"""
from __future__ import annotations

import subprocess
import time

from .config import settings

# argv: Modus (show, reload, close), gesuchte Tab-Kennung, Adressen von Jarvis
_SCRIPT = '''
on run argv
    set mode to item 1 of argv
    set wanted to item 2 of argv
    set bases to rest of rest of argv
    tell application "Google Chrome"
        if mode is "close" then
            if wanted is "" then return "closed 0"
            set n to 0
            repeat with w in windows
                repeat with i from (count of tabs of w) to 1 by -1
                    set u to URL of tab i of w
                    repeat with b in bases
                        if u starts with (b as string) and u ends with ("#" & wanted) then
                            close tab i of w
                            set n to n + 1
                            exit repeat
                        end if
                    end repeat
                end repeat
            end repeat
            return "closed " & n
        end if
        set best to missing value
        repeat with w in windows
            set i to 0
            repeat with t in tabs of w
                set i to i + 1
                set u to URL of t
                set ours to false
                repeat with b in bases
                    if u starts with (b as string) and u does not contain "/anzeige" then set ours to true
                end repeat
                if ours then
                    if wanted is not "" and u contains ("#" & wanted) then
                        set best to {id of w, i}
                        exit repeat
                    end if
                    if best is missing value then set best to {id of w, i}
                end if
            end repeat
        end repeat
        if best is missing value then return "none " & (count of windows)
        set w to window id (item 1 of best)
        set active tab index of w to (item 2 of best)
        if mode is "reload" then reload (active tab of w)
        try
            set minimized of w to false
        end try
        set index of w to 1
        activate
        return "found"
    end tell
end run
'''


def _bases() -> list[str]:
    return [f"http://localhost:{settings.port}", f"http://127.0.0.1:{settings.port}"]


def chrome_running() -> bool:
    return subprocess.run(["pgrep", "-x", "Google Chrome"], capture_output=True).returncode == 0


def _tab_action(mode: str, tab: str = "", timeout: float = 15) -> str | None:
    """'found', 'none <Fensterzahl>', 'closed N' oder None, wenn Chrome nicht gesteuert werden darf."""
    try:
        proc = subprocess.run(["osascript", "-e", _SCRIPT, mode, tab, *_bases()],
                              capture_output=True, text=True, timeout=timeout)
    except (subprocess.SubprocessError, OSError):
        return None
    return proc.stdout.strip() if proc.returncode == 0 else None


def open_jarvis(url: str) -> str:
    """Zeigt das Jarvis-Fenster. Gibt es schon einen Jarvis-Tab, wird er neu geladen statt verdoppelt."""
    if not chrome_running():
        # Chrome stellt beim Start oft die alten Tabs wieder her, darunter Jarvis: kurz darauf warten
        subprocess.run(["open", "-a", "Google Chrome"], capture_output=True)
        with_windows = 0
        for _ in range(8):
            time.sleep(0.5)
            result = _tab_action("reload")
            if result is None:
                break
            if result == "found":
                return "found"
            # Fenster sind da, aber kein Jarvis darunter: nicht laenger warten
            with_windows = with_windows + 1 if result.startswith("none") and result != "none 0" else 0
            if with_windows >= 2:
                break
    elif _tab_action("reload") == "found":
        return "found"
    subprocess.run(["open", "-a", "Google Chrome", url], capture_output=True)
    return "opened"


def show(tab: str = ""):
    """Holt den aktiven Jarvis-Tab nach vorne (beim Klatschen, wenn Jarvis schon offen ist)."""
    if _tab_action("show", tab, timeout=8) != "found":
        subprocess.run(["open", "-a", "Google Chrome"], capture_output=True)


def close_tab(tab: str) -> str | None:
    """Schliesst einen ueberzaehligen Jarvis-Tab (erkannt an seiner Kennung in der Adresse)."""
    return _tab_action("close", tab, timeout=8) if tab else None
