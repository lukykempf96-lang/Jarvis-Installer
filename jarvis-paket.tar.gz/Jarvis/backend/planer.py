"""Termine und Erinnerungen anlegen, Kontakte zeigen, anrufen, Websites und Programme oeffnen.

Termine und Erinnerungen gehen ueber EventKit in die Kalender- und Erinnerungen-App (und per iCloud
aufs iPhone). Kontakte kommen aus der Kontakte-Datenbank, notfalls per AppleScript. Angerufen wird
ueber das iPhone (tel:-Link); der Mac fragt vor jedem Anruf noch einmal nach.
"""
from __future__ import annotations

import glob
import os
import re
import sqlite3
import subprocess
import threading
import unicodedata
from datetime import datetime, timedelta
from pathlib import Path
from urllib.parse import quote, urlparse

from . import alltag

WEEKDAYS = alltag.WEEKDAYS
MONTHS = ["Januar", "Februar", "Maerz", "April", "Mai", "Juni", "Juli", "August", "September",
          "Oktober", "November", "Dezember"]

REMINDERS_HINT = (
    "Ich darf noch keine Erinnerungen anlegen. In den Systemeinstellungen unter Datenschutz und Sicherheit, "
    "Erinnerungen, das Terminal auf Vollzugriff stellen und Jarvis neu starten. Ich habe die Einstellung geoeffnet."
)
CONTACTS_HINT = (
    "Ich komme nicht an die Kontakte. In den Systemeinstellungen unter Datenschutz und Sicherheit, "
    "Festplattenvollzugriff, das Terminal einschalten und Jarvis neu starten. Ich habe die Einstellung geoeffnet."
)
EVENTKIT_MISSING = "Der Kalender-Baustein fehlt noch. Bitte Jarvis einmal neu installieren."


def _norm(text: str) -> str:
    text = (text or "").lower()
    for umlaut, plain in (("ä", "ae"), ("ö", "oe"), ("ü", "ue"), ("ß", "ss")):  # Müller = Mueller
        text = text.replace(umlaut, plain)
    text = "".join(ch for ch in unicodedata.normalize("NFKD", text) if not unicodedata.combining(ch))
    return " ".join("".join(ch if ch.isalnum() else " " for ch in text).split())


def _when(dt: datetime, with_time: bool = True) -> str:
    """'Dienstag, 6. Oktober um 14:00 Uhr', bei heute und morgen kuerzer."""
    today = datetime.now()
    days = (dt.date() - today.date()).days
    day = {0: "heute", 1: "morgen", 2: "uebermorgen"}.get(days) or f"{WEEKDAYS[dt.weekday()]}, {dt.day}. {MONTHS[dt.month - 1]}"
    if dt.year != today.year and days > 2:
        day += f" {dt.year}"
    return f"{day} um {dt.strftime('%H:%M')} Uhr" if with_time else day


def _parse(value: str, field: str) -> tuple[datetime, bool]:
    """ISO-Zeit aus dem Tool ('2026-10-06T14:00' oder nur '2026-10-06'). Zweiter Wert: mit Uhrzeit?"""
    text = (value or "").strip().replace(" ", "T")
    if not text:
        raise ValueError(f"{field} fehlt")
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        dt = datetime.fromisoformat(text)
    except ValueError:
        raise ValueError(f"{field} '{value}' bitte als 2026-10-06T14:00 angeben") from None
    if dt.tzinfo is not None:
        dt = dt.astimezone().replace(tzinfo=None)
    return dt, "T" in text


def _dashboard_stale(section: str):
    """Damit das Dashboard die Aenderung beim naechsten Laden zeigt statt erst nach ein paar Minuten."""
    try:
        from . import dashboard

        dashboard._sections[section]["at"] = 0.0
    except Exception:
        pass


# ---------------------------------------------------------------- Kalender und Erinnerungen (EventKit)

def _store():
    import EventKit  # pyobjc, gibt es nur auf dem Mac

    return EventKit, EventKit.EKEventStore.alloc().init()


def _nsdate(dt: datetime):
    from Foundation import NSDate

    return NSDate.dateWithTimeIntervalSince1970_(dt.timestamp())


def _from_nsdate(d) -> datetime:
    return datetime.fromtimestamp(d.timeIntervalSince1970())


def _ok(result) -> tuple[bool, str]:
    """pyobjc gibt bei Methoden mit error:-Zeiger (Erfolg, Fehler) zurueck."""
    ok, err = (result[0], result[1] if len(result) > 1 else None) if isinstance(result, tuple) else (result, None)
    message = str(err.localizedDescription()) if err is not None and hasattr(err, "localizedDescription") else ""
    return bool(ok), (": " + message if message else "")


def _similar(a: str, b: str) -> bool:
    """Listen- und Kalendernamen grob gleich? Einkauf, Einkaufen, Einkaufsliste."""
    if not a or not b:
        return False
    if a in b or b in a:
        return True
    common = 0
    for x, y in zip(a, b):
        if x != y:
            break
        common += 1
    return common >= 5 and common >= 0.7 * min(len(a), len(b))


def _find_calendar(store, name: str, entity: int):
    if not name:
        return None
    wanted = _norm(name)
    writable = [c for c in (store.calendarsForEntityType_(entity) or []) if c.allowsContentModifications()]
    for test in (lambda t: t == wanted, lambda t: wanted in t, lambda t: _similar(wanted, t)):
        for cal in writable:
            if test(_norm(str(cal.title() or ""))):
                return cal
    return None


def _access(entity_name: str) -> str | None:
    """None = Vollzugriff, sonst ein Satz, was fehlt (die passende Einstellung wird geoeffnet)."""
    try:
        import EventKit
    except ImportError:
        return EVENTKIT_MISSING
    if entity_name == "events":
        if alltag._ensure_access(EventKit.EKEntityTypeEvent):
            return None
        alltag._open_privacy_settings("Privacy_Calendars")
        return alltag.CALENDAR_HINT
    if alltag._ensure_access(EventKit.EKEntityTypeReminder):
        return None
    alltag._open_privacy_settings("Privacy_Reminders")
    return REMINDERS_HINT


def add_event(title: str, start: str, end: str = "", duration_min: int | None = None, location: str = "",
              notes: str = "", calendar: str = "", alert_min: int | None = None) -> str:
    title = (title or "").strip() or "Termin"
    try:
        begin, timed = _parse(start, "Beginn")
        if end:
            finish, end_timed = _parse(end, "Ende")
            if not end_timed:  # "bis Freitag" heisst: Freitag gehoert noch dazu
                finish += timedelta(days=1)
        elif timed:
            finish = begin + timedelta(minutes=int(duration_min or 60))
        else:
            finish = begin + timedelta(days=1)
    except (TypeError, ValueError) as exc:
        return f"Termin nicht eingetragen: {exc}."
    if finish <= begin:
        return "Termin nicht eingetragen: Das Ende liegt vor dem Beginn."
    problem = _access("events")
    if problem:
        return problem
    EventKit, store = _store()
    cal = _find_calendar(store, calendar, EventKit.EKEntityTypeEvent) or store.defaultCalendarForNewEvents()
    if cal is None:
        return "Ich finde keinen Kalender, in den ich schreiben darf. Bitte in der Kalender-App einen anlegen."
    event = EventKit.EKEvent.eventWithEventStore_(store)
    event.setTitle_(title)
    event.setStartDate_(_nsdate(begin))
    event.setEndDate_(_nsdate(finish))
    event.setAllDay_(not timed)
    event.setCalendar_(cal)
    if location:
        event.setLocation_(location)
    if notes:
        event.setNotes_(notes)
    if alert_min is not None and timed:
        event.addAlarm_(EventKit.EKAlarm.alarmWithRelativeOffset_(-60.0 * max(0, int(alert_min))))
    ok, error = _ok(store.saveEvent_span_commit_error_(event, EventKit.EKSpanThisEvent, True, None))
    if not ok:
        return f"Der Kalender hat den Termin nicht angenommen{error}."
    _dashboard_stale("calendar")
    if timed:
        when = _when(begin) + (f" bis {finish.strftime('%H:%M')} Uhr" if finish.date() == begin.date() else "")
    else:
        last = finish - timedelta(days=1)
        when = _when(begin, False) + (f" bis {_when(last, False)}" if last.date() > begin.date() else "") + ", ganztaegig"
    past = " Achtung, das liegt in der Vergangenheit." if finish < datetime.now() else ""
    return (f"Eingetragen: {title}, {when}" + (f", Ort {location}" if location else "")
            + (f", Erinnerung {int(alert_min)} Minuten vorher" if alert_min is not None and timed else "")
            + f" (Kalender {cal.title()}).{past}")


def _matching_events(store, query: str, day: str):
    words = _norm(query).split()
    if day:
        start = _parse(day, "Tag")[0].replace(hour=0, minute=0, second=0, microsecond=0)
        end = start + timedelta(days=1)
    else:
        start = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0) - timedelta(days=1)
        end = start + timedelta(days=120)
    pred = store.predicateForEventsWithStartDate_endDate_calendars_(_nsdate(start), _nsdate(end), None)
    found = [e for e in (store.eventsMatchingPredicate_(pred) or [])
             if all(w in _norm(str(e.title() or "")) for w in words)]
    found.sort(key=lambda e: e.startDate().timeIntervalSince1970())
    return found


def change_event(query: str, day: str = "", new_title: str = "", new_start: str = "", new_end: str = "",
                 new_day: str = "", shift_min: int | None = None, new_location: str = "", delete: bool = False) -> str:
    """Sucht einen Termin nach Titel (optional an einem Tag) und verschiebt, aendert oder loescht ihn."""
    problem = _access("events")
    if problem:
        return problem
    EventKit, store = _store()
    try:
        found = _matching_events(store, query, day)
    except ValueError as exc:
        return f"Nichts geaendert: {exc}."
    if not found:
        return f"Ich finde keinen Termin mit '{query}'" + (" an dem Tag." if day else " in den naechsten Monaten.")
    if len(found) > 1:
        lines = [f"{e.title()} {_when(_from_nsdate(e.startDate()), not e.isAllDay())}" for e in found[:6]]
        return "Mehrere Termine passen, frag Lukas welcher (oder gib den Tag mit): " + "; ".join(lines) + "."
    event = found[0]
    old_title = str(event.title() or "Termin")
    old_start, old_end = _from_nsdate(event.startDate()), _from_nsdate(event.endDate())
    if not event.calendar().allowsContentModifications():
        return f"Den Termin {old_title} darf ich nicht aendern, der Kalender ist nur zum Lesen."
    if delete:
        ok, error = _ok(store.removeEvent_span_commit_error_(event, EventKit.EKSpanThisEvent, True, None))
        if ok:
            _dashboard_stale("calendar")
            return f"Geloescht: {old_title}, {_when(old_start, not event.isAllDay())}."
        return f"Konnte den Termin nicht loeschen{error}."
    length = old_end - old_start
    try:
        if new_start:
            begin, timed = _parse(new_start, "Neuer Beginn")
            if new_end:
                finish = _parse(new_end, "Neues Ende")[0]
            elif timed:
                finish = begin + (length if not event.isAllDay() else timedelta(hours=1))
            else:
                finish = begin + timedelta(days=max(1, round(length.total_seconds() / 86400)))
            event.setAllDay_(not timed)
        elif new_day:
            target = _parse(new_day, "Neuer Tag")[0]
            begin = old_start.replace(year=target.year, month=target.month, day=target.day)
            finish = begin + length
        elif shift_min:
            begin, finish = old_start + timedelta(minutes=int(shift_min)), old_end + timedelta(minutes=int(shift_min))
        else:
            begin = old_start
            finish = _parse(new_end, "Neues Ende")[0] if new_end else old_end
    except ValueError as exc:
        return f"Nichts geaendert: {exc}."
    if finish <= begin:
        return "Nichts geaendert: Das Ende laege vor dem Beginn."
    event.setStartDate_(_nsdate(begin))
    event.setEndDate_(_nsdate(finish))
    if new_title:
        event.setTitle_(new_title)
    if new_location:
        event.setLocation_(new_location)
    ok, error = _ok(store.saveEvent_span_commit_error_(event, EventKit.EKSpanThisEvent, True, None))
    if not ok:
        return f"Der Kalender hat die Aenderung nicht angenommen{error}."
    _dashboard_stale("calendar")
    return f"Geaendert: {event.title()}, jetzt {_when(begin, not event.isAllDay())}."


# ---------------------------------------------------------------- Erinnerungen und Listen (z. B. Einkaufsliste)

def _reminder_lists(store, EventKit) -> list:
    return list(store.calendarsForEntityType_(EventKit.EKEntityTypeReminder) or [])


def _list_names(store, EventKit) -> str:
    return ", ".join(str(c.title()) for c in _reminder_lists(store, EventKit)) or "keine"


def _find_list(store, EventKit, name: str, writable: bool = True):
    cal = _find_calendar(store, name, EventKit.EKEntityTypeReminder)
    if cal is None and not writable:
        wanted = _norm(name)
        cal = next((c for c in _reminder_lists(store, EventKit) if _similar(wanted, _norm(str(c.title() or "")))), None)
    return cal


def _open_reminders(store, calendars=None) -> list | None:
    """Offene Erinnerungen (optional nur aus diesen Listen). None, wenn die App nicht antwortet."""
    pred = store.predicateForIncompleteRemindersWithDueDateStarting_ending_calendars_(None, None, calendars)
    result: list = []
    done = threading.Event()

    def handler(reminders):
        result.extend(reminders or [])
        done.set()

    store.fetchRemindersMatchingPredicate_completion_(pred, handler)
    return result if done.wait(20) else None


def _due(reminder) -> tuple[datetime | None, bool]:
    comps = reminder.dueDateComponents()
    if comps is None:
        return None, False
    try:
        from Foundation import NSCalendar

        date = NSCalendar.currentCalendar().dateFromComponents_(comps)
        return (_from_nsdate(date) if date else None), comps.hour() != alltag.NS_UNDEFINED
    except Exception:
        return None, False


def _item_line(reminder) -> str:
    when, timed = _due(reminder)
    title = str(reminder.title() or "Erinnerung")
    return f"{title} ({_when(when, timed)})" if when else title


def _set_due(reminder, EventKit, when: datetime, timed: bool):
    from Foundation import NSCalendar

    units = 4 | 8 | 16 | ((32 | 64) if timed else 0)  # Jahr, Monat, Tag (und Stunde, Minute)
    reminder.setDueDateComponents_(NSCalendar.currentCalendar().components_fromDate_(units, _nsdate(when)))
    for alarm in list(reminder.alarms() or []):
        reminder.removeAlarm_(alarm)
    if timed:  # damit sich Mac und iPhone zur Uhrzeit melden
        reminder.addAlarm_(EventKit.EKAlarm.alarmWithAbsoluteDate_(_nsdate(when)))


def _create_list(store, EventKit, name: str):
    cal = EventKit.EKCalendar.calendarForEntityType_eventStore_(EventKit.EKEntityTypeReminder, store)
    cal.setTitle_(name.strip())
    default = store.defaultCalendarForNewReminders()
    if default is None:
        return None, "keine Erinnerungen-Quelle gefunden"
    cal.setSource_(default.source())  # gleiche Quelle wie die Standardliste, meist iCloud
    ok, error = _ok(store.saveCalendar_commit_error_(cal, True, None))
    return (cal, "") if ok else (None, error)


def get_reminder_list(list_name: str = "") -> str:
    """Was auf einer Liste steht (z. B. Einkauf), oder ohne Namen ein Ueberblick ueber alle Listen."""
    problem = _access("reminders")
    if problem:
        return problem
    EventKit, store = _store()
    if list_name:
        cal = _find_list(store, EventKit, list_name, writable=False)
        if cal is None:
            return f"Keine Liste '{list_name}'. Vorhanden: {_list_names(store, EventKit)}."
        items = _open_reminders(store, [cal])
        if items is None:
            return "Die Erinnerungen-App antwortet gerade nicht."
        if not items:
            return f"Die Liste {cal.title()} ist leer, alles erledigt."
        items.sort(key=lambda r: (_due(r)[0] or datetime.max, _norm(str(r.title() or ""))))
        return f"{cal.title()}, {len(items)} offen: " + ", ".join(_item_line(r) for r in items[:40]) + "."
    items = _open_reminders(store)
    if items is None:
        return "Die Erinnerungen-App antwortet gerade nicht."
    parts = []
    for cal in _reminder_lists(store, EventKit):
        mine = [r for r in items if r.calendar() is not None and str(r.calendar().title()) == str(cal.title())]
        if mine:
            preview = ", ".join(_item_line(r) for r in mine[:5]) + (" und mehr" if len(mine) > 5 else "")
            parts.append(f"{cal.title()} ({len(mine)} offen: {preview})")
        else:
            parts.append(f"{cal.title()} (leer)")
    return "Listen: " + "; ".join(parts) + "." if parts else "Es gibt noch keine Erinnerungslisten."


def add_reminder(title: str = "", due: str = "", list_name: str = "", notes: str = "",
                 items: list | None = None, create_list: bool = False) -> str:
    titles = [str(t).strip() for t in (items or []) if str(t).strip()] or ([title.strip()] if (title or "").strip() else [])
    if not titles:
        return "Woran soll ich erinnern? Der Text fehlt."
    try:
        when, timed = _parse(due, "Zeitpunkt") if due else (None, False)
    except ValueError as exc:
        return f"Erinnerung nicht angelegt: {exc}."
    problem = _access("reminders")
    if problem:
        return problem
    EventKit, store = _store()
    if list_name:
        cal = _find_list(store, EventKit, list_name)
        if cal is None and create_list:
            cal, error = _create_list(store, EventKit, list_name)
            if cal is None:
                return f"Die Liste {list_name} liess sich nicht anlegen{': ' + error if error else ''}."
        if cal is None:
            return (f"Es gibt keine Liste '{list_name}'. Vorhanden: {_list_names(store, EventKit)}. "
                    "Frag Lukas, ob du eine davon nehmen oder die Liste neu anlegen sollst (create_list).")
    else:
        cal = store.defaultCalendarForNewReminders()
    if cal is None:
        return "Ich finde keine Erinnerungsliste. Bitte in der Erinnerungen-App eine anlegen."
    saved, failed = [], ""
    for text in titles[:30]:
        reminder = EventKit.EKReminder.reminderWithEventStore_(store)
        reminder.setTitle_(text)
        reminder.setCalendar_(cal)
        if notes:
            reminder.setNotes_(notes)
        if when is not None:
            _set_due(reminder, EventKit, when, timed)
        ok, error = _ok(store.saveReminder_commit_error_(reminder, True, None))
        if ok:
            saved.append(text)
        else:
            failed = error or ": unbekannter Fehler"
    if not saved:
        return f"Die Erinnerungen-App hat das nicht angenommen{failed}."
    _dashboard_stale("reminders")
    past = " Achtung, der Zeitpunkt liegt in der Vergangenheit." if when and timed and when < datetime.now() else ""
    missing = f" Nicht geklappt bei den restlichen{failed}." if failed else ""
    if len(saved) > 1:
        return f"Auf {cal.title()}: {', '.join(saved)}.{missing}"
    return (f"Erinnerung angelegt: {saved[0]}" + (f", {_when(when, timed)}" if when else "")
            + f" (Liste {cal.title()}). Sie kommt auch aufs iPhone.{past}{missing}")


def _pick_reminder(store, EventKit, query: str, list_name: str):
    """(Erinnerung, None) oder (None, Satz fuer Jarvis) bei keinem oder mehreren Treffern."""
    calendars = None
    if list_name:
        cal = _find_list(store, EventKit, list_name, writable=False)
        if cal is None:
            return None, f"Keine Liste '{list_name}'. Vorhanden: {_list_names(store, EventKit)}."
        calendars = [cal]
    result = _open_reminders(store, calendars)
    if result is None:
        return None, "Die Erinnerungen-App antwortet gerade nicht."
    words = _norm(query).split()
    found = [r for r in result if all(w in _norm(str(r.title() or "")) for w in words)]
    exact = [r for r in found if _norm(str(r.title() or "")) == _norm(query)]
    if len(exact) == 1:
        found = exact
    if not found:
        return None, f"Keine offene Erinnerung mit '{query}' gefunden" + (f" auf {list_name}." if list_name else ".")
    if len(found) > 1:
        return None, ("Mehrere Erinnerungen passen, frag Lukas welche: "
                      + "; ".join(f"{r.title()} ({r.calendar().title()})" for r in found[:6]) + ".")
    return found[0], None


def complete_reminder(query: str = "", list_name: str = "", everything: bool = False) -> str:
    problem = _access("reminders")
    if problem:
        return problem
    EventKit, store = _store()
    if everything:  # "Hak die ganze Einkaufsliste ab"
        if not list_name:
            return "Welche Liste soll ich komplett abhaken?"
        cal = _find_list(store, EventKit, list_name)
        if cal is None:
            return f"Keine Liste '{list_name}', in die ich schreiben darf. Vorhanden: {_list_names(store, EventKit)}."
        items = _open_reminders(store, [cal])
        if items is None:
            return "Die Erinnerungen-App antwortet gerade nicht."
        if not items:
            return f"Auf {cal.title()} ist nichts mehr offen."
        for reminder in items:
            reminder.setCompleted_(True)
            store.saveReminder_commit_error_(reminder, False, None)
        ok, error = _ok(store.commit_(None))
        if not ok:
            return f"Konnte die Liste nicht abhaken{error}."
        _dashboard_stale("reminders")
        return f"Alle {len(items)} auf {cal.title()} abgehakt."
    if not (query or "").strip():
        return "Was soll ich abhaken?"
    reminder, problem = _pick_reminder(store, EventKit, query, list_name)
    if reminder is None:
        return problem
    reminder.setCompleted_(True)
    ok, error = _ok(store.saveReminder_commit_error_(reminder, True, None))
    if not ok:
        return f"Konnte sie nicht abhaken{error}."
    _dashboard_stale("reminders")
    return f"Erledigt und abgehakt: {reminder.title()}."


def change_reminder(query: str, list_name: str = "", new_title: str = "", due: str = "", move_to: str = "",
                    delete: bool = False) -> str:
    """Eine offene Erinnerung umbenennen, neu terminieren, auf eine andere Liste legen oder loeschen."""
    problem = _access("reminders")
    if problem:
        return problem
    EventKit, store = _store()
    reminder, problem = _pick_reminder(store, EventKit, query, list_name)
    if reminder is None:
        return problem
    title = str(reminder.title() or "Erinnerung")
    if not reminder.calendar().allowsContentModifications():
        return f"{title} darf ich nicht aendern, die Liste ist nur zum Lesen."
    if delete:
        ok, error = _ok(store.removeReminder_commit_error_(reminder, True, None))
        if not ok:
            return f"Konnte {title} nicht loeschen{error}."
        _dashboard_stale("reminders")
        return f"Geloescht: {title} (Liste {reminder.calendar().title()})."
    target = None
    if move_to:
        target = _find_list(store, EventKit, move_to)
        if target is None:
            return f"Keine Liste '{move_to}', in die ich schreiben darf. Vorhanden: {_list_names(store, EventKit)}."
    try:
        when = _parse(due, "Zeitpunkt") if due else None
    except ValueError as exc:
        return f"Nichts geaendert: {exc}."
    if not (new_title or "").strip() and when is None and target is None:
        return "Was soll ich an der Erinnerung aendern?"
    if (new_title or "").strip():
        reminder.setTitle_(new_title.strip())
    if when is not None:
        _set_due(reminder, EventKit, when[0], when[1])
    if target is not None:
        reminder.setCalendar_(target)
    ok, error = _ok(store.saveReminder_commit_error_(reminder, True, None))
    if not ok:
        return f"Die Erinnerungen-App hat die Aenderung nicht angenommen{error}."
    _dashboard_stale("reminders")
    return f"Geaendert: {_item_line(reminder)} (Liste {reminder.calendar().title()})."


# ---------------------------------------------------------------- Kontakte und Anrufe

LABELS = {"mobile": "Mobil", "iphone": "iPhone", "home": "Privat", "work": "Arbeit", "main": "Haupt",
          "homefax": "Fax", "workfax": "Fax", "pager": "Pager", "other": "Sonstige", "school": "Schule"}
# was Lukas sagt -> Bezeichnung der Nummer
WHICH = {"handy": "mobil", "mobil": "mobil", "mobile": "mobil", "iphone": "mobil", "privat": "privat",
         "zuhause": "privat", "festnetz": "privat", "daheim": "privat", "arbeit": "arbeit", "geschaeftlich": "arbeit",
         "buero": "arbeit", "dienstlich": "arbeit", "firma": "arbeit", "work": "arbeit", "home": "privat"}


def _label(raw: str | None) -> str:
    text = (raw or "").replace("_$!<", "").replace(">!$_", "").strip()
    return LABELS.get(_norm(text).replace(" ", ""), text or "Nummer")


def _add_person(people: dict, name: str, nick: str, org: str, uid: str, phones: list, emails: list):
    """Gleiche Person aus mehreren Quellen (iCloud, Mac, Google) zu einer zusammenfassen."""
    person = people.setdefault(_norm(name), {"name": name, "nick": nick or "", "org": org or "", "id": uid or "",
                                             "phones": [], "emails": []})
    person["nick"] = person["nick"] or nick or ""
    person["id"] = person["id"] or uid or ""
    seen = {alltag._digits(p["number"]) for p in person["phones"]}
    for phone in phones:
        if alltag._digits(phone["number"]) not in seen:
            seen.add(alltag._digits(phone["number"]))
            person["phones"].append(phone)
    person["emails"] += [e for e in emails if e not in person["emails"]]


def _contacts_from_db() -> list[dict] | None:
    """Alle Kontakte mit Nummern aus der Kontakte-Datenbank. None = kein Zugriff."""
    dbs = glob.glob(str(alltag.ADDRESSBOOK_DIR / "Sources/*/AddressBook-v22.abcddb"))
    dbs.append(str(alltag.ADDRESSBOOK_DIR / "AddressBook-v22.abcddb"))
    people: dict = {}
    readable = False
    for db in dbs:
        if not os.path.exists(db):
            continue
        try:
            con = alltag._open_db(Path(db))
            cols = {row[1] for row in con.execute("pragma table_info(ZABCDRECORD)")}
            nick = "ZNICKNAME" if "ZNICKNAME" in cols else "''"
            uid = "ZUNIQUEID" if "ZUNIQUEID" in cols else "''"
            records = {}
            for pk, first, last, org, nickname, unique in con.execute(
                    f"select Z_PK, ZFIRSTNAME, ZLASTNAME, ZORGANIZATION, {nick}, {uid} from ZABCDRECORD"):
                name = " ".join(p for p in (first, last) if p) or org
                if name:
                    records[pk] = (name, nickname, org, unique, [], [])
            for owner, number, label in con.execute("select ZOWNER, ZFULLNUMBER, ZLABEL from ZABCDPHONENUMBER"):
                if owner in records and number:
                    records[owner][4].append({"number": number, "label": _label(label)})
            for owner, address in con.execute("select ZOWNER, ZADDRESS from ZABCDEMAILADDRESS"):
                if owner in records and address:
                    records[owner][5].append(address)
            con.close()
        except (sqlite3.Error, OSError):
            continue  # ohne Festplattenvollzugriff
        readable = True
        for rec in records.values():
            _add_person(people, *rec)
    return list(people.values()) if readable else None


US, RS, GS = "\x1f", "\x1e", "\x1d"


def _contacts_from_applescript(query: str) -> list[dict] | None:
    """Notweg ueber die Kontakte-App (braucht nur die Automation-Erlaubnis). None = ging nicht."""
    safe = re.sub(r'["\\]', "", query)[:60]
    script = f'''
set US to character id 31
set RS to character id 30
set GS to character id 29
tell application "Contacts"
    set out to ""
    repeat with p in (every person whose name contains "{safe}" or nickname contains "{safe}")
        set nick to ""
        try
            set nick to nickname of p as string
        end try
        if nick is "missing value" then set nick to ""
        set out to out & (name of p) & US & nick & US & (id of p)
        repeat with ph in (phones of p)
            set out to out & US & (value of ph) & GS & (label of ph)
        end repeat
        set out to out & RS
    end repeat
    return out
end tell'''
    try:
        proc = subprocess.run(["osascript", "-e", script], capture_output=True, text=True, timeout=30)
    except (subprocess.SubprocessError, OSError):
        return None
    if proc.returncode != 0:
        return None
    people: dict = {}
    for row in proc.stdout.strip().split(RS):
        parts = row.strip("\n").split(US)
        if len(parts) < 3 or not parts[0].strip():
            continue
        phones = []
        for item in parts[3:]:
            number, _, label = item.partition(GS)
            if number.strip():
                phones.append({"number": number.strip(), "label": _label(label)})
        _add_person(people, parts[0].strip(), parts[1].strip(), "", parts[2].strip(), phones, [])
    return list(people.values())


def _score(person: dict, query: str) -> int | None:
    """0 = genau der Name oder Spitzname, 1 = ganze Woerter passen, 2 = Wortanfaenge, 3 = irgendwo drin."""
    words = _norm(query).split()
    names = [_norm(person["name"]), _norm(person["nick"]), _norm(person["org"])]
    if _norm(query) in names[:2]:
        return 0
    tokens = " ".join(names).split()
    if all(w in tokens for w in words):
        return 1
    if all(any(t.startswith(w) for t in tokens) for w in words):
        return 2
    if all(w in " ".join(names) for w in words):
        return 3
    return None


def find_contacts(query: str) -> tuple[list[tuple[int, dict]] | None, str]:
    """Passende Kontakte als (Guete, Person), beste zuerst. (None, Hinweis), wenn die Kontakte nicht lesbar sind."""
    if not _norm(query):
        return [], ""
    everyone = _contacts_from_db()
    if everyone is None:
        everyone = _contacts_from_applescript(query.split()[0])  # breit suchen, die Bewertung sortiert
        if everyone is None:
            alltag._open_privacy_settings("Privacy_AllFiles")
            return None, CONTACTS_HINT
    scored = [(s, p) for p in everyone for s in [_score(p, query)] if s is not None]
    scored.sort(key=lambda sp: (sp[0], sp[1]["name"]))
    return scored, ""


def _choose(scored: list[tuple[int, dict]]) -> dict | None:
    """Der eine gemeinte Kontakt, oder None, wenn nachgefragt werden muss."""
    if len(scored) == 1:
        return scored[0][1]
    best = [p for s, p in scored if s == scored[0][0]]
    return best[0] if len(best) == 1 and scored[0][0] <= 1 else None


def _phone_line(person: dict) -> str:
    phones = ", ".join(f"{p['label']} {p['number']}" for p in person["phones"]) or "keine Nummer"
    return f"{person['name']} ({phones})"


def open_contact(name: str) -> str:
    scored, hint = find_contacts(name)
    if scored is None:
        subprocess.run(["open", "-a", "Contacts"], capture_output=True)
        return hint
    if not scored:
        subprocess.run(["open", "-a", "Contacts"], capture_output=True)
        return f"Keinen Kontakt '{name}' gefunden. Ich habe die Kontakte-App geoeffnet."
    person = _choose(scored)
    if person is None:
        return "Mehrere Kontakte passen, frag Lukas welcher: " + "; ".join(p["name"] for _, p in scored[:6]) + "."
    shown = bool(person["id"]) and subprocess.run(
        ["open", f"addressbook://{quote(person['id'], safe=':-')}"], capture_output=True).returncode == 0
    if not shown:
        subprocess.run(["open", "-a", "Contacts"], capture_output=True)
    return f"Kontakt geoeffnet: {_phone_line(person)}."


def _pick_number(person: dict, which: str):
    """Eine Nummer (dict), mehrere zur Auswahl (list) oder None."""
    phones = person["phones"]
    if not phones:
        return None
    if which:
        wanted = _norm(which)
        if len(re.sub(r"\D", "", which)) >= 3:
            hits = [p for p in phones if alltag._digits(p["number"]).endswith(alltag._digits(which))]
        else:
            kind = WHICH.get(wanted.replace(" ", ""), wanted)
            hits = [p for p in phones if (kind == "mobil" and p["label"] in ("Mobil", "iPhone"))
                    or kind in _norm(p["label"])]
        if len(hits) == 1:
            return hits[0]
        if hits:
            return hits
    if len(phones) == 1:
        return phones[0]
    mobile = [p for p in phones if p["label"] in ("Mobil", "iPhone")]
    return mobile[0] if len(mobile) == 1 else phones


def _dial_string(number: str) -> str:
    raw = number.strip()
    digits = re.sub(r"\D", "", raw)
    if raw.startswith("+"):
        return "+" + digits
    if raw.startswith("00"):
        return "+" + digits[2:]
    return digits


def _looks_like_number(text: str) -> bool:
    return bool(re.fullmatch(r"\+?\d{3,20}", re.sub(r"[\s/()\-.]", "", text)))


def call(target: str, which: str = "", facetime: bool = False) -> str:
    """Ruft eine Nummer oder einen Kontakt an (ueber das iPhone; der Mac fragt vorher nach)."""
    target = (target or "").strip()
    if not target:
        return "Wen soll ich anrufen?"
    if _looks_like_number(target):
        name, number = None, target
    else:
        scored, hint = find_contacts(target)
        if scored is None:
            return hint
        if not scored:
            return f"Keinen Kontakt '{target}' gefunden. Sag mir die Nummer oder den genauen Namen."
        person = _choose(scored)
        if person is None:
            return "Mehrere Kontakte passen, frag Lukas wen: " + "; ".join(p["name"] for _, p in scored[:6]) + "."
        choice = _pick_number(person, which)
        if choice is None:
            return f"Bei {person['name']} ist keine Telefonnummer gespeichert."
        if isinstance(choice, list):
            return (f"{person['name']} hat mehrere Nummern, frag Lukas welche: "
                    + ", ".join(f"{p['label']} {p['number']}" for p in choice) + ".")
        name, number = person["name"], choice["number"]
    dial = _dial_string(number)
    if len(dial.lstrip("+")) < 3:
        return f"'{number}' ist keine gueltige Telefonnummer."
    proc = subprocess.run(["open", ("facetime-audio://" if facetime else "tel://") + dial], capture_output=True)
    if proc.returncode != 0:
        return "Der Anruf liess sich nicht starten. Ist auf dem iPhone 'Anrufe auf anderen Geraeten' fuer den Mac an?"
    who = f"{name} ({number})" if name else number
    return (f"Anruf an {who} ist vorbereitet. Am Mac oben rechts auf 'Anrufen' klicken, dann waehlt "
            + ("FaceTime." if facetime else "dein iPhone."))


# ---------------------------------------------------------------- Websites und Programme

def open_website(url: str) -> str:
    text = (url or "").strip()
    if not text:
        return "Welche Seite soll ich oeffnen?"
    if not re.match(r"^[a-z][a-z0-9+.-]*://", text, re.I):
        if text.lower().startswith("localhost"):
            text = "http://" + text
        elif " " in text or "." not in text:  # keine Adresse, sondern ein Suchbegriff
            text = "https://www.google.com/search?q=" + quote(text)
        else:
            text = "https://" + text
    parsed = urlparse(text)
    if parsed.scheme.lower() not in ("http", "https") or not parsed.netloc:
        return "Ich oeffne nur normale Internetseiten (http oder https)."
    if subprocess.run(["open", text], capture_output=True).returncode != 0:
        return f"Konnte {parsed.netloc} nicht oeffnen."
    host = parsed.netloc[4:] if parsed.netloc.startswith("www.") else parsed.netloc
    return f"{host} ist im Browser offen."


APP_DIRS = ["/Applications", "/Applications/Utilities", "/System/Applications", "/System/Applications/Utilities",
            str(Path.home() / "Applications"), "/System/Library/CoreServices/Applications"]
# Deutsche Namen der Apple-Apps (die Programme heissen im Ordner englisch) und gaengige Kurznamen
APP_ALIASES = {
    "rechner": ["Calculator"], "taschenrechner": ["Calculator"], "kontakte": ["Contacts"],
    "adressbuch": ["Contacts"], "kalender": ["Calendar"], "erinnerungen": ["Reminders"], "notizen": ["Notes"],
    "karten": ["Maps"], "apple karten": ["Maps"], "fotos": ["Photos"], "nachrichten": ["Messages"],
    "imessage": ["Messages"], "einstellungen": ["System Settings"], "systemeinstellungen": ["System Settings"],
    "vorschau": ["Preview"], "musik": ["Music"], "apple music": ["Music"], "uhr": ["Clock"], "wetter": ["Weather"],
    "buecher": ["Books"], "aktien": ["Stocks"], "telefon": ["Phone", "FaceTime"], "dateien": ["Finder"],
    "sprachmemos": ["Voice Memos"], "wo ist": ["Find My"], "kurzbefehle": ["Shortcuts"],
    "bildschirmfoto": ["Screenshot"], "aktivitaetsanzeige": ["Activity Monitor"],
    "festplattendienstprogramm": ["Disk Utility"], "schriftsammlung": ["Font Book"], "fotoautomat": ["Photo Booth"],
    "passwoerter": ["Passwords"], "zuhause": ["Home"], "home app": ["Home"], "tv": ["TV"],
    "app store": ["App Store"], "chrome": ["Google Chrome"], "word": ["Microsoft Word"],
    "excel": ["Microsoft Excel"], "powerpoint": ["Microsoft PowerPoint"], "outlook": ["Microsoft Outlook"],
    "teams": ["Microsoft Teams"], "vs code": ["Visual Studio Code"], "vscode": ["Visual Studio Code"],
}


def _installed_apps() -> dict[str, str]:
    apps: dict[str, str] = {}
    for folder in APP_DIRS:
        for path in sorted(glob.glob(os.path.join(folder, "*.app")) + glob.glob(os.path.join(folder, "*", "*.app"))):
            apps.setdefault(_norm(Path(path).stem), path)
    return apps


def find_app(name: str) -> str | None:
    """Pfad der passenden App: genauer Name, deutscher Name, ganze Woerter, Wortanfang, Spotlight."""
    wanted = re.sub(r"^(die|das|den|der) | app$|^app ", "", _norm(name)).strip()
    if not wanted:
        return None
    apps = _installed_apps()
    aliases = APP_ALIASES.get(wanted, [])
    for key in [_norm(a) for a in aliases] + [wanted]:
        if key in apps:
            return apps[key]
    words = wanted.split()
    candidates = [k for k in apps if all(w in k.split() for w in words)] or [k for k in apps if k.startswith(wanted)]
    if candidates:
        return apps[min(candidates, key=len)]
    try:  # Spotlight kennt auch die deutschen Anzeigenamen (z. B. Systemeinstellungen)
        safe = re.sub(r"['\"\\*]", "", name.strip())
        out = subprocess.run(["mdfind", "kMDItemContentType == 'com.apple.application-bundle' && "
                                        f"kMDItemDisplayName == '{safe}*'cd"],
                             capture_output=True, text=True, timeout=8).stdout.splitlines()
        hits = [p for p in out if p.endswith(".app") and "/Library/" not in p.replace(str(Path.home()), "")]
        if hits:
            return min(hits, key=len)
    except (subprocess.SubprocessError, OSError):
        pass
    return aliases[0] if aliases else None  # z. B. Finder liegt nicht bei den Programmen, open -a kennt ihn trotzdem


def open_app(app_name: str) -> str:
    name = (app_name or "").strip()
    if not name:
        return "Welches Programm soll ich oeffnen?"
    target = None
    if subprocess.run(["open", "-a", name], capture_output=True).returncode != 0:
        target = find_app(name)
        if not target or subprocess.run(["open", "-a", target], capture_output=True).returncode != 0:
            return f"Ich finde kein Programm '{name}' auf dem Mac."
    return f"{Path(target).stem if target else name} ist offen."
