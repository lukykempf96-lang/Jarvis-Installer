import base64
import subprocess
import tempfile
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import anthropic
import httpx
from playwright.sync_api import sync_playwright

from . import alltag, claude_code, dashboard, eigene, files, handy, haushalt, karten, planer, system_stats
from .config import settings

_playwright = None
_browser = None
_page = None

# Playwright (sync) darf nur aus dem Thread benutzt werden, der es gestartet hat.
# FastAPI ruft Tools aber aus wechselnden Threads auf, deshalb laeuft alles
# Browser-bezogene in genau diesem einen Thread.
_browser_thread = ThreadPoolExecutor(max_workers=1, thread_name_prefix="jarvis-browser")


def _in_browser_thread(fn):
    def wrapper(*args, **kwargs):
        return _browser_thread.submit(fn, *args, **kwargs).result(timeout=60)
    return wrapper


def _get_page():
    global _playwright, _browser, _page
    if _page is None:
        _playwright = sync_playwright().start()
        _browser = _playwright.chromium.launch(headless=False)
        _page = _browser.new_page()
    return _page


def open_app(app_name: str) -> str:
    # findet auch deutsche Namen (Rechner, Kalender) und ungefaehre Namen
    return planer.open_app(app_name)


@_in_browser_thread
def browser_navigate(url: str) -> str:
    page = _get_page()
    if not url.startswith("http"):
        url = "https://" + url
    page.goto(url, wait_until="domcontentloaded")
    return f"Seite geladen: {page.title()} ({page.url})"


@_in_browser_thread
def browser_click(selector: str) -> str:
    page = _get_page()
    page.click(selector, timeout=5000)
    return f"Element '{selector}' angeklickt."


@_in_browser_thread
def browser_type(selector: str, text: str) -> str:
    page = _get_page()
    page.fill(selector, text, timeout=5000)
    return f"Text in '{selector}' eingegeben."


@_in_browser_thread
def browser_read() -> str:
    page = _get_page()
    return page.inner_text("body")[:4000]


def see_screen(question: str = "Was ist auf dem Bildschirm zu sehen?") -> str:
    tmp_path = Path(tempfile.gettempdir()) / "jarvis_screen.png"
    small_path = Path(tempfile.gettempdir()) / "jarvis_screen.jpg"
    subprocess.run(["screencapture", "-x", str(tmp_path)], check=True)
    # Retina-Screenshots sind mehrere MB gross; verkleinert geht es schneller
    # und bleibt sicher unter dem Bild-Limit der API.
    subprocess.run(
        ["sips", "-Z", "1568", "-s", "format", "jpeg", str(tmp_path), "--out", str(small_path)],
        check=True, capture_output=True,
    )
    image_data = base64.standard_b64encode(small_path.read_bytes()).decode("utf-8")

    client = anthropic.Anthropic(api_key=settings.anthropic_api_key)
    response = client.messages.create(
        model=settings.claude_model,
        max_tokens=500,
        messages=[
            {
                "role": "user",
                "content": [
                    {
                        "type": "image",
                        "source": {
                            "type": "base64",
                            "media_type": "image/jpeg",
                            "data": image_data,
                        },
                    },
                    {"type": "text", "text": question},
                ],
            }
        ],
    )
    return "".join(block.text for block in response.content if block.type == "text")


_WEATHER_CODES = {
    0: "klar", 1: "ueberwiegend klar", 2: "teilweise bewoelkt", 3: "bedeckt",
    45: "Nebel", 48: "Nebel mit Reif", 51: "leichter Nieselregen", 53: "Nieselregen",
    55: "starker Nieselregen", 61: "leichter Regen", 63: "Regen", 65: "starker Regen",
    71: "leichter Schneefall", 73: "Schneefall", 75: "starker Schneefall",
    80: "Regenschauer", 81: "Regenschauer", 82: "heftige Regenschauer",
    95: "Gewitter", 96: "Gewitter mit Hagel", 99: "Gewitter mit Hagel",
}


def get_weather(city: str = "") -> str:
    """Aktuelles Wetter und Tagesvorhersage ueber Open-Meteo (kostenlos, ohne Schluessel)."""
    city = city or settings.weather_city
    geo = httpx.get(
        "https://geocoding-api.open-meteo.com/v1/search",
        params={"name": city, "count": 1, "language": "de"}, timeout=10,
    ).json()
    if not geo.get("results"):
        return f"Ort '{city}' nicht gefunden."
    place = geo["results"][0]
    data = httpx.get(
        "https://api.open-meteo.com/v1/forecast",
        params={
            "latitude": place["latitude"], "longitude": place["longitude"],
            "current": "temperature_2m,apparent_temperature,weather_code,wind_speed_10m",
            "daily": "temperature_2m_max,temperature_2m_min,precipitation_probability_max",
            "timezone": "auto", "forecast_days": 1,
        },
        timeout=10,
    ).json()
    cur, day = data["current"], data["daily"]
    return (
        f"{place['name']}: {cur['temperature_2m']} Grad, gefuehlt {cur['apparent_temperature']} Grad, "
        f"{_WEATHER_CODES.get(cur['weather_code'], 'wechselhaft')}, Wind {cur['wind_speed_10m']} km/h. "
        f"Heute {day['temperature_2m_min'][0]} bis {day['temperature_2m_max'][0]} Grad, "
        f"Regenwahrscheinlichkeit {day['precipitation_probability_max'][0]} Prozent."
    )


def get_daily_overview() -> str:
    """Tagesueberblick: Wetter, Termine, ungelesene Mails und Nachrichten, parallel geholt."""
    parts = {
        "Wetter": lambda: get_weather(),
        "Kalender": lambda: alltag.get_calendar(1),
        "Mails": lambda: alltag.get_mails(2),
        "Nachrichten": lambda: alltag.get_messages(18),
    }
    with ThreadPoolExecutor(max_workers=4) as pool:
        futures = {name: pool.submit(fn) for name, fn in parts.items()}
        out = []
        for name, fut in futures.items():
            try:
                out.append(f"## {name}\n{fut.result(timeout=120)}")
            except Exception as exc:
                out.append(f"## {name}\nNicht verfuegbar ({exc}).")
    return "\n\n".join(out)


TOOLS = [
    {
        "name": "open_app",
        "description": ("Startet ein Programm auf dem Mac, z. B. Spotify, Visual Studio Code, Obsidian, Rechner, "
                        "Kalender oder Systemeinstellungen. Deutsche und ungefaehre Namen gehen auch."),
        "input_schema": {
            "type": "object",
            "properties": {
                "app_name": {"type": "string", "description": "Name des Programms, so wie Lukas ihn sagt"}
            },
            "required": ["app_name"],
        },
    },
    {
        "name": "browser_navigate",
        "description": ("Oeffnet eine URL in einem separaten, von Jarvis gesteuerten Browserfenster (Playwright). "
                        "Nur wenn du auf der Seite selbst klicken oder tippen sollst; zum Anschauen open_website."),
        "input_schema": {
            "type": "object",
            "properties": {"url": {"type": "string"}},
            "required": ["url"],
        },
    },
    {
        "name": "browser_click",
        "description": "Klickt auf ein Element im von Jarvis gesteuerten Browserfenster anhand eines CSS-Selektors.",
        "input_schema": {
            "type": "object",
            "properties": {"selector": {"type": "string"}},
            "required": ["selector"],
        },
    },
    {
        "name": "browser_type",
        "description": "Gibt Text in ein Eingabefeld im von Jarvis gesteuerten Browserfenster ein.",
        "input_schema": {
            "type": "object",
            "properties": {
                "selector": {"type": "string"},
                "text": {"type": "string"},
            },
            "required": ["selector", "text"],
        },
    },
    {
        "name": "browser_read",
        "description": "Liest den sichtbaren Text der aktuellen Seite im von Jarvis gesteuerten Browserfenster.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "get_weather",
        "description": "Holt das aktuelle Wetter und die Vorhersage fuer heute. Ohne Ortsangabe gilt der Wohnort des Nutzers.",
        "input_schema": {
            "type": "object",
            "properties": {"city": {"type": "string", "description": "Stadt, optional"}},
        },
    },
    {
        "name": "get_route",
        "description": "Fahrzeit und Strecke ueber Apple Karten fuer Abfahrt jetzt, mit aktueller Verkehrslage. "
        "Fuer Fragen wie 'Wie lange brauche ich nach Frankfurt?' oder 'Wie lange von Aschaffenburg nach Wuerzburg?'. "
        "Ohne Start gilt Lukas' Zuhause.",
        "input_schema": {
            "type": "object",
            "properties": {
                "destination": {"type": "string", "description": "Ziel: Adresse, Ort oder Name, z.B. 'Frankfurt Flughafen'"},
                "start": {"type": "string", "description": "Startpunkt, leer = Zuhause"},
                "mode": {"type": "string", "enum": ["auto", "zu_fuss", "oepnv"], "description": "Standard: auto"},
                "show": {"type": "boolean", "description": "Route zusaetzlich in der Karten-App zeigen"},
            },
            "required": ["destination"],
        },
    },
    {
        "name": "send_to_phone",
        "description": "Schickt etwas als Mitteilung auf Lukas' iPhone: Route (navigate_to, ein Tipp startet die "
        "Navigation in Apple Karten), Notiz, Einkaufsliste, Zusammenfassung oder Link. Fuer 'schick mir das aufs Handy'.",
        "input_schema": {
            "type": "object",
            "properties": {
                "title": {"type": "string", "description": "Kurzer Titel, z.B. 'Route zum Flughafen' oder 'Einkaufsliste'"},
                "message": {"type": "string", "description": "Der Text, bei Notizen vollstaendig ausformuliert"},
                "navigate_to": {"type": "string", "description": "Ziel fuer die Navigation, nur bei Routen"},
                "navigate_from": {"type": "string", "description": "Start der Route, leer = Zuhause"},
                "mode": {"type": "string", "enum": ["auto", "zu_fuss", "oepnv"]},
                "url": {"type": "string", "description": "Link, der beim Antippen aufgeht (nicht bei Routen)"},
            },
            "required": ["title"],
        },
    },
    {
        "name": "set_home_address",
        "description": "Merkt sich Lukas' Heimadresse als Startpunkt fuer get_route, z.B. wenn er sagt 'Ich wohne in der Hauptstrasse 5'.",
        "input_schema": {
            "type": "object",
            "properties": {"address": {"type": "string", "description": "Strasse, Hausnummer, Ort"}},
            "required": ["address"],
        },
    },
    {
        "name": "see_screen",
        "description": "Macht einen Screenshot des gesamten Bildschirms des Nutzers und beschreibt, was darauf zu sehen ist.",
        "input_schema": {
            "type": "object",
            "properties": {
                "question": {"type": "string", "description": "Was genau auf dem Bildschirm beantwortet werden soll"}
            },
        },
    },
]

TOOLS += [
    {
        "name": "ask_claude_code",
        "description": (
            "Gibt eine Aufgabe an Claude Code auf Lukas' Mac weiter, das im Projektordner arbeitet "
            "(Code schreiben/aendern, Dateien lesen, Fragen zum Projekt beantworten). Laeuft im "
            "Hintergrund; das Ergebnis wird spaeter automatisch vorgelesen. Folgefragen setzen das "
            "letzte Gespraech im Projekt fort."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "project": {"type": "string", "description": "Projektname (z. B. 'Jarvis') oder Ordnerpfad (z. B. '~/Downloads/Website')"},
                "task": {"type": "string", "description": "Auftrag in Lukas' Worten, vollstaendig formuliert"},
                "new_conversation": {"type": "boolean", "description": "true = neues Gespraech statt Fortsetzung"},
            },
            "required": ["project", "task"],
        },
    },
    {
        "name": "open_in_claude",
        "description": (
            "Macht ein Projekt fuer Lukas sichtbar: oeffnet Claude Code im Terminal mit dem bisherigen "
            "Gespraech und zeigt es per Remote Control in der Claude-App (Mac und iPhone, Bereich Code), "
            "wo Lukas mitlesen und weiterschreiben kann. Nutzen, wenn er das Projekt in Claude sehen will."
        ),
        "input_schema": {
            "type": "object",
            "properties": {"project": {"type": "string", "description": "Projektname oder Ordnerpfad"}},
            "required": ["project"],
        },
    },
    {
        "name": "list_projects",
        "description": "Listet die Projekte, an denen Claude Code arbeiten kann.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "create_project",
        "description": "Legt einen neuen, leeren Projektordner fuer Claude Code an.",
        "input_schema": {
            "type": "object",
            "properties": {"name": {"type": "string"}},
            "required": ["name"],
        },
    },
    {
        "name": "find_folder",
        "description": (
            "Sucht einen Ordner auf Lukas' Mac nach Namen oder Pfad (z. B. 'Rechnungen', "
            "'Schreibtisch/Website', '~/Downloads/Fotos'). Gibt passende Pfade zurueck."
        ),
        "input_schema": {
            "type": "object",
            "properties": {"name": {"type": "string"}},
            "required": ["name"],
        },
    },
    {
        "name": "list_folder",
        "description": "Zeigt, was in einem Ordner liegt (Unterordner, Dateien, Groessen, Dateitypen).",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Ordnerpfad, z. B. '~/Projekte/Drohne'"},
                "depth": {"type": "integer", "description": "Wie tief in Unterordner schauen, Standard 2"},
            },
            "required": ["path"],
        },
    },
    {
        "name": "read_file",
        "description": (
            "Liest eine Datei und gibt ihren Inhalt: PDF, Bilder (auch iPhone-Fotos), Text, HTML, Code, "
            "Word, Excel, PowerPoint, Pages-Vorschau. Fuer reingezogene Dateien und Dateien in Ordnern."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Dateipfad, z. B. '~/Jarvis/eingang/.../bericht.pdf'"},
                "start": {"type": "integer", "description": "Bei langen Texten: ab diesem Zeichen weiterlesen"},
            },
            "required": ["path"],
        },
    },
]

TOOLS += [
    {
        "name": "get_daily_overview",
        "description": (
            "Tagesueberblick in einem Schritt: Wetter, heutige Termine, ungelesene Mails und die "
            "Nachrichten (iMessage/SMS) der letzten Stunden. Fuer 'Was steht heute an?', 'Gib mir "
            "einen Ueberblick', 'Guten Morgen'."
        ),
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "get_mails",
        "description": (
            "Ungelesene Mails aus dem Posteingang der Mail-App (alle Konten): Absender, Betreff, "
            "Anfang des Textes, Markierungen. Fuer 'Hab ich neue Mails?', 'Was ist wichtig?'."
        ),
        "input_schema": {
            "type": "object",
            "properties": {"days": {"type": "integer", "description": "Wie viele Tage zurueck, Standard 3"}},
        },
    },
    {
        "name": "read_mail",
        "description": "Liest eine Mail vollstaendig (id aus get_mails), z. B. wenn Lukas fragt, was genau drinsteht.",
        "input_schema": {
            "type": "object",
            "properties": {"id": {"type": "string"}},
            "required": ["id"],
        },
    },
    {
        "name": "open_mail",
        "description": "Oeffnet eine Mail (id aus get_mails) in der Mail-App, damit Lukas sie sieht oder beantwortet.",
        "input_schema": {
            "type": "object",
            "properties": {"id": {"type": "string"}},
            "required": ["id"],
        },
    },
    {
        "name": "get_messages",
        "description": (
            "Unterhaltungen aus der Nachrichten-App (iMessage und SMS, auch vom iPhone): wer geschrieben "
            "hat, ungelesene, wer noch auf Antwort wartet, die letzten Nachrichten je Unterhaltung."
        ),
        "input_schema": {
            "type": "object",
            "properties": {"hours": {"type": "integer", "description": "Wie viele Stunden zurueck, Standard 24"}},
        },
    },
    {
        "name": "get_calendar",
        "description": "Termine aus der Kalender-App (alle Kalender, auch iCloud/Google), ab heute.",
        "input_schema": {
            "type": "object",
            "properties": {"days": {"type": "integer", "description": "1 = heute, 2 = heute und morgen, 7 = Woche"}},
        },
    },
]

_TIME = "Ortszeit als 2026-10-06T14:00; nur ein Datum (2026-10-06) heisst ganztaegig"
TOOLS += [
    {
        "name": "add_calendar_event",
        "description": ("Traegt einen Termin in die Kalender-App ein (kommt per iCloud auch aufs iPhone). "
                        "Rechne Angaben wie 'naechsten Dienstag' mit der aktuellen Zeit selbst in ein Datum um."),
        "input_schema": {
            "type": "object",
            "properties": {
                "title": {"type": "string", "description": "Kurzer Titel, z. B. Zahnarzt"},
                "start": {"type": "string", "description": _TIME},
                "end": {"type": "string", "description": "Ende, gleiches Format (bei ganztaegig: letzter Tag)"},
                "duration_min": {"type": "integer", "description": "Dauer in Minuten, wenn kein Ende genannt (Standard 60)"},
                "location": {"type": "string"},
                "notes": {"type": "string"},
                "calendar": {"type": "string", "description": "Nur wenn Lukas einen bestimmten Kalender nennt"},
                "alert_min": {"type": "integer", "description": "Hinweis so viele Minuten vorher, nur wenn gewuenscht"},
            },
            "required": ["title", "start"],
        },
    },
    {
        "name": "change_calendar_event",
        "description": ("Verschiebt, aendert oder loescht einen vorhandenen Termin, gefunden ueber Woerter aus dem Titel. "
                        "Passen mehrere, kommt eine Liste zurueck: dann Lukas fragen. Loeschen nur, wenn er es sagt."),
        "input_schema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Woerter aus dem Titel, z. B. Zahnarzt"},
                "day": {"type": "string", "description": "Tag des Termins (2026-10-06), wenn bekannt"},
                "new_start": {"type": "string", "description": "Neuer Beginn, " + _TIME + "; Dauer bleibt"},
                "new_end": {"type": "string"},
                "new_day": {"type": "string", "description": "Auf diesen Tag legen, Uhrzeit bleibt"},
                "shift_min": {"type": "integer", "description": "Um so viele Minuten verschieben (minus = frueher)"},
                "new_title": {"type": "string"},
                "new_location": {"type": "string"},
                "delete": {"type": "boolean"},
            },
            "required": ["query"],
        },
    },
    {
        "name": "get_reminder_list",
        "description": ("Liest, was auf einer Liste der Erinnerungen-App offen ist, z. B. der Einkaufsliste. "
                        "Ohne Namen: alle Listen mit den ersten Eintraegen."),
        "input_schema": {
            "type": "object",
            "properties": {"list": {"type": "string", "description": "Name der Liste, z. B. Einkauf"}},
        },
    },
    {
        "name": "add_reminder",
        "description": ("Legt Erinnerungen oder Eintraege auf einer Liste der Erinnerungen-App an (Mac und iPhone), "
                        "z. B. Milch, Brot und Eier auf die Einkaufsliste: dann items und list."),
        "input_schema": {
            "type": "object",
            "properties": {
                "title": {"type": "string", "description": "Ein Eintrag, kurz"},
                "items": {"type": "array", "items": {"type": "string"},
                          "description": "Mehrere Eintraege auf einmal, je ein Ding"},
                "due": {"type": "string", "description": "Wann, " + _TIME + " (dann ohne Uhrzeit); leer = ohne Termin"},
                "list": {"type": "string", "description": "Liste, wenn Lukas eine nennt, z. B. Einkauf"},
                "create_list": {"type": "boolean",
                                "description": "Liste neu anlegen, falls es sie nicht gibt; nur wenn Lukas zugestimmt hat"},
                "notes": {"type": "string"},
            },
        },
    },
    {
        "name": "complete_reminder",
        "description": ("Hakt eine offene Erinnerung oder einen Eintrag ab (z. B. 'Milch hab ich'). "
                        "Mit all=true die ganze genannte Liste."),
        "input_schema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Woerter aus dem Eintrag"},
                "list": {"type": "string"},
                "all": {"type": "boolean", "description": "Alle offenen Eintraege der Liste abhaken"},
            },
        },
    },
    {
        "name": "change_reminder",
        "description": ("Aendert einen offenen Eintrag: umbenennen ('aus Milch mach Hafermilch'), neuer Zeitpunkt, "
                        "auf eine andere Liste legen oder loeschen. Loeschen nur, wenn Lukas es ausdruecklich sagt."),
        "input_schema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Woerter aus dem Eintrag"},
                "list": {"type": "string", "description": "Liste, auf der er steht, wenn bekannt"},
                "new_title": {"type": "string"},
                "due": {"type": "string", "description": "Neuer Zeitpunkt, " + _TIME},
                "move_to": {"type": "string", "description": "Auf diese Liste verschieben"},
                "delete": {"type": "boolean"},
            },
            "required": ["query"],
        },
    },
    {
        "name": "open_contact",
        "description": "Sucht einen Kontakt, zeigt ihn in der Kontakte-App und liefert seine Telefonnummern.",
        "input_schema": {
            "type": "object",
            "properties": {"name": {"type": "string", "description": "Name oder Spitzname, z. B. Mama"}},
            "required": ["name"],
        },
    },
    {
        "name": "call_contact",
        "description": ("Ruft einen Kontakt oder eine Nummer ueber Lukas' iPhone an. Der Mac zeigt dann 'Anrufen' "
                        "zum Bestaetigen. Passen mehrere Kontakte oder Nummern, kommt eine Liste zurueck: Lukas fragen."),
        "input_schema": {
            "type": "object",
            "properties": {
                "target": {"type": "string", "description": "Name aus den Kontakten oder Telefonnummer"},
                "which": {"type": "string", "description": "Welche Nummer, z. B. Handy, privat, Arbeit"},
                "facetime": {"type": "boolean", "description": "Nur wenn Lukas FaceTime sagt"},
            },
            "required": ["target"],
        },
    },
    {
        "name": "open_website",
        "description": ("Oeffnet eine Internetseite in Lukas' normalem Browser zum Anschauen, z. B. youtube.com. "
                        "Ein Suchbegriff ohne Adresse oeffnet die Google-Suche dazu."),
        "input_schema": {
            "type": "object",
            "properties": {"url": {"type": "string", "description": "Adresse wie spiegel.de oder ein Suchbegriff"}},
            "required": ["url"],
        },
    },
]

TOOLS += [
    {
        "name": "get_system_status",
        "description": "Aktuelle Auslastung von Lukas' Mac: CPU, Arbeitsspeicher, Grafik, Festplatte, Akku und welche Programme am meisten Leistung brauchen.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "get_week_load",
        "description": "Wie voll die Woche im Kalender ist: Prozent verplant (Mo-Fr, 8-20 Uhr) und pro Tag.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "set_mail_priority",
        "description": (
            "Speichert Lukas' Mail-Regeln fuers Dashboard: Absender, die immer wichtig sind ('Mails von Tim sind "
            "immer wichtig'), Stichwoerter, die Mails wichtig machen ('Rechnung'), oder Absender, die ausgeblendet "
            "werden ('Zeig mir nichts mehr von Zalando'). Absender als Name, Adresse oder '@domain.de'."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "sender": {"type": "string", "description": "Name, Mailadresse oder @domain"},
                "keyword": {"type": "string", "description": "Stichwort im Betreff oder Text"},
                "hide": {"type": "boolean", "description": "true = Absender ausblenden statt wichtig"},
                "remove": {"type": "boolean", "description": "true = Regel wieder entfernen"},
            },
        },
    },
]

HAUSHALT_ARTEN = ["ausgabe", "einnahme", "sparen", "entnahme"]

TOOLS += [
    {
        "name": "haushalt_buchen",
        "description": (
            "Traegt einzelne Zahlungen ins Haushaltsbuch ein: Einkaeufe und Ausgaben, einmalige Einnahmen, "
            "Geld in einen Spartopf (art sparen) oder aus einem Spartopf (art entnahme). Auch fuer Belege: "
            "Kassenzettel, Rechnungen, Kontoauszuege, Screenshots erst mit read_file lesen, dann hier eintragen; "
            "ein Kassenzettel ist EINE Buchung mit der Gesamtsumme. Doppelte und schon feste Posten erkennt es selbst."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "eintraege": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "betrag": {"type": "number", "description": "Euro, immer positiv"},
                            "text": {"type": "string", "description": "Wofuer, kurz, z. B. 'REWE Einkauf'"},
                            "kategorie": {"type": "string", "description": "Eine der Kategorien, sonst neue"},
                            "art": {"type": "string", "enum": HAUSHALT_ARTEN, "description": "Standard ausgabe"},
                            "datum": {"type": "string", "description": "JJJJ-MM-TT, Standard heute"},
                            "topf": {"type": "string", "description": "Spartopf bei sparen/entnahme, z. B. Urlaubskonto"},
                            "datei": {"type": "string", "description": "Dateiname des Belegs"},
                        },
                        "required": ["betrag", "text"],
                    },
                },
            },
            "required": ["eintraege"],
        },
    },
    {
        "name": "haushalt_fest",
        "description": (
            "Feste, wiederkehrende Posten im Haushaltsbuch anlegen, aendern oder beenden: Gehalt (art einnahme), "
            "Miete, Strom, Auto, Versicherung, Finanzierung, Kredit, Handy, Abos (art ausgabe), Sparen und "
            "Spartoepfe wie Urlaubskonto (art sparen). Gleicher Name = derselbe Posten. Aenderungen gelten ab "
            "diesem Monat, fruehere Monate bleiben. Bei jaehrlich usw. ist ab der Monat der naechsten Abbuchung."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "z. B. Gehalt, Miete, Auto Leasing, Urlaubskonto"},
                "betrag": {"type": "number", "description": "Euro pro Abbuchung"},
                "art": {"type": "string", "enum": ["einnahme", "ausgabe", "sparen"]},
                "kategorie": {"type": "string"},
                "tag": {"type": "integer", "description": "Tag im Monat der Abbuchung oder Gutschrift"},
                "rhythmus": {"type": "string", "enum": ["monatlich", "vierteljaehrlich", "halbjaehrlich", "jaehrlich"]},
                "ab": {"type": "string", "description": "JJJJ-MM, Standard dieser Monat"},
                "bis": {"type": "string", "description": "JJJJ-MM, z. B. letzte Kreditrate"},
                "beenden": {"type": "boolean", "description": "true = faellt ab diesem Monat weg"},
            },
            "required": ["name"],
        },
    },
    {
        "name": "haushalt_aendern",
        "description": "Korrigiert oder loescht eine einzelne Buchung im Haushaltsbuch. Ohne Nummer gilt die zuletzt eingetragene.",
        "input_schema": {
            "type": "object",
            "properties": {
                "id": {"type": "string", "description": "Nummer wie b12 aus haushalt_uebersicht"},
                "loeschen": {"type": "boolean"},
                "betrag": {"type": "number"},
                "text": {"type": "string"},
                "kategorie": {"type": "string"},
                "datum": {"type": "string", "description": "JJJJ-MM-TT"},
                "art": {"type": "string", "enum": HAUSHALT_ARTEN},
            },
        },
    },
    {
        "name": "haushalt_uebersicht",
        "description": (
            "Haushaltsbuch abfragen und zeigen: Einnahmen, feste Kosten, Sparen, Ausgaben, was uebrig ist (auch pro "
            "Tag bis Monatsende), Kategorien mit Budgets, Spartoepfe, anstehende Abbuchungen, feste Posten, letzte "
            "Buchungen mit Nummer. Legt es an, falls es noch keins gibt. zeigen=true oeffnet es gross im "
            "Jarvis-Fenster, zeigen=false schliesst es."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "monat": {"type": "string", "description": "JJJJ-MM, Standard dieser Monat"},
                "zeigen": {"type": "boolean"},
                "kategorie": {"type": "string", "description": "Nur diese Kategorie mit allen Buchungen"},
            },
        },
    },
    {
        "name": "haushalt_einstellen",
        "description": (
            "Haushaltsbuch einrichten: eigene Kategorie anlegen oder entfernen, Monatsbudget fuer eine Kategorie "
            "(z. B. Lebensmittel hoechstens 400 Euro, 0 = kein Budget), Spartopf mit aktuellem Kontostand und Sparziel."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "kategorie_neu": {"type": "string"},
                "kategorie_entfernen": {"type": "string"},
                "budget_kategorie": {"type": "string"},
                "budget": {"type": "number"},
                "topf": {"type": "string", "description": "Name des Spartopfs, z. B. Urlaubskonto"},
                "topf_stand": {"type": "number", "description": "Was jetzt drauf ist"},
                "topf_ziel": {"type": "number"},
            },
        },
    },
]

_DISPATCH = {
    "open_app": lambda i: open_app(i["app_name"]),
    "browser_navigate": lambda i: browser_navigate(i["url"]),
    "browser_click": lambda i: browser_click(i["selector"]),
    "browser_type": lambda i: browser_type(i["selector"], i["text"]),
    "browser_read": lambda i: browser_read(),
    "get_weather": lambda i: get_weather(i.get("city", "")),
    "see_screen": lambda i: see_screen(i.get("question", "Was ist auf dem Bildschirm zu sehen?")),
    "ask_claude_code": lambda i: claude_code.ask_claude_code(i["project"], i["task"], i.get("new_conversation", False)),
    "list_projects": lambda i: claude_code.list_projects(),
    "create_project": lambda i: claude_code.create_project(i["name"]),
    "open_in_claude": lambda i: claude_code.open_in_claude(i["project"]),
    "find_folder": lambda i: files.find_folder(i["name"]),
    "list_folder": lambda i: files.list_folder(i["path"], int(i.get("depth") or 2)),
    "read_file": lambda i: files.read_file(i["path"], int(i.get("start") or 0)),
    "get_daily_overview": lambda i: get_daily_overview(),
    "get_mails": lambda i: alltag.get_mails(int(i.get("days") or 3)),
    "read_mail": lambda i: alltag.read_mail(i["id"]),
    "open_mail": lambda i: alltag.open_mail(i["id"]),
    "get_messages": lambda i: alltag.get_messages(int(i.get("hours") or 24)),
    "get_calendar": lambda i: alltag.get_calendar(int(i.get("days") or 1)),
    "add_calendar_event": lambda i: planer.add_event(
        i.get("title", ""), i.get("start", ""), i.get("end", ""), i.get("duration_min"), i.get("location", ""),
        i.get("notes", ""), i.get("calendar", ""), i.get("alert_min")),
    "change_calendar_event": lambda i: planer.change_event(
        i.get("query", ""), i.get("day", ""), i.get("new_title", ""), i.get("new_start", ""), i.get("new_end", ""),
        i.get("new_day", ""), i.get("shift_min"), i.get("new_location", ""), bool(i.get("delete"))),
    "get_reminder_list": lambda i: planer.get_reminder_list(i.get("list", "")),
    "add_reminder": lambda i: planer.add_reminder(i.get("title", ""), i.get("due", ""), i.get("list", ""),
                                                  i.get("notes", ""), i.get("items"), bool(i.get("create_list"))),
    "complete_reminder": lambda i: planer.complete_reminder(i.get("query", ""), i.get("list", ""), bool(i.get("all"))),
    "change_reminder": lambda i: planer.change_reminder(
        i.get("query", ""), i.get("list", ""), i.get("new_title", ""), i.get("due", ""), i.get("move_to", ""),
        bool(i.get("delete"))),
    "open_contact": lambda i: planer.open_contact(i.get("name", "")),
    "call_contact": lambda i: planer.call(i.get("target", ""), i.get("which", ""), bool(i.get("facetime"))),
    "open_website": lambda i: planer.open_website(i.get("url", "")),
    "get_route": lambda i: karten.route(i["destination"], i.get("start", ""), i.get("mode", "auto"), bool(i.get("show"))),
    "set_home_address": lambda i: karten.set_home_address(i["address"]),
    "send_to_phone": lambda i: handy.send(i.get("title", ""), i.get("message", ""), i.get("url", ""),
                                          i.get("navigate_to", ""), i.get("navigate_from", ""), i.get("mode", "auto")),
    "haushalt_buchen": lambda i: haushalt.book(i.get("eintraege") or [i]),
    "haushalt_fest": lambda i: haushalt.set_fixed(
        i.get("name", ""), i.get("betrag"), i.get("art", ""), i.get("kategorie", ""), i.get("tag"),
        i.get("rhythmus", ""), i.get("ab", ""), i.get("bis", ""), bool(i.get("beenden"))),
    "haushalt_aendern": lambda i: haushalt.change_booking(
        i.get("id", ""), bool(i.get("loeschen")), **{k: i.get(k) for k in ("betrag", "text", "kategorie", "datum", "art")}),
    "haushalt_uebersicht": lambda i: haushalt.tool_overview(i.get("monat", ""), i.get("zeigen"), i.get("kategorie", "")),
    "haushalt_einstellen": lambda i: haushalt.configure(**{k: v for k, v in i.items() if k in (
        "kategorie_neu", "kategorie_entfernen", "budget_kategorie", "budget", "topf", "topf_stand", "topf_ziel")}),
    "get_system_status": lambda i: system_stats.describe(),
    "get_week_load": lambda i: dashboard.describe_week(),
    "set_mail_priority": lambda i: dashboard.set_mail_priority(
        i.get("sender", ""), i.get("keyword", ""), bool(i.get("hide")), bool(i.get("remove"))),
}


def execute_tool(name: str, tool_input: dict):
    handler = _DISPATCH.get(name)
    if handler is None:
        if eigene.has(name):  # selbst gebaute Funktion aus eigene/
            return eigene.run(name, tool_input)
        return f"Unbekanntes Tool: {name}"
    try:
        return handler(tool_input)
    except Exception as exc:
        return f"Fehler bei {name}: {exc}"
