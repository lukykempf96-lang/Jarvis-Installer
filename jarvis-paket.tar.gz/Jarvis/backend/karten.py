"""Fahrzeit und Strecke ueber Apple Karten (MapKit), ohne Konto und ohne Schluessel.

Ein kleines Swift-Programm (backend/karten/JarvisKarten.swift) fragt Apple Karten. install.sh uebersetzt es
einmal; fehlt es, wird es beim ersten Aufruf gebaut. Klappt beides nicht, oeffnet Jarvis die Route in der
Karten-App, dort steht die Fahrzeit dann auf dem Bildschirm.
"""

from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
import threading
from datetime import datetime
from pathlib import Path
from urllib.parse import quote

from .config import settings

JARVIS_DIR = Path(__file__).resolve().parent.parent
SOURCE = JARVIS_DIR / "backend" / "karten" / "JarvisKarten.swift"
PLIST = JARVIS_DIR / "backend" / "karten" / "Info.plist"
BUNDLE = JARVIS_DIR / "tools" / "JarvisKarten.app"
HELPER = BUNDLE / "Contents" / "MacOS" / "JarvisKarten"
STAMP = BUNDLE / "Contents" / "quelle.sha1"
HOME_FILE = JARVIS_DIR / "heimadresse.txt"

MODES = {"auto": ("Mit dem Auto", "d"), "zu_fuss": ("Zu Fuss", "w"), "oepnv": ("Mit Bus und Bahn", "r")}
_build_lock = threading.Lock()


def home_address() -> str:
    try:
        value = HOME_FILE.read_text().strip()
        if value:
            return value
    except OSError:
        pass
    return settings.weather_city


def set_home_address(address: str) -> str:
    address = " ".join(address.split())
    if not address:
        return "Keine Adresse genannt."
    HOME_FILE.write_text(address + "\n")
    return f"Gemerkt: Zuhause ist {address}. Ohne Startpunkt rechne ich ab dort."


def _source_hash() -> str:
    return hashlib.sha1(SOURCE.read_bytes() + PLIST.read_bytes()).hexdigest()


def _ensure_helper() -> str | None:
    """Gibt None zurueck, wenn das Hilfsprogramm bereit ist, sonst den Grund."""
    with _build_lock:
        try:
            if HELPER.exists() and STAMP.read_text().strip() == _source_hash():
                return None
        except OSError:
            pass
        if not shutil.which("swiftc"):
            return "swiftc fehlt (Xcode-Befehlszeilentools)"
        HELPER.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy(PLIST, BUNDLE / "Contents" / "Info.plist")
        result = subprocess.run(
            ["swiftc", "-swift-version", "5", "-O", "-o", str(HELPER), str(SOURCE)],
            capture_output=True, text=True, timeout=300,
        )
        if result.returncode != 0 or not HELPER.exists():
            print(f"Karten-Hilfe liess sich nicht bauen: {result.stderr[-800:]}", flush=True)
            return "Uebersetzen fehlgeschlagen"
        STAMP.write_text(_source_hash() + "\n")
        return None


def maps_link(start: str, destination: str, mode: str = "auto") -> str:
    """Apple-Karten-Link mit Route; oeffnet auf dem iPhone direkt die Karten-App."""
    flag = MODES.get(mode, MODES["auto"])[1]
    return f"https://maps.apple.com/?saddr={quote(start)}&daddr={quote(destination)}&dirflg={flag}"


def _open_in_maps(start: str, destination: str, flag: str):
    url = f"maps://?saddr={quote(start)}&daddr={quote(destination)}&dirflg={flag}"
    subprocess.run(["open", url], capture_output=True)


def _duration(seconds: int) -> str:
    minutes = max(1, round(seconds / 60))
    if minutes < 60:
        return f"{minutes} Minuten" if minutes != 1 else "1 Minute"
    hours, rest = divmod(minutes, 60)
    text = "1 Stunde" if hours == 1 else f"{hours} Stunden"
    if not rest:
        return text
    return f"{text} {rest} Minute" if rest == 1 else f"{text} {rest} Minuten"


def route(destination: str, start: str = "", mode: str = "auto", show: bool = False) -> str:
    destination = destination.strip()
    if not destination:
        return "Kein Ziel genannt."
    start = start.strip() or home_address()
    mode = mode if mode in MODES else "auto"
    how, flag = MODES[mode]
    if show:
        _open_in_maps(start, destination, flag)

    problem = _ensure_helper()
    data: dict = {}
    if problem is None:
        try:
            result = subprocess.run([str(HELPER), start, destination, mode], capture_output=True, text=True, timeout=40)
            lines = [line for line in result.stdout.splitlines() if line.startswith("{")]
            data = json.loads(lines[-1]) if lines else {"ok": False, "error": result.stderr.strip()[-300:] or "keine Antwort"}
        except (subprocess.TimeoutExpired, ValueError, OSError) as exc:
            data = {"ok": False, "error": str(exc)}
        problem = None if data.get("ok") else data.get("error", "unbekannt")

    if problem is not None:
        print(f"Fahrzeit ueber Apple Karten nicht moeglich: {problem}", flush=True)
        if "nicht gefunden" in str(problem):
            return f"Apple Karten findet den Ort nicht ({problem}). Frag Lukas nach einer genaueren Adresse."
        if not show:
            _open_in_maps(start, destination, flag)
        return (f"Die Fahrzeit konnte ich nicht direkt abfragen ({problem}). Ich habe die Route von {start} "
                f"nach {destination} in Apple Karten geoeffnet, dort steht die Fahrzeit mit aktuellem Verkehr.")

    arrival = datetime.fromtimestamp(data["arrival"]).strftime("%H:%M")
    km = data["meters"] / 1000
    distance = f"{km:.0f} Kilometer" if km >= 10 else f"{km:.1f} Kilometer".replace(".", ",")
    via = f", ueber {data['via']}" if data.get("via") else ""
    traffic = " bei der aktuellen Verkehrslage" if mode == "auto" else ""
    return (f"{how} von {data['from']} nach {data['to']}: {_duration(data['seconds'])}{traffic} "
            f"(Abfahrt jetzt, Ankunft gegen {arrival} Uhr), {distance}{via}. Quelle: Apple Karten.")
