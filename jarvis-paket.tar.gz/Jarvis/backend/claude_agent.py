from __future__ import annotations

import re
import time
from datetime import datetime, timedelta
from urllib.parse import urlparse

import anthropic

from . import eigene
from .config import settings
from .tools import TOOLS, execute_tool

_client = None
on_status = None  # main.py: zeigt im Fenster, was Jarvis gerade tut ("Suche im Internet: ...")

MAX_HISTORY = 20

# Schnelles Modell (Haiku) fuer Alltagsfragen, Sonnet fuer alles, was Nachdenken braucht.
# Nach diesen Tools uebernimmt Sonnet, weil es viel Inhalt zu lesen und zu gewichten gibt.
HEAVY_TOOLS = {"read_file", "list_folder", "see_screen", "browser_read", "get_daily_overview",
               "get_mails", "read_mail", "get_messages"}
SMART_WORDS = re.compile(
    r"projekt|claude code|programmier|datei|ordner|analys|erkl(ä|ae)r|warum|wieso|weshalb|vergleich|"
    r"plan|schreib|formulier|(ü|ue)bersetz|zusammenfass|recherch|bildschirm|ich habe dir|denk nach|"
    r"ausf(ü|ue)hrlich|genau|\bsuch|\bgoogle|internet|im netz|online|webseite|website|(ö|oe)ffnungszeit|"
    r"bewertung|in der n(ä|ae)he|neuigkeit|\bnews|\bbau|funktion|erweiter|kannst du lernen",
    re.I,
)


def _web_tools(model: str) -> list[dict]:
    """Internet-Suche und Seiten lesen; laeuft bei Anthropic, kein eigener Schluessel (Suche ca. 1 Cent)."""
    where = {"type": "approximate", "city": settings.weather_city, "country": "DE", "timezone": "Europe/Berlin"}
    if "haiku" in model:  # Haiku kennt nur die einfache Suche
        return [{"type": "web_search_20250305", "name": "web_search", "max_uses": 3, "user_location": where}]
    return [
        {"type": "web_search_20260209", "name": "web_search", "max_uses": 4, "user_location": where},
        {"type": "web_fetch_20260209", "name": "web_fetch", "max_uses": 3, "max_content_tokens": 12000},
    ]


def _get_client():
    global _client
    if _client is None:
        _client = anthropic.Anthropic(api_key=settings.anthropic_api_key)
    return _client


def _trim_history(messages: list[dict]) -> list[dict]:
    """Kuerzt den Verlauf, beginnt aber immer bei einer normalen Nutzer-Nachricht.

    Ein blosses messages[-20:] kann mitten in einem Tool-Aufruf schneiden; die API
    lehnt dann den naechsten Request ab (tool_result ohne passenden tool_use).
    """
    if len(messages) <= MAX_HISTORY:
        return messages
    for start in range(len(messages) - MAX_HISTORY, len(messages)):
        msg = messages[start]
        if msg.get("role") == "user" and isinstance(msg.get("content"), str):
            return messages[start:]
    return messages[-1:]


def _web_note(data: dict) -> dict | None:
    """Suchergebnisse als kurze Notiz im Verlauf, damit Rueckfragen ("schick mir den Link") ohne neue Suche gehen."""
    content = data.get("content")
    if data["type"] == "web_search_tool_result" and isinstance(content, list):
        found = [f"{r.get('title', '')} <{r['url']}>" for r in content if isinstance(r, dict) and r.get("url")][:5]
        return {"type": "text", "text": "(Gefundene Seiten: " + " | ".join(found) + ")"} if found else None
    if data["type"] == "web_fetch_tool_result" and isinstance(content, dict) and content.get("url"):
        return {"type": "text", "text": f"(Gelesene Seite: <{content['url']}>)"}
    return None


def _clean_block(block) -> dict | None:
    """Macht aus SDK-Bloecken schlanke Dicts fuer den Verlauf im Browser.

    Denkbloecke (thinking) fallen weg: Sie gelten bei neueren Modellen nur fuer
    exakt den Verlauf, in dem sie entstanden sind. Da wir den Verlauf kuerzen und
    die Uhrzeit im Systemprompt aktualisieren, wuerde die API sie sonst ablehnen.
    """
    data = block if isinstance(block, dict) else block.model_dump()
    kind = data.get("type")
    if kind == "text":
        return {"type": "text", "text": data["text"]}
    if kind == "tool_use":
        return {"type": "tool_use", "id": data["id"], "name": data["name"], "input": data["input"]}
    if kind == "tool_result":
        content = data.get("content")
        if isinstance(content, list):
            # Bilder und PDFs nicht im Verlauf mitschleppen; bei Bedarf liest Jarvis sie neu
            content = [b if b.get("type") == "text" else
                       {"type": "text", "text": "[Inhalt wurde gelesen; fuer Details read_file erneut aufrufen]"}
                       for b in content]
            return {**data, "content": content}
        return data
    if kind in ("web_search_tool_result", "web_fetch_tool_result"):
        return _web_note(data)
    return None  # server_tool_use, Code-Ausfuehrung der Suche usw.


def _clean_history(messages: list[dict]) -> list[dict]:
    cleaned = []
    for msg in messages:
        content = msg["content"]
        if not isinstance(content, str):
            content = [b for b in (_clean_block(b) for b in content) if b]
            if not content:
                content = [{"type": "text", "text": "..."}]
        cleaned.append({"role": msg["role"], "content": content})
    return _trim_history(cleaned)


_fast_missing = False  # gibt es das schnelle Modell nicht, nicht bei jeder Frage neu probieren


def pick_model(message: str) -> str:
    """Kurze Alltagsfragen (Wetter, Uhrzeit, App oeffnen, Smalltalk) an Haiku, der Rest an Sonnet."""
    if not settings.fast_model or _fast_missing or len(message) > 160 or SMART_WORDS.search(message):
        return settings.claude_model
    return settings.fast_model


def _status_text(block) -> str | None:
    data = block.input if isinstance(getattr(block, "input", None), dict) else {}
    if block.name == "web_search" and data.get("query"):
        return f"Suche im Internet: {data['query']}"
    if block.name == "web_fetch" and data.get("url"):
        host = urlparse(data["url"]).netloc
        return f"Lese {host[4:] if host.startswith('www.') else host} ..."
    return None


def _request(client, **kwargs):
    """Gestreamt, damit das Fenster schon waehrend der Internet-Suche zeigt, wonach Jarvis sucht."""
    with client.messages.stream(**kwargs) as stream:
        for event in stream:
            block = getattr(event, "content_block", None) if event.type == "content_block_stop" else None
            if block is not None and block.type == "server_tool_use" and on_status:
                text = _status_text(block)
                if text:
                    on_status(text)
        return stream.get_final_message()


def _create(client, **kwargs):
    """Mit Effort-Einstellung; lehnt ein aelteres Modell sie ab, ohne."""
    kwargs["tools"] = TOOLS + eigene.tools() + _web_tools(kwargs["model"])
    if "haiku" in kwargs["model"]:  # Haiku kennt keine Denktiefe, und ohne Rueckfrage geht es schneller
        return _request(client, **kwargs)
    try:
        # per extra_body, damit es auch mit aelteren anthropic-Versionen funktioniert
        return _request(client, **kwargs, extra_body={"output_config": {"effort": settings.claude_effort}})
    except anthropic.BadRequestError as exc:
        if "effort" not in str(exc) and "output_config" not in str(exc):
            raise
        return _request(client, **kwargs)


def _spoken_text(content) -> str:
    """Nur die Antwort nach der letzten Suche vorlesen, nicht "Ich schaue kurz nach" davor."""
    after, everything = [], []
    for block in content:
        if block.type == "text":
            after.append(block.text)
            everything.append(block.text)
        else:
            after = []
    return ("".join(after) or "".join(everything)).strip()


def _sources(content) -> list[dict]:
    """Seiten, auf die sich die Antwort stuetzt, als Links fuers Fenster."""
    found: dict[str, str] = {}
    for block in content:
        for cite in getattr(block, "citations", None) or []:
            url = getattr(cite, "url", None)
            if url and url not in found:
                found[url] = getattr(cite, "title", None) or urlparse(url).netloc
    if not found:
        for block in content:
            inner = getattr(block, "content", None) if block.type == "web_fetch_tool_result" else None
            url = getattr(inner, "url", None)
            if url and url not in found:
                found[url] = urlparse(url).netloc
    return [{"title": title, "url": url} for url, title in list(found.items())[:4]]


def friendly_error(exc: Exception) -> str:
    """Macht aus einem Fehler einen kurzen Satz, den Jarvis vorlesen kann."""
    text = str(exc).lower()
    if not settings.anthropic_api_key or isinstance(exc, anthropic.AuthenticationError):
        return "Mein Anthropic-Schluessel fehlt oder wird abgelehnt. Bitte in der Datei .env pruefen."
    if "credit balance" in text or "billing" in text:
        return "Das Guthaben bei Anthropic ist aufgebraucht. Bitte in der Anthropic-Konsole aufladen."
    if isinstance(exc, anthropic.NotFoundError):
        return f"Das Modell {settings.claude_model} gibt es nicht. Bitte CLAUDE_MODEL in der Datei .env pruefen."
    if isinstance(exc, anthropic.APIConnectionError):
        return "Ich erreiche Claude gerade nicht. Ist das Internet verbunden?"
    if isinstance(exc, (anthropic.RateLimitError, anthropic.InternalServerError)):
        return "Claude ist gerade ueberlastet. Bitte gleich noch einmal versuchen."
    return f"Da ist etwas schiefgegangen ({type(exc).__name__}). Details stehen in jarvis-server.log."


DAYS = ["Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag", "Sonntag"]


def _system_prompt() -> str:
    today = datetime.now()
    now = f"{DAYS[today.weekday()]}, {today:%d.%m.%Y, %H:%M} Uhr"
    # Die naechsten Tage mit Datum, damit "naechsten Dienstag" bei Terminen sicher stimmt
    week = ", ".join(f"{DAYS[d.weekday()][:2]} {d:%d.%m.}" for d in (today + timedelta(days=n) for n in range(1, 15)))
    own = eigene.prompt()
    return (f"{settings.system_prompt}\n\nAktuelle Zeit: {now}. Die naechsten Tage: {week} "
            f"Standort (Wetter, Suchen in der Naehe): {settings.weather_city}." + (f"\n\n{own}" if own else ""))


def run_agent(message: str, history: list[dict], sources: list | None = None) -> tuple[str, list[dict]]:
    """sources: wird mit den Webseiten gefuellt, auf die sich die Antwort stuetzt (falls im Internet gesucht)."""
    client = _get_client()
    messages = _clean_history(list(history)) + [{"role": "user", "content": message}]
    system = _system_prompt()  # einmal pro Anfrage, damit er waehrend der Tool-Schleife gleich bleibt
    model = pick_model(message)

    for _ in range(8):
        started = time.monotonic()
        try:
            response = _create(client, model=model, max_tokens=4096, system=system, messages=messages)
        except anthropic.NotFoundError:
            global _fast_missing
            if model == settings.claude_model:
                raise
            _fast_missing = True
            print(f"Modell {model} nicht gefunden, nehme {settings.claude_model}", flush=True)
            model = settings.claude_model
            response = _create(client, model=model, max_tokens=4096, system=system, messages=messages)
        print(f"[{model}] {time.monotonic() - started:.1f} s", flush=True)
        messages.append({"role": "assistant", "content": response.content})

        if response.stop_reason == "pause_turn":
            continue  # lange Internet-Suche: einfach nochmal schicken, der Server macht weiter
        if response.stop_reason != "tool_use":
            reply = _spoken_text(response.content)
            if sources is not None:
                sources.extend(_sources(response.content))
            if not reply.strip():
                reply = "Verzeihung, da ist mir der Faden gerissen. Fragen Sie bitte noch einmal."
            return reply, _clean_history(messages)

        tool_results = []
        for block in response.content:
            if block.type == "tool_use":
                result = execute_tool(block.name, block.input)
                if block.name in HEAVY_TOOLS:
                    model = settings.claude_model
                tool_results.append(
                    {"type": "tool_result", "tool_use_id": block.id, "content": result}
                )
        messages.append({"role": "user", "content": tool_results})

    return "Entschuldige, ich komme gerade zu keiner Antwort.", _clean_history(messages)
