"""Etwas aufs iPhone schicken: Mitteilung ueber die kostenlose App "ntfy", mit Link zum Antippen.

Der Mac schickt an ein geheimes "Thema" auf ntfy.sh; das iPhone hat dieses Thema in der ntfy-App abonniert
und zeigt sofort eine Mitteilung. Ein Tipp darauf oeffnet den Link, bei Routen die Navigation in Apple Karten.
Das Thema ist zufaellig und wird nur auf dem Mac gespeichert; wer es kennt, koennte mitlesen.
"""

from __future__ import annotations

import os
import secrets
from pathlib import Path

import httpx

from . import karten
from .config import settings

JARVIS_DIR = Path(__file__).resolve().parent.parent
TOPIC_FILE = JARVIS_DIR / "handy-thema.txt"
READY_FILE = JARVIS_DIR / "handy-eingerichtet.txt"
# Gut abzutippen: keine Verwechslungen wie l/1 oder o/0
ALPHABET = "abcdefghjkmnpqrstuvwxyz23456789"


def topic() -> str:
    try:
        value = TOPIC_FILE.read_text().strip()
        if value:
            return value
    except OSError:
        pass
    value = "jarvis-" + "".join(secrets.choice(ALPHABET) for _ in range(10))
    TOPIC_FILE.write_text(value + "\n")
    os.chmod(TOPIC_FILE, 0o600)
    return value


def info() -> dict:
    return {"topic": topic(), "server": settings.ntfy_server, "ready": READY_FILE.exists()}


def _publish(payload: dict) -> str | None:
    """Gibt None zurueck, wenn es geklappt hat, sonst den Grund."""
    try:
        resp = httpx.post(settings.ntfy_server, json={"topic": topic(), **payload}, timeout=10)
    except httpx.HTTPError as exc:
        return f"keine Verbindung ({exc.__class__.__name__})"
    if resp.status_code >= 400:
        return f"ntfy meldet Fehler {resp.status_code}"
    return None


def send_test() -> dict:
    problem = _publish({
        "title": "Jarvis ist verbunden",
        "message": "Ab jetzt kann Jarvis dir Routen, Notizen und Links hierher schicken.",
        "tags": ["white_check_mark"],
    })
    if problem:
        return {"ok": False, "text": f"Test nicht gesendet: {problem}."}
    READY_FILE.write_text("ja\n")
    return {"ok": True, "text": "Test gesendet. Kommt gleich eine Mitteilung aufs iPhone, ist alles fertig."}


def send(title: str, message: str = "", url: str = "", navigate_to: str = "", navigate_from: str = "",
         mode: str = "auto") -> str:
    title = " ".join((title or "").split())[:120] or "Jarvis"
    message = (message or "").strip()[:3800]
    payload: dict = {"title": title, "message": message or title, "tags": ["memo"]}
    label = "Öffnen"
    if navigate_to.strip():
        start = navigate_from.strip() or karten.home_address()
        url = karten.maps_link(start, navigate_to.strip(), mode)
        payload["tags"] = ["world_map"]
        if not message:
            payload["message"] = f"Route von {start} nach {navigate_to.strip()}. Tippen startet Apple Karten."
        label = "Navigation starten"
    if url.strip():
        payload["click"] = url.strip()
        payload["actions"] = [{"action": "view", "label": label, "url": url.strip()}]

    problem = _publish(payload)
    if problem:
        return f"Konnte nichts aufs Handy schicken: {problem}. Ist der Mac online?"
    text = "Ist unterwegs aufs iPhone"
    text += ", ein Tipp auf die Mitteilung startet die Navigation." if navigate_to.strip() else "."
    if not READY_FILE.exists():
        text += (" Hinweis fuer Lukas: Falls nichts ankommt, im Jarvis-Fenster bei 'Mac' auf 'iPhone' klicken "
                 "und die Einrichtung machen (App ntfy, Thema eintragen).")
    return text
