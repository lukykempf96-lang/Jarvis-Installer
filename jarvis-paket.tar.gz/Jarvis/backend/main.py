from __future__ import annotations

import asyncio
import json
import re
import subprocess
import tempfile
import threading
import time
from datetime import datetime
from pathlib import Path

from fastapi import FastAPI, Request, Response, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from . import alltag, anzeige, claude_code, dashboard, eigene, fenster, files, handy, haushalt, system_stats
from . import claude_agent
from .claude_agent import friendly_error, run_agent
from .config import settings
from .tts import synthesize_speech

BASE_DIR = Path(__file__).resolve().parent.parent
FRONTEND_DIR = BASE_DIR / "frontend"
try:
    VERSION = (BASE_DIR / "VERSION").read_text().strip()
except OSError:
    VERSION = "0"


class NoCache:
    """ASGI-Middleware: Chrome soll Fenster-Dateien nie ungefragt aus dem Zwischenspeicher nehmen.
    Sonst laeuft nach einem Update im Browser noch der alte Stand weiter."""

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http" or scope["path"].startswith("/api/"):
            return await self.app(scope, receive, send)

        async def send_no_cache(message):
            if message["type"] == "http.response.start":
                headers = [h for h in message.get("headers", []) if h[0].lower() != b"cache-control"]
                no_store = any(h[0].lower() == b"cache-control" and b"no-store" in h[1] for h in message.get("headers", []))
                headers.append((b"cache-control", b"no-store" if no_store else b"no-cache"))
                message = dict(message, headers=headers)
            await send(message)

        await self.app(scope, receive, send_no_cache)


app = FastAPI(title="Jarvis")
app.add_middleware(NoCache)
app.add_middleware(anzeige.LanGuard)

_ws_connections: list[WebSocket] = []
_displays: list[WebSocket] = []  # Anzeige-Geraete im WLAN: bekommen alles mit, steuern nichts
_ws_states: dict[int, tuple] = {}  # je Tab: (Zustand, seit wann) - idle / listening / thinking / speaking
BUSY_TIMEOUT = 60  # haengt ein Tab laenger in einem Zustand, gilt er wieder als frei
_startup_lock = threading.Lock()
_speaking_locally = threading.Event()
# Nur ein Jarvis-Tab ist aktiv (hoert zu, spricht): der zuletzt geoeffnete. Weitere Tabs werden stumm
# geschaltet und, wenn Chrome es erlaubt, geschlossen. Je Verbindung: [Tab-Kennung, geoeffnet um]
_tab_info: dict[int, list] = {}
_closing_tabs: set[str] = set()
_last_connect = [0.0]
# Tabs mit altem Stand werden zum Neuladen aufgefordert, aber nie in einer Schleife
_old_tab_reloads = [0]
OLD_TAB_RELOADS = 4
_version_reloaded: set[str] = set()
# Nie zwei Stimmen gleichzeitig: wer spricht, spricht zu Ende (oder wird gestoppt), dann der Naechste
_speech_lock = threading.Lock()
_stop_count = [0]

GREETING_PROMPT = (
    "Ich habe dich gerade per Doppelklatschen geweckt. Begruesse mich passend zur Tageszeit und "
    "gib mir mit get_daily_overview einen kurzen Tagesueberblick: Wetter, naechster Termin und das "
    "Wichtigste aus Mails und Nachrichten. Fehlt dir eine Erlaubnis, sag in einem Satz, was ich "
    "einschalten muss. Hoechstens vier Saetze."
)


class ChatRequest(BaseModel):
    message: str
    history: list[dict] = []


class SpeakRequest(BaseModel):
    text: str
    tab: str = ""


_loop: asyncio.AbstractEventLoop | None = None


@app.on_event("startup")
async def _on_startup():
    global _loop
    _loop = asyncio.get_running_loop()
    claude_code.on_done = _announce
    claude_code.on_progress = _work_progress
    haushalt.on_change = _haushalt_changed
    claude_agent.on_status = _agent_status
    claude_code.on_self_change = _self_changed
    eigene.load()
    threading.Thread(target=_watch_eigene, daemon=True).start()
    # Begruessungen vorab erzeugen, damit "Hey Jarvis" sofort antwortet
    threading.Thread(target=_prepare_greetings, daemon=True).start()


async def _broadcast(message: dict):
    for ws in list(_ws_connections) + list(_displays):
        try:
            await ws.send_json(message)
        except Exception:
            pass


async def _to_displays(message: dict):
    for ws in list(_displays):
        try:
            await ws.send_json(message)
        except Exception:
            pass


def _to_displays_threadsafe(message: dict):
    if _loop and _displays:
        asyncio.run_coroutine_threadsafe(_to_displays(message), _loop)


async def _to_local(message: dict):
    """Nur an die Jarvis-Fenster auf dem Mac, nie an Anzeige-Geraete im WLAN (z. B. Haushaltsbuch)."""
    for ws in list(_ws_connections):
        try:
            await ws.send_json(message)
        except Exception:
            pass


def _agent_status(text: str):
    """Was Jarvis gerade tut, z. B. "Suche im Internet: Fitnessstudio Aschaffenburg" (Fenster und Anzeige)."""
    if _loop:
        asyncio.run_coroutine_threadsafe(_broadcast({"type": "status", "text": text}), _loop)


def _haushalt_changed(event: dict):
    if _loop:
        asyncio.run_coroutine_threadsafe(_to_local({"type": "haushalt", **event}), _loop)


# ---------- Selbst gebaute Funktionen (eigene/) ----------

_eigene_frontend: dict = {}


def _reload_eigene() -> dict:
    """Laedt eigene/ neu; haben sich Fenster-Bausteine geaendert, laedt sich das Jarvis-Fenster neu."""
    global _eigene_frontend
    report = eigene.load()
    frontend = eigene.frontend_files()
    if frontend != _eigene_frontend:
        _eigene_frontend = frontend
        if _loop:
            asyncio.run_coroutine_threadsafe(_to_local({"type": "eigene", "reload": True}), _loop)
    return report


def _watch_eigene():
    """Merkt, wenn sich etwas in eigene/ aendert (auch wenn Lukas Claude Code direkt nutzt)."""
    global _eigene_frontend
    _eigene_frontend = eigene.frontend_files()
    seen = eigene.fingerprint()
    while True:
        time.sleep(2)
        try:
            now = eigene.fingerprint()
            if now == seen:
                continue
            time.sleep(1.5)  # Claude Code schreibt evtl. noch
            if eigene.fingerprint() != now:
                continue
            seen = now
            _reload_eigene()
        except Exception as exc:
            print(f"eigene/ beobachten: {exc!r}", flush=True)


def _self_changed(text: str) -> str:
    """Claude Code hat im Projekt Jarvis gearbeitet: sofort neu laden und Fehler gleich mitsagen."""
    report = _reload_eigene()
    if report["fehler"]:
        names = ", ".join(n.rsplit(".", 1)[0] for n in report["fehler"])
        text += f" Achtung: In {names} steckt noch ein Fehler, das funktioniert so noch nicht."
    return text


def _current_state() -> str:
    if _speaking_locally.is_set():
        return "speaking"
    states = [state for state, _ in _ws_states.values() if state != "idle"]
    return states[0] if states else "idle"


def _announce(text: str):
    """Meldung aus dem Hintergrund (z. B. Claude Code fertig): anzeigen und vorlesen, sobald Jarvis frei ist."""
    print(f"Meldung: {text}", flush=True)
    if _loop:
        asyncio.run_coroutine_threadsafe(_broadcast({"type": "notice", "text": text}), _loop)
    for _ in range(600):  # hoechstens 10 Minuten warten, nie mitten ins Gespraech sprechen
        if not _jarvis_busy():
            # Das Gehirn im Browser soll mitsprechen
            if _loop:
                asyncio.run_coroutine_threadsafe(_broadcast({"type": "say", "on": True, "text": text}), _loop)
            _speak_locally(text)
            if _loop:
                asyncio.run_coroutine_threadsafe(
                    _broadcast({"type": "say", "on": False, "interrupted": _interrupted.is_set()}), _loop)
            return
        time.sleep(1)


# Arbeitsfenster: was Claude Code gerade tut, je Projekt die letzten Schritte
_work: dict[str, dict] = {}


def _work_progress(project: str, text: str, done: bool = False):
    entry = _work.setdefault(project, {"project": project, "lines": [], "running": True})
    entry["lines"] = (entry["lines"] + [text])[-40:]
    entry["running"] = not done
    entry["updated"] = time.time()
    if _loop:
        asyncio.run_coroutine_threadsafe(
            _broadcast({"type": "work", "project": project, "text": text, "done": done}), _loop)


@app.get("/api/work")
def work():
    return sorted(_work.values(), key=lambda e: -e.get("updated", 0))[:6]


@app.post("/api/open")
def open_project(project: str):
    """Knopf "In Claude oeffnen" im Arbeitsfenster."""
    return {"text": claude_code.open_in_claude(project)}


@app.post("/api/upload")
async def upload(request: Request, batch: str, path: str):
    """Eine reingezogene Datei; der Browser schickt sie roh, ohne Formular."""
    return await files.save_upload(batch, path, request.stream())


@app.post("/api/upload/done")
def upload_done(batch: str):
    return files.finish_batch(batch)


# ---------- Dashboard ----------

PRIVACY_PANES = {"Privacy_Automation", "Privacy_Calendars", "Privacy_Reminders", "Privacy_AllFiles"}


@app.get("/api/system")
def system():
    """Live-Auslastung, der Browser fragt alle 2 Sekunden."""
    return system_stats.snapshot()


@app.get("/api/dashboard")
def dashboard_data(refresh: bool = False):
    return dashboard.get(force=refresh)


@app.get("/api/priorities")
def priorities():
    return dashboard.load_priorities()


@app.post("/api/priorities")
def save_priorities(data: dict):
    return dashboard.save_priorities(data)


@app.post("/api/mail/open")
def mail_open(id: str):
    return {"text": alltag.open_mail(id)}


@app.post("/api/privacy")
def privacy(pane: str):
    """Knopf "Einstellung oeffnen" bei fehlender Erlaubnis."""
    if pane in PRIVACY_PANES:
        subprocess.run(["open", f"x-apple.systempreferences:com.apple.preference.security?{pane}"], capture_output=True)
    return {"ok": pane in PRIVACY_PANES}


@app.post("/api/chat")
def chat(req: ChatRequest):
    _to_displays_threadsafe({"type": "chat", "user": req.message})
    sources: list = []
    try:
        reply, history = run_agent(req.message, req.history, sources)
    except Exception as exc:
        print(f"Fehler bei Claude: {exc!r}", flush=True)
        reply, history = friendly_error(exc), req.history
    _to_displays_threadsafe({"type": "chat", "reply": reply})
    return {"reply": reply, "history": history, "sources": sources}


# ---------- Haushaltsbuch (nur vom Mac aus, die Anzeige im WLAN bekommt es nicht) ----------

@app.get("/api/haushalt")
def haushalt_view(monat: str = ""):
    return haushalt.view(monat)


@app.post("/api/haushalt")
def haushalt_apply(action: dict):
    return haushalt.apply(action)


# ---------- Selbst gebaute Funktionen (nur vom Mac aus) ----------

@app.get("/api/eigene")
def eigene_list():
    return eigene.frontend_files()


@app.get("/eigene/{name}")
def eigene_file(name: str):
    path = eigene.frontend_file(name)
    if path is None:
        return Response(status_code=404)
    kind = "text/css" if path.suffix == ".css" else "text/javascript"
    return FileResponse(path, media_type=kind, headers={"Cache-Control": "no-store"})


@app.api_route("/api/eigene/{module}/{name}", methods=["GET", "POST"])
async def eigene_api(module: str, name: str, request: Request):
    data = dict(request.query_params)
    if request.method == "POST":
        try:
            body = await request.json()
        except ValueError:
            body = {}
        if isinstance(body, dict):
            data.update(body)
    status, result = await asyncio.to_thread(eigene.call_api, module, name, data)
    return Response(json.dumps(result, ensure_ascii=False, default=str), status_code=status,
                    media_type="application/json")


# ---------- iPhone-Mitteilungen ----------

@app.get("/api/handy")
def handy_info():
    return handy.info()


@app.post("/api/handy/test")
def handy_test():
    return handy.send_test()


# ---------- Anzeige auf einem zweiten Geraet ----------

@app.get("/anzeige")
def anzeige_page():
    return _page("anzeige.html")


@app.get("/api/anzeige")
def anzeige_link(request: Request):
    """Fuer den Knopf "Anzeige" im Jarvis-Fenster (nur vom Mac aus erreichbar)."""
    info = anzeige.link(request.url.port)
    info["qr"] = anzeige.qr_svg(info["url"]) if info["url"] else None
    return info


@app.post("/api/speak")
def speak(req: SpeakRequest):
    result = synthesize_speech(req.text)
    if result is None:
        return Response(status_code=204)
    audio, media_type = result
    return Response(content=audio, media_type=media_type)


@app.websocket("/ws")
async def ws_endpoint(websocket: WebSocket):
    await websocket.accept()
    if not anzeige.is_local(websocket.scope) or websocket.query_params.get("rolle") == "anzeige":
        await _display_socket(websocket)
        return
    _ws_connections.append(websocket)
    _ws_states[id(websocket)] = ("idle", time.monotonic())
    _last_connect[0] = time.monotonic()
    asyncio.get_running_loop().call_later(3, lambda: asyncio.ensure_future(_refresh_old_tab(websocket)))
    try:
        while True:
            text = await websocket.receive_text()
            try:
                data = json.loads(text)
            except ValueError:
                continue
            if data.get("type") == "state":
                _ws_states[id(websocket)] = (data.get("state", "idle"), time.monotonic())
                await _to_displays({"type": "state", "state": _current_state()})
            elif data.get("type") == "hello":
                tab = str(data.get("tab") or "")[:40]
                try:
                    opened = float(data.get("opened") or 0)
                except (TypeError, ValueError):
                    opened = 0.0
                _tab_info[id(websocket)] = [tab, opened]
                await _assign_roles()
                if str(data.get("version") or "") != VERSION and tab not in _version_reloaded:
                    # Tab laeuft noch mit dem Stand vor dem Update: einmal neu laden (die Seite holt dann den neuen)
                    _version_reloaded.add(tab)
                    await _ask_reload(websocket)
            elif data.get("type") == "claim":  # "Jarvis hier benutzen" in einem stummen Tab
                _tab_info.setdefault(id(websocket), ["", 0.0])[1] = time.time() * 1000
                await _assign_roles()
    except WebSocketDisconnect:
        pass
    finally:
        if websocket in _ws_connections:
            _ws_connections.remove(websocket)
        _ws_states.pop(id(websocket), None)
        _tab_info.pop(id(websocket), None)
        await _assign_roles()


def _active_ws() -> WebSocket | None:
    """Der zuletzt geoeffnete Jarvis-Tab; bei Gleichstand der zuletzt verbundene."""
    best, best_opened = None, -1.0
    for ws in list(_ws_connections):
        opened = _tab_info.get(id(ws), ["", 0.0])[1]
        if opened >= best_opened:
            best, best_opened = ws, opened
    return best


def _active_tab_id() -> str:
    active = _active_ws()
    return _tab_info.get(id(active), [""])[0] if active is not None else ""


async def _assign_roles():
    """Sagt jedem Tab, ob er aktiv ist. Stumme Tabs mit eigener Kennung schliesst Chrome, wenn erlaubt."""
    active = _active_ws()
    active_tab = _active_tab_id()
    for ws in list(_ws_connections):
        try:
            await ws.send_json({"type": "role", "active": ws is active})
        except Exception:
            continue
        tab = _tab_info.get(id(ws), [""])[0]
        if ws is not active and tab and tab != active_tab and tab not in _closing_tabs:
            _closing_tabs.add(tab)
            print("Zweites Jarvis-Fenster erkannt, es wird stumm geschaltet und geschlossen.", flush=True)
            threading.Thread(target=fenster.close_tab, args=(tab,), daemon=True).start()


async def _refresh_old_tab(websocket: WebSocket):
    """Ein Tab mit altem Stand (vor dem Update) meldet sich nicht an: neu laden lassen, sobald er frei ist."""
    if websocket not in _ws_connections or id(websocket) in _tab_info:
        return
    # Nur ein paar Mal je Start: hilft Neuladen nicht, bleibt der Tab einfach, wie er ist (nie eine Schleife)
    _old_tab_reloads[0] += 1
    if _old_tab_reloads[0] > OLD_TAB_RELOADS:
        if _old_tab_reloads[0] == OLD_TAB_RELOADS + 1:
            print("Ein Jarvis-Tab hat noch einen alten Stand. Im Tab Cmd+Shift+R druecken.", flush=True)
        return
    await _ask_reload(websocket)


async def _ask_reload(websocket: WebSocket):
    try:
        await websocket.send_json({"type": "eigene", "reload": True})
    except Exception:
        pass


async def _display_socket(websocket: WebSocket):
    """Anzeige-Geraet: bekommt Zustand, Fragen und Antworten; was es schickt, wird ignoriert."""
    _displays.append(websocket)
    try:
        await websocket.send_json({"type": "state", "state": _current_state()})
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        pass
    finally:
        if websocket in _displays:
            _displays.remove(websocket)


def _jarvis_busy() -> bool:
    """Spricht, denkt oder hoert Jarvis gerade? Dann wird Klatschen ignoriert."""
    if _speaking_locally.is_set() or _startup_lock.locked():
        return True
    now = time.monotonic()
    return any(state != "idle" and now - since < BUSY_TIMEOUT for state, since in _ws_states.values())


@app.get("/api/health")
def health():
    return {"ok": True, "tabs": len(_ws_connections), "displays": len(_displays), "busy": _jarvis_busy()}


async def _notify_listen() -> int:
    """Nur der aktive Tab hoert zu, sonst antworten zwei Fenster gleichzeitig."""
    active = _active_ws()
    if active is None:
        return 0
    try:
        await active.send_json({"type": "listen"})
    except Exception:
        if active in _ws_connections:
            _ws_connections.remove(active)
        _ws_states.pop(id(active), None)
        _tab_info.pop(id(active), None)
        return 0
    return 1


@app.post("/api/trigger-listen")
async def trigger_listen():
    return {"notified": await _notify_listen()}


_player: subprocess.Popen | None = None
_interrupted = threading.Event()
_speaking_text = ""


def _stop_speaking() -> bool:
    """"Jarvis, stopp": laufende Sprachausgabe sofort abbrechen (und wartende Ansagen verwerfen)."""
    if not _speaking_locally.is_set():
        return False
    _stop_count[0] += 1
    _interrupted.set()
    player = _player
    if player and player.poll() is None:
        player.terminate()
    return True


def _speak_locally(text: str, cache: bool = False) -> bool:
    """Spricht direkt ueber die Mac-Lautsprecher (kein Browser-Autoplay-Problem)."""
    global _player, _speaking_text
    stops = _stop_count[0]
    if not _speech_lock.acquire(timeout=300):
        return False
    if _stop_count[0] != stops:  # waehrend des Wartens kam "stopp": nicht hinterherreden
        _speech_lock.release()
        return True
    _interrupted.clear()
    _speaking_text = text
    _speaking_locally.set()
    try:
        result = synthesize_speech(text, cache=cache)
        if not result:
            return False
        if _interrupted.is_set():  # schon waehrend die Stimme erzeugt wurde gestoppt
            return True
        audio, media_type = result
        suffix = ".mp3" if media_type == "audio/mpeg" else ".m4a"
        with tempfile.NamedTemporaryFile(prefix="jarvis_", suffix=suffix, delete=False) as f:
            f.write(audio)
        try:
            _player = subprocess.Popen(["afplay", f.name])
            if _interrupted.is_set():  # Stopp kam genau beim Start
                _player.terminate()
            _player.wait()
        finally:
            _player = None
            Path(f.name).unlink(missing_ok=True)
        return True
    finally:
        _speaking_locally.clear()
        _speech_lock.release()


@app.post("/api/say")
def say(req: SpeakRequest):
    """Antwort ueber die Mac-Lautsprecher abspielen; kehrt zurueck, wenn Jarvis fertig gesprochen hat.

    Chrome blockiert Ton aus Tabs, in die nie geklickt wurde (Autoplay-Regel). Dann blieb Jarvis
    im Zustand "spricht" haengen und reagierte nicht mehr aufs Klatschen.
    """
    active = _active_tab_id()
    if req.tab and active and req.tab != active:  # ein stummer zweiter Tab spricht nie
        return {"ok": True, "interrupted": False, "skipped": True}
    ok = _speak_locally(req.text)
    return {"ok": ok, "interrupted": _interrupted.is_set()}


@app.post("/api/stop")
def stop():
    """Vom Browser, wenn er waehrend der Antwort "Jarvis, stopp" hoert."""
    return {"stopped": _stop_speaking()}


def _greeting(hour: int | None = None) -> str:
    hour = datetime.now().hour if hour is None else hour
    hello = ("Guten Morgen" if 5 <= hour < 11 else "Guten Tag" if 11 <= hour < 17
             else "Guten Abend" if 17 <= hour < 23 else "Hallo")
    return f"{hello}, {settings.user_name}. Was kann ich für dich tun?"


def _prepare_greetings():
    for hour in (8, 12, 18, 23):
        try:
            synthesize_speech(_greeting(hour), cache=True)
        except Exception as exc:
            print(f"Begruessung vorbereiten fehlgeschlagen: {exc!r}", flush=True)
            return


def _startup_session(loop: asyncio.AbstractEventLoop, source: str = "clap"):
    """Klatschen wie im Video: Apps starten, Oberflaeche oeffnen, mit Ueberblick begruessen.
    "Hey Jarvis": nur Oberflaeche oeffnen, sofort kurz begruessen und zuhoeren."""
    if not _startup_lock.acquire(blocking=False):
        return
    try:
        url = f"http://localhost:{settings.port}"
        if source == "wake":
            # vorhandenen Jarvis-Tab nehmen statt einen zweiten zu oeffnen (laeuft neben der Begruessung)
            threading.Thread(target=fenster.open_jarvis, args=(url,), daemon=True).start()
            greeting = _greeting()
        else:
            for app_name in settings.startup_apps:
                subprocess.run(["open", "-a", app_name], capture_output=True)
            fenster.open_jarvis(url)
            try:
                greeting, _ = run_agent(GREETING_PROMPT, [])
            except Exception as exc:
                print(f"Begruessung fehlgeschlagen: {exc!r}", flush=True)
                greeting = friendly_error(exc)
        print(f"Jarvis: {greeting}", flush=True)
        _speak_locally(greeting, cache=source == "wake")
        # Chrome braucht beim ersten Start etwas; zuhoeren, sobald das Fenster verbunden ist
        deadline = time.monotonic() + 20
        while not _ws_connections and time.monotonic() < deadline:
            time.sleep(0.2)
        # Stellt Chrome alte Tabs wieder her, melden die sich kurz nacheinander: erst danach zuhoeren,
        # damit nur der richtige Tab das Mikrofon bekommt
        settle = time.monotonic() + 4
        while time.monotonic() < settle and (time.monotonic() - _last_connect[0] < 1.0
                                             or any(id(ws) not in _tab_info for ws in list(_ws_connections))):
            time.sleep(0.1)
        asyncio.run_coroutine_threadsafe(_notify_listen(), loop)
    finally:
        _startup_lock.release()


def _signal_listening():
    """Kurzer Ton: Er hoert jetzt zu. (Das Fenster bleibt, wo es ist, damit Chrome nie den Fokus klaut.)"""
    subprocess.Popen(["afplay", "/System/Library/Sounds/Tink.aiff"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


@app.post("/api/cue")
def cue():
    """Kurzer Ton: Jarvis hoert im Gespraech wieder zu."""
    subprocess.Popen(["afplay", "/System/Library/Sounds/Tink.aiff"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return {"ok": True}


@app.post("/api/clap")
async def clap(source: str = "clap"):
    """Doppelklatschen oder "Hey Jarvis": Ist Jarvis schon offen, hoert er zu. Sonst startet die ganze Session."""
    # "Hey Jarvis" mitten in seiner Antwort unterbricht ihn; der Browser hoert danach zu.
    # Klatschen nicht, das loest sonst auch Musik oder seine eigene Stimme aus.
    # Sagt er selbst "Jarvis", koennte das Wake-Wort auf seine eigene Stimme reagieren; dann gilt nur "stopp".
    if source == "wake" and "jarvis" not in _speaking_text.lower() and _stop_speaking():
        return {"action": "stopped"}
    if _jarvis_busy():
        return {"action": "ignored", "reason": "Jarvis ist gerade beschaeftigt"}
    if _active_ws() is not None:
        _signal_listening()
        return {"action": "listen", "notified": await _notify_listen()}
    loop = asyncio.get_running_loop()
    threading.Thread(target=_startup_session, args=(loop, source), daemon=True).start()
    return {"action": "startup"}


@app.post("/api/show")
async def show_window():
    """Jarvis.command ein zweites Mal geoeffnet: kein zweiter Jarvis, nur das Fenster nach vorne holen."""
    if _active_ws() is not None:
        threading.Thread(target=fenster.show, args=(_active_tab_id(),), daemon=True).start()
        return {"action": "show"}
    url = f"http://localhost:{settings.port}"
    threading.Thread(target=fenster.open_jarvis, args=(url,), daemon=True).start()
    return {"action": "open"}


_ASSET = re.compile(r'(src|href)="([\w-]+\.(?:js|css))"')


def _page(name: str) -> HTMLResponse:
    """Seite mit Versionsnummer an Skripten und Styles: nach einem Update laedt Chrome garantiert den neuen Stand."""
    html = (FRONTEND_DIR / name).read_text(encoding="utf-8")
    html = _ASSET.sub(lambda m: f'{m.group(1)}="{m.group(2)}?v={VERSION}"', html)
    return HTMLResponse(html, headers={"Cache-Control": "no-cache"})


@app.get("/")
@app.get("/index.html")
def index_page():
    return _page("index.html")


app.mount("/", StaticFiles(directory=FRONTEND_DIR, html=True), name="frontend")
