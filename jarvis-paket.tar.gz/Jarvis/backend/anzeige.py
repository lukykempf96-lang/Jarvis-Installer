"""Zweites Geraet als Anzeige (z. B. ein altes Handy an der Wand): Gehirn und Dashboard ansehen, nichts steuern.

Der Server ist dafuer im WLAN erreichbar. Andere Geraete duerfen aber nur die Anzeige-Seite und das
Dashboard lesen, und nur mit dem Schluessel aus dem QR-Code. Alles andere (Chat, Apps oeffnen, Mails
oeffnen, Claude Code, Dateien) geht weiterhin nur vom Mac selbst.
"""

from __future__ import annotations

import os
import secrets
import socket
from http.cookies import SimpleCookie
from pathlib import Path
from urllib.parse import parse_qs

from .config import settings

KEY_FILE = Path(__file__).resolve().parent.parent / "anzeige-schluessel.txt"
COOKIE = "jarvis_anzeige"
LOCAL_HOSTS = {"127.0.0.1", "::1", "localhost"}

# Was ein anderes Geraet abrufen darf (nur lesen)
REMOTE_PATHS = {
    "/anzeige", "/anzeige.html", "/anzeige.js", "/anzeige.css", "/style.css", "/brain.js",
    "/favicon.ico", "/api/system", "/api/dashboard", "/api/work",
}

DENIED_PAGE = """<!DOCTYPE html><html lang="de"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>Jarvis</title></head>
<body style="background:#0a0e17;color:#e6ecff;font-family:sans-serif;display:grid;place-items:center;
min-height:100vh;margin:0;padding:16px;text-align:center"><div><h2 style="color:#5ec8ff">Jarvis-Anzeige</h2>
<p>Dieses Geraet ist nicht freigegeben.</p><p>Am Mac im Jarvis-Fenster auf <b>Anzeige</b> klicken
und den QR-Code mit diesem Geraet scannen.</p></div></body></html>"""


def key() -> str:
    """Zufaelliger Schluessel, einmal erzeugt und auf dem Mac gespeichert (steckt im QR-Code)."""
    try:
        value = KEY_FILE.read_text().strip()
        if len(value) >= 16:
            return value
    except OSError:
        pass
    value = secrets.token_urlsafe(18)
    KEY_FILE.write_text(value + "\n")
    os.chmod(KEY_FILE, 0o600)
    return value


def is_local(scope: dict) -> bool:
    client = scope.get("client")
    return bool(client) and client[0] in LOCAL_HOSTS


def lan_ip() -> str | None:
    """Adresse des Macs im WLAN (es wird nichts gesendet, nur die Route nachgeschlagen)."""
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.connect(("10.255.255.255", 1))
        ip = sock.getsockname()[0]
    except OSError:
        return None
    finally:
        sock.close()
    return None if ip.startswith("127.") else ip


def link(port: int | None = None) -> dict:
    ip = lan_ip()
    if not ip:
        return {"url": None, "text": "Der Mac ist in keinem WLAN. Verbinde ihn und das Handy mit demselben WLAN."}
    if settings.host in ("127.0.0.1", "localhost"):
        return {"url": None, "text": "Die Anzeige ist abgeschaltet (JARVIS_HOST in .env)."}
    return {"url": f"http://{ip}:{port or settings.port}/anzeige?k={key()}", "text": ""}


def qr_svg(url: str) -> str | None:
    try:
        import qrcode
        import qrcode.image.svg
    except ImportError:
        return None
    image = qrcode.make(url, image_factory=qrcode.image.svg.SvgPathFillImage, border=2)
    return image.to_string(encoding="unicode")


def _cookie_key(scope: dict) -> str:
    for name, value in scope.get("headers", []):
        if name == b"cookie":
            jar = SimpleCookie()
            try:
                jar.load(value.decode("latin-1"))
            except Exception:
                return ""
            return jar[COOKIE].value if COOKIE in jar else ""
    return ""


class LanGuard:
    """ASGI-Middleware: Anfragen von anderen Geraeten nur fuer die Anzeige und nur mit Schluessel."""

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] not in ("http", "websocket") or is_local(scope):
            return await self.app(scope, receive, send)

        query = parse_qs(scope.get("query_string", b"").decode("latin-1"))
        from_link = (query.get("k") or [""])[0]
        expected = key()
        valid = secrets.compare_digest(from_link, expected) or secrets.compare_digest(_cookie_key(scope), expected)
        path = scope["path"]
        if scope["type"] == "websocket":
            allowed = path == "/ws"
        else:
            allowed = scope["method"] in ("GET", "HEAD") and path in REMOTE_PATHS and "refresh" not in query

        if not (valid and allowed):
            if scope["type"] == "websocket":
                await receive()
                await send({"type": "websocket.close", "code": 1008})
                return
            body = DENIED_PAGE.encode()
            await send({"type": "http.response.start", "status": 403,
                        "headers": [(b"content-type", b"text/html; charset=utf-8"),
                                    (b"content-length", str(len(body)).encode())]})
            await send({"type": "http.response.body", "body": body})
            return

        if scope["type"] == "http" and from_link:
            # Schluessel aus dem QR-Code merken, damit die Seite auch ohne ihn in der Adresse weiterlaeuft
            cookie = f"{COOKIE}={expected}; Max-Age=31536000; Path=/; HttpOnly; SameSite=Strict".encode()

            async def send_with_cookie(message):
                if message["type"] == "http.response.start":
                    message = {**message, "headers": [*message.get("headers", []), (b"set-cookie", cookie)]}
                await send(message)

            return await self.app(scope, receive, send_with_cookie)
        return await self.app(scope, receive, send)
