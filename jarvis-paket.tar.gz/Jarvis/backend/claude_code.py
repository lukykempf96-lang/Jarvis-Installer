"""Bruecke zu Claude Code: Jarvis gibt Projektaufgaben an Claude Code auf dem Mac weiter.

Claude Code laeuft im Hintergrund im Projektordner (claude -p). Ist es fertig, liest Jarvis
die kurze Zusammenfassung vor. Claude Code darf Dateien im Projektordner aendern, aber ohne
Rueckfrage keine Befehle ausfuehren.
"""
from __future__ import annotations

import json
import os
import shlex
import shutil
import subprocess
import threading
import time
from pathlib import Path

from . import eigene, files
from .config import settings

JARVIS_DIR = Path(__file__).resolve().parent.parent
PROJECTS_DIR = Path(os.path.expanduser(settings.projects_dir))
SESSIONS_FILE = JARVIS_DIR / "claude-code-sitzungen.json"
LOG_FILE = JARVIS_DIR / "claude-code.log"
TIMEOUT = 30 * 60
SPOKEN_HINT = (
    "Deine Antwort wird Lukas mit einer Stimme vorgelesen. Beende sie mit einer Zusammenfassung "
    "in hoechstens drei kurzen Saetzen auf Deutsch: was du getan oder herausgefunden hast. "
    "Kein Markdown, keine Aufzaehlungen, keine Codebloecke."
)

on_done = None  # setzt main.py: Funktion(text), die das Ergebnis anzeigt und vorliest
on_progress = None  # setzt main.py: Funktion(projekt, text, fertig) fuers Arbeitsfenster
on_self_change = None  # setzt main.py: Funktion(text) -> text, laedt Jarvis' eigene Funktionen nach einem Umbau neu
_running: dict[str, threading.Thread] = {}
_lock = threading.Lock()


def _find_claude() -> str | None:
    found = shutil.which("claude")
    if found:
        return found
    for candidate in ("~/.local/bin/claude", "~/.claude/local/claude", "/opt/homebrew/bin/claude",
                      "/usr/local/bin/claude", "~/.npm-global/bin/claude"):
        path = Path(os.path.expanduser(candidate))
        if path.exists():
            return str(path)
    return None


def projects() -> dict[str, Path]:
    found = {"Jarvis": JARVIS_DIR}
    if PROJECTS_DIR.is_dir():
        for folder in sorted(PROJECTS_DIR.iterdir()):
            if folder.is_dir() and not folder.name.startswith("."):
                found[folder.name] = folder
    return found


def _norm(text: str) -> str:
    return "".join(ch for ch in text.lower() if ch.isalnum())


def _match(name: str) -> tuple[str, Path] | None:
    if "/" in name or name.startswith("~"):  # ein Ordner irgendwo auf dem Mac
        folder = files.resolve(name)
        return (folder.name, folder) if folder.is_dir() and not files._is_secret(folder) else None
    wanted, all_projects = _norm(name), projects()
    for key, path in all_projects.items():
        if _norm(key) == wanted:
            return key, path
    for key, path in all_projects.items():
        if wanted and (wanted in _norm(key) or _norm(key) in wanted):
            return key, path
    return None


def list_projects() -> str:
    return f"Projekte: {', '.join(projects())}. Neue Projekte sind Ordner in {PROJECTS_DIR}."


def create_project(name: str) -> str:
    safe = "".join(ch for ch in name if ch.isalnum() or ch in " -_").strip()
    if not safe:
        return "Ungueltiger Projektname."
    (PROJECTS_DIR / safe).mkdir(parents=True, exist_ok=True)
    _progress(safe, f"Projekt angelegt in {files._short(PROJECTS_DIR / safe)}", done=True)
    return f"Projekt {safe} angelegt in {PROJECTS_DIR}."


def _sessions() -> dict:
    try:
        return json.loads(SESSIONS_FILE.read_text())
    except (OSError, ValueError):
        return {}


def _save_session(key: str, session_id: str):
    data = _sessions()
    data[key] = session_id
    SESSIONS_FILE.write_text(json.dumps(data, indent=2))


def ask_claude_code(project: str, task: str, new_conversation: bool = False) -> str:
    claude = _find_claude()
    if not claude:
        return ("Claude Code ist auf diesem Mac nicht installiert. Installation: claude.ai/code, "
                "danach einmal im Terminal 'claude' starten und anmelden.")
    match = _match(project)
    if not match:
        return f"Projekt '{project}' nicht gefunden. {list_projects()}"
    key, path = match
    with _lock:
        if key in _running and _running[key].is_alive():
            return f"Claude Code arbeitet noch am Projekt {key}. Ich sage Bescheid, wenn er fertig ist."
        session = None if new_conversation else _sessions().get(key)
        thread = threading.Thread(target=_run, args=(claude, key, path, task, session), daemon=True)
        _running[key] = thread
        thread.start()
    return (f"Claude Code arbeitet jetzt im Projekt {key}. Was er tut, steht live im Arbeitsfenster; "
            "ich sage Bescheid, sobald er fertig ist.")


def open_in_claude(project: str) -> str:
    """Oeffnet das Projekt sichtbar: Claude Code im Terminal mit dem bisherigen Gespraech,
    per Remote Control auch in der Claude-App (Mac und iPhone, Bereich Code)."""
    claude = _find_claude()
    if not claude:
        return "Claude Code ist auf diesem Mac nicht installiert."
    match = _match(project)
    if not match:
        return f"Projekt '{project}' nicht gefunden. {list_projects()}"
    key, path = match
    session = _sessions().get(key)
    base = f"cd {shlex.quote(str(path))} && {shlex.quote(claude)}"
    resume = f" --resume {shlex.quote(session)}" if session else ""
    # Kennt Claude Code Remote Control nicht oder ist es gesperrt, startet es normal im Terminal
    line = f"{base} --remote-control --name {shlex.quote('Jarvis: ' + key)}{resume} || {base}{resume}"
    quoted = line.replace("\\", "\\\\").replace('"', '\\"')
    script = f'tell application "Terminal"\nactivate\ndo script "{quoted}"\nend tell'
    try:
        subprocess.run(["osascript", "-e", script], check=True, capture_output=True, timeout=15)
    except (subprocess.SubprocessError, OSError) as exc:
        return f"Konnte das Terminal nicht oeffnen: {exc}"
    return (f"Projekt {key} ist im Terminal offen{' mit dem bisherigen Gespräch' if session else ''}. "
            f"In der Claude-App erscheint es unter Code als „Jarvis: {key}“, sofern Remote Control erlaubt ist.")


SELF_CHECK = "venv/bin/python -m backend.eigene"  # darf Claude Code im Jarvis-Ordner ohne Rueckfrage ausfuehren


def _command(claude: str, session: str | None, path: Path | None = None) -> list[str]:
    cmd = [claude, "-p", "--output-format", "stream-json", "--verbose", "--permission-mode", "acceptEdits"]
    if path == JARVIS_DIR:
        # per Option statt nur in .claude/settings.json: die gilt erst, wenn Lukas dem Ordner einmal vertraut hat
        cmd += ["--allowedTools", f"Bash({SELF_CHECK})", f"Bash({SELF_CHECK}:*)"]
    cmd += ["--append-system-prompt", SPOKEN_HINT]
    if session:
        cmd += ["--resume", session]
    return cmd  # den Auftrag bekommt Claude Code ueber stdin, so wird er nie als Option gelesen


VERBS = {
    "Read": "liest", "Write": "schreibt", "Edit": "ändert", "MultiEdit": "ändert", "NotebookEdit": "ändert",
    "Bash": "führt aus", "Glob": "sucht Dateien", "Grep": "durchsucht", "LS": "schaut in",
    "WebFetch": "liest Webseite", "WebSearch": "sucht im Netz", "TodoWrite": "plant die Schritte",
    "Task": "startet einen Helfer", "Agent": "startet einen Helfer",
}


def _describe(event: dict, path: Path) -> list[str]:
    """Macht aus einem Claude-Code-Ereignis kurze Zeilen fuers Arbeitsfenster."""
    if event.get("type") != "assistant":
        return []
    lines = []
    for block in (event.get("message") or {}).get("content") or []:
        if block.get("type") == "text" and block.get("text", "").strip():
            text = " ".join(block["text"].split())
            lines.append(text[:220] + ("..." if len(text) > 220 else ""))
        elif block.get("type") == "tool_use":
            name, args = block.get("name", ""), block.get("input") or {}
            target = next((str(args[k]) for k in ("file_path", "notebook_path", "path", "pattern", "command",
                                                  "url", "query", "description") if args.get(k)), "")
            target = target.replace(str(path) + "/", "")
            target = target[:120] + ("..." if len(target) > 120 else "")
            lines.append(f"{VERBS.get(name, name)} {target}".strip())
    return lines


def _stream(cmd: list[str], task: str, key: str, path: Path, env: dict) -> tuple[int, dict | None, str]:
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            cwd=path, env=env, text=True)
    timed_out = threading.Event()

    def stop():
        timed_out.set()
        proc.kill()

    timer = threading.Timer(TIMEOUT, stop)
    timer.start()
    errors: list[str] = []
    reader = threading.Thread(target=lambda: errors.extend(proc.stderr), daemon=True)
    reader.start()
    try:
        proc.stdin.write(task)
        proc.stdin.close()
    except (BrokenPipeError, OSError):
        pass
    result, plain = None, []
    for line in proc.stdout:
        line = line.strip()
        if not line:
            continue
        try:
            event = json.loads(line)
        except ValueError:
            plain.append(line)
            continue
        if event.get("type") == "result":
            result = event
        elif event.get("session_id") and event.get("subtype") == "init":
            _save_session(key, event["session_id"])
        for text in _describe(event, path):
            _progress(key, text)
    proc.wait()
    timer.cancel()
    reader.join(timeout=2)
    if timed_out.is_set():
        raise subprocess.TimeoutExpired(cmd, TIMEOUT)
    return proc.returncode, result, ("\n".join(plain) + "\n" + "".join(errors)).strip()


def _progress(key: str, text: str, done: bool = False):
    if on_progress:
        try:
            on_progress(key, text, done)
        except Exception:
            pass


def _run(claude: str, key: str, path: Path, task: str, session: str | None):
    # Ohne ANTHROPIC_API_KEY nutzt Claude Code dein Claude-Abo statt Jarvis' API-Guthaben
    env = {k: v for k, v in os.environ.items() if k not in ("ANTHROPIC_API_KEY", "ANTHROPIC_BASE_URL")}
    started = time.monotonic()
    _progress(key, f"Auftrag: {task}")
    if path == JARVIS_DIR:  # Jarvis baut sich selbst um: vorher eigene/ sichern
        try:
            eigene.snapshot()
        except OSError as exc:
            print(f"Sicherung von eigene/ fehlgeschlagen: {exc}", flush=True)
    try:
        code, result, raw = _stream(_command(claude, session, path), task, key, path, env)
        if session and code != 0 and not (result and result.get("result")):  # alte Sitzung weg: neu anfangen
            _progress(key, "Altes Gespräch nicht mehr da, fange neu an")
            code, result, raw = _stream(_command(claude, None, path), task, key, path, env)
        text = _result_text(key, result, code, raw)
    except subprocess.TimeoutExpired:
        text = f"Claude Code hat im Projekt {key} nach 30 Minuten abgebrochen."
    except OSError as exc:
        text = f"Claude Code liess sich nicht starten: {exc}"
    with open(LOG_FILE, "a") as log:
        log.write(f"\n=== {time.strftime('%d.%m.%Y %H:%M')} | {key} | {round(time.monotonic() - started)} s\n"
                  f"Auftrag: {task}\nErgebnis: {text}\n")
    _progress(key, "Fertig", done=True)
    if path == JARVIS_DIR and on_self_change:
        try:
            text = on_self_change(text)
        except Exception as exc:
            print(f"Eigene Funktionen neu laden fehlgeschlagen: {exc!r}", flush=True)
    if on_done:
        on_done(text)


def _result_text(key: str, data: dict | None, code: int, raw: str) -> str:
    if data is None:
        try:  # aeltere Claude-Code-Versionen ohne stream-json
            data = json.loads(raw.splitlines()[0]) if raw.startswith("{") else {}
        except (ValueError, IndexError):
            data = {}
    if data.get("session_id"):
        _save_session(key, data["session_id"])
    result = (data.get("result") or raw or "").strip()
    if "login" in result.lower() and (data.get("is_error") or code != 0):
        return ("Claude Code ist nicht angemeldet. Bitte einmal im Terminal 'claude' starten "
                "und mit deinem Claude-Konto anmelden.")
    if not result:
        return f"Claude Code ist im Projekt {key} fertig, hat aber nichts geantwortet."
    if len(result) > 700:  # nur das Ende vorlesen, dort steht die Zusammenfassung
        result = "..." + result[-700:]
    return f"Claude Code meldet zum Projekt {key}: {result}"
