"""Selbst gebaute Funktionen: Jarvis laesst sie von Claude Code im Ordner eigene/ anlegen.

Updates fassen eigene/ nie an, deshalb bleibt dort alles erhalten. Eine Datei eigene/<name>.py kann haben:
  BESCHREIBUNG = "..."   was die Funktion kann (steht in Jarvis' Anweisungen)
  PROMPT = "..."         optional: wann und wie Jarvis sie benutzen soll
  TOOLS = [...]          Tools wie in backend/tools.py, dazu je eine Funktion mit dem Namen des Tools
  API = {"name": fn}     optional: fn(**daten) unter /api/eigene/<datei>/<name> fuers Fenster (nur am Mac)
Dazu eigene/*.js und eigene/*.css: laedt das Jarvis-Fenster am Mac automatisch.

Pruefen: venv/bin/python -m backend.eigene
Entfernen: venv/bin/python -m backend.eigene --entfernen <name>   Rueckgaengig: ... --zurueck
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import re
import shutil
import sys
import threading
import time
import traceback
from pathlib import Path

JARVIS_DIR = Path(__file__).resolve().parent.parent
DIR = JARVIS_DIR / "eigene"
BACKUP_DIR = JARVIS_DIR / ".eigene-sicherung"
KEEP_BACKUPS = 10
NAME = re.compile(r"^[A-Za-z][A-Za-z0-9_]{0,40}$")
TOOL_NAME = re.compile(r"^[a-zA-Z0-9_-]{1,64}$")

_lock = threading.Lock()
_modules: dict = {}  # Dateiname ohne .py -> Modul
_tools: list[dict] = []
_handlers: dict = {}  # Toolname -> Funktion
_errors: dict[str, str] = {}  # Datei -> Fehler in einem Satz


def _short_error(exc: BaseException) -> str:
    if isinstance(exc, SyntaxError):
        return f"Schreibfehler in Zeile {exc.lineno}: {exc.msg}"
    frames = [f for f in traceback.extract_tb(exc.__traceback__) if str(DIR) in (f.filename or "")]
    where = f" (Zeile {frames[-1].lineno})" if frames else ""
    return f"{type(exc).__name__}: {exc}{where}"[:300]


def _check_tool(tool, module, reserved: set[str]) -> str | None:
    if not isinstance(tool, dict):
        return "Ein Eintrag in TOOLS ist kein Dict."
    name = tool.get("name")
    if not isinstance(name, str) or not TOOL_NAME.match(name):
        return f"Ungueltiger Toolname: {name!r}"
    if name in reserved:
        return f"Toolname {name} gibt es schon."
    if not isinstance(tool.get("description"), str) or not tool["description"].strip():
        return f"Tool {name} hat keine description."
    schema = tool.get("input_schema")
    if not isinstance(schema, dict) or schema.get("type") != "object":
        return f"Tool {name}: input_schema muss {{'type': 'object', ...}} sein."
    if not callable(getattr(module, name, None)):
        return f"Tool {name}: Es fehlt die Funktion def {name}(...)."
    try:
        json.dumps(tool)
    except (TypeError, ValueError):
        return f"Tool {name} laesst sich nicht als JSON schreiben."
    return None


def load(verbose: bool = True) -> dict:
    """Laedt alle eigenen Funktionen neu. Eine kaputte Datei bremst die anderen nicht aus."""
    from .tools import TOOLS  # erst hier, tools.py importiert dieses Modul

    core = {t["name"] for t in TOOLS} | {"web_search", "web_fetch"}
    modules, tools, handlers, errors = {}, [], {}, {}
    files = sorted(DIR.glob("*.py")) if DIR.is_dir() else []
    for path in files:
        stem = path.stem
        if stem.startswith(("_", ".")):
            continue
        if not NAME.match(stem):
            errors[path.name] = "Dateiname bitte nur aus Buchstaben, Ziffern und _."
            continue
        mod_name = f"jarvis_eigene_{stem}"
        sys.modules.pop(mod_name, None)
        try:
            spec = importlib.util.spec_from_file_location(mod_name, path)
            module = importlib.util.module_from_spec(spec)
            sys.modules[mod_name] = module
            spec.loader.exec_module(module)
        except BaseException as exc:  # auch SystemExit aus einer eigenen Datei darf Jarvis nicht beenden
            sys.modules.pop(mod_name, None)
            errors[path.name] = _short_error(exc)
            continue
        problem = None
        own = getattr(module, "TOOLS", [])
        if not isinstance(own, list):
            problem = "TOOLS muss eine Liste sein."
        else:
            for tool in own:
                problem = _check_tool(tool, module, core | set(handlers))
                if problem:
                    break
        api = getattr(module, "API", {})
        if not problem and (not isinstance(api, dict) or not all(
                isinstance(k, str) and NAME.match(k) and callable(v) for k, v in api.items())):
            problem = "API muss ein Dict {'name': funktion} sein."
        if problem:
            errors[path.name] = problem
            continue
        modules[stem] = module
        for tool in own:
            tools.append({k: tool[k] for k in ("name", "description", "input_schema")})
            handlers[tool["name"]] = getattr(module, tool["name"])
    with _lock:
        _modules.clear(); _modules.update(modules)
        _tools[:] = tools
        _handlers.clear(); _handlers.update(handlers)
        _errors.clear(); _errors.update(errors)
    for name, error in errors.items() if verbose else ():
        print(f"Eigene Funktion {name} hat einen Fehler: {error}", flush=True)
    return {"geladen": sorted(modules), "tools": [t["name"] for t in tools], "fehler": dict(errors)}


def tools() -> list[dict]:
    with _lock:
        return list(_tools)


def has(name: str) -> bool:
    return name in _handlers


def run(name: str, tool_input: dict):
    handler = _handlers.get(name)
    if handler is None:
        return f"Unbekanntes Tool: {name}"
    try:
        result = handler(**(tool_input or {}))
    except Exception as exc:
        return f"Fehler in der eigenen Funktion {name}: {_short_error(exc)}"
    if result is None:
        return "Erledigt."
    if isinstance(result, (str, list)):  # Liste: fertige Inhaltsbloecke (z. B. Text und Bild)
        return result
    try:
        return json.dumps(result, ensure_ascii=False, default=str)
    except (TypeError, ValueError):
        return str(result)


def call_api(module: str, name: str, data: dict):
    """Fuer eigene Fenster-Bausteine: /api/eigene/<datei>/<name>. Gibt (Status, Antwort) zurueck."""
    mod = _modules.get(module)
    api = getattr(mod, "API", {}) if mod else {}
    fn = api.get(name) if isinstance(api, dict) else None
    if fn is None:
        return 404, {"fehler": f"{module}/{name} gibt es nicht"}
    try:
        return 200, fn(**(data or {}))
    except TypeError as exc:
        return 400, {"fehler": str(exc)}
    except Exception as exc:
        return 500, {"fehler": _short_error(exc)}


def prompt() -> str:
    """Zusatz fuer Jarvis' Anweisungen: was er sich selbst gebaut hat und was gerade kaputt ist."""
    with _lock:
        modules, errors = dict(_modules), dict(_errors)
    parts = []
    if modules:
        names = []
        for stem, module in modules.items():
            text = getattr(module, "BESCHREIBUNG", "")
            names.append(f"{stem}: {text}" if isinstance(text, str) and text else stem)
        parts.append("Selbst gebaute Funktionen (Ordner eigene/): " + "; ".join(names) + ".")
        for module in modules.values():
            extra = getattr(module, "PROMPT", "")
            if isinstance(extra, str) and extra.strip():
                parts.append(extra.strip()[:1500])
    if errors:
        parts.append("Gerade kaputt (nicht benutzbar): " + "; ".join(f"{n}: {e}" for n, e in errors.items())
                     + ". Will Lukas so eine Funktion nutzen, sag es ihm und biete an, sie von Claude Code "
                       "im Projekt Jarvis reparieren zu lassen.")
    return "\n".join(parts)


def frontend_files() -> dict:
    """Eigene Fenster-Bausteine; v = Aenderungszeit, damit der Browser keine alte Fassung nimmt."""
    found = {"js": [], "css": []}
    if DIR.is_dir():
        for path in sorted(DIR.iterdir()):
            kind = path.suffix[1:]
            if kind in found and path.is_file() and NAME.match(path.stem):
                found[kind].append({"name": path.name, "v": int(path.stat().st_mtime)})
    return found


def frontend_file(name: str) -> Path | None:
    path = DIR / name
    if "/" in name or "\\" in name or path.suffix not in (".js", ".css") or not NAME.match(path.stem):
        return None
    return path if path.is_file() else None


CODE = (".py", ".js", ".css", ".md")  # Daten in eigene/daten/ bleiben beim Rueckgaengigmachen, wie sie sind


def _code_files(folder: Path) -> list[Path]:
    return sorted(p for p in folder.iterdir() if p.is_file() and p.suffix in CODE) if folder.is_dir() else []


def _code_hash(folder: Path) -> str:
    digest = hashlib.sha256()
    for path in _code_files(folder):
        digest.update(path.name.encode() + b"\0" + path.read_bytes() + b"\0")
    return digest.hexdigest()


def _backups() -> list[Path]:
    return sorted(p for p in BACKUP_DIR.iterdir() if p.is_dir()) if BACKUP_DIR.is_dir() else []


def snapshot() -> Path | None:
    """Sichert die eigenen Dateien, bevor Claude Code etwas aendert (fuer "mach das rueckgaengig")."""
    if not _code_files(DIR):
        return None
    backups = _backups()
    if backups and _code_hash(backups[-1]) == _code_hash(DIR):
        return backups[-1]  # nichts geaendert seit der letzten Sicherung
    stamp, n = time.strftime("%Y-%m-%d_%H-%M-%S"), 1
    target = BACKUP_DIR / stamp
    while target.exists():  # zwei Sicherungen in derselben Sekunde
        n += 1
        target = BACKUP_DIR / f"{stamp}_{n}"
    target.mkdir(parents=True)
    for path in _code_files(DIR):
        shutil.copy2(path, target / path.name)
    for old in _backups()[:-KEEP_BACKUPS]:
        shutil.rmtree(old, ignore_errors=True)
    return target


def restore() -> str:
    """Holt den letzten Stand zurueck, der sich vom jetzigen unterscheidet."""
    current = _code_hash(DIR)
    older = [b for b in _backups() if _code_hash(b) != current]
    if not older:
        return "Es gibt keinen frueheren Stand zum Zurueckholen."
    source = older[-1]
    snapshot()  # den jetzigen Stand auch sichern, dann laesst sich das Zurueckholen selbst rueckgaengig machen
    DIR.mkdir(exist_ok=True)
    for path in _code_files(DIR):
        path.unlink()
    for path in _code_files(source):
        shutil.copy2(path, DIR / path.name)
    try:
        when = time.strftime("%d.%m. um %H:%M Uhr", time.strptime(source.name[:19], "%Y-%m-%d_%H-%M-%S"))
    except ValueError:
        when = source.name
    return f"Stand vom {when} zurueckgeholt."


def remove(name: str) -> str:
    """Entfernt eine eigene Funktion (alle Dateien mit diesem Namen); vorher gesichert."""
    stem = Path(name).stem
    if not NAME.match(stem):
        return f"Ungueltiger Name: {name}"
    found = [p for p in _code_files(DIR) if p.stem == stem]
    if not found:
        return f"Keine eigene Funktion {stem} gefunden."
    snapshot()
    for path in found:
        path.unlink()
    return "Entfernt: " + ", ".join(p.name for p in found) + " (Sicherung in .eigene-sicherung/)."


def fingerprint() -> tuple:
    """Aendert sich, sobald eine eigene Datei dazukommt, wegfaellt oder geaendert wird."""
    if not DIR.is_dir():
        return ()
    return tuple((p.name, p.stat().st_mtime_ns, p.stat().st_size)
                 for p in sorted(DIR.iterdir()) if p.is_file() and p.suffix in (".py", ".js", ".css"))


def _main(args: list[str]) -> int:
    if args[:1] == ["--entfernen"] and len(args) == 2:
        print(remove(args[1]))
    elif args[:1] == ["--zurueck"]:
        print(restore())
    elif args:
        print("Aufruf: python -m backend.eigene [--entfernen NAME | --zurueck]")
        return 2
    report = load(verbose=False)
    if not report["geladen"] and not report["fehler"]:
        print(f"Noch keine eigenen Funktionen in {DIR}.")
    for name in report["geladen"]:
        print(f"ok   {name}.py")
    for name in report["tools"]:
        print(f"     Tool {name}")
    for name, error in report["fehler"].items():
        print(f"FEHLER {name}: {error}")
    files = frontend_files()
    for kind in ("js", "css"):
        for item in files[kind]:
            print(f"ok   {item['name']} (wird im Fenster geladen)")
    return 1 if report["fehler"] else 0


if __name__ == "__main__":
    sys.exit(_main(sys.argv[1:]))
