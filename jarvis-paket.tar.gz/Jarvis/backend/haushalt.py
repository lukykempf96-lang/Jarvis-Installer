"""Haushaltsbuch: Gehalt, feste Kosten, Sparen und einzelne Ausgaben, per Sprache, im Fenster oder aus Belegen.

Alles liegt in haushaltsbuch.json im Jarvis-Ordner, nur auf dem Mac; vor jedem Speichern entsteht eine Kopie
haushaltsbuch.json.bak. Feste Posten (Gehalt, Miete, Kredit, Sparen ...) gelten jeden Monat von "ab" bis "bis".
Aendert sich ein Betrag, endet der alte Posten im Vormonat und ein neuer beginnt, damit fruehere Monate stimmen.
"""

from __future__ import annotations

import calendar
import json
import os
import re
import shutil
import threading
from datetime import date, datetime
from pathlib import Path

JARVIS_DIR = Path(__file__).resolve().parent.parent
BOOK = Path(os.path.expanduser(os.getenv("JARVIS_HAUSHALT_FILE", ""))) if os.getenv("JARVIS_HAUSHALT_FILE") \
    else JARVIS_DIR / "haushaltsbuch.json"
BACKUP = BOOK.with_name(BOOK.name + ".bak")

KATEGORIEN = [
    "Lebensmittel", "Drogerie", "Essen & Trinken", "Tanken", "Auto", "Wohnen", "Strom & Energie",
    "Versicherungen", "Kredit & Finanzierung", "Verträge & Abos", "Freizeit", "Kleidung", "Haushalt",
    "Gesundheit", "Geschenke", "Urlaub", "Sparen", "Gehalt", "Einnahmen", "Sonstiges",
]
ARTEN = ("ausgabe", "einnahme", "sparen", "entnahme")
RHYTHMUS = {"monatlich": 1, "vierteljaehrlich": 3, "halbjaehrlich": 6, "jaehrlich": 12}
MONATE = ["Januar", "Februar", "März", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober",
          "November", "Dezember"]

# Woran Jarvis ohne Angabe die Kategorie erkennt (Reihenfolge zaehlt: "Kfz-Versicherung" ist eine Versicherung)
GUESS = [
    ("Gehalt", r"gehalt|lohn|einkommen|rente|kindergeld"),
    ("Versicherungen", r"versicherung|haftpflicht|kasko"),
    ("Kredit & Finanzierung", r"kredit|finanzierung|darlehen|ratenkauf|tilgung"),
    ("Sparen", r"spar|urlaubskonto|r(ü|ue)cklage|tagesgeld|depot|etf|notgroschen"),
    ("Wohnen", r"miete|nebenkosten|wohnung|hausgeld|grundsteuer|rundfunk"),
    ("Strom & Energie", r"strom|gas\b|heiz|fernw(ä|ae)rme|energie|wasser"),
    ("Tanken", r"tank|aral|shell|esso|\bjet\b|totalenergies|benzin|diesel|laden.*auto|ladestation"),
    ("Auto", r"auto|kfz|leasing|werkstatt|t(ü|ue)v|parken|parkhaus|waschanlage"),
    ("Verträge & Abos", r"handy|mobilfunk|internet|dsl|netflix|spotify|disney|prime|abo|fitness|"
                        r"streaming|icloud|youtube|telekom|vodafone|o2"),
    ("Lebensmittel", r"rewe|edeka|aldi|lidl|netto|penny|kaufland|norma|tegut|globus|supermarkt|einkauf|"
                     r"b(ä|ae)cker|metzger|getr(ä|ae)nke|lebensmittel"),
    ("Drogerie", r"\bdm\b|rossmann|m(ü|ue)ller|drogerie"),
    ("Essen & Trinken", r"restaurant|d(ö|oe)ner|pizza|mc ?donald|burger|caf(é|e)|lieferando|imbiss|bar\b|kantine"),
    ("Gesundheit", r"apotheke|arzt|zahnarzt|brille|physio"),
    ("Kleidung", r"zalando|h&m|kleid|schuhe|jacke|hose|primark|zara"),
    ("Haushalt", r"ikea|baumarkt|obi|hornbach|bauhaus|haushalt"),
    ("Freizeit", r"kino|konzert|ticket|eintritt|sport|verein|hobby|spiel"),
    ("Geschenke", r"geschenk|geburtstag"),
    ("Urlaub", r"urlaub|hotel|flug|booking|airbnb|reise"),
]

_lock = threading.RLock()
on_change = None  # main.py haengt sich hier ein, damit das Fenster sofort neu zeichnet


# ---------- Hilfen ----------

def _today() -> date:
    return date.today()


def _mkey(d: date) -> str:
    return f"{d.year:04d}-{d.month:02d}"


def _midx(key: str) -> int:
    year, month = key.split("-")
    return int(year) * 12 + int(month) - 1


def _mkey_of(index: int) -> str:
    return f"{index // 12:04d}-{index % 12 + 1:02d}"


def month_label(key: str) -> str:
    year, month = key.split("-")
    return f"{MONATE[int(month) - 1]} {year}"


def _norm_month(value) -> str | None:
    """'2026-10', '10/2026', '10.2026', 'Oktober 2026' oder 'Oktober' -> '2026-10'."""
    text = str(value or "").strip().lower()
    if not text:
        return None
    m = re.fullmatch(r"(\d{4})-(\d{1,2})(-\d{1,2})?", text)
    if m:
        year, month = int(m.group(1)), int(m.group(2))
    else:
        m = re.fullmatch(r"(\d{1,2})[./](\d{4})", text)
        if m:
            year, month = int(m.group(2)), int(m.group(1))
        else:
            names = [n.lower() for n in MONATE] + ["maerz"]
            found = [i for i, n in enumerate(names) if text.startswith(n[:3])]
            if not found:
                raise ValueError(f"Monat '{value}' verstehe ich nicht (JJJJ-MM)")
            month = (found[0] % 12) + 1 if found[0] < 12 else 3
            year_match = re.search(r"\d{4}", text)
            year = int(year_match.group()) if year_match else _today().year
    if not 1 <= month <= 12:
        raise ValueError(f"Monat '{value}' gibt es nicht")
    return f"{year:04d}-{month:02d}"


def _norm_date(value) -> str:
    text = str(value or "").strip()
    if not text or text.lower() == "heute":
        return _today().isoformat()
    m = re.fullmatch(r"(\d{4})-(\d{1,2})-(\d{1,2})", text)
    if m:
        return date(int(m.group(1)), int(m.group(2)), int(m.group(3))).isoformat()
    m = re.fullmatch(r"(\d{1,2})\.(\d{1,2})\.(\d{2,4})?", text)
    if m:
        year = int(m.group(3)) if m.group(3) else _today().year
        year = year + 2000 if year < 100 else year
        return date(year, int(m.group(2)), int(m.group(1))).isoformat()
    raise ValueError(f"Datum '{value}' verstehe ich nicht (JJJJ-MM-TT)")


def _number(value) -> float:
    if isinstance(value, bool):
        raise ValueError("kein Betrag")
    if isinstance(value, (int, float)):
        return round(abs(float(value)), 2)
    text = re.sub(r"[^\d,.]", "", str(value or ""))
    if "," in text:  # deutsch: 1.234,56
        text = text.replace(".", "").replace(",", ".")
    elif re.fullmatch(r"\d{1,3}(\.\d{3})+", text):  # 1.200 = tausendzweihundert
        text = text.replace(".", "")
    try:
        return round(abs(float(text)), 2)
    except ValueError:
        raise ValueError(f"Betrag '{value}' verstehe ich nicht") from None


def _amount(value) -> float:
    number = _number(value)
    if not number:
        raise ValueError("Betrag fehlt")
    return number


def eur(value: float) -> str:
    """1234.5 -> '1.234,50 €', 850 -> '850 €' (liest sich laut besser)."""
    sign = "-" if value < -0.004 else ""
    value = abs(round(value, 2))
    text = f"{value:,.0f}" if value == int(value) else f"{value:,.2f}"
    return sign + text.replace(",", "X").replace(".", ",").replace("X", ".") + " €"


def _short_date(iso: str) -> str:
    d = date.fromisoformat(iso)
    return f"{d.day:02d}.{d.month:02d}."


def _clean(text, limit: int = 80) -> str:
    return " ".join(str(text or "").split())[:limit]


# ---------- Datei ----------

def _empty() -> dict:
    return {"version": 1, "angelegt": _today().isoformat(), "kategorien": list(KATEGORIEN), "budgets": {},
            "fest": [], "buchungen": [], "toepfe": {}, "naechste_id": 1}


def exists() -> bool:
    return BOOK.exists()


def _load() -> dict:
    try:
        data = json.loads(BOOK.read_text("utf-8"))
    except FileNotFoundError:
        return _empty()
    except (OSError, ValueError) as exc:
        # Kaputte Datei nie ueberschreiben: lieber die Sicherung nehmen oder abbrechen
        try:
            data = json.loads(BACKUP.read_text("utf-8"))
            print(f"Haushaltsbuch beschaedigt ({exc}), nehme die Sicherung", flush=True)
        except (OSError, ValueError):
            raise RuntimeError(f"Das Haushaltsbuch laesst sich nicht lesen ({exc}). Datei: {BOOK}") from exc
    for key, value in _empty().items():
        data.setdefault(key, value)
    return data


def _save(data: dict):
    BOOK.parent.mkdir(parents=True, exist_ok=True)
    if BOOK.exists():
        shutil.copy2(BOOK, BACKUP)
        os.chmod(BACKUP, 0o600)
    tmp = BOOK.with_name(BOOK.name + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=1), "utf-8")
    os.chmod(tmp, 0o600)
    os.replace(tmp, BOOK)


def _new_id(data: dict, prefix: str) -> str:
    number = int(data.get("naechste_id") or 1)
    data["naechste_id"] = number + 1
    return f"{prefix}{number}"


def _changed(event: dict | None = None):
    if on_change:
        try:
            on_change(event or {})
        except Exception as exc:
            print(f"Haushaltsbuch-Anzeige: {exc!r}", flush=True)


# ---------- Rechnen ----------

def _active(item: dict, month: int) -> bool:
    return _midx(item["ab"]) <= month and (not item.get("bis") or month <= _midx(item["bis"]))


def _due(item: dict, month: int) -> bool:
    step = RHYTHMUS.get(item.get("rhythmus") or "monatlich", 1)
    return _active(item, month) and (month - _midx(item["ab"])) % step == 0


def _category(data: dict, given, text: str, art: str) -> str:
    given = _clean(given, 40)
    if given:
        for name in data["kategorien"]:
            if name.casefold() == given.casefold():
                return name
        given = given[0].upper() + given[1:]
        data["kategorien"].append(given)
        return given
    if art == "einnahme":
        return "Gehalt" if re.search(GUESS[0][1], text, re.I) else "Einnahmen"
    if art in ("sparen", "entnahme"):
        return "Sparen"
    for name, pattern in GUESS:
        if re.search(pattern, text, re.I):
            return name
    return "Sonstiges"


def _guess_art(name: str) -> str:
    if re.search(GUESS[0][1], name, re.I):
        return "einnahme"
    if re.search(r"spar|urlaubskonto|r(ü|ue)cklage|tagesgeld|depot|etf|notgroschen", name, re.I):
        return "sparen"
    return "ausgabe"


def _pot_name(data: dict, given) -> str:
    given = _clean(given, 40)
    names = list(data["toepfe"])
    for name in names:
        if given and name.casefold() == given.casefold():
            return name
    if given:
        return given
    return names[0] if len(names) == 1 else "Sparen"


def _words(text: str) -> set:
    return {w for w in re.findall(r"\w+", text.casefold()) if len(w) >= 4}


def _pots(data: dict) -> list[dict]:
    now = _midx(_mkey(_today()))
    names = list(data["toepfe"])
    for item in data["fest"]:
        if item["art"] == "sparen" and item["name"] not in names:
            names.append(item["name"])
    pots = []
    for name in names:
        paid, rate = 0.0, 0.0
        for item in data["fest"]:
            if item["art"] != "sparen" or item["name"] != name:
                continue
            last = min(now, _midx(item["bis"])) if item.get("bis") else now
            paid += sum(item["betrag"] for m in range(_midx(item["ab"]), last + 1) if _due(item, m))
            if _active(item, now):
                rate += item["betrag"] / RHYTHMUS.get(item.get("rhythmus") or "monatlich", 1)
        for b in data["buchungen"]:
            if b.get("topf") == name and b["art"] == "sparen":
                paid += b["betrag"]
            elif b.get("topf") == name and b["art"] == "entnahme":
                paid -= b["betrag"]
        info = data["toepfe"].get(name) or {}
        pots.append({"name": name, "stand": round((info.get("start") or 0) + paid, 2),
                     "ziel": info.get("ziel"), "rate": round(rate, 2), "eingezahlt": round(paid, 2)})
    return pots


def _summary(data: dict, key: str) -> dict:
    month = _midx(key)
    today = _today()
    fest = []
    for item in data["fest"]:
        if _active(item, month):
            fest.append({**item, "faellig": _due(item, month)})
        elif (item.get("rhythmus") or "monatlich") != "monatlich" and 0 < _midx(item["ab"]) - month <= 12:
            fest.append({**item, "faellig": False})  # jaehrlich usw.: schon anzeigen, faellig erst im Monat "ab"
    order = {"einnahme": 0, "ausgabe": 1, "sparen": 2}
    fest.sort(key=lambda i: (order.get(i["art"], 3), -i["betrag"]))
    bookings = [b for b in data["buchungen"] if b["datum"][:7] == key]
    bookings.sort(key=lambda b: (b["datum"], int(re.sub(r"\D", "", b["id"]) or 0)), reverse=True)

    due = [i for i in fest if i["faellig"]]
    income = sum(i["betrag"] for i in due if i["art"] == "einnahme") + \
        sum(b["betrag"] for b in bookings if b["art"] in ("einnahme", "entnahme"))
    fixed = sum(i["betrag"] for i in due if i["art"] == "ausgabe")
    saving = sum(i["betrag"] for i in due if i["art"] == "sparen") + \
        sum(b["betrag"] for b in bookings if b["art"] == "sparen")
    spent = sum(b["betrag"] for b in bookings if b["art"] == "ausgabe")
    available = income - fixed - saving
    left = available - spent

    per_cat: dict[str, float] = {}
    for i in due:
        if i["art"] == "ausgabe":
            per_cat[i["kategorie"]] = per_cat.get(i["kategorie"], 0) + i["betrag"]
    for b in bookings:
        if b["art"] == "ausgabe":
            per_cat[b["kategorie"]] = per_cat.get(b["kategorie"], 0) + b["betrag"]
    budgets = data["budgets"]
    categories = [{"kategorie": k, "betrag": round(v, 2), "budget": budgets.get(k)}
                  for k, v in sorted(per_cat.items(), key=lambda kv: -kv[1])]
    for k, limit in budgets.items():
        if k not in per_cat:
            categories.append({"kategorie": k, "betrag": 0.0, "budget": limit})

    current = key == _mkey(today)
    days_left = calendar.monthrange(today.year, today.month)[1] - today.day + 1 if current else 0
    upcoming = [i for i in due if current and i.get("tag") and int(i["tag"]) > today.day and i["art"] != "einnahme"]
    upcoming.sort(key=lambda i: int(i["tag"]))
    return {
        "monat": key, "label": month_label(key), "aktuell": current,
        "einnahmen": round(income, 2), "fix": round(fixed, 2), "sparen": round(saving, 2),
        "ausgaben": round(spent, 2), "verfuegbar": round(available, 2), "uebrig": round(left, 2),
        "tage_rest": days_left, "pro_tag": round(left / days_left, 2) if current and left > 0 else 0,
        "fest": fest, "buchungen": bookings, "kategorien_summe": categories,
        "offen": [{"name": i["name"], "betrag": i["betrag"], "tag": i["tag"]} for i in upcoming],
    }


def _status_line(data: dict) -> str:
    s = _summary(data, _mkey(_today()))
    text = f"Im {s['label'].split()[0]} uebrig: {eur(s['uebrig'])}"
    if s["pro_tag"]:
        text += f", das sind {eur(s['pro_tag'])} pro Tag bis Monatsende"
    return text + "."


def _budget_warnings(data: dict, categories: set) -> str:
    s = _summary(data, _mkey(_today()))
    notes = []
    for row in s["kategorien_summe"]:
        if row["kategorie"] in categories and row["budget"]:
            share = row["betrag"] / row["budget"]
            if share >= 1:
                notes.append(f"Achtung: {row['kategorie']} liegt mit {eur(row['betrag'])} ueber dem Budget von {eur(row['budget'])}.")
            elif share >= 0.8:
                notes.append(f"{row['kategorie']}: {eur(row['betrag'])} von {eur(row['budget'])} Budget verbraucht.")
    return " ".join(notes)


# ---------- Aendern ----------

def create() -> bool:
    """Legt das Haushaltsbuch an, falls es noch keins gibt. True = neu angelegt."""
    with _lock:
        if BOOK.exists():
            return False
        _save(_empty())
    _changed()
    return True


def book(entries: list) -> str:
    """Einzelne Buchungen: Einkaeufe, Ausgaben, einmalige Einnahmen, Sparen in einen Topf, Entnahmen."""
    if isinstance(entries, dict):
        entries = [entries]
    added, notes = [], []
    with _lock:
        data = _load()
        for entry in list(entries or [])[:80]:
            if not isinstance(entry, dict):
                continue
            try:
                amount = _amount(entry.get("betrag"))
                day = _norm_date(entry.get("datum"))
            except (ValueError, TypeError) as exc:
                notes.append(f"Nicht eingetragen ({_clean(entry.get('text'))}): {exc}.")
                continue
            art = entry.get("art") if entry.get("art") in ARTEN else "ausgabe"
            file = Path(str(entry.get("datei") or "")).name[:120]
            text = _clean(entry.get("text")) or _clean(entry.get("kategorie")) or "Ausgabe"
            category = _category(data, entry.get("kategorie"), text, art)
            pot = _pot_name(data, entry.get("topf")) if art in ("sparen", "entnahme") else None

            same = [b for b in data["buchungen"] if b["datum"] == day and abs(b["betrag"] - amount) < 0.005
                    and b["art"] == art and ((file and b.get("datei") == file) or b["text"].casefold() == text.casefold())]
            if same:
                notes.append(f"{text} ({eur(amount)}, {_short_date(day)}) steht schon drin ({same[0]['id']}).")
                continue
            month = _midx(day[:7])
            fixed = [i for i in data["fest"] if i["art"] == art and _due(i, month) and abs(i["betrag"] - amount) < 0.005
                     and (_words(i["name"]) & _words(text) or i["name"].casefold() in text.casefold())]
            if fixed:
                notes.append(f"{text} ({eur(amount)}) laeuft schon als fester Posten {fixed[0]['name']}, nicht doppelt eingetragen.")
                continue

            item = {"id": _new_id(data, "b"), "datum": day, "art": art, "betrag": amount, "text": text,
                    "kategorie": category, "quelle": "beleg" if file else (entry.get("quelle") or "sprache"),
                    "eingetragen": datetime.now().isoformat(timespec="seconds")}
            if file:
                item["datei"] = file
            if pot:
                item["topf"] = pot
                data["toepfe"].setdefault(pot, {"start": 0, "ziel": None})
            data["buchungen"].append(item)
            added.append(item)
        if added or not BOOK.exists():
            _save(data)
    if added:
        _changed({"neu": [b["id"] for b in added]})

    parts = []
    if len(added) <= 4:
        for b in added:
            sign = {"einnahme": "+", "entnahme": "aus Topf "}.get(b["art"], "")
            where = f"in {b['topf']}" if b["art"] == "sparen" else b["kategorie"]
            parts.append(f"{b['text']} {sign}{eur(b['betrag'])} am {_short_date(b['datum'])} ({where}, {b['id']})")
        text = ("Eingetragen: " + "; ".join(parts) + ".") if parts else ""
    else:
        total = sum(b["betrag"] for b in added if b["art"] == "ausgabe")
        cats = sorted({b["kategorie"] for b in added})
        text = f"{len(added)} Buchungen eingetragen, Ausgaben zusammen {eur(total)} ({', '.join(cats)})."
    with _lock:
        data = _load()
    warn = _budget_warnings(data, {b["kategorie"] for b in added})
    return " ".join(x for x in [text, " ".join(notes), warn, _status_line(data) if added else ""] if x)


def change_booking(id: str = "", delete: bool = False, **fields) -> str:
    with _lock:
        data = _load()
        if not data["buchungen"]:
            return "Es gibt noch keine Buchungen."
        if id:
            found = [b for b in data["buchungen"] if b["id"] == id.strip().lower()]
            if not found:
                return f"Die Buchung {id} finde ich nicht. Die Nummern stehen in haushalt_uebersicht."
            item = found[0]
        else:
            item = data["buchungen"][-1]
        if delete:
            data["buchungen"].remove(item)
            _save(data)
            result = f"Geloescht: {item['text']} {eur(item['betrag'])} vom {_short_date(item['datum'])}."
        else:
            try:
                if fields.get("betrag") not in (None, ""):
                    item["betrag"] = _amount(fields["betrag"])
                if fields.get("datum"):
                    item["datum"] = _norm_date(fields["datum"])
            except ValueError as exc:
                return f"Nicht geaendert: {exc}."
            if fields.get("text"):
                item["text"] = _clean(fields["text"])
            if fields.get("art") in ARTEN:
                item["art"] = fields["art"]
            if fields.get("kategorie"):
                item["kategorie"] = _category(data, fields["kategorie"], item["text"], item["art"])
            _save(data)
            result = (f"Geaendert: {item['text']} {eur(item['betrag'])} am {_short_date(item['datum'])} "
                      f"({item['kategorie']}, {item['id']}).")
    _changed({"neu": [] if delete else [item["id"]]})
    return f"{result} {_status_line(data)}"


def set_fixed(name: str = "", betrag=None, art: str = "", kategorie: str = "", tag=None, rhythmus: str = "",
              ab: str = "", bis: str = "", beenden: bool = False, id: str = "") -> str:
    """Fester Posten anlegen, aendern oder beenden (Gehalt, Miete, Kredit, Sparen ...)."""
    name = _clean(name, 60)
    try:
        start = _norm_month(ab) or _mkey(_today())
        end = _norm_month(bis) if bis else None
        amount = _amount(betrag) if betrag not in (None, "") else None
    except ValueError as exc:
        return f"Nicht eingetragen: {exc}."
    if rhythmus and rhythmus not in RHYTHMUS:
        rhythmus = "monatlich"
    day = None
    if tag not in (None, ""):
        try:
            day = min(31, max(1, int(tag)))
        except (TypeError, ValueError):
            day = None
    month = _midx(start)

    with _lock:
        data = _load()
        # auch Posten, die erst spaeter beginnen (z. B. jaehrliche Versicherung im Maerz)
        active = [i for i in data["fest"] if _active(i, month)] + \
            [i for i in data["fest"] if _midx(i["ab"]) > month]
        item = None
        if id:
            item = next((i for i in data["fest"] if i["id"] == id), None)
        elif name:
            item = next((i for i in active if i["name"].casefold() == name.casefold()), None)
            if item is None:
                close = [i for i in active if name.casefold() in i["name"].casefold() or i["name"].casefold() in name.casefold()]
                item = close[0] if len(close) == 1 else None
        if not name and not item:
            return "Welcher Posten? Bitte einen Namen nennen, z. B. Miete."

        if beenden:
            if not item:
                return f"Einen festen Posten '{name}' finde ich nicht."
            if _midx(item["ab"]) >= month:
                data["fest"].remove(item)
            else:
                item["bis"] = _mkey_of(month - 1)
            _save(data)
            result = f"{item['name']} ist ab {month_label(start)} nicht mehr dabei."
        elif item:
            changes = {}
            if amount is not None and abs(amount - item["betrag"]) >= 0.005:
                changes["betrag"] = amount
            if art in ARTEN[:3] and art != item["art"]:
                changes["art"] = art
            if rhythmus and rhythmus != (item.get("rhythmus") or "monatlich"):
                changes["rhythmus"] = rhythmus
            money = dict(changes)
            if kategorie:
                changes["kategorie"] = _category(data, kategorie, item["name"], changes.get("art", item["art"]))
            if day and day != item.get("tag"):
                changes["tag"] = day
            if bis:
                changes["bis"] = end
            if not changes:
                return f"{item['name']} steht schon so drin ({eur(item['betrag'])})."
            if money and _midx(item["ab"]) < month:
                # Fruehere Monate behalten den alten Betrag
                new = {**item, **changes, "id": _new_id(data, "f"), "ab": start}
                new.setdefault("bis", item.get("bis"))
                item["bis"] = _mkey_of(month - 1)
                data["fest"].append(new)
                item = new
            else:
                item.update(changes)
            _save(data)
            result = f"Geaendert: {_describe_fixed(item)}."
        else:
            if amount is None:
                return f"Wie hoch ist {name}? Bitte mit Betrag nochmal eintragen."
            kind = art if art in ARTEN[:3] else _guess_art(name)
            item = {"id": _new_id(data, "f"), "name": name, "art": kind, "betrag": amount,
                    "kategorie": _category(data, kategorie, name, kind), "tag": day,
                    "rhythmus": rhythmus or "monatlich", "ab": start, "bis": end}
            if kind == "sparen":
                data["toepfe"].setdefault(name, {"start": 0, "ziel": None})
            data["fest"].append(item)
            _save(data)
            result = f"Eingetragen: {_describe_fixed(item)}."
    _changed({"neu": [] if beenden else [item["id"]]})
    s = _summary(data, _mkey(_today()))
    return (f"{result} Monat jetzt: Einnahmen {eur(s['einnahmen'])}, feste Kosten {eur(s['fix'])}, "
            f"Sparen {eur(s['sparen'])}, frei fuer den Monat {eur(s['verfuegbar'])}.")


def _describe_fixed(item: dict) -> str:
    rhythm = item.get("rhythmus") or "monatlich"
    how = "im Monat" if rhythm == "monatlich" else rhythm.replace("ae", "ä")
    sign = "+" if item["art"] == "einnahme" else ""
    text = f"{item['name']} {sign}{eur(item['betrag'])} {how} ({item['kategorie']}"
    if item.get("tag"):
        text += f", am {item['tag']}."
    text += f", ab {month_label(item['ab'])}"
    if item.get("bis"):
        text += f" bis {month_label(item['bis'])}"
    return text + ")"


def configure(kategorie_neu: str = "", kategorie_entfernen: str = "", budget_kategorie: str = "", budget=None,
              topf: str = "", topf_stand=None, topf_ziel=None) -> str:
    done = []
    with _lock:
        data = _load()
        if kategorie_neu:
            before = len(data["kategorien"])
            name = _category(data, kategorie_neu, "", "ausgabe")
            done.append(f"Kategorie {name} angelegt" if len(data["kategorien"]) > before else f"Kategorie {name} gibt es schon")
        if kategorie_entfernen:
            match = [k for k in data["kategorien"] if k.casefold() == kategorie_entfernen.strip().casefold()]
            if match:
                data["kategorien"].remove(match[0])
                data["budgets"].pop(match[0], None)
                done.append(f"Kategorie {match[0]} entfernt (alte Buchungen behalten sie)")
            else:
                done.append(f"Kategorie {kategorie_entfernen} gibt es nicht")
        if budget_kategorie:
            name = _category(data, budget_kategorie, "", "ausgabe")
            try:
                limit = _amount(budget) if budget not in (None, "", 0, "0") else None
            except ValueError:
                limit = None
            if limit:
                data["budgets"][name] = limit
                done.append(f"Budget {name}: hoechstens {eur(limit)} im Monat")
            else:
                data["budgets"].pop(name, None)
                done.append(f"Budget fuer {name} entfernt")
        if topf:
            name = _pot_name(data, topf)
            info = data["toepfe"].setdefault(name, {"start": 0, "ziel": None})
            if topf_ziel not in (None, ""):
                try:
                    info["ziel"] = _amount(topf_ziel)
                except ValueError:
                    info["ziel"] = None
                done.append(f"Sparziel {name}: {eur(info['ziel'])}" if info["ziel"] else f"Sparziel {name} entfernt")
            if topf_stand not in (None, ""):
                try:
                    wanted = _number(topf_stand)
                except ValueError:
                    return f"Den Stand '{topf_stand}' verstehe ich nicht."
                info["start"] = 0
                paid = next(p["eingezahlt"] for p in _pots(data) if p["name"] == name)
                info["start"] = round(wanted - paid, 2)
                done.append(f"{name} steht jetzt bei {eur(wanted)}")
            if topf_ziel in (None, "") and topf_stand in (None, ""):
                done.append(f"Spartopf {name} angelegt")
        if not done:
            return "Nichts geaendert."
        _save(data)
    _changed()
    return "; ".join(done) + "."


# ---------- Abfragen ----------

def overview(monat: str = "", kategorie: str = "") -> str:
    """Text fuer Jarvis: Monatsueberblick, Kategorien, Toepfe, anstehende Abbuchungen, letzte Buchungen."""
    try:
        key = _norm_month(monat) or _mkey(_today())
    except ValueError as exc:
        return str(exc)
    with _lock:
        new = not BOOK.exists()
        data = _load()
    if new or (not data["fest"] and not data["buchungen"]):
        return ("Das Haushaltsbuch ist angelegt und noch leer. Frag Lukas der Reihe nach, je eine kurze Frage: "
                "Netto-Gehalt und an welchem Tag es kommt, Miete (warm oder mit Nebenkosten), Auto (Versicherung, "
                "Steuer, Leasing), Finanzierungen und Kredite mit Rate, was er im Monat spart und fuers Urlaubskonto "
                "zuruecklegt, dann weitere feste Kosten wie Strom, Handy, Internet, Versicherungen und Abos. "
                "Trag jede Antwort sofort mit haushalt_fest ein. Einkaeufe traegt er spaeter per Sprache oder Beleg ein.")
    s = _summary(data, key)
    lines = [f"Haushaltsbuch {s['label']}" + (f" (heute {_short_date(_today().isoformat())})" if s["aktuell"] else "") + ":",
             f"Einnahmen {eur(s['einnahmen'])}, feste Kosten {eur(s['fix'])}, Sparen {eur(s['sparen'])}, "
             f"Ausgaben {eur(s['ausgaben'])}. Uebrig {eur(s['uebrig'])}"
             + (f", {eur(s['pro_tag'])} pro Tag fuer die restlichen {s['tage_rest']} Tage." if s["pro_tag"] else ".")]
    if kategorie:
        rows = [b for b in s["buchungen"] if b["kategorie"].casefold() == kategorie.strip().casefold()]
        fixed = [i for i in s["fest"] if i["faellig"] and i["kategorie"].casefold() == kategorie.strip().casefold()]
        total = sum(b["betrag"] for b in rows if b["art"] == "ausgabe") + sum(i["betrag"] for i in fixed if i["art"] == "ausgabe")
        lines.append(f"{kategorie}: zusammen {eur(total)}, " + (" | ".join(
            [f"fest {i['name']} {eur(i['betrag'])}" for i in fixed] +
            [f"{b['id']} {_short_date(b['datum'])} {b['text']} {eur(b['betrag'])}" for b in rows]) or "keine Buchungen"))
        return "\n".join(lines)
    if s["kategorien_summe"]:
        lines.append("Nach Kategorie: " + ", ".join(
            f"{c['kategorie']} {eur(c['betrag'])}" + (f" (Budget {eur(c['budget'])})" if c["budget"] else "")
            for c in s["kategorien_summe"][:12]))
    pots = _pots(data)
    if pots:
        lines.append("Spartoepfe: " + ", ".join(
            f"{p['name']} {eur(p['stand'])}" + (f" (Ziel {eur(p['ziel'])})" if p["ziel"] else "")
            + (f", {eur(p['rate'])} im Monat" if p["rate"] else "") for p in pots))
    if s["offen"]:
        lines.append("Wird diesen Monat noch abgebucht: " + ", ".join(
            f"{o['name']} {eur(o['betrag'])} am {o['tag']}." for o in s["offen"]))
    if s["fest"]:
        lines.append("Feste Posten: " + " | ".join(
            f"{i['name']} {'+' if i['art'] == 'einnahme' else ''}{eur(i['betrag'])} ({i['art']}, {i['kategorie']}"
            + (f", am {i['tag']}." if i.get("tag") else "") + ("" if i["faellig"] else ", diesen Monat nicht faellig") + ")"
            for i in s["fest"]))
    if s["buchungen"]:
        lines.append("Letzte Buchungen: " + " | ".join(
            f"{b['id']} {_short_date(b['datum'])} {b['text']} {eur(b['betrag'])} ({b['art']}, {b['kategorie']})"
            for b in s["buchungen"][:12]))
    return "\n".join(lines)


def view(monat: str = "") -> dict:
    """Alles fuers Fenster im Browser."""
    try:
        key = _norm_month(monat) or _mkey(_today())
    except ValueError:
        key = _mkey(_today())
    with _lock:
        present = BOOK.exists()
        data = _load()
    s = _summary(data, key)
    months = {b["datum"][:7] for b in data["buchungen"]} | {i["ab"] for i in data["fest"]} | {_mkey(_today())}
    index = _midx(key)
    return {**s, "exists": present, "toepfe": _pots(data), "kategorien": data["kategorien"],
            "budgets": data["budgets"], "vorher": _mkey_of(index - 1), "nachher": _mkey_of(index + 1),
            "erster_monat": min(months), "heute": _today().isoformat()}


def show(open_view: bool = True, monat: str = "") -> bool:
    """Fenster im Browser oeffnen oder schliessen. True = Haushaltsbuch wurde dabei neu angelegt."""
    created = create() if open_view else False
    try:
        key = _norm_month(monat) or _mkey(_today())
    except ValueError:
        key = _mkey(_today())
    _changed({"show": bool(open_view), "monat": key})
    return created


def tool_overview(monat: str = "", zeigen=None, kategorie: str = "") -> str:
    if zeigen is False:
        show(False)
        return "Haushaltsbuch im Fenster geschlossen."
    if zeigen:
        show(True, monat)
    else:
        create()
    return overview(monat, kategorie)


def apply(action: dict) -> dict:
    """Aenderungen aus dem Fenster im Browser."""
    kind = action.get("aktion")
    try:
        if kind == "anlegen":
            create()
            return {"ok": True, "text": "Haushaltsbuch angelegt."}
        if kind == "buchen":
            entry = dict(action.get("eintrag") or {})
            entry.setdefault("quelle", "hand")
            return {"ok": True, "text": book([entry])}
        if kind == "buchung":
            return {"ok": True, "text": change_booking(
                action.get("id", ""), bool(action.get("loeschen")),
                **{k: action.get(k) for k in ("betrag", "text", "kategorie", "datum", "art")})}
        if kind == "fest":
            return {"ok": True, "text": set_fixed(
                action.get("name", ""), action.get("betrag"), action.get("art", ""), action.get("kategorie", ""),
                action.get("tag"), action.get("rhythmus", ""), action.get("ab", ""), action.get("bis", ""),
                bool(action.get("beenden")), action.get("id", ""))}
        if kind == "einstellen":
            return {"ok": True, "text": configure(**{k: action.get(k) for k in (
                "kategorie_neu", "kategorie_entfernen", "budget_kategorie", "budget", "topf", "topf_stand", "topf_ziel")
                if action.get(k) not in (None, "")})}
    except RuntimeError as exc:
        return {"ok": False, "text": str(exc)}
    return {"ok": False, "text": f"Unbekannte Aktion: {kind}"}
