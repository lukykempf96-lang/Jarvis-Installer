"""Mails (Apple Mail), Nachrichten (iMessage/SMS), Kalender und Kontakte vom Mac lesen.

Alles bleibt auf dem Mac: Mail wird per AppleScript gefragt, Nachrichten und Kontakte
liegen als Datenbanken in ~/Library, der Kalender kommt ueber EventKit. macOS fragt beim
ersten Mal nach der Erlaubnis; fuer Nachrichten braucht Terminal "Festplattenvollzugriff".
Gesendet oder geloescht wird hier nichts.
"""
from __future__ import annotations

import glob
import os
import re
import shutil
import sqlite3
import subprocess
import tempfile
import threading
import time
from datetime import datetime, timedelta
from pathlib import Path
from urllib.parse import quote

HOME = Path.home()
MESSAGES_DB = HOME / "Library/Messages/chat.db"
ADDRESSBOOK_DIR = HOME / "Library/Application Support/AddressBook"
APPLE_EPOCH = 978307200  # 1.1.2001, Startpunkt der Apple-Zeitstempel

WEEKDAYS = ["Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag", "Sonntag"]

FDA_HINT = (
    "Ich darf die Nachrichten noch nicht lesen. Dafuer in den Systemeinstellungen unter "
    "Datenschutz und Sicherheit, Festplattenvollzugriff, das Terminal einschalten und Jarvis neu starten. "
    "Ich habe die Einstellung geoeffnet."
)
MAIL_AUTOMATION_HINT = (
    "Ich darf die Mail-App noch nicht fragen. In den Systemeinstellungen unter Datenschutz und "
    "Sicherheit, Automation, beim Terminal den Schalter fuer Mail einschalten. Ich habe die Einstellung geoeffnet."
)
CALENDAR_HINT = (
    "Ich darf den Kalender noch nicht lesen. In den Systemeinstellungen unter Datenschutz und "
    "Sicherheit, Kalender, das Terminal auf Vollzugriff stellen und Jarvis neu starten. Ich habe die Einstellung geoeffnet."
)

_settings_opened: set[str] = set()


def _open_privacy_settings(pane: str):
    """Oeffnet die passende Datenschutz-Einstellung, aber nur einmal pro Jarvis-Start."""
    if pane in _settings_opened:
        return
    _settings_opened.add(pane)
    subprocess.run(["open", f"x-apple.systempreferences:com.apple.preference.security?{pane}"],
                   capture_output=True)


def _fmt_time(dt: datetime, now: datetime | None = None) -> str:
    now = now or datetime.now()
    days = (dt.date() - now.date()).days
    clock = dt.strftime("%H:%M")
    if days == 0:
        return f"heute {clock}"
    if days == -1:
        return f"gestern {clock}"
    if days == 1:
        return f"morgen {clock}"
    if -7 < days < 7:
        return f"{WEEKDAYS[dt.weekday()]} {clock}"
    return dt.strftime("%d.%m. %H:%M")


def _short(text: str, limit: int) -> str:
    text = re.sub(r"\s+", " ", text or "").strip()
    return text if len(text) <= limit else text[: limit - 1].rstrip() + "…"


# ---------------------------------------------------------------- Kontakte

def _digits(number: str) -> str:
    """Telefonnummern vergleichbar machen: die letzten 9 Ziffern (+49 171 ... == 0171 ...)."""
    d = re.sub(r"\D", "", number or "")
    return d[-9:] if len(d) >= 6 else d


def _open_db(path: Path) -> sqlite3.Connection:
    """Nur lesend oeffnen. Klappt das nicht (z. B. WAL-Datei gesperrt), mit einer Kopie arbeiten."""
    try:
        con = sqlite3.connect(f"file:{quote(str(path))}?mode=ro", uri=True, timeout=5)
        con.execute("select 1 from sqlite_master limit 1").fetchall()
        return con
    except sqlite3.Error:
        tmp = Path(tempfile.mkdtemp(prefix="jarvis_db_"))
        for suffix in ("", "-wal", "-shm"):
            src = Path(str(path) + suffix)
            if src.exists():
                shutil.copy2(src, tmp / (path.name + suffix))
        return sqlite3.connect(str(tmp / path.name))


_contacts: dict = {"at": 0.0, "phones": {}, "emails": {}}
_contacts_lock = threading.Lock()


def _load_contacts():
    """Namen zu Telefonnummern und Mailadressen aus der Kontakte-App (fuer 10 Minuten gemerkt)."""
    with _contacts_lock:
        if time.time() - _contacts["at"] < 600:
            return _contacts
        phones, emails = {}, {}
        dbs = glob.glob(str(ADDRESSBOOK_DIR / "Sources/*/AddressBook-v22.abcddb"))
        dbs.append(str(ADDRESSBOOK_DIR / "AddressBook-v22.abcddb"))
        for db in dbs:
            if not os.path.exists(db):
                continue
            try:
                con = _open_db(Path(db))
                names = {}
                for pk, first, last, org in con.execute(
                        "select Z_PK, ZFIRSTNAME, ZLASTNAME, ZORGANIZATION from ZABCDRECORD"):
                    name = " ".join(p for p in (first, last) if p) or org
                    if name:
                        names[pk] = name
                for owner, number in con.execute("select ZOWNER, ZFULLNUMBER from ZABCDPHONENUMBER"):
                    if owner in names and _digits(number):
                        phones[_digits(number)] = names[owner]
                for owner, address in con.execute("select ZOWNER, ZADDRESS from ZABCDEMAILADDRESS"):
                    if owner in names and address:
                        emails[address.strip().lower()] = names[owner]
                con.close()
            except (sqlite3.Error, OSError):
                continue  # ohne Festplattenvollzugriff gibt es eben keine Namen
        _contacts.update(at=time.time(), phones=phones, emails=emails)
        return _contacts


def contact_name(handle: str) -> str | None:
    if not handle:
        return None
    c = _load_contacts()
    if "@" in handle:
        return c["emails"].get(handle.strip().lower())
    return c["phones"].get(_digits(handle))


# ---------------------------------------------------------------- Mail

US, RS = "\x1f", "\x1e"  # Trennzeichen fuer die AppleScript-Ausgabe

_AUTOMATED = re.compile(
    r"no-?reply|do-?not-?reply|newsletter|news@|info@|noti(fy|fication)|mailer|marketing|"
    r"service@|support@|hello@|team@|updates?@|angebote|werbung|deals|promo",
    re.I,
)


class PermissionMissing(Exception):
    pass


def _osascript(script: str, timeout: int = 90) -> str:
    try:
        proc = subprocess.run(["osascript", "-e", script], capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        raise RuntimeError("Die Mail-App antwortet nicht (Zeitlimit). Ist sie gerade beschaeftigt?")
    if proc.returncode != 0:
        err = proc.stderr.strip()
        if "-1743" in err or "nicht berechtigt" in err.lower() or "not authorized" in err.lower():
            raise PermissionMissing(err)
        raise RuntimeError(err or "AppleScript-Fehler")
    return proc.stdout.rstrip("\n")


def _as_string(value: str) -> str:
    return '"' + value.replace("\\", "\\\\").replace('"', '\\"') + '"'


def _split_sender(sender: str) -> tuple[str, str]:
    """'Max Muster <max@x.de>' -> ('Max Muster', 'max@x.de')"""
    m = re.match(r'\s*"?(.*?)"?\s*<([^>]+)>', sender or "")
    if m:
        return (m.group(1).strip() or m.group(2)), m.group(2).strip()
    return (sender or "").strip(), (sender or "").strip()


def _parse_mails(raw: str) -> tuple[int, list[dict]]:
    parts = raw.split(RS)
    total = int(parts[0] or 0) if parts and parts[0].strip().isdigit() else 0
    mails = []
    for rec in parts[1:]:
        f = rec.split(US)
        if len(f) < 7:
            continue
        msg_id, sender, subject, date, flagged, account, content = f[:7]
        read = len(f) > 7 and f[7].strip() == "true"
        name, address = _split_sender(sender)
        try:
            received = datetime.fromisoformat(date.strip())
        except ValueError:
            received = datetime.now()
        mails.append({
            "id": msg_id.strip(), "name": contact_name(address) or name, "address": address,
            "subject": subject.strip() or "(ohne Betreff)", "received": received,
            "flagged": flagged.strip() == "true", "account": account.strip(),
            "preview": _short(content, 220), "known": contact_name(address) is not None,
            "automated": bool(_AUTOMATED.search(address)), "read": read,
        })
    mails.sort(key=lambda m: m["received"], reverse=True)
    return total, mails


def fetch_mails(days: int = 3, limit: int = 30, unread_only: bool = True) -> tuple[int, list[dict]]:
    mails = _mails_from_db(days, unread_only)
    if mails is not None:
        return len(mails), mails[:limit]
    condition = "read status is false and date received > cutoff" if unread_only else "date received > cutoff"
    script = f"""
set US to character id 31
set RS to character id 30
set cutoff to (current date) - ({int(days)} * days)
set out to ""
tell application "Mail"
    set msgs to (messages of inbox whose {condition})
    set n to count of msgs
    repeat with i from 1 to n
        if i > {int(limit)} then exit repeat
        set m to item i of msgs
        set acc to ""
        try
            set acc to name of account of mailbox of m
        end try
        set c to ""
        try
            set c to content of m
            if length of c > 400 then set c to text 1 thru 400 of c
        end try
        set out to out & (message id of m) & US & (sender of m) & US & (subject of m) & US & ((date received of m) as «class isot» as string) & US & (flagged status of m) & US & acc & US & c & US & (read status of m) & RS
    end repeat
    return (n as string) & RS & out
end tell
"""
    return _parse_mails(_osascript(script))


def fetch_mail_headers(days: int = 3, limit: int = 80) -> list[dict]:
    """Schnell: nur Absender, Betreff, Datum usw. als Listen in wenigen Apple-Events, ohne Mailtext.

    Den Text jeder Mail einzeln zu holen dauert bei vielen Mails (IMAP) leicht Minuten.
    Am schnellsten geht es ueber Mails eigene Datenbank; die Mail-App ist nur der Ersatzweg.
    """
    mails = _mails_from_db(days)
    if mails is not None:
        return mails[:limit]
    script = f"""
set US to character id 31
set RS to character id 30
set cutoff to (current date) - ({int(days)} * days)
tell application "Mail"
    set ids to message id of (messages of inbox whose date received > cutoff)
    set snd to sender of (messages of inbox whose date received > cutoff)
    set subj to subject of (messages of inbox whose date received > cutoff)
    set dts to date received of (messages of inbox whose date received > cutoff)
    set flg to flagged status of (messages of inbox whose date received > cutoff)
    set rd to read status of (messages of inbox whose date received > cutoff)
end tell
set n to count of ids
set out to ""
repeat with i from 1 to n
    set out to out & (item i of ids) & US & (item i of snd) & US & (item i of subj) & US & ((item i of dts) as «class isot» as string) & US & (item i of flg) & US & "" & US & "" & US & (item i of rd) & RS
end repeat
return (n as string) & RS & out
"""
    _, mails = _parse_mails(_osascript(script, timeout=45))
    return mails[:limit]  # _parse_mails sortiert schon: neueste zuerst


def fetch_mail_preview(message_id: str, length: int = 400) -> str:
    """Anfang des Textes einer Mail, fuer die Kurzfassung."""
    script = f"""
tell application "Mail"
    set c to content of {_mail_ref(message_id)}
end tell
if length of c > {int(length)} then set c to text 1 thru {int(length)} of c
return c
"""
    return _short(_osascript(script, timeout=30), length)


# Mail fuehrt selbst eine Datenbank ("Envelope Index") mit Absender, Betreff, Datum und einer
# kurzen Vorschau jeder Mail. Sie direkt zu lesen dauert Millisekunden, die Mail-App per
# AppleScript zu fragen bei grossen Postfaechern dagegen Minuten (oder sie antwortet gar nicht).
# Braucht wie die Nachrichten "Festplattenvollzugriff" fuers Terminal.
MAIL_DIR = HOME / "Library/Mail"
_mail_db_state = {"warned": ""}


def _mail_db_path() -> Path | None:
    found = []
    for path in glob.glob(str(MAIL_DIR / "V*/MailData/Envelope Index")):
        m = re.search(r"/V(\d+)/", path)
        found.append((int(m.group(1)) if m else 0, path))
    return Path(max(found)[1]) if found else None


def _open_mail_db(path: Path) -> sqlite3.Connection:
    """Nur lesend; die Datei ist oft gross, darum keine Kopie wie bei den Nachrichten."""
    uri = f"file:{quote(str(path))}"
    try:
        con = sqlite3.connect(uri + "?mode=ro", uri=True, timeout=5)
        con.execute("select 1 from sqlite_master limit 1").fetchall()
        return con
    except sqlite3.Error:
        con = sqlite3.connect(uri + "?immutable=1", uri=True)
        con.execute("select 1 from sqlite_master limit 1").fetchall()
        return con


def _columns(con: sqlite3.Connection, table: str) -> set[str]:
    return {row[1] for row in con.execute(f"pragma table_info({table})")}


def _is_inbox(url: str) -> bool:
    from urllib.parse import unquote
    last = unquote(url or "").rstrip("/").rsplit("/", 1)[-1].lower()
    return last in ("inbox", "posteingang")


def mail_db_readable() -> bool:
    """False, wenn es Mails Datenbank gibt, Jarvis sie aber nicht lesen darf oder kann."""
    return not _mail_db_state["warned"]


def _mails_from_db(days: int, unread_only: bool = False) -> list[dict] | None:
    """Mails der letzten Tage aus dem Posteingang, neueste zuerst. None, wenn die Datenbank nicht lesbar ist."""
    path = _mail_db_path()
    if path is None:
        return None
    try:
        con = _open_mail_db(path)
        try:
            mails = _query_mail_db(con, days, unread_only)
        finally:
            con.close()
        _mail_db_state["warned"] = ""
        return mails
    except Exception as exc:  # fehlende Erlaubnis, anderes Format: dann eben ueber die Mail-App
        reason = f"{type(exc).__name__}: {exc}"
        if _mail_db_state["warned"] != reason:
            _mail_db_state["warned"] = reason
            print(f"Mail-Datenbank nicht lesbar ({reason}), frage die Mail-App.", flush=True)
        return None


def _query_mail_db(con: sqlite3.Connection, days: int, unread_only: bool) -> list[dict]:
    cols = _columns(con, "messages")
    need = {"sender", "subject", "date_received", "mailbox", "read", "flagged"}
    if not need <= cols:
        raise RuntimeError(f"unbekanntes Format, es fehlen {sorted(need - cols)}")
    inboxes = [rid for rid, url in con.execute("select ROWID, url from mailboxes") if _is_inbox(url)]
    if not inboxes:
        return []

    select = ["m.ROWID", "a.address", "a.comment", "s.subject", "m.date_received", "m.read", "m.flagged"]
    joins = ["left join addresses a on a.ROWID = m.sender", "left join subjects s on s.ROWID = m.subject"]
    select.append("m.subject_prefix" if "subject_prefix" in cols else "''")
    if "summary" in cols and _columns(con, "summaries") >= {"summary"}:
        select.append("su.summary")
        joins.append("left join summaries su on su.ROWID = m.summary")
    else:
        select.append("''")
    header = "''"
    if "global_message_id" in cols and "message_id_header" in _columns(con, "message_global_data"):
        header = "g.message_id_header"
        joins.append("left join message_global_data g on g.ROWID = m.global_message_id")
    elif "message_id_header" in cols:
        header = "m.message_id_header"
    select.append(header)

    # Datum: Unix-Sekunden; aeltere Formate zaehlen ab 2001
    max_date = con.execute("select max(date_received) from messages").fetchone()[0] or 0
    offset = APPLE_EPOCH if max_date and max_date < 1_200_000_000 else 0
    cutoff = time.time() - days * 86400 - offset

    where = [f"m.mailbox in ({','.join('?' * len(inboxes))})", "m.date_received > ?"]
    if "deleted" in cols:
        where.append("coalesce(m.deleted, 0) = 0")
    if unread_only:
        where.append("coalesce(m.read, 0) = 0")
    sql = (f"select {', '.join(select)} from messages m {' '.join(joins)} "
           f"where {' and '.join(where)} order by m.date_received desc limit 300")

    mails, seen = [], set()
    for rowid, address, comment, subject, date, read, flagged, prefix, summary, msg_id in con.execute(sql, [*inboxes, cutoff]):
        msg_id = (msg_id or "").strip().strip("<>")
        key = msg_id or f"x-rowid:{rowid}"
        if key in seen:  # dieselbe Mail in mehreren Konten / Gmail-Ordnern
            continue
        seen.add(key)
        address = (address or "").strip()
        known = contact_name(address)
        mails.append({
            "id": key, "name": known or (comment or "").strip() or address, "address": address,
            "subject": ((prefix or "") + (subject or "")).strip() or "(ohne Betreff)",
            "received": datetime.fromtimestamp((date or 0) + offset),
            "flagged": bool(flagged), "account": "", "preview": _short(summary or "", 220),
            "known": known is not None, "automated": bool(_AUTOMATED.search(address)),
            "read": bool(read), "src": "db",
        })
    return mails


def _mail_ref(message_id: str) -> str:
    """AppleScript-Ausdruck fuer eine Mail, ueber die Message-ID oder Mails interne Nummer."""
    if message_id.startswith("x-rowid:"):
        return f"(first message of inbox whose id is {int(message_id[8:])})"
    return f"(first message of inbox whose message id is {_as_string(message_id)})"


def fetch_unread_mails(days: int = 3, limit: int = 30) -> tuple[int, list[dict]]:
    return fetch_mails(days, limit, unread_only=True)


def _mail_line(m: dict) -> str:
    tags = []
    if m["flagged"]:
        tags.append("markiert")
    if m["known"]:
        tags.append("Kontakt")
    if m["automated"]:
        tags.append("automatisch")
    tag = f" [{', '.join(tags)}]" if tags else ""
    return (f"- {_fmt_time(m['received'])}, von {m['name']} <{m['address']}>{tag}: "
            f"„{m['subject']}“ — {m['preview']} (id: {m['id']})")


def get_mails(days: int = 3) -> str:
    try:
        total, mails = fetch_unread_mails(days)
    except PermissionMissing:
        _open_privacy_settings("Privacy_Automation")
        return MAIL_AUTOMATION_HINT
    except RuntimeError as exc:
        return f"Mail konnte nicht gelesen werden: {exc}"
    if not mails:
        return f"Keine ungelesenen Mails im Posteingang der letzten {days} Tage."
    head = f"{total} ungelesene Mails der letzten {days} Tage"
    if total > len(mails):
        head += f", hier die {len(mails)} neuesten"
    return head + ":\n" + "\n".join(_mail_line(m) for m in mails)


def read_mail(message_id: str) -> str:
    script = f"""
set US to character id 31
tell application "Mail"
    set m to {_mail_ref(message_id)}
    return (sender of m) & US & (subject of m) & US & ((date received of m) as string) & US & (content of m)
end tell
"""
    try:
        sender, subject, date, content = _osascript(script).split(US, 3)
    except PermissionMissing:
        _open_privacy_settings("Privacy_Automation")
        return MAIL_AUTOMATION_HINT
    except (RuntimeError, ValueError) as exc:
        return f"Diese Mail habe ich nicht gefunden ({exc})."
    content = content.strip()
    if len(content) > 6000:
        content = content[:6000] + " …(gekuerzt)"
    return f"Von: {sender}\nBetreff: {subject}\nDatum: {date}\n\n{content}"


def open_mail(message_id: str) -> str:
    """Zeigt die Mail in der Mail-App (message://-Link)."""
    if message_id.startswith("x-rowid:"):
        try:
            _osascript(f'tell application "Mail"\n    open {_mail_ref(message_id)}\n    activate\nend tell', timeout=30)
            return "Die Mail ist in der Mail-App geoeffnet."
        except Exception:
            return "Konnte die Mail nicht oeffnen."
    url = "message://" + quote(f"<{message_id.strip('<>')}>", safe="")
    proc = subprocess.run(["open", url], capture_output=True)
    return "Die Mail ist in der Mail-App geoeffnet." if proc.returncode == 0 else "Konnte die Mail nicht oeffnen."


# ---------------------------------------------------------------- Nachrichten (iMessage/SMS)

def _apple_time(value) -> datetime:
    value = value or 0
    if value > 1e11:  # seit macOS 10.13 in Nanosekunden
        value = value / 1e9
    return datetime.fromtimestamp(value + APPLE_EPOCH)


def _decode_attributed_body(blob: bytes | None) -> str:
    """Neuere macOS-Versionen speichern den Text nur noch im attributedBody (NSAttributedString)."""
    if not blob:
        return ""
    idx = blob.find(b"NSString")
    if idx < 0:
        return ""
    rest = blob[idx + len(b"NSString") + 5:]
    if not rest:
        return ""
    if rest[0] == 0x81:
        length, start = int.from_bytes(rest[1:3], "little"), 3
    elif rest[0] == 0x82:
        length, start = int.from_bytes(rest[1:4], "little"), 4
    else:
        length, start = rest[0], 1
    return rest[start:start + length].decode("utf-8", errors="ignore")


def _is_automated_handle(handle: str) -> bool:
    """Kurznummern und Absendernamen (Banken, Paketdienste, Codes) statt echter Menschen."""
    if not handle or "@" in handle:
        return False
    digits = re.sub(r"\D", "", handle)
    return len(digits) <= 6 or bool(re.search(r"[A-Za-z]", handle))


def fetch_recent_chats(hours: int = 24) -> list[dict]:
    if not MESSAGES_DB.exists():
        return []
    try:
        with open(MESSAGES_DB, "rb"):
            pass
    except PermissionError:
        raise PermissionMissing("Festplattenvollzugriff fehlt")
    since = (time.time() - hours * 3600 - APPLE_EPOCH) * 1e9
    con = _open_db(MESSAGES_DB)
    try:
        rows = con.execute(
            """
            select m.date, m.is_from_me, m.is_read, m.text, m.attributedBody, m.cache_has_attachments,
                   h.id, c.ROWID, c.display_name, c.chat_identifier, c.style
            from message m
            join chat_message_join cmj on cmj.message_id = m.ROWID
            join chat c on c.ROWID = cmj.chat_id
            left join handle h on h.ROWID = m.handle_id
            where m.date > ? and coalesce(m.associated_message_type, 0) = 0 and coalesce(m.item_type, 0) = 0
            order by m.date asc
            """,
            (since,),
        ).fetchall()
        members: dict[int, list[str]] = {}
        for chat_id, handle in con.execute(
                "select chj.chat_id, h.id from chat_handle_join chj join handle h on h.ROWID = chj.handle_id"):
            members.setdefault(chat_id, []).append(handle)
    finally:
        con.close()

    chats: dict[int, dict] = {}
    for date, from_me, is_read, text, body, has_att, handle, chat_id, display, identifier, style in rows:
        text = (text or _decode_attributed_body(body)).replace("￼", "").strip()
        if not text and has_att:
            text = "[Anhang]"
        if not text:
            continue
        group = style == 43
        if group:
            names = [contact_name(h) or h for h in members.get(chat_id, [])]
            title = display or ", ".join(names[:4]) or "Gruppe"
        else:
            title = contact_name(identifier) or identifier
        chat = chats.setdefault(chat_id, {
            "title": title, "group": group, "known": group or contact_name(identifier) is not None,
            "automated": not group and _is_automated_handle(identifier),
            "messages": [], "unread": 0, "last": None, "last_from_me": False,
        })
        sender = "Ich" if from_me else (contact_name(handle) or handle or title)
        chat["messages"].append((_apple_time(date), sender, text))
        if not from_me and not is_read:
            chat["unread"] += 1
        chat["last"] = _apple_time(date)
        chat["last_from_me"] = bool(from_me)
    result = [c for c in chats.values() if c["messages"]]
    result.sort(key=lambda c: c["last"], reverse=True)
    return result


def _chat_block(c: dict) -> str:
    tags = []
    if c["unread"]:
        tags.append(f"{c['unread']} ungelesen")
    if c["last_from_me"]:
        tags.append("zuletzt hat Lukas geschrieben")
    elif not c["automated"]:
        tags.append("wartet evtl. auf Antwort")
    if c["group"]:
        tags.append("Gruppe")
    if c["automated"]:
        tags.append("automatisch")
    lines = [f"* {c['title']} ({', '.join(tags)}), zuletzt {_fmt_time(c['last'])}:"]
    for when, sender, text in c["messages"][-4:]:
        lines.append(f"    {when.strftime('%H:%M')} {sender}: {_short(text, 200)}")
    return "\n".join(lines)


def get_messages(hours: int = 24) -> str:
    try:
        chats = fetch_recent_chats(hours)
    except PermissionMissing:
        _open_privacy_settings("Privacy_AllFiles")
        return FDA_HINT
    except sqlite3.Error as exc:
        return f"Nachrichten konnten nicht gelesen werden: {exc}"
    if not chats:
        return f"Keine Nachrichten in den letzten {hours} Stunden."
    return (f"Unterhaltungen der letzten {hours} Stunden (iMessage/SMS, neueste zuerst):\n"
            + "\n".join(_chat_block(c) for c in chats[:15]))


# ---------------------------------------------------------------- Kalender

def _ensure_access(entity: int) -> bool:
    """Fragt beim ersten Mal nach Kalender- (0) oder Erinnerungs-Zugriff (1). True = Vollzugriff."""
    import EventKit  # pyobjc, gibt es nur auf dem Mac

    status = EventKit.EKEventStore.authorizationStatusForEntityType_(entity)
    if status == 0:  # noch nie gefragt: macOS zeigt jetzt den Dialog
        store = EventKit.EKEventStore.alloc().init()
        done = threading.Event()

        def handler(granted, error):
            done.set()

        if entity == 0 and hasattr(store, "requestFullAccessToEventsWithCompletion_"):
            store.requestFullAccessToEventsWithCompletion_(handler)
        elif entity == 1 and hasattr(store, "requestFullAccessToRemindersWithCompletion_"):
            store.requestFullAccessToRemindersWithCompletion_(handler)
        else:
            store.requestAccessToEntityType_completion_(entity, handler)
        done.wait(120)
        status = EventKit.EKEventStore.authorizationStatusForEntityType_(entity)
    return status == 3  # 3 = Vollzugriff


def _hex_color(cal) -> str:
    try:
        from AppKit import NSColorSpace
        c = cal.color().colorUsingColorSpace_(NSColorSpace.sRGBColorSpace())
        return "#%02x%02x%02x" % tuple(int(round(v * 255)) for v in (c.redComponent(), c.greenComponent(), c.blueComponent()))
    except Exception:
        return ""


def fetch_events_between(start: datetime, end: datetime) -> list[dict]:
    import EventKit
    from Foundation import NSDate

    if not _ensure_access(EventKit.EKEntityTypeEvent):
        raise PermissionMissing("Kalenderzugriff fehlt")
    store = EventKit.EKEventStore.alloc().init()
    pred = store.predicateForEventsWithStartDate_endDate_calendars_(
        NSDate.dateWithTimeIntervalSince1970_(start.timestamp()),
        NSDate.dateWithTimeIntervalSince1970_(end.timestamp()), None)
    events = []
    for e in store.eventsMatchingPredicate_(pred) or []:
        cal = e.calendar()
        events.append({
            "title": str(e.title() or "Termin"),
            "start": datetime.fromtimestamp(e.startDate().timeIntervalSince1970()),
            "end": datetime.fromtimestamp(e.endDate().timeIntervalSince1970()),
            "all_day": bool(e.isAllDay()),
            "location": str(e.location() or ""),
            "calendar": str(cal.title() or "") if cal else "",
            "color": _hex_color(cal) if cal else "",
        })
    events.sort(key=lambda e: (e["start"], not e["all_day"]))
    return events


def fetch_events(days: int = 1) -> list[dict]:
    start = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
    return fetch_events_between(start, start + timedelta(days=max(1, days)))


NS_UNDEFINED = 9223372036854775807  # NSDateComponentUndefined: Erinnerung ohne Uhrzeit


def fetch_reminders(until: datetime) -> list[dict]:
    """Offene Erinnerungen, die bis `until` faellig sind (auch ueberfaellige)."""
    import EventKit
    from Foundation import NSCalendar, NSDate

    if not _ensure_access(EventKit.EKEntityTypeReminder):
        raise PermissionMissing("Erinnerungszugriff fehlt")
    store = EventKit.EKEventStore.alloc().init()
    pred = store.predicateForIncompleteRemindersWithDueDateStarting_ending_calendars_(
        None, NSDate.dateWithTimeIntervalSince1970_(until.timestamp()), None)
    result: list = []
    done = threading.Event()

    def handler(reminders):
        result.extend(reminders or [])
        done.set()

    store.fetchRemindersMatchingPredicate_completion_(pred, handler)
    done.wait(20)
    items = []
    for r in result:
        due = None
        comps = r.dueDateComponents()
        if comps is not None:
            try:
                d = NSCalendar.currentCalendar().dateFromComponents_(comps)
                due = datetime.fromtimestamp(d.timeIntervalSince1970()) if d else None
            except Exception:
                due = None
        items.append({"title": str(r.title() or "Erinnerung"), "due": due,
                      "has_time": bool(comps is not None and comps.hour() != NS_UNDEFINED)})
    items.sort(key=lambda i: i["due"] or until)
    return items


def get_calendar(days: int = 1) -> str:
    try:
        events = fetch_events(days)
    except PermissionMissing:
        _open_privacy_settings("Privacy_Calendars")
        return CALENDAR_HINT
    except ImportError:
        return "Der Kalender-Baustein fehlt noch. Bitte Jarvis einmal neu installieren."
    span = "heute" if days <= 1 else f"in den naechsten {days} Tagen"
    if not events:
        return f"Keine Termine {span}."
    now = datetime.now()
    lines = []
    for e in events:
        if e["all_day"]:
            when = "ganztaegig" + ("" if e["start"].date() == now.date() else f" {WEEKDAYS[e['start'].weekday()]}")
        else:
            when = f"{_fmt_time(e['start'], now)} bis {e['end'].strftime('%H:%M')}"
            if e["end"] < now:
                when += " (vorbei)"
        where = f", Ort: {e['location']}" if e["location"] else ""
        lines.append(f"- {when}: {e['title']}{where} [{e['calendar']}]")
    return f"Termine {span}:\n" + "\n".join(lines)
