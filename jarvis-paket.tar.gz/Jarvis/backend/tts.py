from __future__ import annotations

import hashlib
import subprocess
import tempfile
from pathlib import Path

import httpx

from .config import settings

ELEVENLABS_URL = "https://api.elevenlabs.io/v1/text-to-speech/{voice_id}"
# Feste Saetze (Begruessung) einmal erzeugen und dann sofort abspielen
CACHE_DIR = Path(__file__).resolve().parent.parent / "stimmen-cache"


def _elevenlabs(text: str) -> bytes | None:
    url = ELEVENLABS_URL.format(voice_id=settings.elevenlabs_voice_id)
    headers = {
        "xi-api-key": settings.elevenlabs_api_key,
        "Content-Type": "application/json",
        "Accept": "audio/mpeg",
    }
    payload = {
        "text": text,
        "model_id": "eleven_multilingual_v2",
        "voice_settings": {"stability": 0.4, "similarity_boost": 0.8},
    }
    try:
        resp = httpx.post(url, headers=headers, json=payload, timeout=30)
        resp.raise_for_status()
        return resp.content
    except httpx.HTTPError as exc:
        print(f"ElevenLabs-Fehler, nehme Mac-Stimme: {exc}")
        return None


def _mac_voice(text: str) -> bytes | None:
    """Eingebaute macOS-Stimme (say), als m4a fuer den Browser."""
    tmp = Path(tempfile.gettempdir())
    aiff, m4a = tmp / "jarvis_say.aiff", tmp / "jarvis_say.m4a"
    result = subprocess.run(["say", "-v", settings.mac_voice, "-o", str(aiff), text], capture_output=True)
    if result.returncode != 0:  # Stimme nicht installiert -> Standardstimme
        result = subprocess.run(["say", "-o", str(aiff), text], capture_output=True)
    if result.returncode != 0:
        return None
    subprocess.run(["afconvert", "-f", "m4af", "-d", "aac", str(aiff), str(m4a)], capture_output=True)
    return m4a.read_bytes() if m4a.exists() else None


def synthesize_speech(text: str, cache: bool = False) -> tuple[bytes, str] | None:
    """Liefert (Audio, Medientyp) oder None. Mit cache=True wird der Satz nur einmal erzeugt."""
    if not cache:
        return _synthesize(text)
    voice = settings.elevenlabs_voice_id if settings.elevenlabs_api_key else settings.mac_voice
    stem = hashlib.sha1(f"{voice}|{text}".encode()).hexdigest()[:20]
    for suffix, media_type in ((".mp3", "audio/mpeg"), (".m4a", "audio/mp4")):
        cached = CACHE_DIR / (stem + suffix)
        if cached.exists():
            return cached.read_bytes(), media_type
    result = _synthesize(text)
    if result:
        CACHE_DIR.mkdir(exist_ok=True)
        (CACHE_DIR / (stem + (".mp3" if result[1] == "audio/mpeg" else ".m4a"))).write_bytes(result[0])
    return result


def _synthesize(text: str) -> tuple[bytes, str] | None:
    if settings.elevenlabs_api_key:
        audio = _elevenlabs(text)
        if audio:
            return audio, "audio/mpeg"
    audio = _mac_voice(text)
    if audio:
        return audio, "audio/mp4"
    return None
