"""Dashboard im Jarvis-Fenster: wichtige Mails (mit Kurzfassung), Termine, Erinnerungen, Wochenauslastung.

Welche Mails wichtig sind, entscheiden zuerst Lukas' eigene Regeln (mail-prioritaeten.json),
danach Claude Haiku (pro Mail einmal, wird gemerkt), ohne Schluessel einfache Regeln.
"""
from __future__ import annotations

import json
import re
import threading
import time
from datetime import datetime, timedelta
from pathlib import Path

import anthropic

from . import alltag
from .config import settings

BASE_DIR = Path(__file__).resolve().parent.parent
PRIO_FILE = BASE_DIR / "mail-prioritaeten.json"
CACHE_FILE = BASE_DIR / "mail-einordnung.json"

WORK_START, WORK_END = 8, 20  # Wochenauslastung: verplante Zeit zwischen 8 und 20 Uhr
DAY_SHORT = ["Mo", "Di", "Mi", "Do", "Fr", "Sa", "So"]
EMPTY_PRIOS = {"wichtig_absender": [], "wichtig_woerter": [], "ausblenden": []}

_lock = threading.Lock()


# ---------------------------------------------------------------- eigene Prioritaeten

def load_priorities() -> dict:
    try:
        data = json.loads(PRIO_FILE.read_text())
    except (OSError, ValueError):
        data = {}
    return {k: [str(v).strip() for v in data.get(k, []) if str(v).strip()] for k in EMPTY_PRIOS}


def save_priorities(data: dict) -> dict:
    clean = {k: sorted({str(v).strip() for v in data.get(k, []) if str(v).strip()}, key=str.lower)
             for k in EMPTY_PRIOS}
    PRIO_FILE.write_text(json.dumps(clean, ensure_ascii=False, indent=2))
    _sections["mails"]["at"] = 0.0  # Mails beim naechsten Abruf neu einordnen
    return clean


def _matches(entry: str, mail: dict) -> bool:
    """'tim@x.de' = genau diese Adresse, '@firma.de' = ganze Domain, sonst Teil von Name oder Adresse."""
    e = entry.lower()
    address, name = mail["address"].lower(), mail["name"].lower()
    if e.startswith("@"):
        return address.endswith(e)
    if "@" in e:
        return address == e
    return e in name or e in address


def set_mail_priority(sender: str = "", keyword: str = "", hide: bool = False, remove: bool = False) -> str:
    """Fuer Jarvis per Sprache: 'Mails von Tim sind immer wichtig', 'Zeig mir nichts mehr von Zalando'."""
    prios = load_priorities()
    changes = []
    for value, key in ((sender, "ausblenden" if hide else "wichtig_absender"), (keyword, "wichtig_woerter")):
        value = (value or "").strip()
        if not value:
            continue
        if remove:
            for k in EMPTY_PRIOS:
                prios[k] = [v for v in prios[k] if v.lower() != value.lower()]
            changes.append(f"'{value}' entfernt")
        elif value.lower() not in (v.lower() for v in prios[key]):
            prios[key].append(value)
            label = {"ausblenden": "wird ausgeblendet", "wichtig_absender": "gilt als wichtig",
                     "wichtig_woerter": "macht Mails wichtig"}[key]
            changes.append(f"'{value}' {label}")
    if not changes:
        return "Nichts geaendert. Nenne einen Absender oder ein Stichwort."
    save_priorities(prios)
    return "Gespeichert: " + ", ".join(changes) + "."


# ---------------------------------------------------------------- Mails einordnen

def _load_cache() -> dict:
    try:
        return json.loads(CACHE_FILE.read_text())
    except (OSError, ValueError):
        return {}


def _save_cache(cache: dict):
    # nur die letzten 500 Mails merken
    items = sorted(cache.items(), key=lambda kv: kv[1].get("t", 0))[-500:]
    try:
        CACHE_FILE.write_text(json.dumps(dict(items), ensure_ascii=False))
    except OSError:
        pass


def _rule_category(mail: dict) -> str:
    if mail["automated"]:
        return "werbung" if re.search(r"newsletter|angebot|rabatt|sale|deal|promo|%", mail["subject"], re.I) else "info"
    if mail["known"] or mail["flagged"]:
        return "wichtig"
    return "normal"


def _ask_claude(mails: list[dict]) -> dict:
    """Ordnet neue Mails mit dem schnellen Modell ein: Kategorie und eine kurze Zusammenfassung."""
    if not settings.anthropic_api_key or not mails:
        return {}
    listing = "\n".join(
        f'{i}. Von: {m["name"]} <{m["address"]}>{" (Kontakt)" if m["known"] else ""} | Betreff: {m["subject"]} | '
        f'Anfang: {m["preview"][:220]}' for i, m in enumerate(mails))
    prompt = (
        "Ordne diese Mails fuer Lukas ein. Kategorien: wichtig (ein Mensch will etwas von ihm, Frist, Termin, "
        "Rechnung oder Zahlung, Behoerde, Arbeit, Sicherheit), info (Versand, Bestaetigung, Konto-Hinweis), "
        "werbung (Newsletter, Angebote, Werbung, Social Media). Schreibe je Mail eine Zusammenfassung auf "
        "Deutsch in hoechstens 12 Woertern, ohne Codes, Passwoerter oder Kontonummern. Antworte nur mit JSON: "
        '[{"nr": 0, "kategorie": "wichtig", "zusammenfassung": "..."}]\n\n' + listing)
    client = anthropic.Anthropic(api_key=settings.anthropic_api_key)
    for model in [m for m in (settings.fast_model, settings.claude_model) if m]:
        try:
            resp = client.messages.create(model=model, max_tokens=2000,
                                          messages=[{"role": "user", "content": prompt}])
        except anthropic.NotFoundError:
            continue
        except anthropic.APIError as exc:
            print(f"Mail-Einordnung fehlgeschlagen: {exc!r}", flush=True)
            return {}
        text = "".join(b.text for b in resp.content if b.type == "text")
        match = re.search(r"\[.*\]", text, re.S)
        try:
            rows = json.loads(match.group(0)) if match else []
        except ValueError:
            rows = []
        out = {}
        for row in rows:
            try:
                mail = mails[int(row["nr"])]
            except (KeyError, ValueError, IndexError, TypeError):
                continue
            cat = str(row.get("kategorie", "")).lower()
            out[mail["id"]] = {"cat": cat if cat in ("wichtig", "info", "werbung") else "info",
                               "sum": str(row.get("zusammenfassung", ""))[:140], "t": time.time(),
                               "pre": mail["preview"][:220]}
        return out
    return {}


def classify(mails: list[dict], ask: bool = True) -> list[dict]:
    prios = load_priorities()
    with _lock:
        cache = _load_cache()
        new = [m for m in mails if m["id"] not in cache] if ask else []
        for start in range(0, len(new), 25):
            cache.update(_ask_claude(new[start:start + 25]))
        if new:
            _save_cache(cache)
    for m in mails:
        known = cache.get(m["id"], {})
        m["summary"] = known.get("sum") or m["preview"][:120]
        if any(_matches(e, m) for e in prios["ausblenden"]):
            m["category"], m["reason"] = "werbung", "ausgeblendet"
        elif any(_matches(e, m) for e in prios["wichtig_absender"]):
            m["category"], m["reason"] = "wichtig", "deine Priorität"
        elif any(w.lower() in (m["subject"] + " " + m["preview"]).lower() for w in prios["wichtig_woerter"]):
            m["category"], m["reason"] = "wichtig", "Stichwort"
        else:
            m["category"] = known.get("cat") or _rule_category(m)
            m["reason"] = "markiert" if m["flagged"] else ("Kontakt" if m["known"] else "")
    return mails


# ---------------------------------------------------------------- Kalender und Woche

def _merge_busy(events: list[dict], day: datetime) -> float:
    """Verplante Stunden an einem Tag zwischen WORK_START und WORK_END (Ueberschneidungen nur einmal)."""
    lo, hi = day.replace(hour=WORK_START), day.replace(hour=WORK_END)
    spans = sorted((max(e["start"], lo), min(e["end"], hi)) for e in events
                   if not e["all_day"] and e["end"] > lo and e["start"] < hi)
    total, cur_s, cur_e = 0.0, None, None
    for s, e in spans:
        if cur_e is None or s > cur_e:
            if cur_e is not None:
                total += (cur_e - cur_s).total_seconds()
            cur_s, cur_e = s, e
        else:
            cur_e = max(cur_e, e)
    if cur_e is not None:
        total += (cur_e - cur_s).total_seconds()
    return total / 3600


def week_load(events: list[dict], now: datetime) -> dict:
    monday = (now - timedelta(days=now.weekday())).replace(hour=0, minute=0, second=0, microsecond=0)
    window = WORK_END - WORK_START
    days, workday_hours = [], 0.0
    for i in range(7):
        day = monday + timedelta(days=i)
        hours = _merge_busy(events, day)
        if i < 5:
            workday_hours += hours
        days.append({"label": DAY_SHORT[i], "date": day.strftime("%d.%m."), "hours": round(hours, 1),
                     "percent": round(100 * hours / window), "today": day.date() == now.date(),
                     "count": sum(1 for e in events if e["start"].date() == day.date())})
    return {"percent": round(100 * workday_hours / (5 * window)), "hours": round(workday_hours, 1),
            "kw": now.isocalendar()[1], "window": f"Mo–Fr, {WORK_START}–{WORK_END} Uhr", "days": days}


def _day_label(day: datetime, now: datetime) -> str:
    diff = (day.date() - now.date()).days
    name = {0: "Heute", 1: "Morgen"}.get(diff, alltag.WEEKDAYS[day.weekday()])
    return f"{name}, {day.strftime('%d.%m.')}"


def _agenda(events: list[dict], now: datetime, days: int = 5) -> list[dict]:
    today = now.replace(hour=0, minute=0, second=0, microsecond=0)
    out = []
    for i in range(days):
        day = today + timedelta(days=i)
        items = []
        for e in events:
            if not (e["start"] < day + timedelta(days=1) and e["end"] > day):
                continue
            items.append({
                "time": "ganztägig" if e["all_day"] else e["start"].strftime("%H:%M"),
                "end": "" if e["all_day"] else e["end"].strftime("%H:%M"),
                "title": e["title"], "location": e["location"], "calendar": e["calendar"],
                "color": e.get("color", ""), "past": (not e["all_day"]) and e["end"] < now,
                "now": (not e["all_day"]) and e["start"] <= now < e["end"],
            })
        out.append({"label": _day_label(day, now), "items": items})
    return out


# ---------------------------------------------------------------- alles zusammen

def _mail_json(m: dict, now: datetime) -> dict:
    return {"id": m["id"], "name": m["name"], "address": m["address"], "subject": m["subject"],
            "summary": m["summary"], "when": alltag._fmt_time(m["received"], now), "read": m["read"],
            "flagged": m["flagged"], "reason": m["reason"], "category": m["category"]}


# Die drei Teile laden getrennt im Hintergrund. Haengt einer (z. B. weil macOS noch auf eine
# Erlaubnis wartet), zeigen die anderen trotzdem ihren Stand.

PREVIEWS_PER_RUN = 12  # so viele Mailtexte holen wir pro Durchlauf fuer die Kurzfassung


def _mail_summary(mails: list[dict], now: datetime, ask: bool) -> dict:
    classify(mails, ask=ask)
    important = [m for m in mails if m["category"] == "wichtig"]
    important.sort(key=lambda m: (m["read"], -m["received"].timestamp()))
    return {"mails": {
        "important": [_mail_json(m, now) for m in important[:12]],
        "unread": sum(1 for m in mails if not m["read"]),
        "unread_important": sum(1 for m in important if not m["read"]),
        "info": sum(1 for m in mails if m["category"] in ("info", "normal") and not m["read"]),
        "ads": sum(1 for m in mails if m["category"] == "werbung"),
        "total": len(mails),
    }}


class Hint(Exception):
    """Fehler mit eigenem Hinweistext und passender Einstellung fuers Dashboard."""
    def __init__(self, text: str, pane: str | None = None):
        super().__init__(text)
        self.pane = pane


MAIL_FDA_TEXT = ("Die Mail-App antwortet zu langsam. Viel schneller geht es, wenn Jarvis Mails Verzeichnis direkt "
                 "lesen darf: Datenschutz & Sicherheit → Festplattenvollzugriff → Terminal einschalten, dann Jarvis neu starten.")


# Beim Start gemerkt: so nutzt das Dashboard immer die Mail-Abfrage aus dem Kern,
# auch wenn eine selbst gebaute Reparatur in eigene/ sie spaeter ersetzt.
_fetch_mail_headers = alltag.fetch_mail_headers


def _mails_section(publish) -> dict:
    now = datetime.now()
    try:
        mails = _fetch_mail_headers(days=3, limit=80)
    except RuntimeError as exc:
        if not alltag.mail_db_readable():
            raise Hint(f"Mail: {MAIL_FDA_TEXT}", "Privacy_AllFiles") from exc
        raise
    cache = _load_cache()
    for m in mails:
        m["preview"] = cache.get(m["id"], {}).get("pre", "") or m.get("preview", "")
    # 1. Sofort zeigen: gemerkte Einordnung, neue Mails vorerst nach einfachen Regeln
    publish(_mail_summary(mails, now, ask=False))
    # 2. Fuer neue Mails von Menschen den Textanfang holen, dann von Claude einordnen lassen
    # (aus Mails Datenbank kommt die Vorschau schon mit, dann muss die Mail-App nicht gefragt werden)
    fresh = [m for m in mails if m["id"] not in cache and not m["automated"] and not m["preview"]][:PREVIEWS_PER_RUN]
    for m in fresh:
        try:
            m["preview"] = alltag.fetch_mail_preview(m["id"])
        except Exception:
            pass
    return _mail_summary(mails, now, ask=True)


def _calendar_section(publish) -> dict:
    now = datetime.now()
    monday = (now - timedelta(days=now.weekday())).replace(hour=0, minute=0, second=0, microsecond=0)
    today = now.replace(hour=0, minute=0, second=0, microsecond=0)
    events = alltag.fetch_events_between(min(monday, today), max(monday + timedelta(days=7), today + timedelta(days=5)))
    return {"agenda": _agenda(events, now), "week": week_load(events, now)}


def _reminders_section(publish) -> dict:
    now = datetime.now()
    today = now.replace(hour=0, minute=0, second=0, microsecond=0)
    return {"reminders": [
        {"title": r["title"], "overdue": bool(r["due"] and r["due"] < (now if r["has_time"] else today)),
         "time": r["due"].strftime("%H:%M") if r["due"] and r["has_time"] else ""}
        for r in alltag.fetch_reminders(today + timedelta(days=1))][:10]}


SECTIONS = {
    "mails": (_mails_section, 120, "Mail", "Privacy_Automation",
              "Erlaubnis fehlt (Datenschutz & Sicherheit → Automation → Terminal → Mail)."),
    "calendar": (_calendar_section, 300, "Kalender", "Privacy_Calendars",
                 "Erlaubnis fehlt (Datenschutz & Sicherheit → Kalender → Terminal: Vollzugriff)."),
    "reminders": (_reminders_section, 300, "Erinnerungen", "Privacy_Reminders",
                  "Erlaubnis fehlt (Datenschutz & Sicherheit → Erinnerungen → Terminal)."),
}
SLOW_AFTER = 20  # Sekunden; danach erklaert das Dashboard, worauf es wartet

_sections = {name: {"at": 0.0, "data": None, "hint": None, "running": False, "started": 0.0} for name in SECTIONS}
_state_lock = threading.Lock()


def _run_section(name: str):
    fn, _, label, pane, perm_text = SECTIONS[name]
    st = _sections[name]
    t0 = time.time()

    def publish(partial: dict):
        with _state_lock:
            st["data"] = partial

    hint = None
    try:
        data = fn(publish)
    except alltag.PermissionMissing:
        data, hint = None, {"text": f"{label}: {perm_text}", "pane": pane}
    except Hint as exc:
        data, hint = None, {"text": str(exc), "pane": exc.pane}
    except ImportError:
        data, hint = None, {"text": f"{label}: Baustein fehlt. Jarvis einmal neu installieren."}
    except Exception as exc:
        data, hint = None, {"text": f"{label} nicht erreichbar: {exc}"}
    with _state_lock:
        if data is not None:
            st["data"] = data
        st.update(hint=hint, at=time.time(), running=False)
    print(f"Dashboard {label}: {time.time() - t0:.1f} s" + (f" – {hint['text']}" if hint else ""), flush=True)


def _start_stale(force: bool):
    now = time.time()
    with _state_lock:
        for name, (_, max_age, *_rest) in SECTIONS.items():
            st = _sections[name]
            if st["running"] or (not force and st["at"] and now - st["at"] < max_age):
                continue
            st.update(running=True, started=now)
            threading.Thread(target=_run_section, args=(name,), daemon=True, name=f"dashboard-{name}").start()


def _assemble() -> dict:
    now = time.time()
    data = {"updated": datetime.now().strftime("%H:%M"), "hints": [], "loading": [], "waiting": []}
    with _state_lock:
        for name, (_, _, label, _, _) in SECTIONS.items():
            st = _sections[name]
            if st["data"]:
                data.update(st["data"])
            if st["hint"]:
                data["hints"].append(st["hint"])
            if st["running"]:
                data["loading"].append(name)
                if now - st["started"] > SLOW_AFTER:
                    data["waiting"].append(label)
    if data["waiting"]:
        data["hints"].append({"text": f"{' und '.join(data['waiting'])} antwortet noch. Wartet vielleicht ein "
                                      "Erlaubnis-Fenster von macOS hinter anderen Fenstern? Dann dort „Erlauben“ klicken."})
    return data


def get(force: bool = False, wait: float = 1.5) -> dict:
    """Startet veraltete Teile im Hintergrund und liefert nach hoechstens `wait` Sekunden den aktuellen Stand."""
    _start_stale(force)
    end = time.time() + wait
    while time.time() < end:
        with _state_lock:
            if not any(st["running"] for st in _sections.values()):
                break
        time.sleep(0.1)
    return _assemble()


def describe_week() -> str:
    """Fuer Jarvis: Wochenauslastung in einem Satz."""
    data = get(wait=60)
    week = data.get("week")
    if not week:
        return "Den Kalender kann ich gerade nicht lesen."
    busy = ", ".join(f"{d['label']} {d['percent']} %" for d in week["days"] if d["percent"])
    return (f"Kalenderwoche {week['kw']}: {week['percent']} Prozent verplant ({week['hours']} Stunden, "
            f"{week['window']}). " + (f"Pro Tag: {busy}." if busy else "Keine festen Termine."))
