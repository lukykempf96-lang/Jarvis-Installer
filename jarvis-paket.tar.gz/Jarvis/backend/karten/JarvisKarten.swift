// Fahrzeit ueber Apple Karten (MapKit), ohne Konto und ohne Schluessel.
// Aufruf: JarvisKarten START ZIEL [auto|zu_fuss|oepnv]
// Ausgabe: eine Zeile JSON, z. B. {"ok":true,"from":"...","to":"...","seconds":2280,"meters":42000,"arrival":1790000000,"via":"A3"}
// install.sh uebersetzt diese Datei einmal mit swiftc (Xcode-Befehlszeilentools).

import Foundation
import MapKit

func finish(_ result: [String: Any], _ code: Int32 = 0) -> Never {
    if let data = try? JSONSerialization.data(withJSONObject: result),
       let text = String(data: data, encoding: .utf8) {
        print(text)
    }
    fflush(stdout)
    exit(code)
}

let args = CommandLine.arguments
if args.count < 3 {
    finish(["ok": false, "error": "Aufruf: JarvisKarten START ZIEL [auto|zu_fuss|oepnv]"], 2)
}
let mode = args.count > 3 ? args[3] : "auto"

// Nie haengen bleiben, Jarvis wartet auf die Antwort
DispatchQueue.main.asyncAfter(deadline: .now() + 25) {
    finish(["ok": false, "error": "Apple Karten antwortet nicht"], 3)
}

func search(_ query: String, near: CLLocationCoordinate2D?, _ done: @escaping (MKMapItem) -> Void) {
    let request = MKLocalSearch.Request()
    request.naturalLanguageQuery = query
    if let near = near {
        // Ziel bevorzugt in der Naehe des Starts suchen ("Bahnhof" soll nicht in Hamburg landen)
        request.region = MKCoordinateRegion(center: near, latitudinalMeters: 300_000, longitudinalMeters: 300_000)
    }
    MKLocalSearch(request: request).start { response, error in
        guard let item = response?.mapItems.first else {
            finish(["ok": false, "error": "Ort nicht gefunden: \(query)", "detail": error?.localizedDescription ?? ""], 1)
        }
        done(item)
    }
}

func label(_ item: MKMapItem) -> String {
    var parts: [String] = []
    for part in [item.name, item.placemark.locality] {
        if let part = part, !part.isEmpty, !parts.contains(part) {
            parts.append(part)
        }
    }
    return parts.joined(separator: ", ")
}

search(args[1], near: nil) { from in
    search(args[2], near: from.placemark.coordinate) { to in
        let request = MKDirections.Request()
        request.source = from
        request.destination = to
        request.departureDate = Date()
        switch mode {
        case "zu_fuss": request.transportType = .walking
        case "oepnv": request.transportType = .transit
        default: request.transportType = .automobile
        }
        // Ankunftszeit fuer "jetzt losfahren", so wie Apple Karten sie gerade schaetzt
        MKDirections(request: request).calculateETA { eta, error in
            guard let eta = eta else {
                finish(["ok": false, "error": "Keine Route gefunden", "detail": error?.localizedDescription ?? ""], 1)
            }
            let base: [String: Any] = [
                "ok": true,
                "from": label(from),
                "to": label(to),
                "seconds": Int(eta.expectedTravelTime),
                "meters": Int(eta.distance),
                "arrival": Int(eta.expectedArrivalDate.timeIntervalSince1970),
            ]
            if mode == "oepnv" {
                finish(base)
            }
            // Name der Strecke (z. B. "A3") fuer die Ansage; klappt das nicht, reicht die Fahrzeit
            MKDirections(request: request).calculate { response, _ in
                var result = base
                if let route = response?.routes.first, !route.name.isEmpty {
                    result["via"] = route.name
                }
                finish(result)
            }
        }
    }
}

dispatchMain()
