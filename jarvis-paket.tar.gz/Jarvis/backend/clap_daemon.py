from __future__ import annotations

import fcntl
import os
import queue
import subprocess
import sys
import threading
import time
from collections import deque
from pathlib import Path

import httpx
import numpy as np
import sounddevice as sd

from .config import settings

SAMPLE_RATE = 16000
BLOCK_SIZE = int(SAMPLE_RATE * 0.02)

THRESHOLD = 0.35
# Ein Klatschen ist ein kurzer Knall aus der Stille. Sprache und Musik sind dauerhaft laut:
# Ist es im letzten halben Sekunde schon so laut (Median), zaehlt der Ausschlag nicht.
BACKGROUND_MAX = 0.08
BACKGROUND_BLOCKS = 25  # 25 x 20 ms = 0,5 s
REFRACTORY_SECONDS = 0.25
DOUBLE_CLAP_WINDOW = (0.12, 0.6)
# Sprachstart: "Hey Jarvis" (englisch ausgesprochen, "Hey Dschar-wis"), Modell von openWakeWord
WAKEWORD = "hey_jarvis"
WAKEWORD_THRESHOLD = 0.5  # hoeher = weniger Fehlausloeser, niedriger = reagiert leichter
WAKEWORD_FRAME = 1280  # 80 ms bei 16 kHz, so erwartet es das Modell
WAKEWORD_COOLDOWN = 3.0
BASE_URL = f"http://localhost:{settings.port}"
PROJECT_DIR = Path(__file__).resolve().parent.parent
LOCK_FILE = PROJECT_DIR / ".jarvis-laeuft.lock"

_clap_times: deque[float] = deque(maxlen=2)
_max_peak = 0.0  # lautester Wert seit Start, um Stille (fehlende Mikrofon-Freigabe) zu erkennen
_last_print = [0.0]
_recent_peaks: deque[float] = deque(maxlen=BACKGROUND_BLOCKS)
_audio_queue: queue.Queue | None = None  # nur gesetzt, wenn der Sprachstart verfuegbar ist


def _server_running() -> bool:
    try:
        return httpx.get(f"{BASE_URL}/api/health", timeout=1).status_code == 200
    except httpx.HTTPError:
        return False


def _ensure_server():
    """Startet den Jarvis-Server, falls er noch nicht laeuft."""
    if _server_running():
        return
    print("Starte Jarvis-Server ...")
    log = open(PROJECT_DIR / "jarvis-server.log", "a")
    subprocess.Popen(
        [sys.executable, "-m", "uvicorn", "backend.main:app", "--host", settings.host, "--port", str(settings.port)],
        cwd=PROJECT_DIR, stdout=log, stderr=log,
        env={**os.environ, "PYTHONUNBUFFERED": "1"},  # Meldungen sofort ins Log schreiben
    )
    for _ in range(40):
        if _server_running():
            return
        time.sleep(0.5)
    print("Server startet nicht, siehe jarvis-server.log")


def _notify_backend(source: str = "clap"):
    _ensure_server()
    try:
        result = httpx.post(f"{BASE_URL}/api/clap", params={"source": source}, timeout=5).json()
        if result.get("action") == "ignored":
            print("Ignoriert: Jarvis spricht oder hoert gerade zu.")
        elif result.get("action") == "stopped":
            print("Jarvis unterbrochen, er hoert jetzt zu.")
        else:
            print(f"Jarvis: {result.get('action')}")
    except httpx.HTTPError as exc:
        print(f"Konnte Jarvis nicht benachrichtigen: {exc}")


def _register_clap(now: float):
    _clap_times.append(now)
    if len(_clap_times) == 2:
        gap = _clap_times[1] - _clap_times[0]
        if DOUBLE_CLAP_WINDOW[0] <= gap <= DOUBLE_CLAP_WINDOW[1]:
            _clap_times.clear()
            print("Doppelklatschen erkannt -> Jarvis wird aktiviert")
            threading.Thread(target=_notify_backend, daemon=True).start()


def _load_wakeword_model():
    """Laedt das "Hey Jarvis"-Modell. Fehlt etwas, laeuft Jarvis nur mit Klatschen weiter."""
    try:
        import openwakeword
        import openwakeword.utils
        from openwakeword.model import Model
    except ImportError:
        print("Sprachstart nicht verfuegbar (Paket openwakeword fehlt). Klatschen funktioniert trotzdem.")
        return None
    models_dir = Path(openwakeword.__file__).parent / "resources" / "models"
    if not list(models_dir.glob(f"{WAKEWORD}*.onnx")):
        print("Lade Sprachmodell fuer \"Hey Jarvis\" ...")
        try:
            openwakeword.utils.download_models([WAKEWORD])
        except Exception as exc:
            print(f"Sprachmodell konnte nicht geladen werden ({exc}). Klatschen funktioniert trotzdem.")
            return None
    try:
        return Model(wakeword_models=[WAKEWORD], inference_framework="onnx")
    except Exception as exc:  # z. B. defektes Modell: dann eben nur Klatschen
        print(f"Sprachstart konnte nicht starten ({exc}). Klatschen funktioniert trotzdem.")
        return None


def _wakeword_worker(model):
    """Wertet das Mikrofon in 80-ms-Stuecken auf "Hey Jarvis" aus (eigener Thread, nicht im Audio-Callback)."""
    buffer = np.zeros(0, dtype=np.int16)
    last_trigger = 0.0
    while True:
        block = _audio_queue.get()
        buffer = np.concatenate([buffer, (np.clip(block, -1, 1) * 32767).astype(np.int16)])
        while len(buffer) >= WAKEWORD_FRAME:
            frame, buffer = buffer[:WAKEWORD_FRAME], buffer[WAKEWORD_FRAME:]
            score = model.predict(frame)[WAKEWORD]
            if score >= WAKEWORD_THRESHOLD and time.monotonic() - last_trigger > WAKEWORD_COOLDOWN:
                last_trigger = time.monotonic()
                model.reset()
                print(f"\"Hey Jarvis\" erkannt ({score:.2f}) -> Jarvis wird aktiviert")
                threading.Thread(target=_notify_backend, args=("wake",), daemon=True).start()


def _callback(indata, frames, time_info, status):
    global _max_peak
    if _audio_queue is not None:
        _audio_queue.put(indata[:, 0].copy())
    peak = float(np.max(np.abs(indata)))
    _max_peak = max(_max_peak, peak)
    background = float(np.median(_recent_peaks)) if len(_recent_peaks) >= 5 else 0.0
    _recent_peaks.append(peak)
    if peak > THRESHOLD / 2 and time.monotonic() - _last_print[0] > 0.5:
        _last_print[0] = time.monotonic()
        print(f"  Geraeusch: {peak:.2f}, Hintergrund {background:.2f} (Klatschen ab {THRESHOLD}, Hintergrund max {BACKGROUND_MAX})")
    if peak > THRESHOLD and background < BACKGROUND_MAX:
        now = time.monotonic()
        if not _clap_times or now - _clap_times[-1] > REFRACTORY_SECONDS:
            _register_clap(now)


def _only_instance():
    """Laeuft Jarvis schon (z. B. Jarvis.command doppelt geoeffnet)? Dann None, sonst die gehaltene Sperre.

    Zwei Mithoerer wuerden jedes Klatschen und jedes "Hey Jarvis" doppelt melden. Die Sperre gibt macOS
    automatisch frei, wenn das Fenster geschlossen wird oder Jarvis abstuerzt.
    """
    handle = open(LOCK_FILE, "a+")
    try:
        fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        handle.close()
        return None
    handle.seek(0)
    handle.truncate()
    handle.write(str(os.getpid()))
    handle.flush()
    return handle


def main():
    global _audio_queue
    lock = _only_instance()
    if lock is None:
        print("Jarvis laeuft schon in einem anderen Terminal-Fenster. Ich hole sein Fenster nach vorne.")
        print("Dieses Fenster kannst du schliessen.")
        try:
            httpx.post(f"{BASE_URL}/api/show", timeout=5)
        except httpx.HTTPError:
            pass
        return
    _ensure_server()
    model = _load_wakeword_model()
    if model is not None:
        _audio_queue = queue.Queue()
        threading.Thread(target=_wakeword_worker, args=(model,), daemon=True).start()
        print("Sprachstart aktiv: Sag \"Hey Jarvis\" (englisch: \"Hey Dschar-wis\").")
    print("Hoere auf Doppelklatschen... (Strg+C zum Beenden)")
    print(f"Schwellenwert: {THRESHOLD} — bei zu vielen Fehlauslösern in clap_daemon.py erhoehen, "
          "bei zu wenig Reaktion senken.")
    print(f"Mikrofon: {sd.query_devices(kind='input')['name']}")
    with sd.InputStream(
        channels=1,
        samplerate=SAMPLE_RATE,
        blocksize=BLOCK_SIZE,
        callback=_callback,
    ):
        time.sleep(3)
        if _max_peak == 0.0:
            print("\nACHTUNG: Das Mikrofon liefert nur Stille. Bitte unter Systemeinstellungen > "
                  "Datenschutz & Sicherheit > Mikrofon das Terminal erlauben und Jarvis neu starten.\n")
        while True:
            time.sleep(0.1)


if __name__ == "__main__":
    main()
